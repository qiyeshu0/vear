const testIndexUrl = process.env.NODE_ENV !== "production"
  ? String(process.env.UPDATE_TEST_INDEX_URL || "").trim()
  : "";

const officialSources = testIndexUrl
  ? [{
      key: "official",
      label: "本地测试更新源",
      indexUrl: testIndexUrl,
      signatureUrl: String(process.env.UPDATE_TEST_SIGNATURE_URL || `${testIndexUrl}.sig`).trim()
    }]
  : [
      {
        key: "github",
        label: "主线路 · GitHub",
        indexUrl: "https://git.722331.xyz/https://raw.githubusercontent.com/qiyeshu0/vear/refs/heads/main/latest.json",
        signatureUrl: "https://git.722331.xyz/https://raw.githubusercontent.com/qiyeshu0/vear/refs/heads/main/latest.json.sig"
      },
      {
        key: "gitee",
        label: "备用一 · Gitee",
        indexUrl: "https://gitee.com/aesculus-aesculus/vear/raw/master/latest.json",
        signatureUrl: "https://gitee.com/aesculus-aesculus/vear/raw/master/latest.json.sig"
      },
      {
        key: "official",
        label: "备用二 · 官方更新源",
        indexUrl: "https://api.llqxs.cn/updates/stable/latest.json",
        signatureUrl: "https://api.llqxs.cn/updates/stable/latest.json.sig"
      }
    ];

module.exports = Object.freeze({
  indexFormat: "vear-update-index-v2",
  packageFormat: "vear-incremental-update-v2",
  officialSources: Object.freeze(officialSources.map(source => Object.freeze(source))),
  publicKey: `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAOCx774bZbclFKhD9gVbmJ0QJWMpAoG1NN43u+Dc9Bb0=
-----END PUBLIC KEY-----`
});
