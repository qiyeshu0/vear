const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const controller = require("../controllers/lens.controller");

const router = express.Router();
router.use(auth());
router.get("/options", requireUserPermission("customer:glasses"), controller.getOptions);
router.get("/", requireUserPermission("lens:view"), controller.getList);
router.post("/", requireUserPermission("lens:create"), controller.create);
router.put("/:id", requireUserPermission("lens:update"), controller.update);
router.patch("/:id/status", requireUserPermission("lens:status"), controller.updateStatus);
router.post("/:id/copy", requireUserPermission("lens:create"), controller.copyToStore);
router.delete("/:id", requireUserPermission("lens:delete"), controller.remove);

module.exports = router;
