/**
 * 微信小程序后端 API
 * 为客户家长提供：登录、查看孩子档案、核销记录、检查记录
 */

const express = require("express");
const { pool } = require("../config/db");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { toCamelCase } = require("../utils/case");
const { normalizePage } = require("../utils/pagination");
const { createTables } = require("../install/schema");
const { getCustomerCardsMap } = require("../utils/customer-card");
const { getWechatRuntimeConfig, getMiniprogramRuntimeConfig } = require("../utils/runtime-config");
const { normalizeGlassesStatus, getGlassesStatusLabel, formatGlassesRecord } = require("../services/customer.service");
const wechatService = require("../services/wechat.service");
const { getVersionInfo } = require("../services/system-update.service");

const router = express.Router();
let schemaPromise = null;

function ensureSchema() {
  if (!schemaPromise) {
    schemaPromise = createTables(pool).catch((error) => {
      schemaPromise = null;
      throw error;
    });
  }
  return schemaPromise;
}

function getCustomerJwtSecret() {
  return process.env.JWT_SECRET || "wx-mini-program";
}

function buildCustomerPayload(row = {}) {
  return {
    id: Number(row.id),
    customerNo: row.customer_no,
    childName: row.child_name || "",
    parentPhone: row.parent_phone || "",
    hasCard: Number(row.has_card || 0) === 1,
    trainingProject: row.training_project || "",
    totalTimes: Number(row.total_times || 0),
    usedTimes: Number(row.used_times || 0),
    remainingTimes: row.remaining_times == null
      ? Number(row.total_times || 0) - Number(row.used_times || 0)
      : Number(row.remaining_times || 0),
    expireDate: row.expire_date || null,
    status: Number(row.status || 0),
  };
}

function signCustomerToken(customer = {}, openid = "") {
  const jwt = require("jsonwebtoken");
  return jwt.sign({
    customerId: Number(customer.id),
    childName: customer.child_name,
    parentPhone: customer.parent_phone,
    storeId: Number(customer.store_id || 0),
    openid: openid || undefined,
    type: "customer",
  }, getCustomerJwtSecret(), { expiresIn: "30d" });
}

async function listBoundAccountsByOpenid(openid) {
  const [rows] = await pool.query(
    `SELECT c.id, c.customer_no, c.child_name, c.parent_phone,
      c.store_id, c.has_card, c.training_project, c.total_times, c.used_times,
      c.remaining_times, c.open_card_date, c.expire_date, c.status
    FROM wx_user_bindings b
    INNER JOIN customers c ON c.id = b.customer_id AND c.status = 1
    WHERE b.wx_openid = ?
    ORDER BY b.created_at ASC, c.id ASC`,
    [openid],
  );
  return rows.map(buildCustomerPayload);
}

// ═══════════════════════════════════════════════════════
// 0. 小程序公开配置
//    注意：这里只返回非敏感配置，AppSecret 等敏感信息绝不下发给小程序。
// ═══════════════════════════════════════════════════════
router.get("/config", async (_req, res, next) => {
  try {
    const [wechatCfg, miniCfg] = await Promise.all([
      getWechatRuntimeConfig(),
      getMiniprogramRuntimeConfig(),
    ]);
    const notificationTemplates = {
      verify_success: wechatCfg.subscribeTemplateId || process.env.WX_SUBSCRIBE_TEMPLATE_ID || "",
      glasses_status: wechatCfg.glassesTemplateId || process.env.WX_GLASSES_TEMPLATE_ID || "",
      card_low_times: wechatCfg.lowTimesTemplateId || process.env.WX_LOW_TIMES_TEMPLATE_ID || "",
      card_expire_soon: wechatCfg.expireSoonTemplateId || process.env.WX_EXPIRE_SOON_TEMPLATE_ID || "",
      followup: wechatCfg.followupTemplateId || process.env.WX_FOLLOWUP_TEMPLATE_ID || "",
      glasses_delivered_followup: wechatCfg.followupTemplateId || process.env.WX_FOLLOWUP_TEMPLATE_ID || "",
    };
    const versionInfo = getVersionInfo();
    return sendSuccess(res, {
      system: {
        name: miniCfg.title,
        subtitle: miniCfg.subtitle,
      },
      features: {
        enableStaffHiddenEntry: miniCfg.enableStaffHiddenEntry,
        showGlassesProgress: miniCfg.showGlassesProgress,
        showTrainingCard: miniCfg.showTrainingCard,
      },
      home: {
        glassesKeepDaysAfterDelivered: miniCfg.homeGlassesKeepDays,
        recentVerifyLimit: miniCfg.homeRecentVerifyLimit,
        glassesLimit: miniCfg.homeGlassesLimit,
      },
      notificationTemplates,
      version: {
        systemVersion: versionInfo.systemVersion,
        recommendedMiniprogramVersion: versionInfo.miniprogramVersion,
        minSupportedMiniprogramVersion: versionInfo.miniprogramMinimumVersion,
        maxSupportedMiniprogramVersion: versionInfo.miniprogramMaximumVersion
      },
      // 兼容旧小程序字段，后续可删除
      subscribeTmplId: notificationTemplates.verify_success,
      glassesSubscribeTmplId: notificationTemplates.glasses_status,
    }, "获取小程序配置成功");
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 1a. 静默登录（返回已绑定的所有账号列表）
// ═══════════════════════════════════════════════════════
router.post("/silent-login", async (req, res, next) => {
  try {
    await ensureSchema();
    const { code } = req.body;
    if (!code) return sendFail(res, "缺少 code", 400);

    let openid;
    try {
      const session = await wechatService.code2session(code);
      openid = session.openid;
    } catch (e) {
      return sendFail(res, "微信登录失败: " + e.message, 400);
    }
    if (!openid) return sendFail(res, "获取 openid 失败", 400);

    // 查所有绑定关系
    const [bindings] = await pool.query(
      `SELECT b.customer_id, c.id, c.customer_no, c.child_name, c.parent_phone,
        c.store_id, c.has_card, c.training_project, c.total_times, c.used_times,
        c.remaining_times, c.open_card_date, c.expire_date, c.status
      FROM wx_user_bindings b
      INNER JOIN customers c ON c.id = b.customer_id AND c.status = 1
      WHERE b.wx_openid = ?
      ORDER BY b.created_at ASC`,
      [openid],
    );

    if (!bindings.length) {
      return sendSuccess(res, { needBind: true, accounts: [] }, "未绑定");
    }

    var accounts = bindings.map(function(row) {
      return {
        id: Number(row.id), customerNo: row.customer_no,
        childName: row.child_name || "", parentPhone: row.parent_phone || "",
        hasCard: Number(row.has_card || 0) === 1,
        trainingProject: row.training_project || "",
        totalTimes: Number(row.total_times || 0),
        usedTimes: Number(row.used_times || 0),
        remainingTimes: row.remaining_times == null
          ? Number(row.total_times || 0) - Number(row.used_times || 0)
          : Number(row.remaining_times || 0),
        expireDate: row.expire_date || null,
        status: Number(row.status || 0),
      };
    });

    return sendSuccess(res, {
      needBind: false,
      accounts: accounts,
      count: accounts.length,
      maxBindings: 5,
    }, "获取成功");
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 1b. 手机绑定（绑定 openid → 自动建档/登录）
// ═══════════════════════════════════════════════════════
router.post("/bind-phone", async (req, res, next) => {
  try {
    await ensureSchema();
    const { code, phone } = req.body;
    if (!code || !phone) return sendFail(res, "缺少参数", 400);

    // 验证手机号格式
    if (!/^1[3-9]\d{9}$/.test(phone)) return sendFail(res, "手机号格式不正确", 400);

    // code → openid
    let openid;
    try {
      const session = await wechatService.code2session(code);
      openid = session.openid;
    } catch (e) {
      return sendFail(res, "微信登录失败: " + e.message, 400);
    }

    // 按手机号查客户：同一手机号可能对应多个孩子
    const [customers] = await pool.query(
      `SELECT id, customer_no, child_name, parent_phone, store_id, has_card,
        training_project, total_times, used_times, remaining_times,
        open_card_date, expire_date, status
      FROM customers
      WHERE status = 1
        AND (
          parent_phone = ?
          OR id IN (
            SELECT customer_id FROM customer_phones
            WHERE phone = ? AND status = 1
          )
        )
      ORDER BY id ASC`,
      [phone, phone],
    );
    if (!customers.length) {
      return sendFail(res, "该手机号未在门店登记，请联系门店先建立档案", 400, { errorCode: "PHONE_NOT_FOUND" });
    }

    // 检查绑定数量（最多5个）
    const [[{ cnt }]] = await pool.query(
      "SELECT COUNT(*) AS cnt FROM wx_user_bindings WHERE wx_openid = ?", [openid],
    );
    const [existingRows] = await pool.query(
      "SELECT customer_id FROM wx_user_bindings WHERE wx_openid = ?",
      [openid],
    );
    const existingIds = new Set(existingRows.map((row) => Number(row.customer_id)));
    const newCustomers = customers.filter((customer) => !existingIds.has(Number(customer.id)));

    if (Number(cnt) + newCustomers.length > 5) {
      return sendFail(res, "绑定账号已达上限（5个），请先解绑其他账号", 400, { errorCode: "BINDING_LIMIT" });
    }

    for (const customer of newCustomers) {
      await pool.execute(
        "INSERT IGNORE INTO wx_user_bindings (wx_openid, customer_id) VALUES (?, ?)",
        [openid, customer.id],
      );

      // 兼容旧字段；真正的多账号关系以 wx_user_bindings 为准
      await pool.execute("UPDATE customers SET wx_openid = ? WHERE id = ?", [openid, customer.id]);
    }

    const selectedCustomer = customers[0];
    const token = signCustomerToken(selectedCustomer, openid);
    const accounts = await listBoundAccountsByOpenid(openid);

    return sendSuccess(res, {
      accessToken: token,
      customer: buildCustomerPayload(selectedCustomer),
      accounts,
      count: accounts.length,
      maxBindings: 5,
    }, accounts.length > 1 ? "绑定成功，已关联多个孩子" : "绑定成功");
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 1c. 选账号登录（从已绑列表中选一个，生成JWT）
// ═══════════════════════════════════════════════════════
router.post("/select-account", async (req, res, next) => {
  try {
    const { code, customerId } = req.body;
    if (!code || !customerId) return sendFail(res, "缺少参数", 400);

    let openid;
    try {
      const session = await wechatService.code2session(code);
      openid = session.openid;
    } catch (e) {
      return sendFail(res, "微信登录失败: " + e.message, 400);
    }

    // 验证绑定关系
    const [bind] = await pool.query(
      "SELECT 1 FROM wx_user_bindings WHERE wx_openid = ? AND customer_id = ? LIMIT 1",
      [openid, customerId],
    );
    if (!bind.length) return sendFail(res, "未绑定该账号", 403);

    // 更新 customers.wx_openid，确保消息推送能找到人
    await pool.execute("UPDATE customers SET wx_openid = ? WHERE id = ?", [openid, customerId]);

    const [[customer]] = await pool.query(
      "SELECT id, customer_no, child_name, parent_phone, store_id, has_card, training_project, total_times, used_times, remaining_times, open_card_date, expire_date, status FROM customers WHERE id = ? AND status = 1 LIMIT 1",
      [customerId],
    );
    if (!customer) return sendFail(res, "账号已停用或不存在", 403);

    const token = signCustomerToken(customer, openid);

    return sendSuccess(res, {
      accessToken: token,
      customer: {
        id: Number(customer.id), customerNo: customer.customer_no,
        childName: customer.child_name || "", parentPhone: customer.parent_phone || "",
        hasCard: Number(customer.has_card || 0) === 1,
        trainingProject: customer.training_project || "",
        totalTimes: Number(customer.total_times || 0),
        usedTimes: Number(customer.used_times || 0),
        remainingTimes: customer.remaining_times == null
          ? Number(customer.total_times || 0) - Number(customer.used_times || 0)
          : Number(customer.remaining_times || 0),
        expireDate: customer.expire_date || null,
        status: Number(customer.status || 0),
      },
    }, "登录成功");
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 1d. 解绑账号
// ═══════════════════════════════════════════════════════
router.post("/unbind", async (req, res, next) => {
  try {
    const { code, customerId } = req.body;
    if (!code || !customerId) return sendFail(res, "缺少参数", 400);

    let openid;
    try {
      const session = await wechatService.code2session(code);
      openid = session.openid;
    } catch (e) {
      return sendFail(res, "微信登录失败: " + e.message, 400);
    }

    await pool.execute(
      "DELETE FROM wx_user_bindings WHERE wx_openid = ? AND customer_id = ?",
      [openid, customerId],
    );

    // 更新 customers 表
    await pool.execute(
      "UPDATE customers SET wx_openid = NULL WHERE id = ? AND wx_openid = ?",
      [customerId, openid],
    );

    return sendSuccess(res, null, "已解绑");
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 1b. 微信一键登录（授权手机号 → 自动建档/登录）
// ═══════════════════════════════════════════════════════
router.post("/wechat-login", async (req, res, next) => {
  try {
    const { code, phoneCode } = req.body;

    if (!phoneCode) {
      return sendFail(res, "缺少手机号授权码", 400, { errorCode: "MISSING_PHONE_CODE" });
    }

    // 1. 获取微信手机号
    let phone;
    try {
      phone = await wechatService.getPhoneNumber(phoneCode);
    } catch (e) {
      return sendFail(res, "获取微信手机号失败: " + e.message, 400, {
        errorCode: "WECHAT_PHONE_FAILED",
      });
    }

    if (!phone) {
      return sendFail(res, "未能获取到手机号，请重新授权", 400, {
        errorCode: "PHONE_EMPTY",
      });
    }

    // 2. code2session（可选，拿到 openid）
    let openid = null;
    if (code) {
      try {
        const session = await wechatService.code2session(code);
        openid = session.openid;
      } catch (e) {
        console.log("[微信] code2session 失败:", e.message);
        // 非致命错误，继续
      }
    }

    // 3. 按手机号查找客户
    const [customerRows] = await pool.execute(
      `SELECT c.id, c.customer_no, c.child_name, c.gender, c.birthday,
        c.parent_name, c.parent_phone, c.store_id, s.store_name,
        c.has_card, c.training_project, c.total_times, c.used_times, c.remaining_times,
        c.open_card_date, c.expire_date, c.status
      FROM customers c
      LEFT JOIN stores s ON s.id = c.store_id
      WHERE c.parent_phone = ? AND c.status = 1
      LIMIT 1`,
      [phone],
    );

    let customer = customerRows[0] || null;

    // 4. 没找到 → 自动建档
    if (!customer) {
      const customerNo = "WX" + Date.now().toString(36).toUpperCase() + Math.floor(Math.random() * 1000).toString().padStart(3, "0");
      const childName = "新客户" + phone.slice(-4);

      // 取一个默认门店（新建客户需要绑定门店）
      const [storeRows] = await pool.query("SELECT id FROM stores LIMIT 1");
      const defaultStoreId = storeRows.length ? storeRows[0].id : 1;

      const [insertResult] = await pool.execute(
        `INSERT INTO customers
         (customer_no, child_name, parent_phone, store_id, has_card, status, training_project, total_times, used_times, open_card_date, expire_date)
         VALUES (?, ?, ?, ?, 0, 1, NULL, 0, 0, NULL, NULL)`,
        [customerNo, childName, phone, defaultStoreId],
      );

      // 读回刚创建的客户
      const [newRows] = await pool.execute(
        `SELECT c.id, c.customer_no, c.child_name, c.parent_name, c.parent_phone,
          c.has_card, c.training_project, c.total_times, c.used_times, c.remaining_times,
          c.open_card_date, c.expire_date, c.status, c.store_id
        FROM customers c WHERE c.id = ? LIMIT 1`,
        [insertResult.insertId],
      );
      customer = newRows[0] || null;

      console.log(`[微信] 自动建档: ${childName} / ${phone} / ${customerNo}`);
    }

    if (!customer) {
      return sendFail(res, "建档失败", 500);
    }

    // 保存 openid（用于后续发送订阅消息）
    if (openid) {
      await pool.execute("UPDATE customers SET wx_openid = ? WHERE id = ?", [openid, customer.id]);
      await pool.execute(
        "INSERT IGNORE INTO wx_user_bindings (wx_openid, customer_id) VALUES (?, ?)",
        [openid, customer.id],
      );
    }

    // 5. 生成 JWT
    const jwt = require("jsonwebtoken");
    const wxSecret = getCustomerJwtSecret();
    const tokenPayload = {
      customerId: Number(customer.id),
      childName: customer.child_name || "",
      parentPhone: customer.parent_phone || phone,
      storeId: Number(customer.store_id || 0),
      openid: openid || undefined,
      type: "customer",
    };
    const accessToken = jwt.sign(tokenPayload, wxSecret, { expiresIn: "30d" });

    return sendSuccess(
      res,
      {
        accessToken,
        isNewCustomer: !customer.has_card, // 标记是否新客户
        customer: {
          id: Number(customer.id),
          customerNo: customer.customer_no,
          childName: customer.child_name || "",
          parentPhone: customer.parent_phone || phone,
          storeId: Number(customer.store_id || 0),
          storeName: customer.store_name || "",
          hasCard: Number(customer.has_card || 0) === 1,
          trainingProject: customer.training_project || "",
          totalTimes: Number(customer.total_times || 0),
          usedTimes: Number(customer.used_times || 0),
          remainingTimes: customer.remaining_times == null
            ? Number(customer.total_times || 0) - Number(customer.used_times || 0)
            : Number(customer.remaining_times || 0),
          openCardDate: customer.open_card_date || null,
          expireDate: customer.expire_date || null,
          status: Number(customer.status || 0),
        },
      },
      "登录成功",
    );
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 1c. 订阅消息授权（保存 openid）
// ═══════════════════════════════════════════════════════
router.post("/subscribe", async (req, res, next) => {
  try {
    await ensureSchema();

    const { code } = req.body;
    const token = (req.headers.authorization || "").replace("Bearer ", "").trim();

    // 解析 JWT 拿到 customerId
    let customerId = null;
    if (token) {
      try {
        const jwt = require("jsonwebtoken");
        const wxSecret = getCustomerJwtSecret();
        const decoded = jwt.verify(token, wxSecret);
        customerId = decoded.customerId;
      } catch (e) {
        // token 无效，继续尝试 code
      }
    }

    // 通过 code 获取 openid
    let openid = null;
    if (code) {
      try {
        const session = await wechatService.code2session(code);
        openid = session.openid;
      } catch (e) {
        return sendFail(res, "获取 openid 失败: " + e.message, 400);
      }
    }

    if (!openid) {
      return sendFail(res, "缺少 code", 400);
    }

    if (!customerId) {
      return sendFail(res, "登录已过期，请重新登录后再订阅", 401);
    }

    // 保存 openid 到客户档案
    await pool.execute("UPDATE customers SET wx_openid = ? WHERE id = ?", [openid, customerId]);
    await pool.execute(
      "INSERT IGNORE INTO wx_user_bindings (wx_openid, customer_id) VALUES (?, ?)",
      [openid, customerId],
    );

    return sendSuccess(res, { openid, customerId }, "订阅授权已记录");
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 小程序鉴权中间件
// ═══════════════════════════════════════════════════════
async function customerAuth(req, res, next) {
  const token = (req.headers.authorization || "").replace("Bearer ", "").trim();
  if (!token) {
    return sendFail(res, "未登录", 401);
  }

  try {
    const jwt = require("jsonwebtoken");
    const wxSecret = getCustomerJwtSecret();
    const decoded = jwt.verify(token, wxSecret);

    if (decoded.type !== "customer") {
      return sendFail(res, "请使用小程序登录", 401);
    }

    req.customerId = Number(decoded.customerId);
    req.customerInfo = decoded;

    try {
      const [[row]] = await pool.query(
        `SELECT c.id, c.status,
                EXISTS(
                  SELECT 1 FROM wx_user_bindings b
                  WHERE b.customer_id = c.id AND b.wx_openid = ?
                  LIMIT 1
                ) AS binding_exists
         FROM customers c
         WHERE c.id = ?
         LIMIT 1`,
        [String(decoded.openid || "").trim(), req.customerId],
      );
      if (!row || Number(row.status) !== 1) {
        return sendFail(res, "账号已停用", 401);
      }
      if (decoded.openid && Number(row.binding_exists || 0) !== 1) {
        return sendFail(res, "当前账号绑定关系已失效，请重新登录", 401);
      }
    } catch (dbErr) {
      return next(dbErr);
    }

    next();
  } catch (error) {
    return sendFail(res, "登录已过期，请重新登录", 401);
  }
}

// ═══════════════════════════════════════════════════════
// 2. 孩子档案详情
// ═══════════════════════════════════════════════════════
router.get("/profile", customerAuth, async (req, res, next) => {
  try {
    await ensureSchema();
    const customerId = req.customerId;

    const [rows] = await pool.query(
      `SELECT c.id, c.customer_no, c.child_name, c.gender, c.birthday,
        c.parent_name, c.parent_phone, c.store_id, s.store_name,
        c.has_card, c.training_project, c.total_times, c.used_times, c.remaining_times,
        c.open_card_date, c.expire_date, c.status, c.remark
      FROM customers c
      LEFT JOIN stores s ON s.id = c.store_id
      WHERE c.id = ? LIMIT 1`,
      [customerId],
    );

    const customer = rows[0];
    if (!customer) {
      return sendFail(res, "客户不存在", 404);
    }

    const cardMap = await getCustomerCardsMap(pool, [customerId], { activeOnly: true });
    const cards = cardMap.get(customerId) || [];
    const hasActiveCard = Number(customer.has_card || 0) === 1 || cards.length > 0;
    const [[latestGlassesRow]] = await pool.query(
      `SELECT id, customer_id, record_time, source_check_id, delivery_status, pd,
        sphere_od, cylinder_od, axis_od, sphere_os, cylinder_os, axis_os,
        lens_brand, lens_type, lens_od_id, lens_od_brand, lens_od_name,
        lens_od_refractive_index, lens_od_features, lens_os_id, lens_os_brand,
        lens_os_name, lens_os_refractive_index, lens_os_features,
        frame_info, operator_id, operator_name, remark, created_at
       FROM customer_glasses_records
       WHERE customer_id = ? AND delivery_status <> 7
       ORDER BY record_time DESC, id DESC LIMIT 1`,
      [customerId],
    );

    return sendSuccess(res, {
      id: Number(customer.id),
      customerNo: customer.customer_no,
      childName: customer.child_name,
      gender: customer.gender,
      birthday: customer.birthday,
      parentName: customer.parent_name,
      parentPhone: customer.parent_phone,
      storeName: customer.store_name || "",
      hasCard: hasActiveCard ? 1 : 0,
      trainingProject: customer.training_project,
      totalTimes: Number(customer.total_times || 0),
      usedTimes: Number(customer.used_times || 0),
      remainingTimes: customer.remaining_times == null
        ? Number(customer.total_times || 0) - Number(customer.used_times || 0)
        : Number(customer.remaining_times || 0),
      openCardDate: customer.open_card_date,
      expireDate: customer.expire_date,
      status: Number(customer.status),
      cards,
      currentGlasses: latestGlassesRow ? formatGlassesRecord(latestGlassesRow) : null,
    }, "获取成功");
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 3. 核销记录列表
// ═══════════════════════════════════════════════════════
router.get("/verify-records", customerAuth, async (req, res, next) => {
  try {
    await ensureSchema();
    const { pageNum, pageSize, offset } = normalizePage(req.query);
    const customerId = req.customerId;

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) AS total FROM verify_records WHERE customer_id = ? AND revoked = 0`,
      [customerId],
    );

    const [rows] = await pool.query(
      `SELECT id, verify_no, verify_date, verify_time, child_name, training_project,
        card_name, operator_name, remark, created_at
      FROM verify_records
      WHERE customer_id = ? AND revoked = 0
      ORDER BY verify_time DESC, id DESC
      LIMIT ? OFFSET ?`,
      [customerId, pageSize, offset],
    );

    return sendPage(res, toCamelCase(rows), Number(total), pageNum, pageSize);
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 4. 到店检查记录
// ═══════════════════════════════════════════════════════
router.get("/visit-checks", customerAuth, async (req, res, next) => {
  try {
    await ensureSchema();
    const { pageNum, pageSize, offset } = normalizePage(req.query);
    const customerId = req.customerId;

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) AS total FROM customer_visit_checks WHERE customer_id = ?`,
      [customerId],
    );

    const [rows] = await pool.query(
      `SELECT id, check_time, check_result, naked_vision_od, naked_vision_os,
        corrected_vision_od, corrected_vision_os, pd,
        exam_sphere_od, exam_cylinder_od, exam_axis_od,
        exam_sphere_os, exam_cylinder_os, exam_axis_os,
        recommended_sphere_od, recommended_cylinder_od, recommended_axis_od,
        recommended_sphere_os, recommended_cylinder_os, recommended_axis_os,
        suggestion, operator_name, remark, created_at
      FROM customer_visit_checks
      WHERE customer_id = ?
      ORDER BY check_time DESC, id DESC
      LIMIT ? OFFSET ?`,
      [customerId, pageSize, offset],
    );

    return sendPage(res, toCamelCase(rows), Number(total), pageNum, pageSize);
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 5. 续卡记录
// ═══════════════════════════════════════════════════════
router.get("/renewals", customerAuth, async (req, res, next) => {
  try {
    await ensureSchema();
    const { pageNum, pageSize, offset } = normalizePage(req.query);
    const customerId = req.customerId;

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) AS total FROM customer_renewals WHERE customer_id = ?`,
      [customerId],
    );

    const [rows] = await pool.query(
      `SELECT id, before_total_times, before_used_times, before_expire_date,
        add_times, after_total_times, after_expire_date, operator_name, remark, created_at
      FROM customer_renewals
      WHERE customer_id = ?
      ORDER BY created_at DESC, id DESC
      LIMIT ? OFFSET ?`,
      [customerId, pageSize, offset],
    );

    return sendPage(res, toCamelCase(rows), Number(total), pageNum, pageSize);
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 6. 配镜记录
// ═══════════════════════════════════════════════════════
router.get("/glasses-records", customerAuth, async (req, res, next) => {
  try {
    await ensureSchema();
    const { pageNum, pageSize, offset } = normalizePage(req.query);
    const customerId = req.customerId;

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) AS total FROM customer_glasses_records WHERE customer_id = ?`,
      [customerId],
    );

    const [rows] = await pool.query(
      `SELECT id, record_time, delivery_status, pd,
        sphere_od, cylinder_od, axis_od, sphere_os, cylinder_os, axis_os,
        lens_brand, lens_type, lens_od_id, lens_od_brand, lens_od_name,
        lens_od_refractive_index, lens_od_features, lens_os_id, lens_os_brand,
        lens_os_name, lens_os_refractive_index, lens_os_features,
        frame_info, operator_name, remark, created_at
      FROM customer_glasses_records
      WHERE customer_id = ?
      ORDER BY record_time DESC, id DESC
      LIMIT ? OFFSET ?`,
      [customerId, pageSize, offset],
    );

    const recordIds = rows.map((row) => Number(row.id || 0)).filter(Boolean);
    let statusLogs = [];
    if (recordIds.length) {
      const [logRows] = await pool.query(
        `SELECT id, glasses_record_id, from_status, to_status, remark, operator_name, created_at
         FROM customer_glasses_status_logs
         WHERE glasses_record_id IN (${recordIds.map(() => "?").join(",")})
         ORDER BY created_at ASC, id ASC`,
        recordIds,
      );
      statusLogs = logRows;
    }
    const logMap = new Map();
    statusLogs.forEach((log) => {
      const key = Number(log.glasses_record_id || 0);
      if (!logMap.has(key)) logMap.set(key, []);
      logMap.get(key).push({
        id: Number(log.id || 0),
        glassesRecordId: key,
        fromStatus: log.from_status == null ? null : normalizeGlassesStatus(log.from_status),
        fromStatusLabel: log.from_status == null ? "" : getGlassesStatusLabel(log.from_status),
        toStatus: normalizeGlassesStatus(log.to_status),
        toStatusLabel: getGlassesStatusLabel(log.to_status),
        remark: log.remark || "",
        operatorName: log.operator_name || "",
        createdAt: log.created_at || null,
      });
    });

    const list = rows.map((row) => {
      const item = formatGlassesRecord(row);
      return {
        ...item,
        statusLogs: logMap.get(Number(item.id || 0)) || [],
      };
    });

    return sendPage(res, list, Number(total), pageNum, pageSize);
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════
// 7. 视力档案 — 历史检查数据（用于折线图）
// ═══════════════════════════════════════════════════════
router.get("/vision-report", customerAuth, async (req, res, next) => {
  try {
    await ensureSchema();
    const customerId = req.customerId;
    const limit = Math.min(Number(req.query.limit) || 20, 50);

    const [rows] = await pool.query(
      `SELECT check_time, check_result,
        naked_vision_od, naked_vision_os,
        corrected_vision_od, corrected_vision_os,
        suggestion
      FROM customer_visit_checks
      WHERE customer_id = ?
      ORDER BY check_time ASC
      LIMIT ?`,
      [customerId, limit],
    );

    // 解析视力值为数字（用于图表）
    function parseVision(v) {
      if (!v) return null;
      var s = String(v).trim();
      var n = parseFloat(s);
      return isNaN(n) ? null : n;
    }

    var list = rows.map(function(row) {
      return {
        date: row.check_time ? String(row.check_time).substring(0, 10) : "",
        nakedOd: parseVision(row.naked_vision_od),
        nakedOs: parseVision(row.naked_vision_os),
        correctedOd: parseVision(row.corrected_vision_od),
        correctedOs: parseVision(row.corrected_vision_os),
        result: row.check_result || "",
        suggestion: row.suggestion || "",
      };
    }).filter(function(item) {
      // 至少有一个有效数据
      return item.nakedOd || item.nakedOs || item.correctedOd || item.correctedOs;
    });

    // 统计
    var latest = list.length ? list[list.length - 1] : null;
    var first = list.length ? list[0] : null;

    return sendSuccess(res, {
      list: list,
      count: list.length,
      latest: latest,
      first: first,
      trend: list.length >= 2 ? (function() {
        var lastNakedOd = latest.nakedOd;
        var firstNakedOd = first.nakedOd;
        if (lastNakedOd && firstNakedOd) {
          return lastNakedOd > firstNakedOd ? "up" : lastNakedOd < firstNakedOd ? "down" : "stable";
        }
        return null;
      })() : null,
    }, "获取成功");
  } catch (error) {
    next(error);
  }
});

module.exports = router;
