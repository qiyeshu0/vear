require("dotenv").config();
process.env.TZ = "Asia/Shanghai";

const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const morgan = require("morgan");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");

const authRoutes = require("./routes/auth.routes");
const dashboardRoutes = require("./routes/dashboard.routes");
const customerRoutes = require("./routes/customer.routes");
const verifyRoutes = require("./routes/verify.routes");
const visitRoutes = require("./routes/visit.routes");
const recordRoutes = require("./routes/record.routes");
const storeRoutes = require("./routes/store.routes");
const userRoutes = require("./routes/user.routes");
const permissionRoutes = require("./routes/permission.routes");
const logRoutes = require("./routes/log.routes");
const installRoutes = require("./routes/install.routes");
const trainingProjectRoutes = require("./routes/training-project.routes");
const cardTemplateRoutes = require("./routes/card-template.routes");
const lensRoutes = require("./routes/lens.routes");
const apiKeyRoutes = require("./routes/api-key.routes");
const toolRoutes = require("./routes/tool.routes");
const dataCenterRoutes = require("./routes/data-center.routes");
const dataCenterController = require("./controllers/data-center.controller");
const systemSettingsRoutes = require("./routes/system-settings.routes");
const runtimeConfigRoutes = require("./routes/runtime-config.routes");
const systemUpdateRoutes = require("./routes/system-update.routes");
const smsRoutes = require("./routes/sms.routes");
const { getSettingsMap } = require("./utils/system-settings");
const { getCorsOrigins } = require("./utils/runtime-config");
const { formatChinaDateTime, toChinaIsoString } = require("./utils/date");
const { ensureDefaultUserPermissions } = require("./utils/permission");
const { backfillVisitsFromVerifications } = require("./services/visit.service");
const { startUpdateScheduler } = require("./services/system-update.service");
const { ensureDefaultBusinessReleaseSeed } = require("./install/default-business-data");
const { ensureDefaultLensSeed } = require("./services/lens.service");
const { pool, testDbConnection } = require("./config/db");
const {
  notFoundHandler,
  errorHandler,
} = require("./middleware/error.middleware");
const {
  apiLimiter,
  authLimiter,
  installLimiter,
  registerLimiter,
} = require("./config/rate-limiter");

const app = express();

const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || "development";
const INSTALLED_FLAG_FILE = path.resolve(__dirname, "..", ".installed");
const isInstalled = fs.existsSync(INSTALLED_FLAG_FILE);

// 安全检查：已安装状态下，JWT_SECRET 必须是强密钥
if (isInstalled && NODE_ENV === "production") {
  const jwtSecret = process.env.JWT_SECRET || "";
  const weakDefaults = [
    "please_change_this_to_a_strong_secret",
    "verify-system-secret",
    "change_me",
    "your-secret-key",
    "123456",
  ];
  const normalizedJwtSecret = jwtSecret.toLowerCase();
  const isWeakSecret =
    !jwtSecret ||
    jwtSecret.length < 32 ||
    weakDefaults.includes(normalizedJwtSecret);
  const isInstallerGeneratedWeakSecret = normalizedJwtSecret.startsWith(
    "please_change_this_to_a_strong_secret_"
  );

  if (isWeakSecret) {
    console.error("[启动失败] 安全检测：JWT_SECRET 未配置或使用默认弱密钥。");
    console.error("请在 backend-后端/.env 中设置一个足够复杂的 JWT_SECRET。");
    process.exit(1);
  }

  if (isInstallerGeneratedWeakSecret) {
    console.warn("[安全提醒] 当前 JWT_SECRET 是旧安装流程生成的弱格式，本机测试可继续运行，正式部署前请替换为强随机密钥。");
  }
}
const UPLOAD_DIR = path.join(__dirname, "uploads");
const CUSTOMER_ATTACH_DIR = path.join(UPLOAD_DIR, "customer_attach");
const FRONTEND_DIST_DIR = path.resolve(__dirname, "..", "..", "frontend-pure-前端", "dist");
const FRONTEND_INDEX_FILE = path.join(FRONTEND_DIST_DIR, "index.html");
const FRONTEND_TITLE_CACHE_MS = Number(process.env.FRONTEND_TITLE_CACHE_MS || "10000");
let cachedFrontendSystemName = "";
let frontendTitleLoadedAt = 0;
let frontendTitleRefreshPromise = null;

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function refreshFrontendSystemName() {
  if (
    frontendTitleRefreshPromise ||
    (frontendTitleLoadedAt && Date.now() - frontendTitleLoadedAt < FRONTEND_TITLE_CACHE_MS)
  ) {
    return frontendTitleRefreshPromise || Promise.resolve(cachedFrontendSystemName);
  }

  frontendTitleRefreshPromise = getSettingsMap()
    .then((settings) => {
      cachedFrontendSystemName = String(settings?.system_name || "").trim();
      frontendTitleLoadedAt = Date.now();
      return cachedFrontendSystemName;
    })
    .catch((error) => {
      console.warn("[系统名称缓存刷新失败]", error?.message || error);
      return cachedFrontendSystemName;
    })
    .finally(() => {
      frontendTitleRefreshPromise = null;
    });

  return frontendTitleRefreshPromise;
}

function sendFrontendIndexWithSystemTitle(res) {
  let html = fs.readFileSync(FRONTEND_INDEX_FILE, "utf8");

  if (cachedFrontendSystemName) {
    html = html.replace(
      /<title>[\s\S]*?<\/title>/i,
      `<title>${escapeHtml(cachedFrontendSystemName)}</title>`,
    );
  }

  refreshFrontendSystemName();
  res.type("html").send(html);
}

function buildSelfOrigins(req) {
  const host = req.headers.host;

  if (!host) {
    return [];
  }

  const forwardedProto = String(req.headers["x-forwarded-proto"] || "")
    .split(",")[0]
    .trim();
  const protocol = forwardedProto || req.protocol || "http";

  return Array.from(new Set([
    `${protocol}://${host}`,
    `http://${host}`,
    `https://${host}`
  ]));
}

if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

if (!fs.existsSync(CUSTOMER_ATTACH_DIR)) {
  fs.mkdirSync(CUSTOMER_ATTACH_DIR, { recursive: true });
}

app.disable("x-powered-by");
app.set("trust proxy", 1);

app.use(
  helmet({
    crossOriginResourcePolicy: false,
    contentSecurityPolicy: {
      directives: {
        upgradeInsecureRequests: null,
      },
    },
  }),
);

app.use(
  cors((req, callback) => {
    const origin = req.header("Origin");

    if (!origin) {
      callback(null, { origin: true, credentials: true });
      return;
    }

    getCorsOrigins()
      .catch(() => (
        process.env.CORS_ORIGIN ||
        [
          "http://localhost:5173",
          "http://127.0.0.1:5173",
          "http://localhost:4173",
          "http://127.0.0.1:4173"
        ].join(",")
      )
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean))
      .then((allowList) => {
        const selfOrigins = buildSelfOrigins(req);
        const finalAllowList = new Set([...allowList, ...selfOrigins]);

        if (finalAllowList.has("*") || finalAllowList.has(origin)) {
          callback(null, { origin: true, credentials: true });
          return;
        }

        callback(new Error(`CORS blocked for origin: ${origin}`));
      });
  }),
);

morgan.token("china-date", () => `${formatChinaDateTime()} +0800`);
const productionLogFormat = ':remote-addr - :remote-user [:china-date] ":method :url HTTP/:http-version" :status :res[content-length] ":referrer" ":user-agent"';
app.use(morgan(NODE_ENV === "production" ? productionLogFormat : "dev"));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(cookieParser());

app.get("/health", (req, res) => {
  res.json({
    code: 0,
    message: "ok",
    data: {
      name: "verification-system-api",
      env: NODE_ENV,
      time: toChinaIsoString(),
    },
  });
});

app.use("/uploads", express.static(UPLOAD_DIR));

// 安装接口（无需认证，严格限流）
app.use("/api/install", installLimiter, installRoutes);

app.use("/api/auth", authLimiter, authRoutes);

// 通用 API 限流（120次/分钟，防滥用）
app.use("/api/dashboard", apiLimiter, dashboardRoutes);
app.use("/api/customers", apiLimiter, customerRoutes);
app.use("/api/verify", apiLimiter, verifyRoutes);
app.use("/api/visits", apiLimiter, visitRoutes);
app.use("/api/records", apiLimiter, recordRoutes);
app.use("/api/stores", apiLimiter, storeRoutes);
app.use("/api/users", apiLimiter, userRoutes);
app.use("/api/permissions", apiLimiter, permissionRoutes);
app.use("/api/logs", apiLimiter, logRoutes);
app.use("/api/training-projects", apiLimiter, trainingProjectRoutes);
app.use("/api/card-templates", apiLimiter, cardTemplateRoutes);
app.use("/api/lenses", apiLimiter, lensRoutes);
app.use("/api/api-keys", apiLimiter, apiKeyRoutes);
app.use("/api/system-settings", apiLimiter, systemSettingsRoutes);
app.use("/api/runtime-config", apiLimiter, runtimeConfigRoutes);
app.use("/api/system-update", apiLimiter, systemUpdateRoutes);
app.use("/api/sms", apiLimiter, smsRoutes);
app.use("/api/tools/data-center", apiLimiter, dataCenterRoutes);
app.use("/api/tools", apiLimiter, toolRoutes);

// 微信小程序 API（客户端）
const wxRoutes = require("./routes/wx.routes");
app.use("/api/wx", apiLimiter, wxRoutes);

// 报表导出
const reportRoutes = require("./routes/report.routes");
app.use("/api/reports", apiLimiter, reportRoutes);

if (fs.existsSync(FRONTEND_DIST_DIR)) {
  // 静态资源照常托管，但 index.html 必须走下方动态入口：
  // 这样系统设置里的系统名称才能同步到浏览器初始标题，而不是一直显示打包模板标题。
  app.use(express.static(FRONTEND_DIST_DIR, { index: false }));

  app.use((req, res, next) => {
    if (req.method !== "GET") {
      next();
      return;
    }

    if (
      req.path.startsWith("/api") ||
      req.path.startsWith("/uploads") ||
      req.path === "/health"
    ) {
      next();
      return;
    }

    if (!fs.existsSync(FRONTEND_INDEX_FILE)) {
      next();
      return;
    }

    try {
      sendFrontendIndexWithSystemTitle(res);
    } catch (error) {
      next(error);
    }
  });
}

app.use(notFoundHandler);
app.use(errorHandler);

let httpServer = null;

function startServer() {
  if (httpServer) return httpServer;
  httpServer = app.listen(PORT, () => {
    console.log(`API server is running at http://localhost:${PORT}`);

    // 先预热一条数据库连接；远程 MySQL 偶尔会给第一条请求慢/断的连接，别让用户登录来踩雷。
    testDbConnection().catch(error => {
      console.warn("[数据库预连接失败]", error?.message || error);
    });
    refreshFrontendSystemName();

    // 权限/首页数据结构是低频维护任务，不应该阻塞登录接口。
    // 延迟几秒后台预热，避免服务刚启动时和用户第一次登录争抢远程 MySQL 连接。
    setTimeout(() => {
      ensureDefaultUserPermissions().catch(error => {
        console.warn("[权限预热失败]", error?.message || error);
      });

      backfillVisitsFromVerifications()
        .then(result => {
          if (Number(result?.linked || 0) > 0) {
            console.log(`[来访中心] 历史核销同步完成：生成 ${result.created} 条来访，关联 ${result.linked} 条核销`);
          }
        })
        .catch(error => {
          console.warn("[来访中心历史同步失败]", error?.message || error);
        });

      if (typeof dashboardRoutes.ensureDashboardSchema === "function") {
        dashboardRoutes.ensureDashboardSchema().catch(error => {
          console.warn("[首页数据结构预热失败]", error?.message || error);
        });
      }

      if (typeof dataCenterController.startAutoBackupScheduler === "function") {
        dataCenterController.startAutoBackupScheduler();
      }
      if (isInstalled) {
        ensureDefaultBusinessReleaseSeed(pool)
          .then(result => {
            if (result?.inserted) {
              console.log(`[基础资料] 已初始化训练项目 ${result.trainingProjects} 项、卡项模板 ${result.cardTemplates} 项`);
            }
          })
          .catch(error => {
            console.warn("[基础资料初始化失败]", error?.message || error);
          });
        ensureDefaultLensSeed()
          .then(result => {
            if (result?.inserted) {
              console.log(`[镜片资料] 已初始化系统镜片模板 ${result.inserted} 项`);
            }
          })
          .catch(error => {
            console.warn("[镜片资料初始化失败]", error?.message || error);
          });
        startUpdateScheduler();
      }
    }, Number(process.env.STARTUP_WARMUP_DELAY_MS || "5000"));
  });
  return httpServer;
}

if (require.main === module) startServer();

app.startServer = startServer;
module.exports = app;
