const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const os = require("os");
const { spawnSync } = require("child_process");
const AdmZip = require("adm-zip");
const { pool } = require("../config/db");
const dataCenter = require("../controllers/data-center.controller");
const UPDATE_SOURCE = require("../config/update-source");
const { ensureSystemUpdateTables } = require("../utils/internal-schema");
const { toChinaIsoString } = require("../utils/date");

const BACKEND_ROOT = path.resolve(__dirname, "..", "..");
const APP_ROOT = path.resolve(BACKEND_ROOT, "..");
const VERSION_FILE = path.join(APP_ROOT, "version.json");
const CONFIG_FILE = path.join(BACKEND_ROOT, "system-update.config.json");
const UPDATE_ROOT = path.join(BACKEND_ROOT, ".updates");
const DOWNLOAD_DIR = path.join(UPDATE_ROOT, "downloads");
const BACKUP_DIR = path.join(UPDATE_ROOT, "file-backups");
const STATE_FILE = path.join(UPDATE_ROOT, "state.json");
const LOCK_FILE = path.join(UPDATE_ROOT, "update.lock");
const INDEX_FORMAT = UPDATE_SOURCE.indexFormat;
const PACKAGE_FORMAT = UPDATE_SOURCE.packageFormat;
const MAX_PACKAGE_BYTES = 200 * 1024 * 1024;

const DEFAULT_CONFIG = {
  fallbackManifestUrl: "",
  fallbackEnabled: true,
  channel: "stable",
  autoCheck: true,
  checkIntervalHours: 24,
  autoDownload: false,
  lastCheckedAt: null
};

function ensureDirs() {
  fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return fallback; }
}

function writeJsonAtomic(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temporary = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(temporary, `${JSON.stringify(value, null, 2)}\n`);
  fs.renameSync(temporary, file);
}

function getVersionInfo() {
  const version = readJson(VERSION_FILE, {});
  return {
    systemVersion: String(version.systemVersion || "1.0.0"),
    backendVersion: String(version.backendVersion || version.systemVersion || "1.0.0"),
    frontendVersion: String(version.frontendVersion || version.systemVersion || "1.0.0"),
    databaseVersion: Number(version.databaseVersion || 1),
    miniprogramVersion: String(version.miniprogramVersion || "1.0.0"),
    miniprogramMinimumVersion: String(version.miniprogramMinimumVersion || "1.0.0"),
    miniprogramMaximumVersion: String(version.miniprogramMaximumVersion || "1.x"),
    releaseChannel: String(version.releaseChannel || "stable"),
    releasedAt: version.releasedAt || null,
    releaseName: version.releaseName || "",
    changelog: Array.isArray(version.changelog) ? version.changelog : [],
    releaseHistory: Array.isArray(version.releaseHistory) ? version.releaseHistory : []
  };
}

function readConfig() {
  const saved = readJson(CONFIG_FILE, {});
  return {
    ...DEFAULT_CONFIG,
    fallbackManifestUrl: String(saved.fallbackManifestUrl || saved.manifestUrl || "").trim(),
    fallbackEnabled: saved.fallbackEnabled === undefined ? DEFAULT_CONFIG.fallbackEnabled : Boolean(saved.fallbackEnabled),
    channel: ["stable", "beta"].includes(saved.channel) ? saved.channel : DEFAULT_CONFIG.channel,
    autoCheck: saved.autoCheck === undefined ? DEFAULT_CONFIG.autoCheck : Boolean(saved.autoCheck),
    checkIntervalHours: Math.max(1, Math.min(168, Number(saved.checkIntervalHours) || DEFAULT_CONFIG.checkIntervalHours)),
    autoDownload: saved.autoDownload === undefined ? DEFAULT_CONFIG.autoDownload : Boolean(saved.autoDownload),
    lastCheckedAt: saved.lastCheckedAt || null
  };
}

function saveConfig(input = {}) {
  const previous = readConfig();
  const next = {
    ...previous,
    fallbackManifestUrl: String(input.fallbackManifestUrl ?? previous.fallbackManifestUrl).trim(),
    fallbackEnabled: input.fallbackEnabled === undefined ? previous.fallbackEnabled : Boolean(input.fallbackEnabled),
    channel: ["stable", "beta"].includes(input.channel) ? input.channel : previous.channel,
    autoCheck: input.autoCheck === undefined ? previous.autoCheck : Boolean(input.autoCheck),
    checkIntervalHours: Math.max(1, Math.min(168, Number(input.checkIntervalHours ?? previous.checkIntervalHours) || 24)),
    autoDownload: input.autoDownload === undefined ? previous.autoDownload : Boolean(input.autoDownload)
  };
  writeJsonAtomic(CONFIG_FILE, next);
  return next;
}

async function ensureSchema() {
  await ensureSystemUpdateTables(pool);
}

function parseVersion(value) {
  return String(value || "0").replace(/^v/, "").split(/[.-]/).slice(0, 3).map(item => Number(item) || 0);
}

function compareVersions(a, b) {
  const left = parseVersion(a);
  const right = parseVersion(b);
  for (let i = 0; i < 3; i += 1) {
    if (left[i] !== right[i]) return left[i] > right[i] ? 1 : -1;
  }
  return 0;
}

function canonicalize(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonicalize(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function verifyManifest(manifest, detachedSignature) {
  const signature = String(manifest.signature || "").trim();
  const detached = String(detachedSignature || "").trim();
  const unsigned = { ...manifest };
  delete unsigned.signature;
  if (!signature) throw new Error("更新清单缺少数字签名");
  if (!detached) throw new Error("更新清单缺少独立签名文件");
  const embeddedBuffer = Buffer.from(signature, "base64");
  const detachedBuffer = Buffer.from(detached, "base64");
  if (!embeddedBuffer.length || embeddedBuffer.length !== detachedBuffer.length || !crypto.timingSafeEqual(embeddedBuffer, detachedBuffer)) {
    throw new Error("更新清单与独立签名文件不匹配");
  }
  const valid = crypto.verify(null, Buffer.from(canonicalize(unsigned)), UPDATE_SOURCE.publicKey, detachedBuffer);
  if (!valid) throw new Error("更新清单数字签名校验失败");
}

function assertRemoteUrl(rawUrl) {
  const url = new URL(rawUrl);
  if (url.protocol !== "https:" && process.env.NODE_ENV === "production") throw new Error("正式环境更新地址必须使用 HTTPS");
  if (!["https:", "http:"].includes(url.protocol)) throw new Error("更新地址协议无效");
  return url.toString();
}

function resolvePackage(manifest, currentVersion) {
  const packages = Array.isArray(manifest.packages) ? manifest.packages : manifest.package ? [manifest.package] : [];
  return packages.find(item => {
    const from = item.fromVersions || item.fromVersion || [currentVersion];
    return from === "*" || (Array.isArray(from) ? from.includes(currentVersion) : String(from) === currentVersion);
  }) || null;
}

async function fetchJson(url) {
  const response = await fetch(assertRemoteUrl(url), { headers: { "User-Agent": "VEAR-System-Updater/1.0" }, signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error(`更新服务器返回 HTTP ${response.status}`);
  return response.json();
}

async function fetchText(url) {
  const response = await fetch(assertRemoteUrl(url), { headers: { "User-Agent": "VEAR-System-Updater/1.0" }, signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error(`签名服务器返回 HTTP ${response.status}`);
  return response.text();
}

function deriveSignatureUrl(indexUrl) {
  const url = new URL(indexUrl);
  url.pathname = `${url.pathname}.sig`;
  return url.toString();
}

async function fetchVerifiedIndex(source) {
  const [manifest, detachedSignature] = await Promise.all([
    fetchJson(source.indexUrl),
    fetchText(source.signatureUrl || deriveSignatureUrl(source.indexUrl))
  ]);
  if (manifest.format !== INDEX_FORMAT) throw new Error("更新清单格式不受支持");
  verifyManifest(manifest, detachedSignature);
  return manifest;
}

async function probeUpdateSource(source) {
  const startedAt = Date.now();
  try {
    const manifest = await fetchVerifiedIndex(source);
    return {
      key: source.key,
      label: source.label,
      status: "online",
      latencyMs: Math.max(0, Date.now() - startedAt),
      latestVersion: String(manifest.version || ""),
      checkedAt: toChinaIsoString(),
      message: "线路可用",
      manifest
    };
  } catch (error) {
    return {
      key: source.key,
      label: source.label,
      status: "offline",
      latencyMs: Math.max(0, Date.now() - startedAt),
      latestVersion: "",
      checkedAt: toChinaIsoString(),
      message: String(error?.message || "线路不可用").slice(0, 180)
    };
  }
}

async function checkForUpdates() {
  ensureDirs();
  const config = readConfig();
  const sourceErrors = [];
  let manifest = null;
  let sourceUsed = "";
  let sourceUrl = "";
  const sourceProbeResults = await Promise.all(UPDATE_SOURCE.officialSources.map(probeUpdateSource));
  const sourceChecks = sourceProbeResults.map(({ manifest: _manifest, ...safe }) => safe);
  const successfulSource = sourceProbeResults.find(item => item.status === "online");
  if (successfulSource) {
    const source = UPDATE_SOURCE.officialSources.find(item => item.key === successfulSource.key);
    manifest = successfulSource.manifest;
    sourceUsed = source.key;
    sourceUrl = source.indexUrl;
  } else if (config.fallbackEnabled && config.fallbackManifestUrl) {
    const fallback = { key: "fallback", label: "自定义备用源", indexUrl: config.fallbackManifestUrl };
    const fallbackCheck = await probeUpdateSource(fallback);
    const { manifest: fallbackManifest, ...safeFallbackCheck } = fallbackCheck;
    sourceChecks.push(safeFallbackCheck);
    if (fallbackCheck.status === "online") {
      manifest = fallbackManifest;
      sourceUsed = fallback.key;
      sourceUrl = fallback.indexUrl;
    }
  }
  for (const check of sourceChecks) {
    if (check.status !== "online") sourceErrors.push({ source: check.key, label: check.label, message: check.message });
  }
  if (!manifest) {
    const details = sourceErrors.map(item => `${item.label}：${item.message}`).join("；");
    console.warn(`[系统更新] 所有更新源均不可用：${details}`);
    const current = getVersionInfo();
    const checkedAt = toChinaIsoString();
    const nextConfig = { ...config, lastCheckedAt: checkedAt };
    const unavailableState = {
      status: "unavailable",
      checkedAt,
      currentVersion: current.systemVersion,
      latestVersion: "",
      manifest: null,
      selectedPackage: null,
      sourceUsed: "",
      sourceUrl: "",
      sourceErrors,
      sourceChecks
    };
    writeJsonAtomic(CONFIG_FILE, nextConfig);
    writeJsonAtomic(STATE_FILE, unavailableState);
    return unavailableState;
  }
  const current = getVersionInfo();
  const latestVersion = String(manifest.version || "");
  if (!latestVersion) throw new Error("更新清单缺少版本号");
  const updateAvailable = compareVersions(latestVersion, current.systemVersion) > 0;
  const selectedPackage = updateAvailable ? resolvePackage(manifest, current.systemVersion) : null;
  const nextConfig = { ...config, lastCheckedAt: toChinaIsoString() };
  writeJsonAtomic(CONFIG_FILE, nextConfig);
  const state = {
    status: updateAvailable ? (selectedPackage ? "available" : "incompatible") : "latest",
    checkedAt: nextConfig.lastCheckedAt,
    currentVersion: current.systemVersion,
    latestVersion,
    manifest,
    selectedPackage,
    sourceUsed,
    sourceUrl,
    sourceErrors,
    sourceChecks
  };
  writeJsonAtomic(STATE_FILE, state);
  return state;
}

async function downloadUpdate() {
  const state = readJson(STATE_FILE, null) || await checkForUpdates();
  if (!state.selectedPackage) throw new Error("当前版本没有可用的增量更新包");
  const item = state.selectedPackage;
  const urls = Array.isArray(item.urls) ? item.urls.filter(Boolean) : item.url ? [item.url] : [];
  if (!urls.length) throw new Error("更新清单没有提供更新包下载地址");
  let buffer = null;
  let downloadUrl = "";
  const downloadErrors = [];
  for (const candidate of urls) {
    try {
      const response = await fetch(assertRemoteUrl(candidate), { signal: AbortSignal.timeout(120000) });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const length = Number(response.headers.get("content-length") || 0);
      if (length > MAX_PACKAGE_BYTES) throw new Error("更新包超过 200MB 安全限制");
      buffer = Buffer.from(await response.arrayBuffer());
      downloadUrl = candidate;
      break;
    } catch (error) { downloadErrors.push(`${candidate}：${error.message}`); }
  }
  if (!buffer) {
    console.warn(`[系统更新] 所有更新包下载地址均失败：${downloadErrors.join("；")}`);
    throw new Error("更新包下载失败，请稍后重试");
  }
  if (buffer.length > MAX_PACKAGE_BYTES) throw new Error("更新包超过 200MB 安全限制");
  const sha256 = crypto.createHash("sha256").update(buffer).digest("hex");
  if (!item.sha256 || sha256 !== String(item.sha256).toLowerCase()) throw new Error("更新包 SHA-256 校验失败");
  const filePath = path.join(DOWNLOAD_DIR, `${state.currentVersion}-to-${state.latestVersion}.zip`);
  fs.writeFileSync(filePath, buffer);
  const next = { ...state, status: "downloaded", downloadedAt: toChinaIsoString(), packagePath: filePath, packageSha256: sha256, packageSize: buffer.length, downloadUrl, downloadErrors };
  writeJsonAtomic(STATE_FILE, next);
  return next;
}

function normalizeRelativePath(input) {
  const normalized = String(input || "").replace(/\\/g, "/").replace(/^\.\//, "");
  if (!normalized || normalized.startsWith("/") || normalized.includes("../") || normalized.includes("\0")) throw new Error(`更新文件路径无效：${input}`);
  const forbidden = [".env", ".installed", "node_modules", ".git", "uploads", "backups", ".updates", "data-center-backup.config.json", "system-update.config.json"];
  if (normalized.split("/").some(part => forbidden.includes(part))) throw new Error(`更新包试图修改受保护内容：${normalized}`);
  const allowed = ["backend-后端/", "frontend-pure-前端/dist/", "miniprogram-tdesign/", "scripts/", "openapi.json", "version.json", "package.json", "package-lock.json", "ecosystem.config.cjs", "上线包使用说明.md", "部署说明-发布版.md"];
  if (!allowed.some(prefix => normalized === prefix || normalized.startsWith(prefix))) throw new Error(`更新文件不在允许范围：${normalized}`);
  return normalized;
}

function acquireLock() {
  ensureDirs();
  try { fs.writeFileSync(LOCK_FILE, JSON.stringify({ pid: process.pid, at: toChinaIsoString() }), { flag: "wx" }); }
  catch { throw new Error("已有更新任务正在执行，请勿重复操作"); }
}

function releaseLock() { try { fs.unlinkSync(LOCK_FILE); } catch {} }

function restoreFileBackup(backupPath, journal) {
  for (const item of [...journal].reverse()) {
    const destination = path.join(APP_ROOT, item.path);
    if (item.existed) {
      fs.mkdirSync(path.dirname(destination), { recursive: true });
      fs.copyFileSync(path.join(backupPath, "files", item.path), destination);
    } else if (fs.existsSync(destination)) fs.rmSync(destination, { recursive: true, force: true });
  }
}

async function applyMigrations(connection, migrations, version) {
  for (const migration of migrations) {
    const id = String(migration.id || "").trim();
    const sql = String(migration.sql || "").trim();
    if (!id || !sql) throw new Error("数据库迁移缺少 id 或 sql");
    const [existing] = await connection.query("SELECT id FROM schema_migrations WHERE id = ? LIMIT 1", [id]);
    if (existing.length) continue;
    await connection.query(sql);
    await connection.execute("INSERT INTO schema_migrations (id, version, checksum) VALUES (?, ?, ?)", [id, version, crypto.createHash("sha256").update(sql).digest("hex")]);
  }
}

async function applyUpdate(operator = {}) {
  acquireLock();
  let connection;
  let historyId = 0;
  let fileBackupPath = "";
  let journal = [];
  try {
    await ensureSchema();
    const state = readJson(STATE_FILE, null);
    if (!state || state.status !== "downloaded" || !state.packagePath) throw new Error("请先检查并下载更新包");
    const zip = new AdmZip(state.packagePath);
    const metadataEntry = zip.getEntry("update-package.json");
    const metadataSignatureEntry = zip.getEntry("update-package.sig");
    if (!metadataEntry) throw new Error("更新包缺少 update-package.json");
    if (!metadataSignatureEntry) throw new Error("更新包缺少内部清单签名 update-package.sig");
    const metadataBuffer = metadataEntry.getData();
    const metadataSha256 = crypto.createHash("sha256").update(metadataBuffer).digest("hex");
    if (!state.selectedPackage?.manifestSha256 || metadataSha256 !== String(state.selectedPackage.manifestSha256).toLowerCase()) {
      throw new Error("更新包内部清单哈希校验失败");
    }
    const metadataSignature = metadataSignatureEntry.getData().toString("utf8").trim();
    if (!crypto.verify(null, metadataBuffer, UPDATE_SOURCE.publicKey, Buffer.from(metadataSignature, "base64"))) {
      throw new Error("更新包内部清单数字签名校验失败");
    }
    const metadata = JSON.parse(metadataBuffer.toString("utf8"));
    if (metadata.format !== PACKAGE_FORMAT || String(metadata.toVersion) !== String(state.latestVersion)) throw new Error("更新包元数据与更新清单不一致");
    const current = getVersionInfo();
    const allowedFrom = metadata.fromVersions || [metadata.fromVersion];
    if (!allowedFrom.includes("*") && !allowedFrom.includes(current.systemVersion)) throw new Error(`更新包不支持从 ${current.systemVersion} 升级`);
    const files = Array.isArray(metadata.files) ? metadata.files : [];
    const deletedFiles = Array.isArray(metadata.deletedFiles) ? metadata.deletedFiles : [];
    if (!files.some(item => normalizeRelativePath(item.path) === "version.json")) throw new Error("更新包必须包含新的 version.json");
    const safeBackup = await dataCenter.createUpdateSafetyBackup();
    const stamp = `${Date.now()}-${current.systemVersion}-to-${metadata.toVersion}`;
    fileBackupPath = path.join(BACKUP_DIR, stamp);
    fs.mkdirSync(path.join(fileBackupPath, "files"), { recursive: true });
    const targets = [...files.map(item => normalizeRelativePath(item.path)), ...deletedFiles.map(normalizeRelativePath)];
    for (const relative of [...new Set(targets)]) {
      const source = path.join(APP_ROOT, relative);
      const existed = fs.existsSync(source);
      journal.push({ path: relative, existed });
      if (existed && fs.statSync(source).isFile()) {
        const backup = path.join(fileBackupPath, "files", relative);
        fs.mkdirSync(path.dirname(backup), { recursive: true });
        fs.copyFileSync(source, backup);
      }
    }
    writeJsonAtomic(path.join(fileBackupPath, "journal.json"), { fromVersion: current.systemVersion, toVersion: metadata.toVersion, journal, safetyBackup: safeBackup });
    const [history] = await pool.execute(`INSERT INTO system_update_history (from_version,to_version,status,update_type,changed_files,deleted_files,backup_path,package_sha256,operator_id,operator_name,message,details_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, [current.systemVersion, metadata.toVersion, "installing", metadata.updateType || "feature", files.length, deletedFiles.length, safeBackup.path, state.packageSha256, operator.userId || null, operator.realName || operator.username || "", "正在安装更新", JSON.stringify({ changelog: metadata.changelog || [], fileBackupPath })]);
    historyId = Number(history.insertId || 0);
    connection = await pool.getConnection();
    await connection.beginTransaction();
    await applyMigrations(connection, Array.isArray(metadata.migrations) ? metadata.migrations : [], metadata.toVersion);
    for (const item of files) {
      const relative = normalizeRelativePath(item.path);
      const entry = zip.getEntry(`payload/${relative}`);
      if (!entry || entry.isDirectory) throw new Error(`更新包缺少文件：${relative}`);
      const data = entry.getData();
      const digest = crypto.createHash("sha256").update(data).digest("hex");
      if (!item.sha256 || digest !== String(item.sha256).toLowerCase()) throw new Error(`文件校验失败：${relative}`);
      const destination = path.join(APP_ROOT, relative);
      fs.mkdirSync(path.dirname(destination), { recursive: true });
      const temporary = `${destination}.${process.pid}.update`;
      fs.writeFileSync(temporary, data);
      fs.renameSync(temporary, destination);
    }
    for (const relativeInput of deletedFiles) {
      const destination = path.join(APP_ROOT, normalizeRelativePath(relativeInput));
      if (fs.existsSync(destination)) fs.rmSync(destination, { recursive: true, force: true });
    }
    const changedBackendJs = files.map(item => normalizeRelativePath(item.path)).filter(item => item.startsWith("backend-后端/") && item.endsWith(".js"));
    for (const relative of changedBackendJs) {
      const checked = spawnSync(process.execPath, ["--check", path.join(APP_ROOT, relative)], { encoding: "utf8" });
      if (checked.status !== 0) throw new Error(`更新文件语法检查失败：${relative}`);
    }
    await connection.commit();
    connection.release();
    connection = null;
    const restartRequired = metadata.restartRequired !== false || files.some(item => String(item.path).startsWith("backend-后端/"));
    const nextState = { ...state, status: restartRequired ? "pending_restart" : "completed", appliedAt: toChinaIsoString(), restartRequired, historyId, fileBackupPath };
    writeJsonAtomic(STATE_FILE, nextState);
    await pool.execute("UPDATE system_update_history SET status=?, message=?, completed_at=NOW() WHERE id=?", [nextState.status, restartRequired ? "更新文件已安装，等待重启服务" : "更新完成", historyId]);
    return nextState;
  } catch (error) {
    if (connection) { try { await connection.rollback(); } catch {} try { connection.release(); } catch {} }
    if (fileBackupPath && journal.length) { try { restoreFileBackup(fileBackupPath, journal); } catch {} }
    if (historyId) await pool.execute("UPDATE system_update_history SET status='failed', message=?, completed_at=NOW() WHERE id=?", [String(error.message || error), historyId]).catch(() => {});
    throw error;
  } finally {
    releaseLock();
  }
}

async function rollbackLastUpdate(operator = {}) {
  acquireLock();
  try {
    await ensureSchema();
    const [rows] = await pool.query("SELECT * FROM system_update_history WHERE status IN ('pending_restart','completed') ORDER BY id DESC LIMIT 1");
    const row = rows[0];
    if (!row) throw new Error("没有可回滚的更新记录");
    let details = row.details_json || {};
    if (typeof details === "string") details = JSON.parse(details || "{}");
    const backupPath = details.fileBackupPath;
    const backup = readJson(path.join(backupPath || "", "journal.json"), null);
    if (!backup) throw new Error("更新文件备份不存在，无法回滚");
    restoreFileBackup(backupPath, backup.journal || []);
    await pool.execute("UPDATE system_update_history SET status='rolled_back', message=?, completed_at=NOW() WHERE id=?", [`由 ${operator.realName || operator.username || "管理员"} 执行代码回滚；数据库新增结构保留`, row.id]);
    writeJsonAtomic(STATE_FILE, { status: "pending_restart", currentVersion: row.to_version, latestVersion: row.from_version, restartRequired: true, rolledBackAt: toChinaIsoString() });
    return { fromVersion: row.to_version, toVersion: row.from_version, restartRequired: true };
  } finally { releaseLock(); }
}

async function getOverview() {
  await ensureSchema();
  const currentVersion = getVersionInfo().systemVersion;
  const savedState = readJson(STATE_FILE, { status: "idle" });
  if (savedState.status === "pending_restart" && String(savedState.latestVersion || "") === currentVersion) {
    savedState.status = "completed";
    savedState.restartRequired = false;
    savedState.completedAt = toChinaIsoString();
    writeJsonAtomic(STATE_FILE, savedState);
    if (savedState.historyId) {
      await pool.execute("UPDATE system_update_history SET status='completed', message='服务已重启，更新完成', completed_at=NOW() WHERE id=? AND status='pending_restart'", [savedState.historyId]);
    }
  }
  const [historyRows] = await pool.query("SELECT id,from_version AS fromVersion,to_version AS toVersion,status,update_type AS updateType,changed_files AS changedFiles,deleted_files AS deletedFiles,operator_name AS operatorName,message,details_json AS details,started_at AS startedAt,completed_at AS completedAt FROM system_update_history ORDER BY id DESC LIMIT 30");
  const history = historyRows.map(row => {
    let details = row.details || {};
    if (typeof details === "string") { try { details = JSON.parse(details || "{}"); } catch { details = {}; } }
    const { details: _privateDetails, ...safeRow } = row;
    return { ...safeRow, changelog: Array.isArray(details.changelog) ? details.changelog : [] };
  });
  return {
    version: getVersionInfo(),
    runtime: { node: process.version, platform: `${os.platform()} ${os.arch()}`, uptimeSeconds: Math.floor(process.uptime()), pid: process.pid, managedByPm2: Boolean(process.env.pm_id), environment: process.env.NODE_ENV || "development" },
    config: readConfig(),
    state: sanitizePublicUpdateState(savedState),
    history
  };
}

function sanitizePublicPackage(item) {
  if (!item || typeof item !== "object") return item;
  const { url, urls, ...safe } = item;
  return safe;
}

function sanitizePublicManifest(manifest) {
  if (!manifest || typeof manifest !== "object") return manifest;
  const safe = { ...manifest };
  if (Array.isArray(safe.packages)) safe.packages = safe.packages.map(sanitizePublicPackage);
  if (safe.package) safe.package = sanitizePublicPackage(safe.package);
  delete safe.signature;
  return safe;
}

function sanitizePublicUpdateState(state) {
  if (!state || typeof state !== "object") return state;
  const {
    sourceUsed,
    sourceUrl,
    sourceErrors,
    downloadUrl,
    downloadErrors,
    packagePath,
    fileBackupPath,
    ...safe
  } = state;
  if (safe.manifest) safe.manifest = sanitizePublicManifest(safe.manifest);
  if (safe.selectedPackage) safe.selectedPackage = sanitizePublicPackage(safe.selectedPackage);
  return safe;
}

let schedulerTimer = null;
let schedulerRunning = false;
async function tickScheduler() {
  if (schedulerRunning) return;
  const config = readConfig();
  if (!config.autoCheck) return;
  const last = config.lastCheckedAt ? new Date(config.lastCheckedAt).getTime() : 0;
  if (last && Date.now() - last < Number(config.checkIntervalHours || 24) * 3600000) return;
  schedulerRunning = true;
  try {
    const result = await checkForUpdates();
    if (result.status === "available" && config.autoDownload) await downloadUpdate();
  } catch (error) {
    console.warn("[系统更新自动检查失败]", error?.message || error);
  } finally { schedulerRunning = false; }
}

function startUpdateScheduler() {
  if (schedulerTimer) return;
  schedulerTimer = setInterval(() => tickScheduler().catch(() => {}), 30 * 60 * 1000);
  setTimeout(() => tickScheduler().catch(() => {}), 15000);
  console.log("[系统更新] 自动检查调度已启动");
}

module.exports = { INDEX_FORMAT, PACKAGE_FORMAT, getVersionInfo, readConfig, saveConfig, ensureSchema, compareVersions, canonicalize, checkForUpdates, downloadUpdate, applyUpdate, rollbackLastUpdate, getOverview, sanitizePublicUpdateState, startUpdateScheduler };
