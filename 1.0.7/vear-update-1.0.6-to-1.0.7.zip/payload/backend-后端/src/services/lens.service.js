const { pool } = require("../config/db");
const { createTables } = require("../install/schema");

const DEFAULT_LENSES = [
  ["普通单光镜片", "通用", "单光", "1.56", "树脂", "基础加硬膜", ["日常矫正"], "儿童、成人"],
  ["非球面单光镜片", "通用", "单光", "1.60", "树脂", "耐磨增透膜", ["视野清晰", "轻薄"], "儿童、成人"],
  ["超薄非球面镜片", "通用", "单光", "1.67", "树脂", "耐磨增透膜", ["高度近视", "轻薄"], "中高度近视人群"],
  ["超高折射率镜片", "通用", "单光", "1.74", "树脂", "耐磨增透膜", ["高度近视", "超薄"], "高度近视人群"],
  ["防蓝光单光镜片", "通用", "防蓝光", "1.60", "树脂", "防蓝光膜", ["防蓝光", "日常矫正"], "学生、电子设备使用者"],
  ["儿童离焦防控镜片", "通用", "离焦防控", "1.60", "树脂", "耐磨增透膜", ["近视防控", "周边离焦"], "近视儿童、青少年"],
  ["青少年近视管理镜片", "通用", "近视防控", "1.67", "树脂", "耐磨增透膜", ["近视管理", "轻薄"], "中高度近视青少年"],
  ["抗疲劳镜片", "通用", "抗疲劳", "1.60", "树脂", "防蓝光增透膜", ["缓解视疲劳", "近用辅助"], "学生、办公人群"],
  ["渐进多焦点镜片", "通用", "渐进多焦点", "1.60", "树脂", "耐磨增透膜", ["远中近连续视野", "老视矫正"], "中老年人群"],
  ["成人老花镜片", "通用", "老花", "1.56", "树脂", "基础加硬膜", ["近用阅读", "老视矫正"], "老视人群"],
  ["智能变色镜片", "通用", "变色", "1.60", "树脂", "变色膜", ["室内外变色", "紫外线防护"], "户外活动人群"],
  ["偏光太阳镜片", "通用", "偏光", "1.56", "树脂", "偏光膜", ["防眩光", "紫外线防护"], "驾驶、户外人群"],
  ["驾驶型镜片", "通用", "驾驶", "1.60", "树脂", "减反射膜", ["夜间减反光", "提升对比度"], "驾驶人群"],
  ["运动防护镜片", "通用", "运动防护", "1.59", "PC", "耐冲击膜", ["抗冲击", "轻量"], "儿童、运动人群"],
  ["室内办公镜片", "通用", "办公", "1.60", "树脂", "防蓝光增透膜", ["中近距离优化", "缓解视疲劳"], "长期办公人群"],
  ["双光镜片", "通用", "双光", "1.56", "树脂", "基础加硬膜", ["远近双区", "老视矫正"], "中老年人群"],
];

let schemaPromise = null;

function ensureLensSchema() {
  if (!schemaPromise) {
    schemaPromise = createTables(pool).catch((error) => {
      schemaPromise = null;
      throw error;
    });
  }
  return schemaPromise;
}

function normalizeFeatureTags(value) {
  const items = Array.isArray(value) ? value : String(value || "").split(/[,，|、]/);
  return Array.from(new Set(items.map((item) => String(item || "").trim()).filter(Boolean))).slice(0, 12);
}

function tagsToDb(value) {
  return normalizeFeatureTags(value).join(",");
}

function formatLens(row) {
  if (!row) return null;
  return {
    id: Number(row.id),
    storeId: row.store_id == null ? null : Number(row.store_id),
    storeName: row.store_name || "",
    isSystem: Number(row.is_system || 0) === 1,
    lensName: row.lens_name || "",
    brand: row.brand || "",
    seriesModel: row.series_model || "",
    category: row.category || "",
    refractiveIndex: row.refractive_index || "",
    material: row.material || "",
    coating: row.coating || "",
    featureTags: normalizeFeatureTags(row.feature_tags),
    featureText: normalizeFeatureTags(row.feature_tags).join("、"),
    applicablePeople: row.applicable_people || "",
    referencePrice: row.reference_price == null ? null : Number(row.reference_price),
    status: Number(row.status || 0),
    sortOrder: Number(row.sort_order || 0),
    remark: row.remark || "",
    createdAt: row.created_at || null,
    updatedAt: row.updated_at || null,
  };
}

async function resolveLensSnapshot(connection, lensId, customerStoreId) {
  const id = Number(lensId || 0);
  if (!id) return null;
  const [rows] = await connection.query(
    `SELECT * FROM lens_catalog
     WHERE id = ? AND status = 1 AND (is_system = 1 OR store_id = ?)
     LIMIT 1`,
    [id, Number(customerStoreId || 0)],
  );
  if (!rows.length) {
    const error = new Error("所选镜片不存在、已停用或不属于客户门店");
    error.status = 400;
    error.code = "LENS_UNAVAILABLE";
    throw error;
  }
  const lens = formatLens(rows[0]);
  return {
    id: lens.id,
    brand: lens.brand,
    name: lens.lensName,
    refractiveIndex: lens.refractiveIndex,
    features: lens.featureText,
  };
}

async function ensureDefaultLensSeed() {
  await ensureLensSchema();
  const connection = await pool.getConnection();
  try {
    await connection.query(`
      CREATE TABLE IF NOT EXISTS system_seed_history (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        seed_key varchar(100) NOT NULL,
        status varchar(30) NOT NULL DEFAULT 'applied',
        details_json text DEFAULT NULL,
        applied_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_system_seed_history_key (seed_key)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);
    await connection.beginTransaction();
    const [marker] = await connection.execute(
      "INSERT IGNORE INTO system_seed_history (seed_key, status) VALUES (?, 'running')",
      ["default-lens-catalog-v1"],
    );
    if (!Number(marker.affectedRows || 0)) {
      await connection.rollback();
      return { applied: false, inserted: 0 };
    }
    let inserted = 0;
    for (let index = 0; index < DEFAULT_LENSES.length; index += 1) {
      const [name, brand, category, refractiveIndex, material, coating, features, applicablePeople] = DEFAULT_LENSES[index];
      const [exists] = await connection.execute(
        "SELECT id FROM lens_catalog WHERE is_system = 1 AND lens_name = ? AND refractive_index = ? LIMIT 1",
        [name, refractiveIndex],
      );
      if (exists.length) continue;
      await connection.execute(
        `INSERT INTO lens_catalog
         (store_id, is_system, lens_name, brand, category, refractive_index, material, coating, feature_tags, applicable_people, status, sort_order, remark)
         VALUES (NULL, 1, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`,
        [name, brand, category, refractiveIndex, material, coating, tagsToDb(features), applicablePeople, index + 1, "系统预置模板，可复制为门店镜片后修改"],
      );
      inserted += 1;
    }
    await connection.execute(
      "UPDATE system_seed_history SET status = 'applied', details_json = ?, applied_at = NOW() WHERE seed_key = ?",
      [JSON.stringify({ inserted, total: DEFAULT_LENSES.length }), "default-lens-catalog-v1"],
    );
    await connection.commit();
    return { applied: true, inserted };
  } catch (error) {
    try { await connection.rollback(); } catch {}
    throw error;
  } finally {
    connection.release();
  }
}

module.exports = {
  DEFAULT_LENSES,
  ensureLensSchema,
  ensureDefaultLensSeed,
  normalizeFeatureTags,
  tagsToDb,
  formatLens,
  resolveLensSnapshot,
};
