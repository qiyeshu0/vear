const fs = require("fs");
const path = require("path");
const multer = require("multer");
const { pool, getDbConfig } = require("../config/db");
const { toInt, normalizePage } = require("../utils/pagination");
const { buildStoreScope } = require("../utils/store-scope");
const {
  ROLE_ADMIN,
  CUSTOMER_STATUS,
  FILE_UPLOAD,
} = require("../config/constants");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { writeOperationLog } = require("../utils/operation-log");
const { notifyGlassesStatusWx } = require("../services/notification.service");
const { formatDateYmd, parseDateYmd, compareDateYmd } = require("../utils/date");
const { getLowTimesThreshold } = require("../utils/system-settings");
const { createTables } = require("../install/schema");
const {
  getCustomerCardsMap,
  getActiveCustomerCards,
  createCustomerCardRecord,
  syncCustomerCardSnapshot,
} = require("../utils/customer-card");
const customerService = require("../services/customer.service");
const { syncVisitFromVerification } = require("../services/visit.service");
const { resolveLensSnapshot } = require("../services/lens.service");


const {
  parseTags, isValidPhone, tagsToDbString, dbStringToTags, buildCustomerNo,
  normalizeCustomerMode, hasCustomerCard, normalizeOptionalText, normalizeRemarkText,
  normalizeSalePrice, buildEyeProfilePayload, buildVisitCheckPayload, buildGlassesRecordPayload,
  buildCurrentGlassesSummary, formatCustomer, formatAttachment, formatFollowUpRecord,
  formatVisitCheckRecord, formatGlassesRecord, formatTimelineEvent,
  getCustomerById, upsertCustomerEyeProfile, resolveCardPayload,
  GLASSES_FLOW_STATUS, GLASSES_FLOW_STATUS_OPTIONS, normalizeGlassesStatus, getGlassesStatusLabel,
  CUSTOMER_MODE_ACCOUNT_ONLY, CUSTOMER_MODE_ACCOUNT_AND_CARD,
} = customerService;

const UPLOAD_ROOT = path.join(__dirname, "..", "uploads", "customer_attach");

if (!fs.existsSync(UPLOAD_ROOT)) {
  fs.mkdirSync(UPLOAD_ROOT, { recursive: true });
}

let schemaReadyPromise = null;
let schemaReadySignature = "";

function ensureCustomerSchema() {
  const nextSignature = JSON.stringify(getDbConfig());

  if (!schemaReadyPromise || schemaReadySignature !== nextSignature) {
    schemaReadySignature = nextSignature;
    schemaReadyPromise = createTables(pool).catch((error) => {
      schemaReadyPromise = null;
      schemaReadySignature = "";
      throw error;
    });
  }

  return schemaReadyPromise;
}












function generateVerifyNo(prefix = "HX") {
  const now = new Date();
  return prefix +
    now.getFullYear() +
    `${now.getMonth() + 1}`.padStart(2, "0") +
    `${now.getDate()}`.padStart(2, "0") +
    `${now.getHours()}`.padStart(2, "0") +
    `${now.getMinutes()}`.padStart(2, "0") +
    `${now.getSeconds()}`.padStart(2, "0") +
    `${now.getMilliseconds()}`.padStart(3, "0") +
    `${Math.floor(Math.random() * 90000) + 10000}`;
}

async function insertVerifyRecordWithRetry(connection, payload = {}, maxRetries = 3) {
  let lastError = null;

  for (let attempt = 0; attempt < maxRetries; attempt += 1) {
    const verifyNo = generateVerifyNo("HX");

    try {
      const [insertResult] = await connection.execute(
        `
          INSERT INTO verify_records
          (verify_no, customer_id, customer_card_id, store_id, child_name, training_project,
           card_name, card_sale_price, verify_date, verify_time, operator_id, operator_name, remark)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [
          verifyNo,
          payload.customerId,
          payload.customerCardId || null,
          payload.storeId,
          payload.childName,
          payload.trainingProject,
          payload.cardName || null,
          payload.cardSalePrice ?? null,
          payload.verifyDate,
          payload.verifyTime,
          payload.operatorId,
          payload.operatorName,
          payload.remark || null,
        ],
      );

      return { verifyNo, insertResult };
    } catch (error) {
      lastError = error;
      if (error && error.code === "ER_DUP_ENTRY") {
        continue;
      }
      throw error;
    }
  }

  throw lastError || new Error("创建核销单号失败");
}

function normalizeUsageQuantity(value, defaultValue = 1) {
  const num = Number(value);
  if (!Number.isFinite(num) || num <= 0) {
    return defaultValue;
  }
  return Math.max(1, Math.trunc(num));
}

function formatGlassesStatusLog(row) {
  if (!row) return null;
  return {
    id: Number(row.id || 0),
    glassesRecordId: Number(row.glasses_record_id || 0),
    customerId: Number(row.customer_id || 0),
    fromStatus: row.from_status == null ? null : normalizeGlassesStatus(row.from_status),
    fromStatusLabel: row.from_status == null ? "" : getGlassesStatusLabel(row.from_status),
    toStatus: normalizeGlassesStatus(row.to_status),
    toStatusLabel: getGlassesStatusLabel(row.to_status),
    remark: row.remark || "",
    operatorId: row.operator_id == null ? null : Number(row.operator_id || 0),
    operatorName: row.operator_name || "",
    createdAt: row.created_at || null,
  };
}

async function insertGlassesStatusLog(connection, payload = {}) {
  await connection.execute(
    `
      INSERT INTO customer_glasses_status_logs
      (glasses_record_id, customer_id, from_status, to_status, remark, operator_id, operator_name)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `,
    [
      Number(payload.glassesRecordId || 0),
      Number(payload.customerId || 0),
      payload.fromStatus == null ? null : normalizeGlassesStatus(payload.fromStatus),
      normalizeGlassesStatus(payload.toStatus),
      normalizeRemarkText(payload.remark, 500),
      payload.operatorId == null ? null : Number(payload.operatorId || 0),
      String(payload.operatorName || "").trim() || null,
    ],
  );
}


async function insertCustomerCardUsageLog(connection, payload = {}) {
  await connection.execute(
    `
      INSERT INTO customer_card_usage_logs
      (
        customer_card_id,
        customer_id,
        verify_record_id,
        action_type,
        quantity,
        before_used_times,
        after_used_times,
        remark,
        operator_id,
        operator_name
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
    [
      Number(payload.customerCardId || 0),
      Number(payload.customerId || 0),
      payload.verifyRecordId == null ? null : Number(payload.verifyRecordId),
      String(payload.actionType || "consume"),
      Number(payload.quantity || 1),
      Number(payload.beforeUsedTimes || 0),
      Number(payload.afterUsedTimes || 0),
      normalizeRemarkText(payload.remark, 500),
      Number(payload.operatorId || 0) || null,
      String(payload.operatorName || "").trim() || null,
    ],
  );
}













const storage = multer.diskStorage({
  destination(req, file, cb) {
    cb(null, UPLOAD_ROOT);
  },
  filename(req, file, cb) {
    const ext = path.extname(file.originalname || "").toLowerCase();
    const base = Date.now();
    const random = Math.floor(Math.random() * 100000);
    const customerName = String(req.customerName || "customer")
      .replace(/[\\\\/\\s]+/g, "_")
      .replace(/_+/g, "_")
      .slice(0, 30) || "customer";
    cb(null, `${customerName}_${base}_${random}${ext}`);
  },
});

function fileFilter(req, file, cb) {
  const ext = path
    .extname(file.originalname || "")
    .replace(".", "")
    .toLowerCase();
  const mimeType = String(file.mimetype || "").toLowerCase();

  const allowedExts = FILE_UPLOAD?.ALLOW_EXTENSIONS || [
    "jpg",
    "jpeg",
    "png",
    "gif",
    "webp",
    "pdf",
  ];
  const allowedMimes = FILE_UPLOAD?.ALLOW_MIME_TYPES || [
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
    "application/pdf",
  ];

  if (!allowedExts.includes(ext)) {
    return cb(new Error("文件扩展名不支持"));
  }

  if (!allowedMimes.includes(mimeType)) {
    return cb(new Error("文件类型不支持"));
  }

  return cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: Number(process.env.UPLOAD_MAX_SIZE || FILE_UPLOAD.DEFAULT_MAX_SIZE),
  },
});

function runMulter(req, res) {
  return new Promise((resolve, reject) => {
    upload.array("files", 10)(req, res, (error) => {
      if (error) {
        reject(error);
        return;
      }
      resolve(req.files || []);
    });
  });
}

async function getCustomerOptions(req, res, next) {
  try {
    await ensureCustomerSchema();
    const keyword = String(req.query.keyword || "").trim();
    const status =
      req.query.status === "" || req.query.status == null
        ? null
        : toInt(req.query.status, 1);
    const customerMode = normalizeCustomerMode(req.query.customerMode, "");

    const scope = buildStoreScope(req.user, "c.store_id");
    const where = [scope.sql];
    const params = [...scope.params];

    if (status === 0 || status === 1) {
      where.push("c.status = ?");
      params.push(status);
    }

    if (keyword) {
      where.push(
        "(c.child_name LIKE ? OR c.parent_phone LIKE ? OR c.training_project LIKE ?)",
      );
      params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
    }

    if (customerMode === CUSTOMER_MODE_ACCOUNT_ONLY) {
      where.push("c.has_card = 0");
    } else if (customerMode === CUSTOMER_MODE_ACCOUNT_AND_CARD) {
      where.push("c.has_card = 1");
    }

    const [rows] = await pool.query(
      `
        SELECT
          c.id,
          c.customer_no,
          c.child_name,
          c.parent_name,
          c.parent_phone,
          c.store_id,
          c.has_card,
          s.store_name,
          c.training_project,
          c.total_times,
          c.used_times,
          c.remaining_times,
          c.expire_date,
          c.status,
          c.tags
        FROM customers c
        LEFT JOIN stores s ON s.id = c.store_id
        WHERE ${where.join(" AND ")}
        ORDER BY c.child_name ASC, c.id DESC
        LIMIT 300
      `,
      params,
    );

    return sendSuccess(
      res,
      rows.map((row) => ({
        id: Number(row.id),
        customerNo: row.customer_no,
        childName: row.child_name,
        parentName: row.parent_name || "",
        parentPhone: row.parent_phone,
        storeId: Number(row.store_id || 0),
        storeName: row.store_name || "",
        hasCard: Number(row.has_card || 0) === 1,
        customerMode:
          Number(row.has_card || 0) === 1
            ? CUSTOMER_MODE_ACCOUNT_AND_CARD
            : CUSTOMER_MODE_ACCOUNT_ONLY,
        trainingProject: row.training_project,
        totalTimes: Number(row.total_times || 0),
        usedTimes: Number(row.used_times || 0),
        remainingTimes:
          Number(row.has_card || 0) !== 1
            ? 0
            :
          row.remaining_times == null
            ? Number(row.total_times || 0) - Number(row.used_times || 0)
            : Number(row.remaining_times || 0),
        expireDate: Number(row.has_card || 0) === 1 ? row.expire_date : null,
        status: Number(row.status || 0),
        tags: dbStringToTags(row.tags),
      })),
      "获取客户选项成功",
    );
  } catch (error) {
    next(error);
  }
}

async function getCustomerTags(req, res, next) {
  try {
    await ensureCustomerSchema();
    const scope = buildStoreScope(req.user, "c.store_id");

    const [rows] = await pool.query(
      `
        SELECT c.tags
        FROM customers c
        WHERE c.tags IS NOT NULL
          AND c.tags <> ''
          AND ${scope.sql}
      `,
      scope.params,
    );

    const tagMap = {};
    for (const row of rows) {
      const tags = dbStringToTags(row.tags);
      for (const tag of tags) {
        tagMap[tag] = (tagMap[tag] || 0) + 1;
      }
    }

    const list = Object.entries(tagMap)
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag, "zh-CN"));

    return sendSuccess(res, list, "获取标签成功");
  } catch (error) {
    next(error);
  }
}

async function getCustomerStats(req, res, next) {
  try {
    await ensureCustomerSchema();
    const lowTimesThreshold = await getLowTimesThreshold(pool);
    const scope = buildStoreScope(req.user, "c.store_id");

    const [[totalRow]] = await pool.query(
      `SELECT COUNT(*) AS total FROM customers c WHERE ${scope.sql}`,
      scope.params,
    );

    const [[activeRow]] = await pool.query(
      `SELECT COUNT(*) AS total FROM customers c WHERE c.status = 1 AND c.has_card = 1 AND ${scope.sql}`,
      scope.params,
    );

    const [[accountOnlyRow]] = await pool.query(
      `SELECT COUNT(*) AS total FROM customers c WHERE c.has_card = 0 AND ${scope.sql}`,
      scope.params,
    );

    const [[cardedRow]] = await pool.query(
      `SELECT COUNT(*) AS total FROM customers c WHERE c.has_card = 1 AND ${scope.sql}`,
      scope.params,
    );

    const [[expiredRow]] = await pool.query(
      `
        SELECT COUNT(*) AS total
        FROM customers c
        WHERE c.status = 1
          AND c.has_card = 1
          AND c.expire_date < CURDATE()
          AND ${scope.sql}
      `,
      scope.params,
    );

    const [[lowTimesRow]] = await pool.query(
      `
        SELECT COUNT(*) AS total
        FROM customers c
        WHERE c.status = 1
          AND c.has_card = 1
          AND c.remaining_times > 0
          AND c.remaining_times <= ?
          AND ${scope.sql}
      `,
      [lowTimesThreshold, ...scope.params],
    );

    return sendSuccess(
      res,
      {
        total: Number(totalRow.total || 0),
        active: Number(activeRow.total || 0),
        accountOnly: Number(accountOnlyRow.total || 0),
        carded: Number(cardedRow.total || 0),
        expired: Number(expiredRow.total || 0),
        lowTimes: Number(lowTimesRow.total || 0),
        lowTimesThreshold,
      },
      "获取客户统计成功",
    );
  } catch (error) {
    next(error);
  }
}

async function getCustomerList(req, res, next) {
  try {
    await ensureCustomerSchema();
    const { pageNum, pageSize, offset } = normalizePage(req.query);
    const keyword = String(req.query.keyword || "").trim();
    const status =
      req.query.status === "" || req.query.status == null
        ? null
        : toInt(req.query.status, -1);
    const storeId = toInt(req.query.storeId, 0);
    const tag = String(req.query.tag || "").trim();
    const customerMode = normalizeCustomerMode(req.query.customerMode, "");
    const startExpireDate = String(req.query.startExpireDate || "").trim();
    const endExpireDate = String(req.query.endExpireDate || "").trim();
    const alertType = String(req.query.alertType || req.query.warningType || "").trim();

    const where = [];
    const params = [];
    const scope = buildStoreScope(req.user, "c.store_id");

    where.push(scope.sql);
    params.push(...scope.params);

    if (Number(req.user.role) === ROLE_ADMIN && storeId > 0) {
      where.push("c.store_id = ?");
      params.push(storeId);
    }

    if (keyword) {
      where.push(
        "(c.customer_no LIKE ? OR c.child_name LIKE ? OR c.parent_name LIKE ? OR c.parent_phone LIKE ? OR c.training_project LIKE ?)",
      );
      params.push(
        `%${keyword}%`,
        `%${keyword}%`,
        `%${keyword}%`,
        `%${keyword}%`,
        `%${keyword}%`,
      );
    }

    if (status === 0 || status === 1) {
      where.push("c.status = ?");
      params.push(status);
    }

    if (tag) {
      where.push("c.tags LIKE ?");
      params.push(`%${tag}%`);
    }

    if (customerMode === CUSTOMER_MODE_ACCOUNT_ONLY) {
      where.push("c.has_card = 0");
    } else if (customerMode === CUSTOMER_MODE_ACCOUNT_AND_CARD) {
      where.push("c.has_card = 1");
    }

    if (startExpireDate) {
      where.push("c.has_card = 1");
      where.push("c.expire_date >= ?");
      params.push(startExpireDate);
    }

    if (endExpireDate) {
      where.push("c.has_card = 1");
      where.push("c.expire_date <= ?");
      params.push(endExpireDate);
    }

    if (alertType === "lowTimes") {
      const lowTimesThreshold = await getLowTimesThreshold(pool);
      where.push("c.status = 1");
      where.push("c.has_card = 1");
      where.push("c.remaining_times > 0");
      where.push("c.remaining_times <= ?");
      params.push(lowTimesThreshold);
    } else if (alertType === "expired") {
      where.push("c.status = 1");
      where.push("c.has_card = 1");
      where.push("c.expire_date < CURDATE()");
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const countSql = `
      SELECT COUNT(*) AS total
      FROM customers c
      ${whereSql}
    `;

    const listSql = `
      SELECT
        c.id,
        c.customer_no,
        c.child_name,
        c.gender,
        c.birthday,
        c.parent_name,
        c.parent_phone,
        c.store_id,
        c.has_card,
        s.store_name,
        c.training_project,
        c.total_times,
        c.used_times,
        c.remaining_times,
        c.open_card_date,
        c.expire_date,
        c.status,
        c.remark,
        c.tags,
        c.created_by,
        c.updated_by,
        c.created_at,
        c.updated_at
      FROM customers c
      LEFT JOIN stores s ON s.id = c.store_id
      ${whereSql}
      ORDER BY c.id DESC
      LIMIT ? OFFSET ?
    `;

    const [[countRow]] = await pool.query(countSql, params);
    const [rows] = await pool.query(listSql, [...params, pageSize, offset]);
    const cardMap = await getCustomerCardsMap(
      pool,
      rows.map((item) => item.id),
      { activeOnly: true },
    );
    const list = rows.map((row) => {
      const customer = formatCustomer(row);
      const cards = cardMap.get(Number(row.id || 0)) || [];
      customer.customerCards = cards;
      const currentMainCard = cards.find((item) => !item.isPromotion) || null;
      if (currentMainCard) {
        customer.currentCardId = currentMainCard.id;
        customer.currentCardName = currentMainCard.cardName;
        customer.currentCardSalePrice = currentMainCard.salePrice;
      }
      return customer;
    });

    return sendPage(
      res,
      list,
      Number(countRow.total || 0),
      pageNum,
      pageSize,
    );
  } catch (error) {
    next(error);
  }
}

async function getCustomerGlassesDeliveryList(req, res, next) {
  try {
    await ensureCustomerSchema();
    const { pageNum, pageSize, offset } = normalizePage(req.query);
    const keyword = String(req.query.keyword || "").trim();
    const storeId = toInt(req.query.storeId, 0);
    const deliveryStatus =
      req.query.deliveryStatus === "" || req.query.deliveryStatus == null
        ? 0
        : normalizeGlassesStatus(req.query.deliveryStatus, 0);
    const startDate = String(req.query.startDate || "").trim();
    const endDate = String(req.query.endDate || "").trim();

    const where = [];
    const params = [];
    const scope = buildStoreScope(req.user, "c.store_id");
    where.push(scope.sql);
    params.push(...scope.params);

    if (Number(req.user.role) === ROLE_ADMIN && storeId > 0) {
      where.push("c.store_id = ?");
      params.push(storeId);
    }

    if (keyword) {
      where.push("(c.customer_no LIKE ? OR c.child_name LIKE ? OR c.parent_name LIKE ? OR c.parent_phone LIKE ? OR g.lens_brand LIKE ? OR g.lens_type LIKE ? OR g.frame_info LIKE ?)");
      params.push(
        `%${keyword}%`,
        `%${keyword}%`,
        `%${keyword}%`,
        `%${keyword}%`,
        `%${keyword}%`,
        `%${keyword}%`,
        `%${keyword}%`,
      );
    }

    if (deliveryStatus) {
      where.push("g.delivery_status = ?");
      params.push(deliveryStatus);
    }

    if (startDate) {
      where.push("DATE(g.record_time) >= ?");
      params.push(startDate);
    }

    if (endDate) {
      where.push("DATE(g.record_time) <= ?");
      params.push(endDate);
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const [[countRow]] = await pool.query(
      `
        SELECT
          COUNT(*) AS total,
          COALESCE(SUM(CASE WHEN g.delivery_status IN (1, 2, 3, 4) THEN 1 ELSE 0 END), 0) AS pending,
          COALESCE(SUM(CASE WHEN g.delivery_status = 4 THEN 1 ELSE 0 END), 0) AS ready,
          COALESCE(SUM(CASE WHEN g.delivery_status = 5 THEN 1 ELSE 0 END), 0) AS delivered,
          COALESCE(SUM(CASE WHEN g.delivery_status IN (6, 7) THEN 1 ELSE 0 END), 0) AS exception_count
        FROM customer_glasses_records g
        INNER JOIN customers c ON c.id = g.customer_id
        LEFT JOIN stores s ON s.id = c.store_id
        ${whereSql}
      `,
      params,
    );

    const [rows] = await pool.query(
      `
        SELECT
          g.id,
          g.customer_id,
          g.record_time,
          g.source_check_id,
          g.delivery_status,
          g.pd,
          g.sphere_od,
          g.cylinder_od,
          g.axis_od,
          g.sphere_os,
          g.cylinder_os,
          g.axis_os,
          g.lens_brand,
          g.lens_type,
          g.lens_od_id,
          g.lens_od_brand,
          g.lens_od_name,
          g.lens_od_refractive_index,
          g.lens_od_features,
          g.lens_os_id,
          g.lens_os_brand,
          g.lens_os_name,
          g.lens_os_refractive_index,
          g.lens_os_features,
          g.frame_info,
          g.operator_id,
          g.operator_name,
          g.remark,
          g.created_at,
          c.customer_no,
          c.child_name,
          c.parent_name,
          c.parent_phone,
          c.store_id,
          c.status AS customer_status,
          s.store_name
        FROM customer_glasses_records g
        INNER JOIN customers c ON c.id = g.customer_id
        LEFT JOIN stores s ON s.id = c.store_id
        ${whereSql}
        ORDER BY
          CASE g.delivery_status
            WHEN ${GLASSES_FLOW_STATUS.READY} THEN 1
            WHEN ${GLASSES_FLOW_STATUS.PRODUCING} THEN 2
            WHEN ${GLASSES_FLOW_STATUS.CUSTOMIZING} THEN 3
            WHEN ${GLASSES_FLOW_STATUS.ORDERED} THEN 4
            WHEN ${GLASSES_FLOW_STATUS.EXCEPTION} THEN 5
            WHEN ${GLASSES_FLOW_STATUS.DELIVERED} THEN 6
            WHEN ${GLASSES_FLOW_STATUS.CANCELED} THEN 7
            ELSE 8
          END,
          g.record_time DESC,
          g.id DESC
        LIMIT ? OFFSET ?
      `,
      [...params, pageSize, offset],
    );

    const recordIds = rows.map((item) => Number(item.id || 0)).filter(Boolean);
    const logsMap = new Map();
    if (recordIds.length) {
      const placeholders = recordIds.map(() => "?").join(",");
      const [logRows] = await pool.query(
        `
          SELECT id, glasses_record_id, customer_id, from_status, to_status, remark, operator_id, operator_name, created_at
          FROM customer_glasses_status_logs
          WHERE glasses_record_id IN (${placeholders})
          ORDER BY created_at ASC, id ASC
        `,
        recordIds,
      );
      logRows.forEach((row) => {
        const key = Number(row.glasses_record_id || 0);
        if (!logsMap.has(key)) logsMap.set(key, []);
        logsMap.get(key).push(formatGlassesStatusLog(row));
      });
    }

    const list = rows.map((row) => ({
      ...formatGlassesRecord(row),
      customerId: Number(row.customer_id || 0),
      customerNo: row.customer_no || "",
      childName: row.child_name || "",
      parentName: row.parent_name || "",
      parentPhone: row.parent_phone || "",
      storeId: row.store_id == null ? null : Number(row.store_id || 0),
      storeName: row.store_name || "",
      customerStatus: Number(row.customer_status || 0),
      statusLogs: logsMap.get(Number(row.id || 0)) || [],
    }));

    return sendPage(
      res,
      list,
      Number(countRow.total || 0),
      pageNum,
      pageSize,
      {
        summary: {
          pending: Number(countRow.pending || 0),
          ready: Number(countRow.ready || 0),
          delivered: Number(countRow.delivered || 0),
          exception: Number(countRow.exception_count || 0),
        },
      },
    );
  } catch (error) {
    next(error);
  }
}

async function getCustomerDetail(req, res, next) {
  try {
    await ensureCustomerSchema();
    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "客户ID无效", 400);
    }

    const customer = await getCustomerById(id, req.user);
    if (!customer) {
      return sendFail(res, "客户不存在或无权限查看", 404);
    }

    const [attachments] = await pool.query(
      `
        SELECT
          id,
          customer_id,
          file_name,
          file_path,
          file_ext,
          file_size,
          mime_type,
          uploaded_by,
          created_at
        FROM customer_attachments
        WHERE customer_id = ?
        ORDER BY id DESC
      `,
      [id],
    );

    const [renewals] = await pool.query(
      `
        SELECT
          id,
          customer_id,
          customer_card_id,
          before_total_times,
          before_used_times,
          before_expire_date,
          add_times,
          after_total_times,
          after_expire_date,
          operator_id,
          operator_name,
          remark,
          created_at
        FROM customer_renewals
        WHERE customer_id = ?
        ORDER BY id DESC
      `,
      [id],
    );

    const [verifyRecords] = await pool.query(
      `
        SELECT
          id,
          verify_no,
          verify_date,
          verify_time,
          customer_card_id,
          card_name,
          card_sale_price,
          revoked,
          revoked_at,
          revoked_by,
          revoked_by_name,
          revoke_reason,
          operator_id,
          operator_name,
          remark,
          created_at
        FROM verify_records
        WHERE customer_id = ?
        ORDER BY verify_time DESC, id DESC
      `,
      [id],
    );

    const [followUpRecords] = await pool.query(
      `
        SELECT
          id,
          customer_id,
          record_time,
          result,
          content,
          operator_id,
          operator_name,
          remark,
          created_at
        FROM customer_follow_ups
        WHERE customer_id = ?
        ORDER BY record_time DESC, id DESC
      `,
      [id],
    );

    const [visitCheckRecords] = await pool.query(
      `
        SELECT
          id,
          customer_id,
          check_time,
          check_result,
          naked_vision_od,
          naked_vision_os,
          corrected_vision_od,
          corrected_vision_os,
          pd,
          exam_sphere_od,
          exam_cylinder_od,
          exam_axis_od,
          exam_sphere_os,
          exam_cylinder_os,
          exam_axis_os,
          recommended_sphere_od,
          recommended_cylinder_od,
          recommended_axis_od,
          recommended_sphere_os,
          recommended_cylinder_os,
          recommended_axis_os,
          suggestion,
          operator_id,
          operator_name,
          remark,
          created_at
        FROM customer_visit_checks
        WHERE customer_id = ?
        ORDER BY check_time DESC, id DESC
      `,
      [id],
    );

    const [glassesRecords] = await pool.query(
      `
        SELECT
          id,
          customer_id,
          record_time,
          source_check_id,
          delivery_status,
          pd,
          sphere_od,
          cylinder_od,
          axis_od,
          sphere_os,
          cylinder_os,
          axis_os,
          lens_brand,
          lens_type,
          lens_od_id,
          lens_od_brand,
          lens_od_name,
          lens_od_refractive_index,
          lens_od_features,
          lens_os_id,
          lens_os_brand,
          lens_os_name,
          lens_os_refractive_index,
          lens_os_features,
          frame_info,
          operator_id,
          operator_name,
          remark,
          created_at
        FROM customer_glasses_records
        WHERE customer_id = ?
        ORDER BY record_time DESC, id DESC
      `,
      [id],
    );

    const glassesRecordIds = glassesRecords.map((item) => Number(item.id || 0)).filter(Boolean);
    let glassesStatusLogs = [];
    if (glassesRecordIds.length) {
      const [rows] = await pool.query(
        `
          SELECT
            id,
            glasses_record_id,
            customer_id,
            from_status,
            to_status,
            remark,
            operator_id,
            operator_name,
            created_at
          FROM customer_glasses_status_logs
          WHERE glasses_record_id IN (${glassesRecordIds.map(() => "?").join(",")})
          ORDER BY created_at ASC, id ASC
        `,
        glassesRecordIds,
      );
      glassesStatusLogs = rows;
    }

    const [statusLogs] = await pool.query(
      `
        SELECT
          id,
          action,
          content,
          operator_name,
          created_at
        FROM operation_logs
        WHERE module = 'customer'
          AND biz_type = 'customer'
          AND action = 'update_status'
          AND biz_id = ?
        ORDER BY created_at DESC, id DESC
      `,
      [id],
    );

    const [activityCardUsageLogs] = await pool.query(
      `
        SELECT
          l.id,
          l.customer_card_id,
          l.customer_id,
          l.action_type,
          l.quantity,
          l.before_used_times,
          l.after_used_times,
          l.remark,
          l.operator_id,
          l.operator_name,
          l.created_at,
          cc.card_name_snapshot,
          cc.sale_price
        FROM customer_card_usage_logs l
        INNER JOIN customer_cards cc ON cc.id = l.customer_card_id
        WHERE l.customer_id = ?
        ORDER BY l.created_at DESC, l.id DESC
      `,
      [id],
    );

    const customerCardsMap = await getCustomerCardsMap(pool, [id]);
    const customerCards = customerCardsMap.get(id) || [];

    const formattedRenewals = renewals.map((item) => ({
      id: Number(item.id),
      customerId: Number(item.customer_id),
      customerCardId: Number(item.customer_card_id || 0) || null,
      beforeTotalTimes: Number(item.before_total_times || 0),
      beforeUsedTimes: Number(item.before_used_times || 0),
      beforeExpireDate: item.before_expire_date,
      addTimes: Number(item.add_times || 0),
      afterTotalTimes: Number(item.after_total_times || 0),
      afterExpireDate: item.after_expire_date,
      operatorId: Number(item.operator_id || 0),
      operatorName: item.operator_name || "",
      remark: item.remark || "",
      createdAt: item.created_at,
    }));

    const formattedVerifyRecords = verifyRecords.map((item) => ({
      id: Number(item.id),
      verifyNo: item.verify_no || "",
      verifyDate: item.verify_date,
      verifyTime: item.verify_time,
      customerCardId: Number(item.customer_card_id || 0) || null,
      cardName: item.card_name || "",
      cardSalePrice:
        item.card_sale_price == null ? null : Number(item.card_sale_price),
      revoked: Number(item.revoked || 0) === 1,
      revokedAt: item.revoked_at || null,
      revokedBy: Number(item.revoked_by || 0),
      revokedByName: item.revoked_by_name || "",
      revokeReason: item.revoke_reason || "",
      operatorId: Number(item.operator_id || 0),
      operatorName: item.operator_name || "",
      remark: item.remark || "",
      createdAt: item.created_at,
    }));

    const formattedFollowUpRecords = followUpRecords.map(formatFollowUpRecord);
    const formattedVisitCheckRecords = visitCheckRecords.map(formatVisitCheckRecord);
    const glassesStatusLogMap = new Map();
    for (const log of glassesStatusLogs) {
      const recordId = Number(log.glasses_record_id || 0);
      if (!glassesStatusLogMap.has(recordId)) glassesStatusLogMap.set(recordId, []);
      glassesStatusLogMap.get(recordId).push(formatGlassesStatusLog(log));
    }
    const formattedGlassesRecords = glassesRecords.map((item) => ({
      ...formatGlassesRecord(item),
      statusLogs: glassesStatusLogMap.get(Number(item.id || 0)) || [],
    }));
    const formattedActivityCardUsageLogs = activityCardUsageLogs.map((item) => ({
      id: Number(item.id),
      customerCardId: Number(item.customer_card_id || 0),
      customerId: Number(item.customer_id || 0),
      actionType: item.action_type || "consume",
      quantity: Number(item.quantity || 1),
      beforeUsedTimes: Number(item.before_used_times || 0),
      afterUsedTimes: Number(item.after_used_times || 0),
      remark: item.remark || "",
      operatorId: Number(item.operator_id || 0),
      operatorName: item.operator_name || "",
      cardName: item.card_name_snapshot || "",
      salePrice: item.sale_price == null ? null : Number(item.sale_price),
      createdAt: item.created_at,
    }));
    const latestDeliveredGlassesRecord =
      formattedGlassesRecords.find((item) => item.deliveryStatus === GLASSES_FLOW_STATUS.DELIVERED) ||
      formattedGlassesRecords[0] ||
      null;
    const currentGlasses = buildCurrentGlassesSummary(
      formatCustomer(customer).eyeProfile,
      latestDeliveredGlassesRecord,
    );

    const timeline = [
      formatTimelineEvent({
        id: `account-${customer.id}`,
        type: "account_open",
        title: "客户开户",
        description: "已创建客户档案",
        createdAt: customer.created_at,
        status: customer.status,
        meta: {
          hasCard: hasCustomerCard(customer),
        },
      }),
      ...(customerCards.length
        ? [
            ...customerCards.map((item) =>
              formatTimelineEvent({
                id: `open-${item.id}`,
                type: "open_card",
                title: "客户开卡",
                description: `${item.cardName}，${item.totalTimes} 次${item.salePrice != null ? `，成交价 ¥${item.salePrice}` : ""}`,
                createdAt: item.openCardDate || item.createdAt,
                status: customer.status,
                meta: {
                  cardName: item.cardName,
                  totalTimes: item.totalTimes,
                  expireDate: item.expireDate,
                  trainingProject: item.trainingProject || "",
                  salePrice: item.salePrice,
                },
              }),
            ),
          ]
        : hasCustomerCard(customer)
        ? [
            formatTimelineEvent({
              id: `open-${customer.id}`,
              type: "open_card",
              title: "客户开卡",
              description: `开卡建档，项目：${customer.training_project}，总次数：${customer.total_times}，到期日：${customer.expire_date}`,
              createdAt: customer.open_card_date || customer.created_at,
              status: customer.status,
              meta: {
                totalTimes: Number(customer.total_times || 0),
                expireDate: customer.expire_date,
                trainingProject: customer.training_project || "",
              },
            }),
          ]
        : []),
      
      ...formattedRenewals.map((item) =>
        formatTimelineEvent({
          id: `renew-${item.id}`,
          type: "renew",
          title: "客户续卡",
          description: `增加 ${item.addTimes} 次，到期日调整为 ${item.afterExpireDate}`,
          operatorName: item.operatorName,
          createdAt: item.createdAt,
          meta: {
            addTimes: item.addTimes,
            beforeExpireDate: item.beforeExpireDate,
            afterExpireDate: item.afterExpireDate,
          },
        }),
      ),
      ...formattedVerifyRecords.map((item) =>
        formatTimelineEvent({
          id: `verify-${item.id}`,
          type: "verify",
          title: item.revoked ? "核销记录" : "核销完成",
          description: `核销单号：${item.verifyNo}`,
          operatorName: item.operatorName,
          createdAt: item.verifyTime || item.createdAt,
          meta: {
            verifyNo: item.verifyNo,
            verifyDate: item.verifyDate,
            remark: item.remark || "",
            revoked: item.revoked,
            revokedAt: item.revokedAt,
            revokeReason: item.revokeReason || "",
          },
        }),
      ),
      ...formattedVerifyRecords
        .filter((item) => item.revoked && item.revokedAt)
        .map((item) =>
          formatTimelineEvent({
            id: `verify-revoke-${item.id}`,
            type: "verify_revoke",
            title: "撤回核销",
            description: `撤回核销单号：${item.verifyNo}${item.revokeReason ? `，原因：${item.revokeReason}` : ""}`,
            operatorName: item.revokedByName || item.operatorName,
            createdAt: item.revokedAt || item.createdAt,
            meta: {
              verifyNo: item.verifyNo,
              revokeReason: item.revokeReason || "",
            },
          }),
        ),
      ...formattedFollowUpRecords.map((item) =>
        formatTimelineEvent({
          id: `follow-up-${item.id}`,
          type: "follow_up",
          title: "客户回访",
          description: `${item.result}${item.content ? `：${item.content}` : ""}`,
          operatorName: item.operatorName,
          createdAt: item.recordTime || item.createdAt,
          meta: {
            result: item.result,
            content: item.content,
            remark: item.remark || "",
          },
        }),
      ),
      ...formattedVisitCheckRecords.map((item) =>
        formatTimelineEvent({
          id: `visit-check-${item.id}`,
          type: "visit_check",
          title: "到店检查",
          description: item.checkResult || "已记录到店检查",
          operatorName: item.operatorName,
          createdAt: item.checkTime || item.createdAt,
          meta: {
            checkResult: item.checkResult,
            suggestion: item.suggestion || "",
            remark: item.remark || "",
          },
        }),
      ),
      ...formattedGlassesRecords.map((item) =>
        formatTimelineEvent({
          id: `glasses-${item.id}`,
          type: "glasses_record",
          title: item.deliveryStatus === GLASSES_FLOW_STATUS.DELIVERED ? "配镜交付" : `配镜进度：${item.deliveryStatusLabel || getGlassesStatusLabel(item.deliveryStatus)}`,
          description: [
            item.lensBrand || item.lensType
              ? `镜片：${[item.lensBrand, item.lensType].filter(Boolean).join(" / ")}`
              : "",
            item.frameInfo ? `镜架：${item.frameInfo}` : "",
          ]
            .filter(Boolean)
            .join("，") || "已记录配镜参数",
          operatorName: item.operatorName,
          createdAt: item.recordTime || item.createdAt,
          meta: {
            deliveryStatus: item.deliveryStatus,
            deliveryStatusLabel: item.deliveryStatusLabel || getGlassesStatusLabel(item.deliveryStatus),
            pd: item.pd || "",
            remark: item.remark || "",
          },
        }),
      ),
      ...statusLogs.map((item) =>
        formatTimelineEvent({
          id: `status-${item.id}`,
          type: "status_change",
          title: "状态变更",
          description: item.content || "客户状态已变更",
          operatorName: item.operator_name || "",
          createdAt: item.created_at,
        }),
      ),
    ].sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

    const formattedCustomer = formatCustomer(customer);
    formattedCustomer.customerCards = customerCards;
    const currentMainCard = customerCards.find((item) => !item.isPromotion) || null;
    if (currentMainCard) {
      formattedCustomer.currentCardId = currentMainCard.id;
      formattedCustomer.currentCardName = currentMainCard.cardName;
      formattedCustomer.currentCardSalePrice = currentMainCard.salePrice;
    }

    return sendSuccess(
      res,
      {
        ...formattedCustomer,
        attachments: attachments.map(formatAttachment),
        currentCard: currentMainCard,
        customerCards,
        activityCardUsageLogs: formattedActivityCardUsageLogs,
        renewals: formattedRenewals,
        verifyRecords: formattedVerifyRecords,
        followUpRecords: formattedFollowUpRecords,
        visitCheckRecords: formattedVisitCheckRecords,
        glassesRecords: formattedGlassesRecords,
        currentGlasses,
        timeline,
      },
      "获取客户详情成功",
    );
  } catch (error) {
    next(error);
  }
}

async function createCustomer(req, res, next) {
  const connection = await pool.getConnection();

  try {
    await ensureCustomerSchema();
    const user = req.user;

    const childName = String(req.body.childName || "").trim();
    const gender =
      req.body.gender === "" || req.body.gender == null
        ? null
        : toInt(req.body.gender, 0);
    const birthdayRaw = String(req.body.birthday || "").trim();
    const birthday = birthdayRaw ? parseDateYmd(birthdayRaw) : null;
    const parentName = String(req.body.parentName || "").trim();
    const parentPhone = String(req.body.parentPhone || "").trim();
    const customerMode = normalizeCustomerMode(
      req.body.customerMode,
      CUSTOMER_MODE_ACCOUNT_AND_CARD,
    );
    const hasCard = customerMode === CUSTOMER_MODE_ACCOUNT_AND_CARD;
    const cardPayload = hasCard
      ? await resolveCardPayload(connection, req.body)
      : null;
    const trainingProject = cardPayload?.trainingProject || "";
    const totalTimes = cardPayload?.totalTimes || 0;
    const cardTemplateId = cardPayload?.cardTemplateId || null;
    const cardName = cardPayload?.cardName || "";
    const salePrice = cardPayload?.salePrice ?? null;
    const openCardDate = parseDateYmd(
      String(req.body.openCardDate || "").trim(),
    );
    const expireDate = parseDateYmd(String(req.body.expireDate || "").trim());
    const status =
      req.body.status == null || req.body.status === ""
        ? CUSTOMER_STATUS.ENABLED
        : toInt(req.body.status, CUSTOMER_STATUS.ENABLED);
    const remark = String(req.body.remark || "").trim();
    const tagsText = tagsToDbString(req.body.tags);
    let storeId =
      req.body.storeId == null || req.body.storeId === ""
        ? null
        : toInt(req.body.storeId, 0);
    const eyeProfilePayload = buildEyeProfilePayload(req.body);

    if (!childName || !parentPhone) {
      connection.release();
      return sendFail(res, "请填写完整的客户信息", 400, {
        errorCode: "MISSING_FIELDS",
      });
    }

    if (!isValidPhone(parentPhone)) {
      connection.release();
      return sendFail(res, "家长电话格式不正确", 400, {
        errorCode: "INVALID_PHONE",
      });
    }

    if (birthdayRaw && !birthday) {
      connection.release();
      return sendFail(res, "生日日期格式无效，请使用 YYYY-MM-DD", 400, {
        errorCode: "INVALID_BIRTHDAY",
      });
    }

    if (hasCard) {
      if (!trainingProject) {
        connection.release();
        return sendFail(res, cardPayload?.error || "请选择卡项模板或训练项目", 400, {
          errorCode: cardPayload?.errorCode || "MISSING_PROJECT",
        });
      }

      if (!openCardDate || !expireDate) {
        connection.release();
        return sendFail(res, "日期格式无效，请使用 YYYY-MM-DD", 400, {
          errorCode: "INVALID_DATE",
        });
      }

      if (totalTimes <= 0) {
        connection.release();
        return sendFail(res, "总次数必须大于0", 400, {
          errorCode: "INVALID_TOTAL_TIMES",
        });
      }

      if (compareDateYmd(openCardDate, expireDate) === 1) {
        connection.release();
        return sendFail(res, "到期日期不能早于开卡日期", 400, {
          errorCode: "INVALID_DATE_RANGE",
        });
      }
    }

    if (Number(user.role) !== ROLE_ADMIN) {
      storeId = Number(user.storeId || 0);
    }

    if (!storeId) {
      connection.release();
      return sendFail(res, "请选择所属门店", 400, {
        errorCode: "MISSING_STORE",
      });
    }

    const [storeRows] = await connection.query(
      `SELECT id, store_name FROM stores WHERE id = ? AND status = 1 LIMIT 1`,
      [storeId],
    );
    if (!storeRows.length) {
      connection.release();
      return sendFail(res, "所属门店不存在或已停用，无法新增客户", 400, {
        errorCode: "STORE_UNAVAILABLE",
      });
    }

    let customerNo = buildCustomerNo();
    for (let i = 0; i < 5; i += 1) {
      const [existsRows] = await connection.query(
        `SELECT id FROM customers WHERE customer_no = ? LIMIT 1`,
        [customerNo],
      );
      if (!existsRows.length) break;
      customerNo = buildCustomerNo();
    }

    await connection.beginTransaction();

    const [result] = await connection.execute(
      `
        INSERT INTO customers
        (
          customer_no,
          child_name,
          gender,
          birthday,
          parent_name,
          parent_phone,
          store_id,
          has_card,
          training_project,
          total_times,
          used_times,
          open_card_date,
          expire_date,
          status,
          remark,
          tags,
          created_by,
          updated_by
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        customerNo,
        childName,
        gender,
        birthday,
        parentName || null,
        parentPhone,
        storeId,
        hasCard ? 1 : 0,
        hasCard ? trainingProject : null,
        hasCard ? totalTimes : 0,
        hasCard ? openCardDate : null,
        hasCard ? expireDate : null,
        status === CUSTOMER_STATUS.DISABLED ? 0 : 1,
        remark || null,
        tagsText || null,
        user.userId,
        user.userId,
      ],
    );

    await upsertCustomerEyeProfile(connection, result.insertId, eyeProfilePayload);

    if (hasCard) {
      await createCustomerCardRecord(connection, {
        customerId: result.insertId,
        cardTemplateId,
        cardName,
        trainingProject,
        salePrice,
        totalTimes,
        openCardDate,
        expireDate,
        remark,
        userId: user.userId,
      });

      await syncCustomerCardSnapshot(connection, result.insertId, user.userId);
    }

    await writeOperationLog(
      req,
      {
      module: "customer",
      action: "create",
      bizType: "customer",
      bizId: result.insertId,
      bizNo: customerNo,
      content: hasCard
        ? `新增客户并开卡：${childName}，卡项：${cardName || trainingProject}，总次数：${totalTimes}${salePrice != null ? `，成交价：¥${salePrice}` : ""}`
        : `新增客户开户：${childName}`,
      },
      connection,
    );

    await connection.commit();
    connection.release();

    const customer = await getCustomerById(result.insertId, user);
    return sendSuccess(res, formatCustomer(customer), "新增客户成功");
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore rollback error
    }
    connection.release();
    next(error);
  }
}

async function updateCustomer(req, res, next) {
  try {
    await ensureCustomerSchema();
    const user = req.user;

    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "客户ID无效", 400);
    }

    const oldCustomer = await getCustomerById(id, user);
    if (!oldCustomer) {
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    const childName = String(req.body.childName || "").trim();
    const gender =
      req.body.gender === "" || req.body.gender == null
        ? null
        : toInt(req.body.gender, 0);
    const birthdayRaw = String(req.body.birthday || "").trim();
    const birthday = birthdayRaw ? parseDateYmd(birthdayRaw) : null;
    const parentName = String(req.body.parentName || "").trim();
    const parentPhone = String(req.body.parentPhone || "").trim();
    const customerMode = normalizeCustomerMode(
      req.body.customerMode,
      hasCustomerCard(oldCustomer)
        ? CUSTOMER_MODE_ACCOUNT_AND_CARD
        : CUSTOMER_MODE_ACCOUNT_ONLY,
    );
    const hasCard = hasCustomerCard(oldCustomer);
    const trainingProject = String(
      req.body.trainingProject || oldCustomer.training_project || "",
    ).trim();
    const totalTimes = toInt(
      req.body.totalTimes,
      Number(oldCustomer.total_times || 0),
    );
    const openCardDateRaw =
      req.body.openCardDate == null || req.body.openCardDate === ""
        ? formatDateYmd(oldCustomer.open_card_date)
        : String(req.body.openCardDate || "").trim();
    const expireDateRaw =
      req.body.expireDate == null || req.body.expireDate === ""
        ? formatDateYmd(oldCustomer.expire_date)
        : String(req.body.expireDate || "").trim();
    const openCardDate = parseDateYmd(openCardDateRaw);
    const expireDate = parseDateYmd(expireDateRaw);
    const status =
      req.body.status == null || req.body.status === ""
        ? Number(oldCustomer.status)
        : toInt(req.body.status, Number(oldCustomer.status));
    const remark = String(req.body.remark || "").trim();
    const tagsText = tagsToDbString(req.body.tags);
    let storeId =
      req.body.storeId == null || req.body.storeId === ""
        ? Number(oldCustomer.store_id || 0)
        : toInt(req.body.storeId, 0);
    const eyeProfilePayload = buildEyeProfilePayload(req.body);

    if (!childName || !parentPhone) {
      return sendFail(res, "请填写完整的客户信息", 400, {
        errorCode: "MISSING_FIELDS",
      });
    }

    if (!isValidPhone(parentPhone)) {
      return sendFail(res, "家长电话格式不正确", 400, {
        errorCode: "INVALID_PHONE",
      });
    }

    if (birthdayRaw && !birthday) {
      return sendFail(res, "生日日期格式无效，请使用 YYYY-MM-DD", 400, {
        errorCode: "INVALID_BIRTHDAY",
      });
    }

    if (hasCard) {
      if (!trainingProject) {
        return sendFail(res, "请选择训练项目", 400, {
          errorCode: "MISSING_PROJECT",
        });
      }

      if (!openCardDate || !expireDate) {
        return sendFail(res, "日期格式无效，请使用 YYYY-MM-DD", 400, {
          errorCode: "INVALID_DATE",
        });
      }

      if (totalTimes < Number(oldCustomer.used_times || 0)) {
        return sendFail(res, "总次数不能小于已使用次数", 400, {
          errorCode: "INVALID_TOTAL_TIMES",
        });
      }

      if (compareDateYmd(openCardDate, expireDate) === 1) {
        return sendFail(res, "到期日期不能早于开卡日期", 400, {
          errorCode: "INVALID_DATE_RANGE",
        });
      }
    } else if (customerMode === CUSTOMER_MODE_ACCOUNT_AND_CARD) {
      return sendFail(res, "该客户尚未开卡，请使用开卡操作", 400, {
        errorCode: "USE_OPEN_CARD_ACTION",
      });
    }

    if (Number(user.role) !== ROLE_ADMIN) {
      storeId = Number(user.storeId || 0);
    }

    if (!storeId) {
      return sendFail(res, "请选择所属门店", 400, {
        errorCode: "MISSING_STORE",
      });
    }

    const [storeRows] = await pool.query(
      `SELECT id FROM stores WHERE id = ? LIMIT 1`,
      [storeId],
    );
    if (!storeRows.length) {
      return sendFail(res, "所属门店不存在", 400, {
        errorCode: "STORE_NOT_FOUND",
      });
    }

    await pool.execute(
      `
        UPDATE customers
        SET
          child_name = ?,
          gender = ?,
          birthday = ?,
          parent_name = ?,
          parent_phone = ?,
          store_id = ?,
          has_card = ?,
          training_project = ?,
          total_times = ?,
          used_times = ?,
          open_card_date = ?,
          expire_date = ?,
          status = ?,
          remark = ?,
          tags = ?,
          updated_by = ?
        WHERE id = ?
      `,
      [
        childName,
        gender,
        birthday,
        parentName || null,
        parentPhone,
        storeId,
        hasCard ? 1 : 0,
        hasCard ? trainingProject : null,
        hasCard ? totalTimes : 0,
        hasCard ? Number(oldCustomer.used_times || 0) : 0,
        hasCard ? openCardDate : null,
        hasCard ? expireDate : null,
        status === CUSTOMER_STATUS.DISABLED ? 0 : 1,
        remark || null,
        tagsText || null,
        user.userId,
        id,
      ],
    );

    await upsertCustomerEyeProfile(pool, id, eyeProfilePayload);

    await writeOperationLog(req, {
      module: "customer",
      action: "update",
      bizType: "customer",
      bizId: id,
      bizNo: oldCustomer.customer_no,
      content: hasCard
        ? `编辑客户：${childName}，项目：${trainingProject}，总次数：${totalTimes}`
        : `编辑客户档案：${childName}（仅开户）`,
    });

    const customer = await getCustomerById(id, user);
    return sendSuccess(res, formatCustomer(customer), "更新客户成功");
  } catch (error) {
    next(error);
  }
}

async function updateCustomerStatus(req, res, next) {
  try {
    await ensureCustomerSchema();
    const user = req.user;

    const id = toInt(req.params.id, 0);
    const status = toInt(req.body.status, -1);

    if (!id) {
      return sendFail(res, "客户ID无效", 400);
    }

    if (![CUSTOMER_STATUS.DISABLED, CUSTOMER_STATUS.ENABLED].includes(status)) {
      return sendFail(res, "状态值无效", 400);
    }

    const customer = await getCustomerById(id, user);
    if (!customer) {
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    await pool.execute(
      `UPDATE customers SET status = ?, updated_by = ? WHERE id = ?`,
      [status, user.userId, id],
    );

    await writeOperationLog(req, {
      module: "customer",
      action: "update_status",
      bizType: "customer",
      bizId: id,
      bizNo: customer.customer_no,
      content: `${status === 1 ? "启用" : "停用"}客户：${customer.child_name}`,
    });

    return sendSuccess(res, null, "更新客户状态成功");
  } catch (error) {
    next(error);
  }
}

async function deleteCustomer(req, res, next) {
  await ensureCustomerSchema();
  const connection = await pool.getConnection();

  try {
    const user = req.user;

    const id = toInt(req.params.id, 0);
    if (!id) {
      connection.release();
      return sendFail(res, "客户ID无效", 400);
    }

    const customer = await getCustomerById(id, user);
    if (!customer) {
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    await connection.beginTransaction();

    const [[verifyCountRow]] = await connection.query(
      `SELECT COUNT(*) AS total FROM verify_records WHERE customer_id = ?`,
      [id],
    );

    if (Number(verifyCountRow.total || 0) > 0) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户已有核销记录，不能直接删除", 400);
    }

    const [attachmentRows] = await connection.query(
      `SELECT id, file_path FROM customer_attachments WHERE customer_id = ?`,
      [id],
    );

    await connection.execute(
      `DELETE FROM customer_eye_profiles WHERE customer_id = ?`,
      [id],
    );
    await connection.execute(
      `DELETE FROM customer_card_usage_logs WHERE customer_id = ?`,
      [id],
    );
    await connection.execute(
      `DELETE FROM customer_follow_ups WHERE customer_id = ?`,
      [id],
    );
    await connection.execute(
      `DELETE FROM customer_visit_checks WHERE customer_id = ?`,
      [id],
    );
    await connection.execute(
      `DELETE FROM customer_glasses_records WHERE customer_id = ?`,
      [id],
    );
    await connection.execute(
      `DELETE FROM customer_cards WHERE customer_id = ?`,
      [id],
    );
    await connection.execute(
      `DELETE FROM customer_attachments WHERE customer_id = ?`,
      [id],
    );
    await connection.execute(
      `DELETE FROM customer_renewals WHERE customer_id = ?`,
      [id],
    );
    await connection.execute(`DELETE FROM customers WHERE id = ?`, [id]);

    await writeOperationLog(
      req,
      {
        module: "customer",
        action: "delete",
        bizType: "customer",
        bizId: id,
        bizNo: customer.customer_no,
        content: `删除客户：${customer.child_name}`,
      },
      connection,
    );

    await connection.commit();
    connection.release();

    for (const item of attachmentRows) {
      const filePath = path.join(
        __dirname,
        "..",
        "..",
        item.file_path.replace(/^\//, ""),
      );
      if (fs.existsSync(filePath)) {
        try {
          fs.unlinkSync(filePath);
        } catch (error) {
          // ignore unlink error
        }
      }
    }

    return sendSuccess(res, null, "删除客户成功");
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore rollback error
    }
    connection.release();
    next(error);
  }
}

async function openCustomerCard(req, res, next) {
  await ensureCustomerSchema();
  const connection = await pool.getConnection();

  try {
    const user = req.user;

    const id = toInt(req.params.id, 0);
    const cardPayload = await resolveCardPayload(connection, req.body);
    const trainingProject = cardPayload?.trainingProject || "";
    const totalTimes = cardPayload?.totalTimes || 0;
    const cardTemplateId = cardPayload?.cardTemplateId || null;
    const cardName = cardPayload?.cardName || "";
    const salePrice = cardPayload?.salePrice ?? null;
    const openCardDate = parseDateYmd(String(req.body.openCardDate || "").trim());
    const expireDate = parseDateYmd(String(req.body.expireDate || "").trim());
    const remark = String(req.body.remark || "").trim();

    if (!id) {
      connection.release();
      return sendFail(res, "客户ID无效", 400, { errorCode: "INVALID_ID" });
    }

    if (!trainingProject) {
      connection.release();
      return sendFail(res, cardPayload?.error || "请选择卡项模板或训练项目", 400, {
        errorCode: cardPayload?.errorCode || "MISSING_PROJECT",
      });
    }

    if (totalTimes <= 0) {
      connection.release();
      return sendFail(res, "总次数必须大于0", 400, { errorCode: "INVALID_TOTAL_TIMES" });
    }

    if (!openCardDate || !expireDate) {
      connection.release();
      return sendFail(res, "日期格式无效，请使用 YYYY-MM-DD", 400, {
        errorCode: "INVALID_DATE",
      });
    }

    if (compareDateYmd(openCardDate, expireDate) === 1) {
      connection.release();
      return sendFail(res, "到期日期不能早于开卡日期", 400, {
        errorCode: "INVALID_DATE_RANGE",
      });
    }

    await connection.beginTransaction();

    const scope = buildStoreScope(user, "c.store_id");
    const [rows] = await connection.query(
      `
        SELECT
          c.id,
          c.customer_no,
          c.child_name,
          c.store_id,
          c.status,
          c.has_card,
          c.remark
        FROM customers c
        WHERE c.id = ?
          AND ${scope.sql}
        LIMIT 1
        FOR UPDATE
      `,
      [id, ...scope.params],
    );

    const customer = rows[0];
    if (!customer) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404, {
        errorCode: "CUSTOMER_NOT_FOUND",
      });
    }

    if (hasCustomerCard(customer)) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户已开卡，请使用续卡功能", 400, {
        errorCode: "CUSTOMER_ALREADY_CARDED",
      });
    }

    await createCustomerCardRecord(connection, {
      customerId: id,
      cardTemplateId,
      cardName,
      trainingProject,
      salePrice,
      totalTimes,
      openCardDate,
      expireDate,
      remark: remark || customer.remark || null,
      userId: user.userId,
    });

    await syncCustomerCardSnapshot(connection, id, user.userId);

    await writeOperationLog(
      req,
      {
        module: "customer",
        action: "open_card",
        bizType: "customer",
        bizId: id,
        bizNo: customer.customer_no,
        content: `${hasCustomerCard(customer) ? "客户加购卡" : "客户开卡"}：${customer.child_name}，卡项：${cardName || trainingProject}，总次数：${totalTimes}${salePrice != null ? `，成交价：¥${salePrice}` : ""}`,
      },
      connection,
    );

    await connection.commit();
    connection.release();

    const latest = await getCustomerById(id, user);
    return sendSuccess(res, formatCustomer(latest), "客户开卡成功");
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore rollback error
    }
    connection.release();
    next(error);
  }
}

async function renewCustomer(req, res, next) {
  await ensureCustomerSchema();
  const connection = await pool.getConnection();

  try {
    const user = req.user;

    const id = toInt(req.params.id, 0);
    const selectedCardId = toInt(req.body.customerCardId ?? req.body.cardId, 0);
    const addTimes = toInt(req.body.addTimes, 0);
    const newExpireDate = String(req.body.newExpireDate || "").trim();
    const remark = String(req.body.remark || "").trim();
    const normalizedNewExpireDate = parseDateYmd(newExpireDate);

    if (!id) {
      connection.release();
      return sendFail(res, "客户ID无效", 400, { errorCode: "INVALID_ID" });
    }

    if (addTimes <= 0) {
      connection.release();
      return sendFail(res, "续卡次数必须大于0", 400, {
        errorCode: "INVALID_ADD_TIMES",
      });
    }

    if (!newExpireDate) {
      connection.release();
      return sendFail(res, "请输入新的到期日期", 400, {
        errorCode: "MISSING_DATE",
      });
    }

    if (!normalizedNewExpireDate) {
      connection.release();
      return sendFail(res, "新的到期日期格式无效，请使用 YYYY-MM-DD", 400, {
        errorCode: "INVALID_DATE",
      });
    }

    await connection.beginTransaction();

    const scope = buildStoreScope(user, "c.store_id");
    const [rows] = await connection.query(
      `
        SELECT
          c.id,
          c.customer_no,
          c.child_name,
          c.store_id,
          c.has_card,
          c.total_times,
          c.used_times,
          c.remaining_times,
          c.expire_date,
          c.status
        FROM customers c
        WHERE c.id = ?
          AND ${scope.sql}
        LIMIT 1
        FOR UPDATE
      `,
      [id, ...scope.params],
    );

    const customer = rows[0];
    if (!customer) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404, {
        errorCode: "CUSTOMER_NOT_FOUND",
      });
    }

    if (!hasCustomerCard(customer)) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户尚未开卡，无法续卡", 400, {
        errorCode: "CUSTOMER_NO_CARD",
      });
    }

    if (Number(customer.status) !== CUSTOMER_STATUS.ENABLED) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户已停用，无法续卡", 400, {
        errorCode: "CUSTOMER_DISABLED",
      });
    }

    const [formalCardRows] = await connection.query(
      `
        SELECT
          cc.id,
          cc.customer_id,
          cc.card_template_id,
          cc.card_name_snapshot,
          cc.training_project,
          cc.sale_price,
          cc.total_times,
          cc.used_times,
          cc.remaining_times,
          cc.expire_date,
          cc.status,
          COALESCE(cc.is_promotion, ct.is_promotion, 0) AS is_promotion
        FROM customer_cards cc
        LEFT JOIN card_templates ct ON ct.id = cc.card_template_id
        WHERE cc.customer_id = ?
          AND cc.status = 1
          AND COALESCE(cc.is_promotion, ct.is_promotion, 0) = 0
        ORDER BY
          CASE WHEN cc.remaining_times > 0 AND (cc.expire_date IS NULL OR cc.expire_date >= CURDATE()) THEN 0 ELSE 1 END ASC,
          cc.open_card_date DESC,
          cc.id DESC
        FOR UPDATE
      `,
      [id],
    );

    let currentCard = null;
    if (selectedCardId) {
      currentCard = formalCardRows.find((item) => Number(item.id || 0) === selectedCardId) || null;
      if (!currentCard) {
        await connection.rollback();
        connection.release();
        return sendFail(res, "所选卡项不存在、已停用或不是正式卡", 404, {
          errorCode: "CARD_NOT_FOUND",
        });
      }
    } else if (formalCardRows.length > 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户存在多张正式卡，请先选择要续的卡项", 400, {
        errorCode: "REQUIRE_CARD_SELECTION",
        cards: formalCardRows.map((item) => ({
          id: Number(item.id || 0),
          cardName: item.card_name_snapshot || "",
          trainingProject: item.training_project || "",
          totalTimes: Number(item.total_times || 0),
          usedTimes: Number(item.used_times || 0),
          remainingTimes: Number(item.remaining_times || 0),
          expireDate: formatDateYmd(item.expire_date),
        })),
      });
    } else {
      currentCard = formalCardRows[0] || null;
    }

    const currentExpireDate = formatDateYmd(currentCard?.expire_date || customer.expire_date);

    if (compareDateYmd(normalizedNewExpireDate, currentExpireDate) === -1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "新的到期日期不能早于原到期日期", 400, {
        errorCode: "INVALID_DATE_RANGE",
      });
    }

    const todayDate = formatDateYmd(new Date());
    if (compareDateYmd(normalizedNewExpireDate, todayDate) === -1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "新的到期日期不能早于今天", 400, {
        errorCode: "INVALID_DATE_RANGE",
      });
    }

    const beforeTotalTimes = Number(currentCard?.total_times ?? customer.total_times ?? 0);
    const beforeUsedTimes = Number(currentCard?.used_times ?? customer.used_times ?? 0);
    const beforeExpireDate = currentCard?.expire_date || customer.expire_date;
    const afterTotalTimes = beforeTotalTimes + addTimes;

    if (currentCard) {
      const [cardUpdateResult] = await connection.execute(
        `
          UPDATE customer_cards
          SET
            total_times = ?,
            expire_date = ?,
            updated_by = ?
          WHERE id = ?
            AND customer_id = ?
            AND status = 1
            AND COALESCE(is_promotion, 0) = 0
        `,
        [afterTotalTimes, normalizedNewExpireDate, user.userId, currentCard.id, id],
      );

      if (Number(cardUpdateResult.affectedRows || 0) !== 1) {
        await connection.rollback();
        connection.release();
        return sendFail(res, "卡项状态已变化，请刷新后重试", 409, {
          errorCode: "CARD_STATE_CHANGED",
        });
      }

      await syncCustomerCardSnapshot(connection, id, user.userId);
    } else {
      const [customerUpdateResult] = await connection.execute(
        `
          UPDATE customers
          SET
            total_times = ?,
            expire_date = ?,
            updated_by = ?
          WHERE id = ?
        `,
        [afterTotalTimes, normalizedNewExpireDate, user.userId, id],
      );

      if (Number(customerUpdateResult.affectedRows || 0) !== 1) {
        await connection.rollback();
        connection.release();
        return sendFail(res, "客户状态已变化，请刷新后重试", 409, {
          errorCode: "CUSTOMER_STATE_CHANGED",
        });
      }
    }

    const [renewResult] = await connection.execute(
      `
        INSERT INTO customer_renewals
        (
          customer_id,
          customer_card_id,
          before_total_times,
          before_used_times,
          before_expire_date,
          add_times,
          after_total_times,
          after_expire_date,
          operator_id,
          operator_name,
          remark
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        id,
        currentCard?.id || null,
        beforeTotalTimes,
        beforeUsedTimes,
        beforeExpireDate,
        addTimes,
        afterTotalTimes,
        normalizedNewExpireDate,
        user.userId,
        user.realName,
        remark || null,
      ],
    );

    await writeOperationLog(
      req,
      {
        module: "customer",
        action: "renew",
        bizType: "customer_renewal",
        bizId: id,
        bizNo: customer.customer_no,
        content: `客户续卡：${customer.child_name}，增加${addTimes}次，到期至${normalizedNewExpireDate}`,
      },
      connection,
    );

    await connection.commit();
    connection.release();

    const customerAfter = await getCustomerById(id, user);
    return sendSuccess(
      res,
      {
        renewalId: renewResult.insertId,
        customer: formatCustomer(customerAfter),
      },
      "续卡成功",
    );
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore rollback error
    }
    connection.release();
    next(error);
  }
}

async function createCustomerActivityCard(req, res, next) {
  await ensureCustomerSchema();
  const connection = await pool.getConnection();

  try {
    const user = req.user;

    const id = toInt(req.params.id, 0);
    if (!id) {
      connection.release();
      return sendFail(res, "客户ID无效", 400);
    }

    const customer = await getCustomerById(id, user);
    if (!customer) {
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    const resolved = await resolveCardPayload(connection, req.body, {
      requirePromotion: true,
    });

    if (resolved?.error) {
      connection.release();
      return sendFail(res, resolved.error, 400, {
        errorCode: resolved.errorCode || "INVALID_CARD_TEMPLATE",
      });
    }

    const cardName = String(req.body.cardName || resolved.cardName || "").trim();
    const totalTimes = toInt(req.body.totalTimes, resolved.totalTimes || 0);
    const openCardDate = parseDateYmd(String(req.body.openCardDate || "").trim());
    const expireDateRaw = String(req.body.expireDate || "").trim();
    const expireDate = expireDateRaw ? parseDateYmd(expireDateRaw) : null;
    const trainingProject = String(
      req.body.trainingProject || resolved.trainingProject || "",
    ).trim();
    const salePrice =
      req.body.salePrice === "" || req.body.salePrice == null
        ? resolved.salePrice ?? null
        : normalizeSalePrice(req.body.salePrice);
    const remark = normalizeRemarkText(req.body.remark, 500);

    if (!cardName) {
      connection.release();
      return sendFail(res, "请填写活动名称", 400, {
        errorCode: "MISSING_CARD_NAME",
      });
    }

    if (totalTimes <= 0) {
      connection.release();
      return sendFail(res, "活动卡次数必须大于0", 400, {
        errorCode: "INVALID_TOTAL_TIMES",
      });
    }

    if (!openCardDate) {
      connection.release();
      return sendFail(res, "请选择生效日期", 400, {
        errorCode: "INVALID_DATE",
      });
    }

    if (expireDateRaw && !expireDate) {
      connection.release();
      return sendFail(res, "到期日期格式无效，请使用 YYYY-MM-DD", 400, {
        errorCode: "INVALID_DATE",
      });
    }

    if (expireDate && compareDateYmd(expireDate, openCardDate) === -1) {
      connection.release();
      return sendFail(res, "到期日期不能早于生效日期", 400, {
        errorCode: "INVALID_DATE_RANGE",
      });
    }

    await connection.beginTransaction();

    const insertId = await createCustomerCardRecord(connection, {
      customerId: id,
      cardTemplateId: resolved.cardTemplateId,
      cardName,
      trainingProject,
      salePrice,
      isPromotion: 1,
      totalTimes,
      openCardDate,
      expireDate,
      status: 1,
      remark,
      userId: user.userId,
    });

    const customerCardsMap = await getCustomerCardsMap(connection, [id], {
      activeOnly: false,
    });
    const createdCard = (customerCardsMap.get(id) || []).find((item) => item.id === insertId);

    await writeOperationLog(
      req,
      {
        module: "customer",
        action: "create_activity_card",
        bizType: "customer_activity_card",
        bizId: id,
        bizNo: customer.customer_no,
        content: `新增活动卡：${customer.child_name}，${cardName}，${totalTimes} 次${salePrice != null ? `，成交价 ¥${salePrice}` : ""}`,
      },
      connection,
    );

    await connection.commit();
    connection.release();

    return sendSuccess(
      res,
      { item: createdCard || null },
      "新增活动卡成功",
    );
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore
    }
    connection.release();
    next(error);
  }
}

async function consumeCustomerActivityCard(req, res, next) {
  await ensureCustomerSchema();
  const connection = await pool.getConnection();

  try {
    const user = req.user;

    const customerId = toInt(req.params.id, 0);
    const cardId = toInt(req.params.cardId, 0);
    const quantity = normalizeUsageQuantity(req.body.quantity, 1);
    const remark = normalizeRemarkText(req.body.remark, 500);
    const visitId = toInt(req.body.visitId, 0);

    if (!customerId || !cardId) {
      connection.release();
      return sendFail(res, "参数无效", 400);
    }

    await connection.beginTransaction();

    const customer = await getCustomerById(customerId, user);
    if (!customer) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    const [rows] = await connection.query(
      `
        SELECT
          cc.id,
          cc.customer_id,
          cc.card_template_id,
          cc.card_name_snapshot,
          cc.training_project,
          cc.sale_price,
          cc.total_times,
          cc.used_times,
          cc.remaining_times,
          cc.open_card_date,
          cc.expire_date,
          cc.status,
          cc.remark,
          COALESCE(cc.is_promotion, ct.is_promotion, 0) AS is_promotion
        FROM customer_cards cc
        LEFT JOIN card_templates ct ON ct.id = cc.card_template_id
        WHERE cc.id = ?
          AND cc.customer_id = ?
        LIMIT 1
        FOR UPDATE
      `,
      [cardId, customerId],
    );

    const currentCard = rows[0];
    if (!currentCard) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "活动卡不存在", 404, {
        errorCode: "CARD_NOT_FOUND",
      });
    }

    if (Number(currentCard.is_promotion || 0) !== 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该卡不是活动卡，不能在这里核销", 400, {
        errorCode: "CARD_NOT_PROMOTION",
      });
    }

    if (Number(currentCard.status || 0) !== 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该活动卡已停用", 400, {
        errorCode: "CARD_DISABLED",
      });
    }

    const remain = Number(currentCard.remaining_times || 0);
    if (remain < quantity) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "活动卡剩余次数不足", 400, {
        errorCode: "CARD_NO_REMAINING",
      });
    }

    const expireDate = formatDateYmd(currentCard.expire_date);
    if (expireDate && compareDateYmd(expireDate, formatDateYmd(new Date())) === -1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该活动卡已过期", 400, {
        errorCode: "CARD_EXPIRED",
      });
    }

    const beforeUsedTimes = Number(currentCard.used_times || 0);
    const afterUsedTimes = beforeUsedTimes + quantity;

    const [cardUpdateResult] = await connection.execute(
      `
        UPDATE customer_cards
        SET used_times = used_times + ?,
            updated_by = ?
        WHERE id = ?
          AND customer_id = ?
          AND status = 1
          AND COALESCE(is_promotion, 0) = 1
          AND remaining_times >= ?
      `,
      [quantity, user.userId, cardId, customerId, quantity],
    );

    if (Number(cardUpdateResult.affectedRows || 0) !== 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "活动卡次数已变化，请刷新后重试", 409, {
        errorCode: "CARD_STATE_CHANGED",
      });
    }

    // 创建核销记录（活动卡核销也需要记录到 verify_records，单号冲突自动重试）
    const now = new Date();
    const verifyDate = formatDateYmd(now);
    const verifyTime = [now.getFullYear(),
      `${now.getMonth() + 1}`.padStart(2, "0"),
      `${now.getDate()}`.padStart(2, "0")].join("-") + " " +
      [`${now.getHours()}`.padStart(2, "0"),
       `${now.getMinutes()}`.padStart(2, "0"),
       `${now.getSeconds()}`.padStart(2, "0")].join(":");

    const { verifyNo, insertResult: verifyInsertResult } = await insertVerifyRecordWithRetry(connection, {
      customerId,
      customerCardId: cardId,
      storeId: customer.store_id || 0,
      childName: customer.child_name || "",
      trainingProject: currentCard.training_project || "活动卡",
      cardName: currentCard.card_name_snapshot || "",
      cardSalePrice: currentCard.sale_price ?? null,
      verifyDate,
      verifyTime,
      operatorId: user.userId,
      operatorName: user.realName,
      remark: remark || null,
    });

    await insertCustomerCardUsageLog(connection, {
      customerCardId: cardId,
      customerId,
      verifyRecordId: verifyInsertResult.insertId,
      actionType: "consume",
      quantity,
      beforeUsedTimes,
      afterUsedTimes,
      remark,
      operatorId: user.userId,
      operatorName: user.realName,
    });

    await syncVisitFromVerification(connection, {
      visitId,
      verifyRecordId: Number(verifyInsertResult.insertId),
      customerId,
      storeId: Number(customer.store_id || 0),
      customerName: customer.child_name || "",
      customerPhone: customer.parent_phone || "",
      trainingProject: currentCard.training_project || "活动卡",
      verifyTime,
      operatorId: user.userId,
      operatorName: user.realName,
      remark,
      source: "verify",
    });

    await writeOperationLog(
      req,
      {
        module: "customer",
        action: "consume_activity_card",
        bizType: "customer_activity_card",
        bizId: customerId,
        bizNo: customer.customer_no,
        content: `核销活动卡：${customer.child_name}，${currentCard.card_name_snapshot || "活动卡"}，扣减 ${quantity} 次`,
      },
      connection,
    );

    await connection.commit();
    connection.release();

    return sendSuccess(res, null, "活动卡核销成功");
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore
    }
    connection.release();
    next(error);
  }
}

async function createCustomerFollowUp(req, res, next) {
  await ensureCustomerSchema();
  const connection = await pool.getConnection();

  try {
    const user = req.user;

    const id = toInt(req.params.id, 0);
    const recordTime = String(req.body.recordTime || "").trim();
    const result = String(req.body.result || "").trim();
    const content = String(req.body.content || "").trim();
    const remark = String(req.body.remark || "").trim();

    if (!id) {
      connection.release();
      return sendFail(res, "客户ID无效", 400);
    }

    if (!recordTime || Number.isNaN(new Date(recordTime).getTime())) {
      connection.release();
      return sendFail(res, "回访时间格式无效", 400);
    }

    if (!result) {
      connection.release();
      return sendFail(res, "请填写回访结果", 400);
    }

    if (!content) {
      connection.release();
      return sendFail(res, "请填写回访内容", 400);
    }

    const customer = await getCustomerById(id, user);
    if (!customer) {
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    const [insertResult] = await connection.execute(
      `
        INSERT INTO customer_follow_ups
        (
          customer_id,
          record_time,
          result,
          content,
          operator_id,
          operator_name,
          remark
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `,
      [id, new Date(recordTime), result, content, user.userId, user.realName, remark || null],
    );

    await writeOperationLog(
      req,
      {
        module: "customer",
        action: "follow_up",
        bizType: "customer_follow_up",
        bizId: id,
        bizNo: customer.customer_no,
        content: `新增客户回访：${customer.child_name}，结果：${result}`,
      },
      connection,
    );

    const [[row]] = await connection.query(
      `
        SELECT
          id,
          customer_id,
          record_time,
          result,
          content,
          operator_id,
          operator_name,
          remark,
          created_at
        FROM customer_follow_ups
        WHERE id = ?
        LIMIT 1
      `,
      [insertResult.insertId],
    );

    connection.release();
    return sendSuccess(res, formatFollowUpRecord(row), "新增回访记录成功");
  } catch (error) {
    connection.release();
    next(error);
  }
}

async function createCustomerVisitCheck(req, res, next) {
  await ensureCustomerSchema();
  const connection = await pool.getConnection();

  try {
    const user = req.user;

    const id = toInt(req.params.id, 0);
    const checkTime = String(req.body.checkTime || "").trim();
    const payload = buildVisitCheckPayload(req.body);

    if (!id) {
      connection.release();
      return sendFail(res, "客户ID无效", 400);
    }

    if (!checkTime || Number.isNaN(new Date(checkTime).getTime())) {
      connection.release();
      return sendFail(res, "到店检查时间格式无效", 400);
    }

    if (!payload.checkResult) {
      connection.release();
      return sendFail(res, "请填写检查结果", 400);
    }

    const customer = await getCustomerById(id, user);
    if (!customer) {
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    const [insertResult] = await connection.execute(
      `
        INSERT INTO customer_visit_checks
        (
          customer_id,
          check_time,
          check_result,
          naked_vision_od,
          naked_vision_os,
          corrected_vision_od,
          corrected_vision_os,
          pd,
          exam_sphere_od,
          exam_cylinder_od,
          exam_axis_od,
          exam_sphere_os,
          exam_cylinder_os,
          exam_axis_os,
          recommended_sphere_od,
          recommended_cylinder_od,
          recommended_axis_od,
          recommended_sphere_os,
          recommended_cylinder_os,
          recommended_axis_os,
          suggestion,
          operator_id,
          operator_name,
          remark
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        id,
        new Date(checkTime),
        payload.checkResult,
        payload.nakedVisionOd,
        payload.nakedVisionOs,
        payload.correctedVisionOd,
        payload.correctedVisionOs,
        payload.pd,
        payload.examSphereOd,
        payload.examCylinderOd,
        payload.examAxisOd,
        payload.examSphereOs,
        payload.examCylinderOs,
        payload.examAxisOs,
        payload.recommendedSphereOd,
        payload.recommendedCylinderOd,
        payload.recommendedAxisOd,
        payload.recommendedSphereOs,
        payload.recommendedCylinderOs,
        payload.recommendedAxisOs,
        payload.suggestion || null,
        user.userId,
        user.realName,
        payload.remark || null,
      ],
    );

    await writeOperationLog(
      req,
      {
        module: "customer",
        action: "visit_check",
        bizType: "customer_visit_check",
        bizId: id,
        bizNo: customer.customer_no,
        content: `新增到店检查：${customer.child_name}`,
      },
      connection,
    );

    const [[row]] = await connection.query(
      `
        SELECT
          id,
          customer_id,
          check_time,
          check_result,
          naked_vision_od,
          naked_vision_os,
          corrected_vision_od,
          corrected_vision_os,
          pd,
          exam_sphere_od,
          exam_cylinder_od,
          exam_axis_od,
          exam_sphere_os,
          exam_cylinder_os,
          exam_axis_os,
          recommended_sphere_od,
          recommended_cylinder_od,
          recommended_axis_od,
          recommended_sphere_os,
          recommended_cylinder_os,
          recommended_axis_os,
          suggestion,
          operator_id,
          operator_name,
          remark,
          created_at
        FROM customer_visit_checks
        WHERE id = ?
        LIMIT 1
      `,
      [insertResult.insertId],
    );

    connection.release();
    return sendSuccess(res, formatVisitCheckRecord(row), "新增到店检查记录成功");
  } catch (error) {
    connection.release();
    next(error);
  }
}

async function createCustomerGlassesRecord(req, res, next) {
  await ensureCustomerSchema();
  const connection = await pool.getConnection();

  try {
    const user = req.user;

    const id = toInt(req.params.id, 0);
    const payload = buildGlassesRecordPayload(req.body);

    if (!id) {
      connection.release();
      return sendFail(res, "客户ID无效", 400);
    }

    if (!payload.recordTime || Number.isNaN(new Date(payload.recordTime).getTime())) {
      connection.release();
      return sendFail(res, "配镜时间格式无效", 400);
    }

    const hasPrescription =
      payload.pd ||
      payload.sphereOd ||
      payload.cylinderOd ||
      payload.axisOd ||
      payload.sphereOs ||
      payload.cylinderOs ||
      payload.axisOs;

    if (!hasPrescription) {
      connection.release();
      return sendFail(res, "请至少填写一项配镜参数", 400);
    }

    const customer = await getCustomerById(id, user);
    if (!customer) {
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    const customOd = payload.lensOdName ? {
      id: null,
      brand: payload.lensOdBrand,
      name: payload.lensOdName,
      refractiveIndex: payload.lensOdRefractiveIndex,
      features: payload.lensOdFeatures,
    } : null;
    const customOs = payload.lensOsName ? {
      id: null,
      brand: payload.lensOsBrand,
      name: payload.lensOsName,
      refractiveIndex: payload.lensOsRefractiveIndex,
      features: payload.lensOsFeatures,
    } : null;
    const genericLensId = toInt(req.body.lensId, 0);
    const lensOd = await resolveLensSnapshot(
      connection,
      payload.lensOdId || genericLensId,
      customer.store_id,
    ) || customOd;
    const lensOs = await resolveLensSnapshot(
      connection,
      payload.lensOsId || genericLensId,
      customer.store_id,
    ) || customOs || lensOd;
    const legacyBrand = lensOd?.brand === lensOs?.brand
      ? (lensOd?.brand || "")
      : [lensOd?.brand ? `R ${lensOd.brand}` : "", lensOs?.brand ? `L ${lensOs.brand}` : ""].filter(Boolean).join(" / ");
    const legacyName = lensOd?.name === lensOs?.name
      ? (lensOd?.name || "")
      : [lensOd?.name ? `R ${lensOd.name}` : "", lensOs?.name ? `L ${lensOs.name}` : ""].filter(Boolean).join(" / ");

    if (payload.sourceCheckId) {
      const [[checkRow]] = await connection.query(
        `
          SELECT id
          FROM customer_visit_checks
          WHERE id = ?
            AND customer_id = ?
          LIMIT 1
        `,
        [payload.sourceCheckId, id],
      );
      if (!checkRow) {
        connection.release();
        return sendFail(res, "关联的检查记录不存在", 400);
      }
    }

    const [insertResult] = await connection.execute(
      `
        INSERT INTO customer_glasses_records
        (
          customer_id,
          record_time,
          source_check_id,
          delivery_status,
          pd,
          sphere_od,
          cylinder_od,
          axis_od,
          sphere_os,
          cylinder_os,
          axis_os,
          lens_brand,
          lens_type,
          lens_od_id,
          lens_od_brand,
          lens_od_name,
          lens_od_refractive_index,
          lens_od_features,
          lens_os_id,
          lens_os_brand,
          lens_os_name,
          lens_os_refractive_index,
          lens_os_features,
          frame_info,
          remark,
          operator_id,
          operator_name
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        id,
        new Date(payload.recordTime),
        payload.sourceCheckId || null,
        payload.deliveryStatus,
        payload.pd,
        payload.sphereOd,
        payload.cylinderOd,
        payload.axisOd,
        payload.sphereOs,
        payload.cylinderOs,
        payload.axisOs,
        legacyBrand || payload.lensBrand,
        legacyName || payload.lensType,
        lensOd?.id || null,
        lensOd?.brand || null,
        lensOd?.name || null,
        lensOd?.refractiveIndex || null,
        lensOd?.features || null,
        lensOs?.id || null,
        lensOs?.brand || null,
        lensOs?.name || null,
        lensOs?.refractiveIndex || null,
        lensOs?.features || null,
        payload.frameInfo,
        payload.remark || null,
        user.userId,
        user.realName,
      ],
    );

    await insertGlassesStatusLog(connection, {
      glassesRecordId: insertResult.insertId,
      customerId: id,
      fromStatus: null,
      toStatus: payload.deliveryStatus,
      remark: payload.remark || "创建配镜记录",
      operatorId: user.userId,
      operatorName: user.realName,
    });

    await writeOperationLog(
      req,
      {
        module: "customer",
        action: "glasses_record",
        bizType: "customer_glasses_record",
        bizId: id,
        bizNo: customer.customer_no,
        content: `新增配镜记录：${customer.child_name}，状态：${getGlassesStatusLabel(payload.deliveryStatus)}`,
      },
      connection,
    );

    const [[row]] = await connection.query(
      `
        SELECT
          id,
          customer_id,
          record_time,
          source_check_id,
          delivery_status,
          pd,
          sphere_od,
          cylinder_od,
          axis_od,
          sphere_os,
          cylinder_os,
          axis_os,
          lens_brand,
          lens_type,
          lens_od_id,
          lens_od_brand,
          lens_od_name,
          lens_od_refractive_index,
          lens_od_features,
          lens_os_id,
          lens_os_brand,
          lens_os_name,
          lens_os_refractive_index,
          lens_os_features,
          frame_info,
          operator_id,
          operator_name,
          remark,
          created_at
        FROM customer_glasses_records
        WHERE id = ?
        LIMIT 1
      `,
      [insertResult.insertId],
    );

    notifyGlassesStatusWx(customer, row, getGlassesStatusLabel(payload.deliveryStatus), row.record_time || new Date()).catch(() => {});

    connection.release();
    return sendSuccess(res, formatGlassesRecord(row), "新增配镜记录成功");
  } catch (error) {
    connection.release();
    next(error);
  }
}

async function updateCustomerGlassesStatus(req, res, next) {
  await ensureCustomerSchema();
  const connection = await pool.getConnection();

  try {
    const user = req.user;
    const customerId = toInt(req.params.id, 0);
    const recordId = toInt(req.params.recordId, 0);
    const nextStatus = normalizeGlassesStatus(req.body.status || req.body.deliveryStatus, 0);
    const remark = normalizeRemarkText(req.body.remark, 500);

    if (!customerId || !recordId) {
      connection.release();
      return sendFail(res, "参数错误", 400);
    }
    if (!nextStatus) {
      connection.release();
      return sendFail(res, "配镜状态无效", 400);
    }

    const customer = await getCustomerById(customerId, user);
    if (!customer) {
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    await connection.beginTransaction();
    const [[record]] = await connection.query(
      "SELECT id, customer_id, delivery_status FROM customer_glasses_records WHERE id = ? AND customer_id = ? LIMIT 1 FOR UPDATE",
      [recordId, customerId],
    );
    if (!record) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "配镜记录不存在", 404);
    }

    const fromStatus = normalizeGlassesStatus(record.delivery_status);
    if (fromStatus === nextStatus) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "状态未变化", 400);
    }

    await connection.execute(
      "UPDATE customer_glasses_records SET delivery_status = ? WHERE id = ? AND customer_id = ?",
      [nextStatus, recordId, customerId],
    );

    await insertGlassesStatusLog(connection, {
      glassesRecordId: recordId,
      customerId,
      fromStatus,
      toStatus: nextStatus,
      remark,
      operatorId: user.userId,
      operatorName: user.realName,
    });

    await writeOperationLog(
      req,
      {
        module: "customer",
        action: "glasses_status",
        bizType: "customer_glasses_record",
        bizId: customerId,
        bizNo: customer.customer_no,
        content: `更新配镜流程：${customer.child_name}，${getGlassesStatusLabel(fromStatus)} → ${getGlassesStatusLabel(nextStatus)}`,
      },
      connection,
    );

    await connection.commit();

    const [[row]] = await pool.query(
      "SELECT id, customer_id, record_time, source_check_id, delivery_status, pd, sphere_od, cylinder_od, axis_od, sphere_os, cylinder_os, axis_os, lens_brand, lens_type, lens_od_id, lens_od_brand, lens_od_name, lens_od_refractive_index, lens_od_features, lens_os_id, lens_os_brand, lens_os_name, lens_os_refractive_index, lens_os_features, frame_info, operator_id, operator_name, remark, created_at FROM customer_glasses_records WHERE id = ? LIMIT 1",
      [recordId],
    );
    const [logRows] = await pool.query(
      "SELECT id, glasses_record_id, customer_id, from_status, to_status, remark, operator_id, operator_name, created_at FROM customer_glasses_status_logs WHERE glasses_record_id = ? ORDER BY created_at ASC, id ASC",
      [recordId],
    );

    notifyGlassesStatusWx(customer, row, getGlassesStatusLabel(nextStatus), new Date()).catch(() => {});

    connection.release();
    return sendSuccess(res, {
      ...formatGlassesRecord(row),
      statusLogs: logRows.map(formatGlassesStatusLog),
      statusOptions: GLASSES_FLOW_STATUS_OPTIONS,
    }, "配镜流程已更新");
  } catch (error) {
    try { await connection.rollback(); } catch (_) {}
    connection.release();
    next(error);
  }
}

async function uploadCustomerAttachments(req, res, next) {
  const connection = await pool.getConnection();

  try {
    const user = req.user;

    const id = toInt(req.params.id, 0);
    if (!id) {
      connection.release();
      return sendFail(res, "客户ID无效", 400);
    }

    const customer = await getCustomerById(id, user);
    if (!customer) {
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    req.customerName = customer.child_name || "customer";

    const files = await runMulter(req, res);
    if (!files.length) {
      connection.release();
      return sendFail(res, "请选择要上传的文件", 400);
    }

    const maxImageSize = FILE_UPLOAD?.DEFAULT_MAX_SIZE || 10 * 1024 * 1024;
    for (const file of files) {
      const mimeType = String(file.mimetype || "").toLowerCase();
      if (mimeType.startsWith("image/") && Number(file.size || 0) > maxImageSize) {
        for (const uploaded of files) {
          if (uploaded?.path && fs.existsSync(uploaded.path)) {
            try {
              fs.unlinkSync(uploaded.path);
            } catch (unlinkError) {
              // ignore unlink error
            }
          }
        }
        connection.release();
        return sendFail(res, "图片大小不能超过 10MB", 400);
      }
    }

    await connection.beginTransaction();

    const inserted = [];
    for (const file of files) {
      const fileExt = path
        .extname(file.originalname || "")
        .replace(".", "")
        .toLowerCase();
      const filePath = `/uploads/customer_attach/${path.basename(file.path)}`;
      const displayName = file.filename || file.originalname;

      const [result] = await connection.execute(
        `
          INSERT INTO customer_attachments
          (customer_id, file_name, file_path, file_ext, file_size, mime_type, uploaded_by)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `,
        [
          id,
          displayName,
          filePath,
          fileExt || null,
          Number(file.size || 0),
          file.mimetype || null,
          user.userId,
        ],
      );

      inserted.push({
        id: result.insertId,
        customerId: id,
        fileName: file.originalname,
        filePath,
        fileUrl: filePath,
        fileExt,
        fileSize: Number(file.size || 0),
        mimeType: file.mimetype || "",
        uploadedBy: user.userId,
      });
    }

    await writeOperationLog(
      req,
      {
        module: "customer",
        action: "upload_attachment",
        bizType: "customer_attachment",
        bizId: id,
        bizNo: customer.customer_no,
        content: `上传客户附件：${customer.child_name}，共${inserted.length}个文件`,
      },
      connection,
    );

    await connection.commit();
    connection.release();

    return sendSuccess(res, inserted, "上传附件成功");
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore rollback error
    }
    connection.release();

    if (error && error.code === "LIMIT_FILE_SIZE") {
      return sendFail(res, "文件大小超出限制", 400);
    }

    if (error && error.code === "LIMIT_UNEXPECTED_FILE") {
      return sendFail(res, "文件数量超出限制", 400);
    }

    if (error && typeof error.message === "string") {
      if (error.message.includes("文件扩展名不支持")) {
        return sendFail(res, "文件扩展名不支持", 400);
      }
      if (error.message.includes("文件类型不支持")) {
        return sendFail(res, "文件类型不支持", 400);
      }
    }

    if (Array.isArray(req.files)) {
      for (const file of req.files) {
        const uploadedFilePath = file && file.path;
        if (uploadedFilePath && fs.existsSync(uploadedFilePath)) {
          try {
            fs.unlinkSync(uploadedFilePath);
          } catch (unlinkError) {
            // ignore unlink error
          }
        }
      }
    }

    next(error);
  }
}

async function deleteCustomerAttachment(req, res, next) {
  try {
    const user = req.user;

    const id = toInt(req.params.id, 0);
    const attachmentId = toInt(req.params.attachmentId, 0);

    if (!id || !attachmentId) {
      return sendFail(res, "参数无效", 400);
    }

    const customer = await getCustomerById(id, user);
    if (!customer) {
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    const [rows] = await pool.query(
      `
        SELECT
          id,
          customer_id,
          file_name,
          file_path
        FROM customer_attachments
        WHERE id = ?
          AND customer_id = ?
        LIMIT 1
      `,
      [attachmentId, id],
    );

    const attachment = rows[0];
    if (!attachment) {
      return sendFail(res, "附件不存在", 404);
    }

    await pool.execute(`DELETE FROM customer_attachments WHERE id = ?`, [
      attachmentId,
    ]);

    const absoluteFilePath = path.join(
      __dirname,
      "..",
      "..",
      attachment.file_path.replace(/^\/+/, ""),
    );

    if (fs.existsSync(absoluteFilePath)) {
      try {
        fs.unlinkSync(absoluteFilePath);
      } catch (error) {
        // ignore unlink error
      }
    }

    await writeOperationLog(req, {
      module: "customer",
      action: "delete_attachment",
      bizType: "customer_attachment",
      bizId: id,
      bizNo: customer.customer_no,
      content: `删除客户附件：${customer.child_name}，文件：${attachment.file_name}`,
    });

    return sendSuccess(res, null, "删除附件成功");
  } catch (error) {
    next(error);
  }
}

async function ensureCustomerVisible(req, customerId) {
  const scope = buildStoreScope(req.user, "c");
  const [rows] = await pool.query(
    `
      SELECT c.id, c.customer_no, c.child_name, c.parent_phone
      FROM customers c
      WHERE c.id = ? AND ${scope.sql}
      LIMIT 1
    `,
    [customerId, ...scope.params],
  );
  return rows[0] || null;
}

function formatCustomerPhone(row = {}) {
  return {
    id: Number(row.id),
    customerId: Number(row.customer_id),
    phone: row.phone || "",
    relationName: row.relation_name || "",
    isPrimary: Number(row.is_primary || 0) === 1,
    status: Number(row.status || 0),
    createdAt: row.created_at || null,
    updatedAt: row.updated_at || null,
  };
}

async function getCustomerPhones(req, res, next) {
  try {
    await ensureCustomerSchema();
    const customerId = toInt(req.params.id, 0);
    if (!customerId) return sendFail(res, "参数错误", 400);

    const customer = await ensureCustomerVisible(req, customerId);
    if (!customer) return sendFail(res, "客户不存在", 404);

    if (customer.parent_phone) {
      await pool.execute(
        `
          INSERT IGNORE INTO customer_phones (customer_id, phone, is_primary, status)
          VALUES (?, ?, 1, 1)
        `,
        [customerId, customer.parent_phone],
      );
    }

    const [rows] = await pool.query(
      `
        SELECT id, customer_id, phone, relation_name, is_primary, status, created_at, updated_at
        FROM customer_phones
        WHERE customer_id = ?
        ORDER BY is_primary DESC, status DESC, id ASC
      `,
      [customerId],
    );

    return sendSuccess(res, rows.map(formatCustomerPhone));
  } catch (error) {
    next(error);
  }
}

async function addCustomerPhone(req, res, next) {
  try {
    await ensureCustomerSchema();
    const customerId = toInt(req.params.id, 0);
    const phone = String(req.body.phone || "").trim();
    const relationName = normalizeOptionalText(req.body.relationName || req.body.relation_name, 50);
    const isPrimary = Number(req.body.isPrimary || req.body.is_primary || 0) === 1 ? 1 : 0;
    if (!customerId) return sendFail(res, "参数错误", 400);
    if (!isValidPhone(phone)) return sendFail(res, "手机号格式不正确", 400);

    const customer = await ensureCustomerVisible(req, customerId);
    if (!customer) return sendFail(res, "客户不存在", 404);

    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      if (isPrimary) {
        await connection.execute(
          "UPDATE customer_phones SET is_primary = 0 WHERE customer_id = ?",
          [customerId],
        );
      }
      await connection.execute(
        `
          INSERT INTO customer_phones (customer_id, phone, relation_name, is_primary, status)
          VALUES (?, ?, ?, ?, 1)
          ON DUPLICATE KEY UPDATE
            relation_name = VALUES(relation_name),
            is_primary = IF(VALUES(is_primary) = 1, 1, is_primary),
            status = 1
        `,
        [customerId, phone, relationName || null, isPrimary],
      );
      if (isPrimary) {
        await connection.execute(
          "UPDATE customers SET parent_phone = ? WHERE id = ?",
          [phone, customerId],
        );
      }
      await connection.commit();
    } catch (error) {
      await connection.rollback().catch(() => {});
      throw error;
    } finally {
      connection.release();
    }

    await writeOperationLog(req, {
      module: "customer",
      action: "add_phone",
      bizType: "customer_phone",
      bizId: customerId,
      bizNo: customer.customer_no,
      content: `客户 ${customer.child_name} 添加绑定手机号：${phone}`,
    });

    return sendSuccess(res, null, "手机号已保存");
  } catch (error) {
    next(error);
  }
}

async function setCustomerPhonePrimary(req, res, next) {
  try {
    await ensureCustomerSchema();
    const customerId = toInt(req.params.id, 0);
    const phoneId = toInt(req.params.phoneId, 0);
    if (!customerId || !phoneId) return sendFail(res, "参数错误", 400);

    const customer = await ensureCustomerVisible(req, customerId);
    if (!customer) return sendFail(res, "客户不存在", 404);

    const [[phoneRow]] = await pool.query(
      "SELECT id, phone FROM customer_phones WHERE id = ? AND customer_id = ? AND status = 1 LIMIT 1",
      [phoneId, customerId],
    );
    if (!phoneRow) return sendFail(res, "手机号不存在或已停用", 404);

    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      await connection.execute("UPDATE customer_phones SET is_primary = 0 WHERE customer_id = ?", [customerId]);
      await connection.execute("UPDATE customer_phones SET is_primary = 1 WHERE id = ?", [phoneId]);
      await connection.execute("UPDATE customers SET parent_phone = ? WHERE id = ?", [phoneRow.phone, customerId]);
      await connection.commit();
    } catch (error) {
      await connection.rollback().catch(() => {});
      throw error;
    } finally {
      connection.release();
    }

    await writeOperationLog(req, {
      module: "customer",
      action: "set_primary_phone",
      bizType: "customer_phone",
      bizId: customerId,
      bizNo: customer.customer_no,
      content: `客户 ${customer.child_name} 设置主手机号：${phoneRow.phone}`,
    });

    return sendSuccess(res, null, "已设为主手机号");
  } catch (error) {
    next(error);
  }
}

async function updateCustomerPhoneStatus(req, res, next) {
  try {
    await ensureCustomerSchema();
    const customerId = toInt(req.params.id, 0);
    const phoneId = toInt(req.params.phoneId, 0);
    const status = Number(req.body.status) === 1 ? 1 : 0;
    if (!customerId || !phoneId) return sendFail(res, "参数错误", 400);

    const customer = await ensureCustomerVisible(req, customerId);
    if (!customer) return sendFail(res, "客户不存在", 404);

    const [[phoneRow]] = await pool.query(
      "SELECT id, phone, is_primary FROM customer_phones WHERE id = ? AND customer_id = ? LIMIT 1",
      [phoneId, customerId],
    );
    if (!phoneRow) return sendFail(res, "手机号不存在", 404);
    if (Number(phoneRow.is_primary) === 1 && status === 0) {
      return sendFail(res, "主手机号不能停用，请先设置其他主手机号", 400);
    }

    await pool.execute("UPDATE customer_phones SET status = ? WHERE id = ?", [status, phoneId]);

    await writeOperationLog(req, {
      module: "customer",
      action: status === 1 ? "enable_phone" : "disable_phone",
      bizType: "customer_phone",
      bizId: customerId,
      bizNo: customer.customer_no,
      content: `客户 ${customer.child_name} ${status === 1 ? "启用" : "停用"}手机号：${phoneRow.phone}`,
    });

    return sendSuccess(res, null, status === 1 ? "手机号已启用" : "手机号已停用");
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getCustomerOptions,
  getCustomerTags,
  getCustomerStats,
  getCustomerList,
  getCustomerGlassesDeliveryList,
  getCustomerDetail,
  createCustomer,
  updateCustomer,
  updateCustomerStatus,
  deleteCustomer,
  openCustomerCard,
  renewCustomer,
  createCustomerActivityCard,
  consumeCustomerActivityCard,
  createCustomerFollowUp,
  createCustomerVisitCheck,
  createCustomerGlassesRecord,
  updateCustomerGlassesStatus,
  getCustomerPhones,
  addCustomerPhone,
  setCustomerPhonePrimary,
  updateCustomerPhoneStatus,
  uploadCustomerAttachments,
  deleteCustomerAttachment,
};
