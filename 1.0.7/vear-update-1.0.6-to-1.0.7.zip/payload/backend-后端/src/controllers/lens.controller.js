const { pool } = require("../config/db");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { ROLE_ADMIN } = require("../config/constants");
const { toInt } = require("../utils/pagination");
const { writeOperationLog } = require("../utils/operation-log");
const {
  ensureLensSchema,
  formatLens,
  tagsToDb,
} = require("../services/lens.service");

function text(value, maxLength = 255) {
  return String(value || "").trim().slice(0, maxLength);
}

function isAdmin(user) {
  return Number(user?.role) === ROLE_ADMIN;
}

function buildReadScope(user, alias = "l") {
  if (isAdmin(user)) return { sql: "1 = 1", params: [] };
  return {
    sql: `(${alias}.is_system = 1 OR ${alias}.store_id = ?)`,
    params: [Number(user?.storeId || 0)],
  };
}

function normalizePayload(body = {}) {
  const priceRaw = body.referencePrice;
  const referencePrice = priceRaw === "" || priceRaw == null ? null : Number(priceRaw);
  return {
    lensName: text(body.lensName, 120),
    brand: text(body.brand, 100),
    seriesModel: text(body.seriesModel, 120),
    category: text(body.category, 80),
    refractiveIndex: text(body.refractiveIndex, 20),
    material: text(body.material, 80),
    coating: text(body.coating, 120),
    featureTags: tagsToDb(body.featureTags),
    applicablePeople: text(body.applicablePeople, 255),
    referencePrice: Number.isFinite(referencePrice) && referencePrice >= 0 ? referencePrice : null,
    sortOrder: Math.max(0, toInt(body.sortOrder, 0)),
    remark: text(body.remark, 500),
  };
}

async function validateStore(connection, storeId) {
  const id = Number(storeId || 0);
  if (!id) return false;
  const [rows] = await connection.query("SELECT id FROM stores WHERE id = ? AND status = 1 LIMIT 1", [id]);
  return rows.length > 0;
}

async function findAccessibleLens(user, id) {
  const scope = buildReadScope(user, "l");
  const [rows] = await pool.query(
    `SELECT l.*, s.store_name FROM lens_catalog l LEFT JOIN stores s ON s.id = l.store_id
     WHERE l.id = ? AND ${scope.sql} LIMIT 1`,
    [Number(id || 0), ...scope.params],
  );
  return rows[0] || null;
}

function canWrite(user, row) {
  if (isAdmin(user)) return true;
  return Number(row?.is_system || 0) !== 1 && Number(row?.store_id || 0) === Number(user?.storeId || 0);
}

async function getOptions(req, res, next) {
  try {
    await ensureLensSchema();
    const scope = buildReadScope(req.user, "l");
    const keyword = text(req.query.keyword, 100);
    const where = [scope.sql, "l.status = 1"];
    const params = [...scope.params];
    if (keyword) {
      where.push("(l.lens_name LIKE ? OR l.brand LIKE ? OR l.category LIKE ? OR l.refractive_index LIKE ? OR l.feature_tags LIKE ?)");
      for (let i = 0; i < 5; i += 1) params.push(`%${keyword}%`);
    }
    const [rows] = await pool.query(
      `SELECT l.*, s.store_name FROM lens_catalog l LEFT JOIN stores s ON s.id = l.store_id
       WHERE ${where.join(" AND ")}
       ORDER BY l.is_system ASC, l.sort_order ASC, l.lens_name ASC LIMIT 500`,
      params,
    );
    return sendSuccess(res, rows.map(formatLens), "获取镜片选项成功");
  } catch (error) { next(error); }
}

async function getList(req, res, next) {
  try {
    await ensureLensSchema();
    const pageNum = Math.max(toInt(req.query.pageNum, 1), 1);
    const pageSize = Math.min(Math.max(toInt(req.query.pageSize, 10), 1), 100);
    const offset = (pageNum - 1) * pageSize;
    const scope = buildReadScope(req.user, "l");
    const where = [scope.sql];
    const params = [...scope.params];
    const keyword = text(req.query.keyword, 100);
    const status = req.query.status === "" || req.query.status == null ? null : toInt(req.query.status, -1);
    const category = text(req.query.category, 80);
    const refractiveIndex = text(req.query.refractiveIndex, 20);
    const source = text(req.query.source, 20);
    if (keyword) {
      where.push("(l.lens_name LIKE ? OR l.brand LIKE ? OR l.series_model LIKE ? OR l.feature_tags LIKE ?)");
      for (let i = 0; i < 4; i += 1) params.push(`%${keyword}%`);
    }
    if (status === 0 || status === 1) { where.push("l.status = ?"); params.push(status); }
    if (category) { where.push("l.category = ?"); params.push(category); }
    if (refractiveIndex) { where.push("l.refractive_index = ?"); params.push(refractiveIndex); }
    if (source === "system") where.push("l.is_system = 1");
    if (source === "store") where.push("l.is_system = 0");
    const whereSql = where.join(" AND ");
    const [rows] = await pool.query(
      `SELECT l.*, s.store_name FROM lens_catalog l LEFT JOIN stores s ON s.id = l.store_id
       WHERE ${whereSql} ORDER BY l.is_system DESC, l.sort_order ASC, l.updated_at DESC LIMIT ? OFFSET ?`,
      [...params, pageSize, offset],
    );
    const [[count]] = await pool.query(`SELECT COUNT(*) AS total FROM lens_catalog l WHERE ${whereSql}`, params);
    return sendPage(res, rows.map(formatLens), Number(count.total || 0), pageNum, pageSize);
  } catch (error) { next(error); }
}

async function create(req, res, next) {
  const connection = await pool.getConnection();
  try {
    await ensureLensSchema();
    const data = normalizePayload(req.body);
    if (!data.lensName) return sendFail(res, "请输入镜片名称", 400);
    const system = isAdmin(req.user) && Number(req.body.isSystem || 0) === 1;
    const storeId = system ? null : (isAdmin(req.user) ? toInt(req.body.storeId, 0) : Number(req.user.storeId || 0));
    if (!system && !(await validateStore(connection, storeId))) return sendFail(res, "请选择有效门店", 400);
    const [duplicates] = await connection.query(
      `SELECT id FROM lens_catalog WHERE is_system = ? AND ${system ? "store_id IS NULL" : "store_id = ?"}
       AND lens_name = ? AND COALESCE(refractive_index, '') = ? LIMIT 1`,
      system ? [1, data.lensName, data.refractiveIndex] : [0, storeId, data.lensName, data.refractiveIndex],
    );
    if (duplicates.length) return sendFail(res, "当前范围已存在同名、同折射率镜片", 400);
    const [result] = await connection.execute(
      `INSERT INTO lens_catalog
       (store_id,is_system,lens_name,brand,series_model,category,refractive_index,material,coating,feature_tags,applicable_people,reference_price,status,sort_order,remark,created_by,updated_by)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)`,
      [storeId, system ? 1 : 0, data.lensName, data.brand || null, data.seriesModel || null, data.category || null,
        data.refractiveIndex || null, data.material || null, data.coating || null, data.featureTags || null,
        data.applicablePeople || null, data.referencePrice, data.sortOrder, data.remark || null, req.user.userId, req.user.userId],
    );
    await writeOperationLog(req, { module: "lens", action: "create", bizType: "lens", bizId: result.insertId, bizNo: data.lensName, content: `新增镜片：${data.lensName}` }, connection);
    return sendSuccess(res, { id: Number(result.insertId) }, "新增镜片成功");
  } catch (error) { next(error); } finally { connection.release(); }
}

async function update(req, res, next) {
  try {
    await ensureLensSchema();
    const id = toInt(req.params.id, 0);
    const row = await findAccessibleLens(req.user, id);
    if (!row) return sendFail(res, "镜片资料不存在", 404);
    if (!canWrite(req.user, row)) return sendFail(res, "系统模板请先复制为门店镜片后再修改", 403);
    const data = normalizePayload(req.body);
    if (!data.lensName) return sendFail(res, "请输入镜片名称", 400);
    await pool.execute(
      `UPDATE lens_catalog SET lens_name=?,brand=?,series_model=?,category=?,refractive_index=?,material=?,coating=?,feature_tags=?,applicable_people=?,reference_price=?,sort_order=?,remark=?,updated_by=? WHERE id=?`,
      [data.lensName, data.brand || null, data.seriesModel || null, data.category || null, data.refractiveIndex || null,
        data.material || null, data.coating || null, data.featureTags || null, data.applicablePeople || null,
        data.referencePrice, data.sortOrder, data.remark || null, req.user.userId, id],
    );
    await writeOperationLog(req, { module: "lens", action: "update", bizType: "lens", bizId: id, bizNo: data.lensName, content: `编辑镜片：${data.lensName}` });
    return sendSuccess(res, null, "更新镜片成功");
  } catch (error) { next(error); }
}

async function updateStatus(req, res, next) {
  try {
    await ensureLensSchema();
    const id = toInt(req.params.id, 0);
    const row = await findAccessibleLens(req.user, id);
    if (!row) return sendFail(res, "镜片资料不存在", 404);
    if (!canWrite(req.user, row)) return sendFail(res, "无权停用该系统模板", 403);
    const status = Number(req.body.status) === 1 ? 1 : 0;
    await pool.execute("UPDATE lens_catalog SET status=?,updated_by=? WHERE id=?", [status, req.user.userId, id]);
    await writeOperationLog(req, { module: "lens", action: "status", bizType: "lens", bizId: id, bizNo: row.lens_name, content: `${status ? "启用" : "停用"}镜片：${row.lens_name}` });
    return sendSuccess(res, null, "镜片状态已更新");
  } catch (error) { next(error); }
}

async function remove(req, res, next) {
  try {
    await ensureLensSchema();
    const id = toInt(req.params.id, 0);
    const row = await findAccessibleLens(req.user, id);
    if (!row) return sendFail(res, "镜片资料不存在", 404);
    if (!canWrite(req.user, row)) return sendFail(res, "系统模板不可由门店删除", 403);
    await pool.execute("DELETE FROM lens_catalog WHERE id=?", [id]);
    await writeOperationLog(req, { module: "lens", action: "delete", bizType: "lens", bizId: id, bizNo: row.lens_name, content: `删除镜片：${row.lens_name}（历史配镜快照不受影响）` });
    return sendSuccess(res, null, "删除镜片成功，历史配镜记录已保留");
  } catch (error) { next(error); }
}

async function copyToStore(req, res, next) {
  try {
    await ensureLensSchema();
    const source = await findAccessibleLens(req.user, toInt(req.params.id, 0));
    if (!source) return sendFail(res, "镜片资料不存在", 404);
    const storeId = isAdmin(req.user) ? toInt(req.body.storeId, 0) : Number(req.user.storeId || 0);
    if (!(await validateStore(pool, storeId))) return sendFail(res, "请选择有效门店", 400);
    const name = text(req.body.lensName, 120) || source.lens_name;
    const [result] = await pool.execute(
      `INSERT INTO lens_catalog
       (store_id,is_system,lens_name,brand,series_model,category,refractive_index,material,coating,feature_tags,applicable_people,reference_price,status,sort_order,remark,created_by,updated_by)
       VALUES (?,0,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)`,
      [storeId, name, source.brand, source.series_model, source.category, source.refractive_index, source.material,
        source.coating, source.feature_tags, source.applicable_people, source.reference_price, source.sort_order,
        source.remark || "由系统模板复制", req.user.userId, req.user.userId],
    );
    await writeOperationLog(req, { module: "lens", action: "copy", bizType: "lens", bizId: result.insertId, bizNo: name, content: `复制镜片模板到门店：${name}` });
    return sendSuccess(res, { id: Number(result.insertId) }, "已复制为门店镜片");
  } catch (error) { next(error); }
}

module.exports = { getOptions, getList, create, update, updateStatus, remove, copyToStore };
