const CHINA_TIME_ZONE = "Asia/Shanghai";
const CHINA_UTC_OFFSET_MINUTES = 8 * 60;

// China uses UTC+08:00 all year. Fixing the process timezone also makes legacy
// code that relies on Date's local getters deterministic on overseas servers.
process.env.TZ = CHINA_TIME_ZONE;

function toValidDate(input = new Date()) {
  const date = input instanceof Date ? new Date(input.getTime()) : new Date(input);
  return Number.isNaN(date.getTime()) ? null : date;
}

function getChinaParts(input = new Date()) {
  const date = toValidDate(input);
  if (!date) return null;
  const shifted = new Date(date.getTime() + CHINA_UTC_OFFSET_MINUTES * 60 * 1000);
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth() + 1,
    day: shifted.getUTCDate(),
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
    second: shifted.getUTCSeconds(),
    millisecond: shifted.getUTCMilliseconds(),
  };
}

function pad(value, length = 2) {
  return String(value).padStart(length, "0");
}

function formatChinaDateTime(input = new Date()) {
  const parts = getChinaParts(input);
  if (!parts) return "";
  return `${parts.year}-${pad(parts.month)}-${pad(parts.day)} ${pad(parts.hour)}:${pad(parts.minute)}:${pad(parts.second)}`;
}

function toChinaIsoString(input = new Date()) {
  const parts = getChinaParts(input);
  if (!parts) return null;
  return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}T${pad(parts.hour)}:${pad(parts.minute)}:${pad(parts.second)}.${pad(parts.millisecond, 3)}+08:00`;
}

function formatChinaStamp(input = new Date()) {
  const parts = getChinaParts(input);
  if (!parts) return "";
  return `${parts.year}${pad(parts.month)}${pad(parts.day)}-${pad(parts.hour)}${pad(parts.minute)}${pad(parts.second)}`;
}

function formatDateYmd(input) {
  if (!input) return "";

  if (typeof input === "string") {
    const match = input.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (match) {
      return `${match[1]}-${match[2]}-${match[3]}`;
    }
    const parsed = new Date(input);
    if (!Number.isNaN(parsed.getTime())) {
      return formatDateYmd(parsed);
    }
    return "";
  }

  if (input instanceof Date) {
    const parts = getChinaParts(input);
    if (!parts) return "";
    return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}`;
  }

  return "";
}

function parseDateYmd(input) {
  if (!input || typeof input !== "string") return "";
  const match = input.trim().match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return "";
  return `${match[1]}-${match[2]}-${match[3]}`;
}

function isValidDateYmd(input) {
  return Boolean(parseDateYmd(input));
}

function compareDateYmd(a, b) {
  const dateA = parseDateYmd(String(a || ""));
  const dateB = parseDateYmd(String(b || ""));
  if (!dateA || !dateB) return null;
  if (dateA === dateB) return 0;
  return dateA < dateB ? -1 : 1;
}

module.exports = {
  CHINA_TIME_ZONE,
  formatChinaDateTime,
  toChinaIsoString,
  formatChinaStamp,
  formatDateYmd,
  parseDateYmd,
  isValidDateYmd,
  compareDateYmd
};
