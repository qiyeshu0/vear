var CHINA_OFFSET_MS = 8 * 60 * 60 * 1000;
var DATE_ONLY_RE = /^(\d{4})-(\d{2})-(\d{2})$/;
var NAIVE_DATE_TIME_RE = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?$/;

function pad(value, length) {
  return String(value).padStart(length || 2, '0');
}

function parseTimestamp(value) {
  if (value instanceof Date) return value.getTime();
  if (typeof value === 'number') return Number.isFinite(value) ? value : NaN;
  if (!value) return NaN;

  var text = String(value).trim();
  var dateOnly = text.match(DATE_ONLY_RE);
  if (dateOnly) {
    return Date.UTC(Number(dateOnly[1]), Number(dateOnly[2]) - 1, Number(dateOnly[3])) - CHINA_OFFSET_MS;
  }

  var naive = text.match(NAIVE_DATE_TIME_RE);
  if (naive) {
    var milliseconds = Number((naive[7] || '').padEnd(3, '0')) || 0;
    return Date.UTC(
      Number(naive[1]), Number(naive[2]) - 1, Number(naive[3]),
      Number(naive[4]), Number(naive[5]), Number(naive[6] || 0), milliseconds
    ) - CHINA_OFFSET_MS;
  }

  return Date.parse(text);
}

function chinaParts(value) {
  var timestamp = value === undefined ? Date.now() : parseTimestamp(value);
  if (!Number.isFinite(timestamp)) return null;
  var shifted = new Date(timestamp + CHINA_OFFSET_MS);
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth() + 1,
    day: shifted.getUTCDate(),
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
    second: shifted.getUTCSeconds(),
    millisecond: shifted.getUTCMilliseconds(),
    weekday: shifted.getUTCDay()
  };
}

function formatParts(parts, includeSeconds) {
  if (!parts) return '';
  var result = parts.year + '-' + pad(parts.month) + '-' + pad(parts.day) +
    ' ' + pad(parts.hour) + ':' + pad(parts.minute);
  return includeSeconds === false ? result : result + ':' + pad(parts.second);
}

function today(now) {
  var parts = chinaParts(now);
  return parts ? parts.year + '-' + pad(parts.month) + '-' + pad(parts.day) : '';
}

function nowDateTime(now) {
  return formatParts(chinaParts(now), true);
}

function nowDateTimeMinute(now) {
  return formatParts(chinaParts(now), false);
}

function toChinaIsoString(value) {
  var parts = chinaParts(value);
  if (!parts) return '';
  return parts.year + '-' + pad(parts.month) + '-' + pad(parts.day) + 'T' +
    pad(parts.hour) + ':' + pad(parts.minute) + ':' + pad(parts.second) + '.' +
    pad(parts.millisecond, 3) + '+08:00';
}

function formatDateTime(value, fallback) {
  return formatParts(chinaParts(value), true) || (fallback || '');
}

function formatDateTimeMinute(value, fallback) {
  return formatParts(chinaParts(value), false) || (fallback || '');
}

function formatTime(value, fallback) {
  var parts = chinaParts(value);
  return parts ? pad(parts.hour) + ':' + pad(parts.minute) : (fallback || '');
}

function parseDateYmd(value) {
  var match = String(value || '').trim().match(DATE_ONLY_RE);
  if (!match) return null;
  return { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) };
}

function dateSerial(value) {
  var parts = parseDateYmd(value);
  return parts ? Date.UTC(parts.year, parts.month - 1, parts.day) : NaN;
}

function addDays(value, days) {
  var serial = dateSerial(value || today());
  if (!Number.isFinite(serial)) return '';
  var date = new Date(serial + Number(days || 0) * 86400000);
  return date.getUTCFullYear() + '-' + pad(date.getUTCMonth() + 1) + '-' + pad(date.getUTCDate());
}

function diffDays(targetDate, baseDate) {
  var target = dateSerial(String(targetDate || '').slice(0, 10));
  var base = dateSerial(String(baseDate || today()).slice(0, 10));
  if (!Number.isFinite(target) || !Number.isFinite(base)) return NaN;
  return Math.round((target - base) / 86400000);
}

function isBeforeToday(value, now) {
  var target = String(value || '').slice(0, 10);
  return Boolean(target) && diffDays(target, today(now)) < 0;
}

function chinaHour(now) {
  var parts = chinaParts(now);
  return parts ? parts.hour : 0;
}

module.exports = {
  today: today,
  nowDateTime: nowDateTime,
  nowDateTimeMinute: nowDateTimeMinute,
  toChinaIsoString: toChinaIsoString,
  formatDateTime: formatDateTime,
  formatDateTimeMinute: formatDateTimeMinute,
  formatTime: formatTime,
  parseTimestamp: parseTimestamp,
  addDays: addDays,
  diffDays: diffDays,
  isBeforeToday: isBeforeToday,
  chinaHour: chinaHour
};
