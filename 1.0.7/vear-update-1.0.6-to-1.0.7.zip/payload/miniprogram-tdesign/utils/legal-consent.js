var chinaTime = require('./china-time');

var STORAGE_KEY = 'legal_consent_20260714';
var AGREEMENT_VERSION = '2026-07-14';

function readConsent() {
  try {
    return wx.getStorageSync(STORAGE_KEY) || null;
  } catch (e) {
    return null;
  }
}

function hasConsent() {
  var value = readConsent();
  return !!(value && value.accepted === true && value.version === AGREEMENT_VERSION);
}

function acceptConsent() {
  var value = {
    accepted: true,
    version: AGREEMENT_VERSION,
    acceptedAt: chinaTime.toChinaIsoString()
  };
  try { wx.setStorageSync(STORAGE_KEY, value); } catch (e) {}
  return value;
}

function clearConsent() {
  try { wx.removeStorageSync(STORAGE_KEY); } catch (e) {}
}

module.exports = {
  STORAGE_KEY: STORAGE_KEY,
  AGREEMENT_VERSION: AGREEMENT_VERSION,
  readConsent: readConsent,
  hasConsent: hasConsent,
  acceptConsent: acceptConsent,
  clearConsent: clearConsent
};
