const api = require('../../utils/api');
const authStorage = require('../../utils/auth-storage');
const publicConfig = require('../../utils/public-config');
const chinaTime = require('../../utils/china-time');
const app = getApp();
const NOTIFY_SCENES = publicConfig.NOTIFY_SCENES;

function getCurrentCustomerId() {
  var customer = authStorage.getParentCustomer() || app.globalData.customerInfo || {};
  return customer && customer.id ? String(customer.id) : 'default';
}

function getAvatarStorageKey() {
  return 'wx_avatar_' + getCurrentCustomerId();
}

function getAvatarSetStorageKey() {
  return 'wx_avatar_set';
}

function getInitial(name, fallback) {
  name = String(name || '').trim();
  return name ? name.charAt(0) : fallback;
}

function decorateProfile(profile) {
  profile = profile || {};
  var hasCard = !!Number(profile.hasCard || 0);
  if (!hasCard && (Number(profile.totalTimes || 0) > 0 || Number(profile.remainingTimes || 0) > 0 || profile.expireDate || profile.openCardDate || (profile.cards && profile.cards.length))) {
    hasCard = true;
  }
  profile._hasCard = hasCard;
  profile._avatarText = getInitial(profile.childName, '👤');
  profile._statusText = Number(profile.status) === 1 ? '正常' : '停用';
  profile._statusClass = Number(profile.status) === 1 ? 'badge-active' : 'badge-stopped';
  profile._remainingClass = Number(profile.remainingTimes || 0) <= 5 ? 'text-danger' : 'text-success';
  profile._expireClass = profile._isExpired ? 'text-danger' : '';
  var glasses = profile.currentGlasses || {};
  var od = glasses.lensOd || {};
  var os = glasses.lensOs || {};
  function pairValue(key, fallback) {
    var right = od[key] || fallback || '';
    var left = os[key] || fallback || '';
    if (right && left && right !== left) return 'R ' + right + ' / L ' + left;
    return right || left || '';
  }
  profile._lensNameLabel = pairValue('name', glasses.lensName || glasses.lensType);
  profile._lensIndexLabel = pairValue('refractiveIndex', glasses.lensRefractiveIndex);
  profile._lensFeaturesLabel = pairValue('features', glasses.lensFeatures);
  profile._frameInfoLabel = glasses.frameInfo || '';
  profile._hasLensInfo = !!(profile._lensNameLabel || profile._lensIndexLabel || profile._frameInfoLabel);
  return profile;
}

function decorateRecord(item) {
  item = item || {};
  item._time = chinaTime.formatTime(item.verifyTime);
  item._tagText = item.cardName || item.trainingProject || '核销';
  item._tagClass = item.cardName ? 'tag-orange' : 'tag-blue';
  return item;
}

var GLASSES_STATUS_LABELS = { 1: '已下单', 2: '定制中', 3: '制作中', 4: '待取镜', 5: '已交付', 6: '异常处理中', 7: '已取消' };
var GLASSES_FLOW = [1, 2, 3, 4, 5];
var HOME_DELIVERED_KEEP_DAYS = 15;

function parseAnyDate(value) {
  return value && isFinite(chinaTime.parseTimestamp(value)) ? value : null;
}

function daysSince(date) {
  if (!date) return 0;
  var dateText = chinaTime.formatDateTime(date, '').slice(0, 10);
  return Math.max(0, -chinaTime.diffDays(dateText, chinaTime.today()));
}

function getDeliveredAt(item) {
  var logs = item && item.statusLogs || [];
  for (var i = logs.length - 1; i >= 0; i--) {
    if (Number(logs[i].toStatus) === 5) {
      return parseAnyDate(logs[i].createdAt);
    }
  }
  if (Number(item && item.deliveryStatus) === 5) {
    return parseAnyDate(item.recordTime || item.createdAt);
  }
  return null;
}

function isHomeVisibleGlasses(item, keepDays) {
  if (!item) return false;
  keepDays = Number(keepDays || HOME_DELIVERED_KEEP_DAYS);
  var status = Number(item.deliveryStatus || 1);
  if (status === 5) {
    var deliveredAt = getDeliveredAt(item);
    return daysSince(deliveredAt || parseAnyDate(item.recordTime || item.createdAt)) <= keepDays;
  }
  if (status === 7) {
    // 已取消不是正常交付流程，首页不长期展示；历史仍在记录页查看。
    return daysSince(parseAnyDate(item.createdAt || item.recordTime)) <= keepDays;
  }
  return true;
}

function decorateGlassesHome(item, keepDays) {
  item = item || {};
  keepDays = Number(keepDays || HOME_DELIVERED_KEEP_DAYS);
  var status = Number(item.deliveryStatus || 1);
  item._deliveryText = item.deliveryStatusLabel || GLASSES_STATUS_LABELS[status] || '已下单';
  item._deliveryClass = status === 5 ? 'tag-green' : (status === 6 || status === 7 ? 'tag-red' : (status === 4 ? 'tag-orange' : 'tag-blue'));
  item._flowSteps = GLASSES_FLOW.map(function(value) {
    return {
      value: value,
      label: GLASSES_STATUS_LABELS[value],
      cls: status >= value && status <= 5 ? 'done' : '',
      dotCls: status === value ? 'current' : (status > value && status <= 5 ? 'done' : '')
    };
  });
  var od = item.lensOd || {};
  var os = item.lensOs || {};
  var rightName = od.name || item.lensName || item.lensType || '';
  var leftName = os.name || item.lensName || item.lensType || '';
  item._lensLabel = rightName && leftName && rightName !== leftName ? ('R ' + rightName + ' / L ' + leftName) : (rightName || leftName);
  var rightIndex = od.refractiveIndex || item.lensRefractiveIndex || '';
  var leftIndex = os.refractiveIndex || item.lensRefractiveIndex || '';
  item._lensIndexLabel = rightIndex && leftIndex && rightIndex !== leftIndex ? ('R ' + rightIndex + ' / L ' + leftIndex) : (rightIndex || leftIndex);
  var deliveredAt = getDeliveredAt(item);
  if (status === 5) {
    var remain = keepDays - daysSince(deliveredAt || parseAnyDate(item.recordTime || item.createdAt));
    item._hint = remain > 0 ? '已交付，首页还将保留 ' + remain + ' 天' : '已交付';
  } else if (status === 4) {
    item._hint = '眼镜已到店，可安排取镜';
  } else if (status === 6) {
    item._hint = '当前异常处理中，请留意门店通知';
  } else if (status === 7) {
    item._hint = '订单已取消，历史可在记录中查看';
  } else {
    item._hint = '门店正在为您处理眼镜订单';
  }
  return item;
}

Page({
  data: {
    navTitle: '训练助手',
    navSubtitle: '视界记录本',
    showTrainingCard: true,
    showGlassesProgress: true,
    homeConfig: { glassesKeepDaysAfterDelivered: 15, recentVerifyLimit: 5, glassesLimit: 2 },
    currentPage: 'home', profile: {}, recentRecords: [], glassesDeliveries: [],
    subscribed: false, isExpired: false, daysToExpire: 0, avatarUrl: '',
    loading: false, loadError: '', alertType: '', alertText: ''
  },

  onShow() {
    if (!authStorage.getParentToken()) { wx.reLaunch({ url: '/pages/login/login' }); return; }
    this.applyPublicConfig();
    var that = this;
    if (app.refreshPublicConfig) {
      app.refreshPublicConfig(function() { that.applyPublicConfig(); });
    }
    var avatarUrl = wx.getStorageSync(getAvatarStorageKey()) || wx.getStorageSync('wx_avatar') || '';
    var subscribed = !!wx.getStorageSync('wx_subscribed');
    this.setData({ avatarUrl: avatarUrl, subscribed: subscribed });
    this.runFirstTimeFlow();
    this.loadData();
  },

  applyPublicConfig() {
    var cfg = publicConfig.getPublicConfig();
    if (app && app.globalData && app.globalData.publicConfig) cfg = app.globalData.publicConfig;
    this.setData({
      navTitle: (cfg.system && cfg.system.name) || '训练助手',
      navSubtitle: (cfg.system && cfg.system.subtitle) || '视界记录本',
      showTrainingCard: !cfg.features || cfg.features.showTrainingCard !== false,
      showGlassesProgress: !cfg.features || cfg.features.showGlassesProgress !== false,
      homeConfig: Object.assign({ glassesKeepDaysAfterDelivered: 15, recentVerifyLimit: 5, glassesLimit: 2 }, cfg.home || {})
    });
  },

  // ── 首次引导：头像浮层 → 订阅弹窗 ──
  runFirstTimeFlow() {
    var avatarSet = wx.getStorageSync(getAvatarSetStorageKey());
    if (!avatarSet && !this._avatarAsked) {
      this._avatarAsked = true;
      this.setData({ showAvatarTip: true });
      return;
    }

    var subscribed = !!wx.getStorageSync('wx_subscribed');
    if (!subscribed && !this._subModalAsked) {
      this._subModalAsked = true;
      var that = this;
      setTimeout(function() { that.showSubscribeModal(); }, 600);
    }
  },

  onChooseAvatar(e) {
    var url = e.detail.avatarUrl;
    if (!url) return;
    wx.setStorageSync(getAvatarStorageKey(), url);
    wx.setStorageSync(getAvatarSetStorageKey(), true);
    wx.setStorageSync('wx_avatar', url);
    this.setData({ avatarUrl: url, showAvatarTip: false });
    wx.showToast({ title: '头像已设置', icon: 'success', duration: 1000 });
    var that = this;
    setTimeout(function() { that.showSubscribeModal(); }, 600);
  },

  skipAvatar() {
    wx.setStorageSync(getAvatarSetStorageKey(), true);
    this.setData({ showAvatarTip: false });
    var that = this;
    setTimeout(function() { that.showSubscribeModal(); }, 400);
  },

  // ── 订阅弹窗 ──
  showSubscribeModal(refreshed) {
    var that = this;
    var tmplIds = publicConfig.getNotificationTemplates([
      NOTIFY_SCENES.VERIFY_SUCCESS,
      NOTIFY_SCENES.GLASSES_STATUS
    ]);
    if (!tmplIds.length) {
      if (!refreshed && app.refreshPublicConfig) {
        app.refreshPublicConfig(function() { that.showSubscribeModal(true); });
      }
      return;
    }
    wx.showModal({
      title: '开启服务通知',
      content: '开启后，核销结果和配镜进度有变化时会微信提醒你',
      confirmText: '去开启',
      cancelText: '暂不',
      success: function(res) {
        if (res.confirm) {
          wx.requestSubscribeMessage({
            tmplIds: tmplIds,
            success: function(subRes) {
              var accepted = tmplIds.some(function(id) { return subRes[id] === 'accept'; });
              if (accepted) {
                wx.login({
                  success: function(loginRes) {
                    wx.request({
                      url: app.globalData.apiBase + '/subscribe', method: 'POST',
                      header: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + authStorage.getParentToken() },
                      data: { code: loginRes.code },
                      timeout: 15000,
                      success: function(res) {
                        var body = res.data || {};
                        if (res.statusCode === 200 && body.success !== false) {
                          wx.setStorageSync('wx_subscribed', true);
                          that.setData({ subscribed: true });
                          wx.showToast({ title: '订阅成功', icon: 'success', duration: 2000 });
                        } else {
                          wx.showToast({ title: body.message || '订阅保存失败', icon: 'none' });
                        }
                      },
                      fail: function() {
                        wx.showToast({ title: '订阅保存失败', icon: 'none' });
                      }
                    });
                  }
                });
              }
            }
          });
        }
      }
    });
  },

  onSubscribeTap() { this.showSubscribeModal(); },

  // ── 加载数据 ──
  async loadData() {
    this.setData({ loading: true, loadError: '' });
    try {
      var homeCfg = Object.assign({ glassesKeepDaysAfterDelivered: 15, recentVerifyLimit: 5, glassesLimit: 2 }, this.data.homeConfig || {});
      var recentLimit = Math.max(1, Number(homeCfg.recentVerifyLimit || 5));
      var glassesLimit = Math.max(1, Number(homeCfg.glassesLimit || 2));
      var keepDays = Math.max(0, Number(homeCfg.glassesKeepDaysAfterDelivered || 15));
      var [profile, records] = await Promise.all([api.getProfile(), api.getVerifyRecords(1, recentLimit)]);
      var recentRecords = (records && records.list || []).map(decorateRecord);
      var glassesDeliveries = [];
      if (this.data.showGlassesProgress) {
        try {
          var glasses = await api.getGlassesRecords(1, Math.max(10, glassesLimit * 3));
          glassesDeliveries = ((glasses && glasses.list) || [])
            .filter(function(item) { return isHomeVisibleGlasses(item, keepDays); })
            .slice(0, glassesLimit)
            .map(function(item) { return decorateGlassesHome(item, keepDays); });
        } catch (glassesErr) {
          console.warn('[首页眼镜进度加载失败]', glassesErr);
          glassesDeliveries = [];
        }
      }
      var expireDate = profile.expireDate, isExpired = false, daysToExpire = 0;
      if (expireDate) {
        daysToExpire = chinaTime.diffDays(expireDate, chinaTime.today());
        isExpired = daysToExpire < 0;
      }
      var remaining = Number(profile.remainingTimes || 0);
      var hasCard = !!Number(profile.hasCard || 0);
      if (!hasCard && (Number(profile.totalTimes || 0) > 0 || Number(profile.remainingTimes || 0) > 0 || profile.expireDate || profile.openCardDate || (profile.cards && profile.cards.length))) {
        hasCard = true;
      }
      var alertType = '', alertText = '';
      if (hasCard && isExpired) { alertType = 'danger'; alertText = '训练卡已过期，请到店续卡'; }
      else if (hasCard && remaining <= 5 && remaining > 0) { alertType = 'warning'; alertText = '仅剩 ' + remaining + ' 次，请及时续卡'; }
      else if (hasCard && daysToExpire <= 15 && daysToExpire > 0) { alertType = 'info'; alertText = daysToExpire + ' 天后到期，可提前续卡'; }
      profile._isExpired = isExpired;
      this.setData({ profile: decorateProfile(profile), recentRecords: recentRecords, glassesDeliveries: glassesDeliveries, isExpired: isExpired, daysToExpire: Math.max(0, daysToExpire), alertType: alertType, alertText: alertText });
    } catch(err) { console.error('[首页数据加载失败]', err); this.setData({ loadError: '首页加载失败，请下拉刷新或稍后重试' }); wx.showToast({ title: '首页加载失败', icon: 'none' }); }
    finally { this.setData({ loading: false }); }
  },

  onPullDownRefresh() { return require('../../utils/pull-refresh').run(this.loadData()); },
  goGlassesRecords() { var sr=require('../../utils/subscribe-helper'); sr.silentRenew(false, null, '首页-配镜全部记录'); wx.reLaunch({ url: '/pages/records/records?tab=glasses' }); },
  renewCurrentPage() { var sr=require('../../utils/subscribe-helper'); sr.silentRenew(false, null, '首页-当前标签'); },
  goPage(e) { var p=e.currentTarget.dataset.page; var sr=require('../../utils/subscribe-helper'); sr.silentRenew(false, null, '首页-跳转' + p); wx.reLaunch({ url:'/pages/'+p+'/'+p }); },
});
