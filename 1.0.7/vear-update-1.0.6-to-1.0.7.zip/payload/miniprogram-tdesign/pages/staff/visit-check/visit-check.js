var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');
var chinaTime = require('../../../utils/china-time');
function nowText(){return chinaTime.nowDateTimeMinute();}
Page({
  data:{id:0,checkTime:'',checkResult:'',nakedVisionOd:'',nakedVisionOs:'',correctedVisionOd:'',correctedVisionOs:'',pd:'',suggestion:'',remark:'',submitting:false},
  onLoad:function(o){this.setData({id:Number(o.id)||0,checkTime:nowText()});},
  onInput:function(e){var d={};d[e.currentTarget.dataset.key]=e.detail.value;this.setData(d);},
  onPullDownRefresh:function(){return require('../../../utils/pull-refresh').run();},
  submit:async function(){
    if(!this.data.checkResult.trim()) return wx.showToast({title:'请填写检查结果',icon:'none'});
    this.setData({submitting:true});
    try{ await api.createVisitCheck(this.data.id,this.data); wx.showToast({title:'已保存',icon:'success'}); setTimeout(function(){wx.navigateBack();},700); }
    catch(e){console.error('[新增到店检查失败]',e); errorUtil.modal('新增到店检查失败', e, '新增到店检查失败，请检查填写内容');} finally{this.setData({submitting:false});}
  }
});
