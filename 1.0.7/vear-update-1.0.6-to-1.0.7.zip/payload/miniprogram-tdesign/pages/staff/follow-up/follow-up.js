var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');
var chinaTime = require('../../../utils/china-time');
function nowText(){return chinaTime.nowDateTimeMinute();}
Page({
  data:{ id:0, recordTime:'', result:'已回访', content:'', remark:'', submitting:false },
  onLoad:function(o){ this.setData({ id:Number(o.id)||0, recordTime: nowText() }); },
  onInput:function(e){ var d={}; d[e.currentTarget.dataset.key]=e.detail.value; this.setData(d); },
  onPullDownRefresh:function(){return require('../../../utils/pull-refresh').run();},
  submit: async function(){
    if(!this.data.id) return wx.showToast({title:'参数错误',icon:'none'});
    if(!this.data.result.trim()) return wx.showToast({title:'请填写回访结果',icon:'none'});
    if(!this.data.content.trim()) return wx.showToast({title:'请填写回访内容',icon:'none'});
    this.setData({submitting:true});
    try{ await api.createFollowUp(this.data.id,{recordTime:this.data.recordTime,result:this.data.result,content:this.data.content,remark:this.data.remark}); wx.showToast({title:'已保存',icon:'success'}); setTimeout(function(){wx.navigateBack();},700); }
    catch(e){ console.error('[新增回访失败]',e); errorUtil.modal('新增回访失败', e, '新增回访失败，请检查填写内容'); }
    finally{ this.setData({submitting:false}); }
  }
});
