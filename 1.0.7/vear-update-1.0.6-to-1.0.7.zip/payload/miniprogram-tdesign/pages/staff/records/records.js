var authStorage = require('../../../utils/auth-storage');
var api = require('../utils/admin-api');
var chinaTime = require('../../../utils/china-time');

function decorateRecord(item, revokeMap, canRequestRevoke) {
  item = item || {};
  var status = item.revoked ? 'approved' : (revokeMap && revokeMap[item.id]) || '';
  item._projectText = item.trainingProject === '退卡' ? '⚠ 退卡' : item.trainingProject;
  item._projectClass = item.trainingProject === '退卡' ? 'tag-red' : 'tag-blue';
  item._showRevoked = status === 'approved';
  item._showPending = status === 'pending';
  item._showRejected = status === 'rejected';
  item._canRequestRevoke = !item._showRevoked && !item._showPending && !item._showRejected && !!canRequestRevoke;
  item._timeText = chinaTime.formatDateTime(item.verifyTime);
  return item;
}

Page({
  data: { list: [], page: 1, hasMore: false, loading: false, loadError: '', filterDate: '', title: '核销记录', revokeMap: {}, isAdmin: false },

  onLoad: function(options) {
    var filter = options.filter || '';
    if (filter === 'today') {
      var dateStr = chinaTime.today();
      this.setData({ filterDate: dateStr, title: '今日核销' });
      wx.setNavigationBarTitle({ title: '今日核销' });
    }
    var user = authStorage.getStaffUser() || {};
    this.setData({
      canApproveRevoke: authStorage.hasStaffPermission('record:revoke:approve'),
      canRequestRevoke: authStorage.hasStaffPermission('record:revoke:request')
    });
  },

  onShow: function() { this.load(1); },

  onReachBottom: function() {
    if (this.data.hasMore && !this.data.loading) this.load(this.data.page + 1);
  },

  onDateChange: function(e) { this.setData({ filterDate: e.detail.value }); this.load(1); },

  load: async function(page) {
    if (page > 1 && this.data.loading) return;
    this.setData({ loading: true, loadError: '' });
    try {
      var d = this.data.filterDate;
      var records = await api.getVerifyRecords(page, d, d);
      var list = page === 1 ? (records && records.list || []) : this.data.list.concat(records && records.list || []);

      // 加载撤回状态：审批人看待审批；普通发起人看自己的申请闭环。
      var map = page === 1 ? {} : this.data.revokeMap;
      if (this.data.canApproveRevoke) {
        try {
          var revokeList = await api.getPendingRevokes();
          (revokeList || []).forEach(function(r) {
            map[r.verify_record_id] = r.status === 0 ? 'pending' : r.status === 1 ? 'approved' : 'rejected';
          });
        } catch(e) { console.error('[待审批撤回状态加载失败]', e); }
      }
      if (this.data.canRequestRevoke) {
        try {
          var myRevokes = await api.getMyRevokes();
          (myRevokes || []).forEach(function(r) {
            map[r.verify_record_id] = r.status === 0 ? 'pending' : r.status === 1 ? 'approved' : 'rejected';
          });
        } catch(e) { console.error('[我的撤回状态加载失败]', e); }
      }
      list = list.map(function(item) { return decorateRecord(item, map, this.data.canRequestRevoke); }, this);
      var rows = records && records.list || [];
      var hasMore = Boolean(records && (records.hasMore || (records.total && records.total > page * 15) || rows.length >= 15));
      this.setData({ list: list, page: page, hasMore: hasMore, revokeMap: map });
    } catch(e) {
      console.error('[核销记录加载失败]', e);
      this.setData({ loadError: '核销记录加载失败，请重试' });
    } finally {
      this.setData({ loading: false });
    }
  },

  requestRevoke: function(e) {
    var id = e.currentTarget.dataset.id;
    var no = e.currentTarget.dataset.no;
    var that = this;
    // 先弹窗让输入原因
    wx.showModal({
      title: '申请撤回',
      content: '',
      editable: true,
      placeholderText: '选填：如误操作、客户未到店等',
      success: function(res) {
        if (!res.confirm) return;
        var reason = (res.content || '').trim();
        api.requestRevoke(id, reason).then(function() {
          wx.showToast({ title: '已提交', icon: 'success' });
          var map = that.data.revokeMap || {};
          map[id] = 'pending';
          that.setData({ revokeMap: map });
          that.load(1);
        }).catch(function(err) {
          console.error('[撤回申请失败]', err);
        });
      }
    });
  },

  onPullDownRefresh: function() {
    return require('../../../utils/pull-refresh').run(this.load(1));
  },

  retry: function() { this.load(1); },
  goPage: function(e) { var p = e.currentTarget.dataset.page; wx.reLaunch({ url: '/pages/' + p + '/' + p.split('/').pop() }); },
});
