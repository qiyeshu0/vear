var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');
var chinaTime = require('../../../utils/china-time');
function nowText(){return chinaTime.nowDateTimeMinute();}

var GLASSES_STATUS_OPTIONS = [
  { value: 1, label: '已下单' },
  { value: 2, label: '定制中' },
  { value: 3, label: '制作中' },
  { value: 4, label: '待取镜' },
  { value: 5, label: '已交付' },
  { value: 6, label: '异常处理中' },
  { value: 7, label: '已取消' }
];

Page({
  data:{id:0,recordTime:'',deliveryStatus:1,statusIndex:0,deliveryStatusOptions:GLASSES_STATUS_OPTIONS,deliveryStatusLabel:'已下单',pd:'',sphereOd:'',cylinderOd:'',axisOd:'',sphereOs:'',cylinderOs:'',axisOs:'',lensOptions:[{id:0,_label:'请选择镜片'}],lensOdIndex:0,lensOsIndex:0,lensOdId:null,lensOsId:null,sameLens:true,useCustomLens:false,lensBrand:'',lensName:'',lensRefractiveIndex:'',lensFeatures:'',frameInfo:'',remark:'',submitting:false,lensLoading:false},
  onLoad:function(o){this.setData({id:Number(o.id)||0,recordTime:nowText()});this.loadLenses();},
  loadLenses:async function(){
    this.setData({lensLoading:true});
    try{
      var rows=await api.getLensOptions();
      rows=Array.isArray(rows)?rows:((rows&&rows.list)||[]);
      rows=rows.map(function(item){item._label=[item.brand,item.lensName,item.refractiveIndex?('折射率'+item.refractiveIndex):''].filter(Boolean).join(' / ');return item;});
      this.setData({lensOptions:[{id:0,_label:'请选择镜片'}].concat(rows)});
    }catch(e){console.error('[镜片选项加载失败]',e);wx.showToast({title:'镜片资料加载失败',icon:'none'});}
    finally{this.setData({lensLoading:false});}
  },
  onInput:function(e){var d={};d[e.currentTarget.dataset.key]=e.detail.value;this.setData(d);},
  onStatus:function(e){
    var index=Number(e.detail.value)||0;
    var opt=GLASSES_STATUS_OPTIONS[index]||GLASSES_STATUS_OPTIONS[0];
    this.setData({statusIndex:index,deliveryStatus:opt.value,deliveryStatusLabel:opt.label});
  },
  onSameLens:function(e){var same=!!e.detail.value;this.setData({sameLens:same,lensOsId:same?this.data.lensOdId:this.data.lensOsId,lensOsIndex:same?this.data.lensOdIndex:this.data.lensOsIndex});},
  onCustomLens:function(e){this.setData({useCustomLens:!!e.detail.value});},
  onLensOd:function(e){var index=Number(e.detail.value)||0;var item=this.data.lensOptions[index]||{};var next={lensOdIndex:index,lensOdId:Number(item.id)||null};if(this.data.sameLens){next.lensOsIndex=index;next.lensOsId=Number(item.id)||null;}this.setData(next);},
  onLensOs:function(e){var index=Number(e.detail.value)||0;var item=this.data.lensOptions[index]||{};this.setData({lensOsIndex:index,lensOsId:Number(item.id)||null});},
  onPullDownRefresh:function(){return require('../../../utils/pull-refresh').run();},
  submit:async function(){
    var has=this.data.pd||this.data.sphereOd||this.data.cylinderOd||this.data.axisOd||this.data.sphereOs||this.data.cylinderOs||this.data.axisOs;
    if(!has) return wx.showToast({title:'请至少填写一项参数',icon:'none'});
    this.setData({submitting:true});
    var payload = {
      recordTime:this.data.recordTime,
      deliveryStatus:this.data.deliveryStatus,
      pd:this.data.pd,
      sphereOd:this.data.sphereOd,
      cylinderOd:this.data.cylinderOd,
      axisOd:this.data.axisOd,
      sphereOs:this.data.sphereOs,
      cylinderOs:this.data.cylinderOs,
      axisOs:this.data.axisOs,
      lensOdId:this.data.useCustomLens?null:this.data.lensOdId,
      lensOsId:this.data.useCustomLens?null:(this.data.sameLens?this.data.lensOdId:this.data.lensOsId),
      lensOdBrand:this.data.useCustomLens?this.data.lensBrand:'',
      lensOdName:this.data.useCustomLens?this.data.lensName:'',
      lensOdRefractiveIndex:this.data.useCustomLens?this.data.lensRefractiveIndex:'',
      lensOdFeatures:this.data.useCustomLens?this.data.lensFeatures:'',
      lensOsBrand:this.data.useCustomLens?this.data.lensBrand:'',
      lensOsName:this.data.useCustomLens?this.data.lensName:'',
      lensOsRefractiveIndex:this.data.useCustomLens?this.data.lensRefractiveIndex:'',
      lensOsFeatures:this.data.useCustomLens?this.data.lensFeatures:'',
      frameInfo:this.data.frameInfo,
      remark:this.data.remark
    };
    try{ await api.createGlassesRecord(this.data.id,payload); wx.showToast({title:'已保存',icon:'success'}); setTimeout(function(){wx.navigateBack();},700); }
    catch(e){console.error('[新增配镜记录失败]',e); errorUtil.modal('新增配镜失败', e, '新增配镜失败，请检查验光参数');} finally{this.setData({submitting:false});}
  }
});
