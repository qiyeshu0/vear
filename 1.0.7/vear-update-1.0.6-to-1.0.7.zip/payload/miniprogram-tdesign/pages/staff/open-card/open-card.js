var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');
var chinaTime = require('../../../utils/china-time');

function today() { return chinaTime.today(); }
function addDays(dateStr, days) { return chinaTime.addDays(dateStr || today(), days); }

Page({
  data: {
    id: 0, templateList: [], selectedTemplateIndex: -1, selectedTemplate: null, priceOptions: [], selectedPriceIndex: -1,
    selectedProject: '', cardName: '', totalTimes: '', salePrice: '', selectedTemplateName: '请选择卡项模板', selectedProjectLabel: '选择模板后自动带出', salePriceLabel: '请选择', openCardDate: '', expireDate: '', remark: '', submitting: false
  },

  onLoad: function(options) {
    var openDate = today();
    this.setData({ id: parseInt(options.id) || 0, openCardDate: openDate, expireDate: addDays(openDate, 90) });
    this.loadTemplates();
  },

  loadTemplates: async function() {
    try {
      var templates = await api.getCardTemplates();
      this.setData({ templateList: (templates || []).filter(function(t) { return !t.isPromotion; }) });
    } catch(e) { console.error('[卡项模板加载失败]', e); errorUtil.toast(e, '卡项模板加载失败'); }
  },

  onTemplateChange: function(e) {
    var idx = parseInt(e.detail.value);
    var item = this.data.templateList[idx];
    var priceOptions = item && item.priceOptions || [];
    this.setData({
      selectedTemplateIndex: idx,
      selectedTemplate: item || null,
      selectedProject: item ? item.trainingProject : '',
      cardName: item ? item.cardName : '',
      totalTimes: item ? String(item.defaultTimes || '') : '',
      priceOptions: priceOptions,
      selectedPriceIndex: priceOptions.length ? 0 : -1,
      salePrice: priceOptions.length ? String(priceOptions[0]) : this.data.salePrice,
      selectedTemplateName: item ? item.cardName : '请选择卡项模板',
      selectedProjectLabel: item && item.trainingProject ? item.trainingProject : '选择模板后自动带出',
      salePriceLabel: priceOptions.length ? '¥' + String(priceOptions[0]) : '请选择'
    });
  },

  onPriceChange: function(e) {
    var idx = parseInt(e.detail.value);
    var price = this.data.priceOptions[idx];
    this.setData({ selectedPriceIndex: idx, salePrice: price != null ? String(price) : '', salePriceLabel: price != null ? '¥' + String(price) : '请选择' });
  },

  onInput: function(e) { var d = {}; d[e.currentTarget.dataset.key] = e.detail.value; this.setData(d); },

  onOpenDateChange: function(e) {
    var v = e.detail.value;
    this.setData({ openCardDate: v, expireDate: addDays(v, 90) });
  },

  onDateChange: function(e) { var d = {}; d[e.currentTarget.dataset.key] = e.detail.value; this.setData(d); },

  onPullDownRefresh: function() {
    return require('../../../utils/pull-refresh').run(this.loadTemplates());
  },

  doSubmit: async function() {
    var data = this.data;
    var project = data.selectedProject;
    if (!data.selectedTemplate || !data.selectedTemplate.id) { wx.showToast({ title: '请选择卡项模板', icon: 'none' }); return; }
    if (!project) { wx.showToast({ title: '卡项模板缺少训练项目', icon: 'none' }); return; }
    if (!data.totalTimes || parseInt(data.totalTimes) <= 0) { wx.showToast({ title: '请填写总次数', icon: 'none' }); return; }
    if (!data.expireDate) { wx.showToast({ title: '请选择到期日期', icon: 'none' }); return; }
    this.setData({ submitting: true });
    try {
      await api.openCard(data.id, {
        cardTemplateId: data.selectedTemplate.id, trainingProject: project, cardName: data.cardName || project,
        totalTimes: parseInt(data.totalTimes), salePrice: data.salePrice === '' ? null : Number(data.salePrice),
        openCardDate: data.openCardDate, expireDate: data.expireDate, remark: data.remark || ''
      });
      wx.showToast({ title: '开卡成功', icon: 'success' });
      setTimeout(function() { wx.navigateBack(); }, 800);
    } catch(e) { console.error('[开卡失败]', e); errorUtil.modal('开卡失败', e, '开卡失败，请检查客户状态、卡项模板或日期'); } finally { this.setData({ submitting: false }); }
  },
});
