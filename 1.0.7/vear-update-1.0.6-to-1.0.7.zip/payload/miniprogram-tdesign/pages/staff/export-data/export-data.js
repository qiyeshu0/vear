var authStorage = require('../../../utils/auth-storage');
var app = getApp();
var errorUtil = require('../utils/error');
var chinaTime = require('../../../utils/china-time');

function today() { return chinaTime.today(); }

Page({
  data: { startDate: '', endDate: '', childName: '', loading: false },

  onLoad: function() {
    var d = today();
    this.setData({ startDate: d, endDate: d });
  },

  onInput: function(e) { var d = {}; d[e.currentTarget.dataset.key] = e.detail.value; this.setData(d); },
  onDate: function(e) { var d = {}; d[e.currentTarget.dataset.key] = e.detail.value; this.setData(d); },

  onPullDownRefresh: function() {
    return require('../../../utils/pull-refresh').run();
  },

  doExport: function() {
    var start = this.data.startDate;
    var end = this.data.endDate;
    if (!start || !end) { wx.showToast({ title: '请选择日期范围', icon: 'none' }); return; }
    if (start > end) { wx.showToast({ title: '开始日期不能晚于结束日期', icon: 'none' }); return; }

    this.setData({ loading: true });
    var that = this;
    var base = (app.globalData.apiBase || '').replace('/api/wx', '');
    var url = base + '/api/records/export?startDate=' + start + '&endDate=' + end;
    var childName = this.data.childName.trim();
    if (childName) url += '&childName=' + encodeURIComponent(childName);
    var token = authStorage.getStaffToken();

    wx.showLoading({ title: '正在生成...' });
    wx.downloadFile({
      url: url,
      header: { 'Authorization': 'Bearer ' + token },
      timeout: 30000,
      success: function(res) {
        wx.hideLoading();
        if (res.statusCode === 200) {
          wx.openDocument({ filePath: res.tempFilePath, showMenu: true });
        } else if (res.statusCode === 401) {
          wx.showToast({ title: '登录已过期', icon: 'none' });
        } else {
          errorUtil.modal('导出失败', { message: '服务器返回状态码：' + res.statusCode }, '导出失败，请检查日期范围或权限');
        }
        that.setData({ loading: false });
      },
      fail: function(err) {
        wx.hideLoading();
        errorUtil.modal('导出失败', err || { message: '网络异常，请重试' }, '导出失败，请检查网络或服务器');
        that.setData({ loading: false });
      }
    });
  },
});
