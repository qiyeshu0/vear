module.exports = {
  version: '1.1.4',
  compatibleSystem: '1.0.x',
  channel: '正式版'
};
