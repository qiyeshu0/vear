var authStorage = require('../../../utils/auth-storage');
var req = require('./admin-request');
var errorUtil = require('./error');

module.exports = {
  // 当前员工信息（每次从服务器读取最新角色和归属门店）
  getStaffProfile: function() { return req.request({ url: '/api/auth/profile' }); },
  // 今日统计
  getTodayVerify: function() { return req.request({ url: '/api/verify/today' }); },
  // 可核销客户
  getVerifyOptions: function(keyword, page) {
    return req.request({ url: '/api/verify/customers/options', data: { keyword: keyword || '', pageNum: page || 1, pageSize: 20 } });
  },
  // 执行核销
  doVerify: function(customerId, remark, customerCardId) {
    var data = { customerId: Number(customerId) || 0, remark: remark || '' };
    if (customerCardId) data.customerCardId = Number(customerCardId) || 0;
    return req.request({ url: '/api/verify', method: 'POST', data: data });
  },
  // 客户列表
  getCustomers: function(page, keyword, status, extra) {
    var data = Object.assign({ pageNum: page || 1, pageSize: 15, keyword: keyword || '', status: status != null ? status : '' }, extra || {});
    return req.request({ url: '/api/customers', data: data });
  },
  // 客户详情
  getCustomerDetail: function(id) {
    return req.request({ url: '/api/customers/' + id });
  },
  // 核销记录
  getVerifyRecords: function(page, startDate, endDate) {
    return req.request({ url: '/api/records', data: { pageNum: page || 1, pageSize: 15, startDate: startDate || '', endDate: endDate || '' } });
  },
  // 申请撤回
  requestRevoke: function(recordId, reason) {
    return req.request({ url: '/api/records/' + recordId + '/request-revoke', method: 'POST', data: { reason: reason || '' } });
  },
  // 待审批列表
  getPendingRevokes: function() {
    return req.request({ url: '/api/records/revoke-requests/pending' });
  },
  // 我的撤回申请状态
  getMyRevokes: function() {
    return req.request({ url: '/api/records/revoke-requests/mine' });
  },
  // 审批撤回
  approveRevoke: function(reqId, approved, note) {
    return req.request({ url: '/api/records/revoke-requests/' + reqId + '/approve', method: 'POST', data: { approved: approved, note: note || '' } });
  },
  // 开卡
  openCard: function(customerId, data) {
    return req.request({ url: '/api/customers/' + customerId + '/open-card', method: 'POST', data: data });
  },
  // 续卡
  renewCard: function(customerId, data) {
    return req.request({ url: '/api/customers/' + customerId + '/renew', method: 'POST', data: data });
  },
  // 卡项模板选项
  getCardTemplates: function() {
    return req.request({ url: '/api/card-templates/options?status=1' });
  },
  // 当前门店可用镜片（系统模板 + 当前门店镜片）
  getLensOptions: function() {
    return req.request({ url: '/api/lenses/options' });
  },
  // 操作日志
  getLogs: function(params) {
    var q = [];
    if (params.pageNum) q.push('pageNum=' + params.pageNum);
    if (params.pageSize) q.push('pageSize=' + params.pageSize);
    if (params.keyword) q.push('keyword=' + encodeURIComponent(params.keyword));
    if (params.module) q.push('module=' + params.module);
    if (params.action) q.push('action=' + params.action);
    if (params.startDate) q.push('startDate=' + params.startDate);
    if (params.endDate) q.push('endDate=' + params.endDate);
    if (params.storeId) q.push('storeId=' + params.storeId);
    return req.request({ url: '/api/logs?' + q.join('&') });
  },
  // 门店选项
  getStoreOptions: function() {
    return req.request({ url: '/api/stores/options' });
  },
  // 首页看板
  getDashboard: function() { return req.request({ url: '/api/dashboard/overview' }); },
  // 全体员工可用的来访快捷登记
  getVisitCustomerOptions: function(keyword) {
    return req.request({ url: '/api/visits/customer-options', data: { keyword: keyword || '' } });
  },
  createHealthVisit: function(customerId) {
    return req.request({
      url: '/api/visits',
      method: 'POST',
      data: { customerId: Number(customerId) || 0, visitType: 'other', verificationRequired: false }
    });
  },
  // 退卡
  refundCustomer: function(customerId, data) { return req.request({ url: '/api/customers/' + customerId + '/refund', method: 'POST', data: data }); },
  // 编辑客户
  updateCustomer: function(id, data) { return req.request({ url: '/api/customers/' + id, method: 'PUT', data: data }); },

  // 客户启用/停用
  updateCustomerStatus: function(customerId, status) { return req.request({ url: '/api/customers/' + customerId + '/status', method: 'PATCH', data: { status: Number(status) } }); },
  // 删除附件
  deleteAttachment: function(customerId, attachmentId) { return req.request({ url: '/api/customers/' + customerId + '/attachments/' + attachmentId, method: 'DELETE' }); },
  // 绑定手机号
  getCustomerPhones: function(customerId) { return req.request({ url: '/api/customers/' + customerId + '/phones' }); },
  addCustomerPhone: function(customerId, data) { return req.request({ url: '/api/customers/' + customerId + '/phones', method: 'POST', data: data }); },
  setPhonePrimary: function(customerId, phoneId) { return req.request({ url: '/api/customers/' + customerId + '/phones/' + phoneId + '/primary', method: 'PATCH' }); },
  updatePhoneStatus: function(customerId, phoneId, status) { return req.request({ url: '/api/customers/' + customerId + '/phones/' + phoneId + '/status', method: 'PATCH', data: { status: Number(status) } }); },
  // 客户详情新增记录
  createFollowUp: function(customerId, data) { return req.request({ url: '/api/customers/' + customerId + '/follow-ups', method: 'POST', data: data }); },
  createVisitCheck: function(customerId, data) { return req.request({ url: '/api/customers/' + customerId + '/visit-checks', method: 'POST', data: data }); },
  createGlassesRecord: function(customerId, data) { return req.request({ url: '/api/customers/' + customerId + '/glasses-records', method: 'POST', data: data }); },
  updateGlassesStatus: function(customerId, recordId, data) { return req.request({ url: '/api/customers/' + customerId + '/glasses-records/' + recordId + '/status', method: 'PATCH', data: data }); },
  createActivityCard: function(customerId, data) { return req.request({ url: '/api/customers/' + customerId + '/activity-cards', method: 'POST', data: data }); },
  consumeActivityCard: function(customerId, cardId, data) { return req.request({ url: '/api/customers/' + customerId + '/activity-cards/' + cardId + '/consume', method: 'POST', data: data }); },
  // 通知中心
  getNotifications: function() { return req.request({ url: '/api/dashboard/notifications' }); },
  markNotificationRead: function(id) { return req.request({ url: '/api/dashboard/notifications/' + id + '/read', method: 'POST' }); },
  markNotificationHandled: function(id, note) { return req.request({ url: '/api/dashboard/notifications/' + id + '/handle', method: 'POST', data: { note: note || '' } }); },
  markAllNotificationsRead: function() { return req.request({ url: '/api/dashboard/notifications/read-all', method: 'POST' }); },
  // 上传附件
  uploadAttachment: function(customerId, filePath) {
    var app = getApp();
    var base = (app.globalData.apiBase || '').replace('/api/wx', '');
    return new Promise(function(resolve, reject) {
      wx.uploadFile({
        url: base + '/api/customers/' + customerId + '/attachments',
        filePath: filePath, name: 'files',
        header: { 'Authorization': 'Bearer ' + authStorage.getStaffToken() },
        timeout: 30000,
        success: function(res) {
          if (res.statusCode === 200) {
            try { var body = JSON.parse(res.data); if (body.success !== false) resolve(body); else { body._message = errorUtil.getErrorMessage(body, '上传失败'); reject(body); } }
            catch(e) { resolve(true); }
          } else {
            var body = {};
            try { body = JSON.parse(res.data || '{}'); } catch(e) {}
            body._message = errorUtil.getErrorMessage(body, '上传失败(' + res.statusCode + ')');
            reject(body);
          }
        },
        fail: function(err) { reject(err || new Error('网络异常')); }
      });
    });
  },
};
