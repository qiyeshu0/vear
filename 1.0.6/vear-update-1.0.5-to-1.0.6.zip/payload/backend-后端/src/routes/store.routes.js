const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const {
  listStores,
  getStoreDetail,
  createStore,
  updateStore,
  deleteStore,
  getStoreOptions
} = require("../controllers/store.controller");

const router = express.Router();
router.use(auth());

// 门店选项会在 controller 内按当前账号强制限定：非超级管理员只能读取自己的门店。
router.get("/options", getStoreOptions);
router.get("/", requireUserPermission("store:view"), listStores);
router.get("/:id", requireUserPermission("store:view"), getStoreDetail);
router.post("/", requireUserPermission("store:create"), createStore);
router.put("/:id", requireUserPermission("store:update"), updateStore);
router.delete("/:id", requireUserPermission("store:delete"), deleteStore);

module.exports = router;
