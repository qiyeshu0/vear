var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');

function decorateCustomer(item) {
  item = item || {};
  item._statusText = Number(item.status) === 1 ? '正常' : '停用';
  item._statusClass = Number(item.status) === 1 ? 'tag-green' : 'tag-red';
  item._projectText = item.trainingProject || '未开卡';
  item._visited = false;
  return item;
}

Page({
  data: {
    keyword: '',
    list: [],
    loading: false,
    loadError: '',
    submittingId: 0,
    _timer: 0
  },

  onShow: function() {
    if (!this.data.list.length) this.search();
  },

  onSearch: function(e) {
    this.setData({ keyword: e.detail.value || '' });
    clearTimeout(this.data._timer);
    var that = this;
    this.data._timer = setTimeout(function() { that.search(); }, 350);
  },

  search: async function() {
    this.setData({ loading: true, loadError: '' });
    try {
      var rows = await api.getVisitCustomerOptions(this.data.keyword);
      this.setData({ list: (rows || []).map(decorateCustomer) });
    } catch (err) {
      console.error('[来访客户加载失败]', err);
      this.setData({ loadError: '客户名单加载失败，请重试' });
    } finally {
      this.setData({ loading: false });
    }
  },

  registerVisit: function(e) {
    var id = Number(e.currentTarget.dataset.id || 0);
    var name = e.currentTarget.dataset.name || '该客户';
    var status = Number(e.currentTarget.dataset.status);
    if (!id || this.data.submittingId) return;
    if (status !== 1) {
      wx.showToast({ title: '该客户已停用，无法登记', icon: 'none' });
      return;
    }
    var that = this;
    wx.showModal({
      title: '登记来访',
      content: '确认登记「' + name + '」今天到店保健吗？',
      confirmText: '确认登记',
      success: async function(result) {
        if (!result.confirm) return;
        that.setData({ submittingId: id });
        try {
          await api.createHealthVisit(id);
          var list = that.data.list.map(function(item) {
            if (Number(item.id) === id) item._visited = true;
            return item;
          });
          that.setData({ list: list });
          wx.showToast({ title: '登记成功', icon: 'success' });
        } catch (err) {
          console.error('[来访登记失败]', err);
          errorUtil.modal('登记失败', err, '登记失败，请稍后重试');
        } finally {
          that.setData({ submittingId: 0 });
        }
      }
    });
  },

  onPullDownRefresh: function() {
    return require('../../../utils/pull-refresh').run(this.search());
  },

  retry: function() { this.search(); },
  goPage: function(e) {
    var p = e.currentTarget.dataset.page;
    wx.reLaunch({ url: '/pages/' + p + '/' + p.split('/').pop() });
  }
});
