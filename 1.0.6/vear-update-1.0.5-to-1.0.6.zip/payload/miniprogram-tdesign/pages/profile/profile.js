var api = require('../../utils/api');
var authStorage = require('../../utils/auth-storage');
var publicConfig = require('../../utils/public-config');
var app = getApp();

function loadAccounts() {
  // 从缓存的静默登录结果读取，或调接口
  var cached = wx.getStorageSync('wx_accounts') || [];
  return decorateAccounts(cached);
}

function getAvatarUrl(customerId) {
  if (customerId) {
    return wx.getStorageSync('wx_avatar_' + customerId) || '';
  }
  return wx.getStorageSync('wx_avatar') || '';
}

function getInitial(name, fallback) {
  name = String(name || '').trim();
  return name ? name.charAt(0) : fallback;
}

function decorateAccount(item) {
  item = item || {};
  if (item.id != null) item.id = Number(item.id);
  item._avatarText = getInitial(item.childName, '我');
  return item;
}

function decorateAccounts(list) {
  return (list || []).map(function(item) { return decorateAccount(item); });
}

function decorateProfile(profile) {
  profile = decorateAccount(profile || {});
  var total = Number(profile.totalTimes || 0);
  var used = Number(profile.usedTimes || 0);
  var pct = total > 0 ? Math.min(100, Math.max(0, used / total * 100)) : 0;
  profile._usagePercent = pct.toFixed(0);
  return profile;
}

function mergeAccounts(current, next) {
  var map = {};
  (current || []).forEach(function(item) {
    if (item && item.id) map[String(Number(item.id))] = decorateAccount(item);
  });
  (next || []).forEach(function(item) {
    if (item && item.id) map[String(Number(item.id))] = decorateAccount(item);
  });
  return Object.keys(map).map(function(id) { return map[id]; });
}

Page({
  data: {
    navSubtitle: '视界记录本',
    info: {}, isExpired: false, expiredClass: '', circleClass: 'circle-active',
    accounts: [],
    currentId: 0, loadError: ''
  },

  onShow: function() {
    this.applyPublicConfig();
    var cached = authStorage.getParentCustomer();
    var avatarUrl = getAvatarUrl(cached && cached.id);
    if (cached) this.setData({ info: decorateProfile(cached), currentId: cached.id, avatarUrl: avatarUrl });
    this.setData({ accounts: loadAccounts() });
    this.loadProfile();
  },

  applyPublicConfig: function() {
    var cfg = publicConfig.getPublicConfig();
    this.setData({ navSubtitle: (cfg.system && cfg.system.subtitle) || '视界记录本' });
  },

  loadProfile: async function() {
    this.setData({ loadError: '' });
    try {
      var profile = decorateProfile(await api.getProfile());
      wx.setStorageSync('parentCustomerInfo', profile);
      app.globalData.customerInfo = profile;
      var accounts = decorateAccounts(mergeAccounts(loadAccounts(), [profile]));
      wx.setStorageSync('wx_accounts', accounts);
      var isExpired = profile.expireDate && new Date(profile.expireDate) < new Date();
      this.setData({
        info: profile,
        currentId: Number(profile.id || 0),
        accounts: accounts,
        isExpired: isExpired,
        expiredClass: isExpired ? 'text-danger' : '',
        circleClass: isExpired ? 'circle-expired' : 'circle-active'
      });
    } catch (err) { console.error('[个人资料加载失败]', err); this.setData({ loadError: '资料加载失败，请检查网络后重试' }); wx.showToast({ title: '资料加载失败', icon: 'none' }); }
  },

  retry: function() { this.loadProfile(); },

  // 切换到另一个账号
  switchAccount: function(e) {
    var id = Number(e.currentTarget.dataset.id || 0);
    if (!id) { wx.showToast({ title: '账号无效', icon: 'none' }); return; }
    var that = this;
    wx.showLoading({ title: '切换中...' });
    wx.login({
      success: function(loginRes) {
        if (!loginRes.code) {
          wx.hideLoading();
          wx.showToast({ title: '获取微信登录凭证失败', icon: 'none' });
          return;
        }
        wx.request({
          url: app.globalData.apiBase + '/select-account',
          method: 'POST',
          data: { code: loginRes.code, customerId: id },
          timeout: 15000,
          success: function(r) {
            var body = r.data || {};
            if (r.statusCode !== 200 || body.success === false || !body.data) {
              wx.hideLoading();
              wx.showToast({ title: body.message || '切换失败', icon: 'none' });
              return;
            }
            var d = body.data;
            authStorage.setParentSession(d.accessToken, d.customer);
            authStorage.clearLegacyMixedSession();
            app.globalData.token = d.accessToken;
            app.globalData.isLogin = true;
            app.globalData.customerInfo = d.customer;
            wx.hideLoading();
            wx.showToast({ title: '已切换', icon: 'success' });
            setTimeout(function() { wx.reLaunch({ url: '/pages/home/home' }); }, 500);
          },
          fail: function(err) {
            wx.hideLoading();
            if (app.globalData.env === 'dev') console.error('[切换账号失败]', err);
            wx.showToast({ title: '网络异常，请重试', icon: 'none' });
          }
        });
      },
      fail: function(err) {
        wx.hideLoading();
        if (app.globalData.env === 'dev') console.error('[微信登录失败]', err);
        wx.showToast({ title: '微信登录失败，请重试', icon: 'none' });
      }
    });
  },

  // 解绑
  removeAccount: function(e) {
    var id = Number(e.currentTarget.dataset.id || 0);
    if (!id) { wx.showToast({ title: '账号无效', icon: 'none' }); return; }
    var that = this;
    wx.showModal({
      title: '确认解绑',
      content: '解绑后该账号将无法通过微信登录',
      success: function(res) {
        if (!res.confirm) return;
        wx.login({
          success: function(loginRes) {
            api.unbindAccount(loginRes.code, id).then(function() {
              // 更新列表
              var accounts = loadAccounts().filter(function(a) { return Number(a.id) !== id; });
              wx.setStorageSync('wx_accounts', accounts);
              that.setData({ accounts: accounts });
              if (id === Number(that.data.currentId || 0)) {
                authStorage.clearParentSession();
                wx.removeStorageSync('wx_bound');
                app.globalData.token = '';
                app.globalData.isLogin = false;
                app.globalData.customerInfo = null;
                wx.showToast({ title: '已解绑，请重新登录', icon: 'none' });
                setTimeout(function() { wx.reLaunch({ url: '/pages/login/login' }); }, 1000);
              } else {
                wx.showToast({ title: '已解绑', icon: 'success' });
              }
            });
          }
        });
      }
    });
  },

  // 添加账号 → 弹窗输手机号直接绑定
  addAccount: function() {
    var that = this;
    wx.showModal({
      title: '添加账号',
      editable: true,
      placeholderText: '输入在册手机号',
      content: '',
      success: function(res) {
        if (!res.confirm || !res.content) return;
        var phone = (res.content || '').trim();
        if (!/^1[3-9]\d{9}$/.test(phone)) { wx.showToast({ title: '请输入正确手机号', icon: 'none' }); return; }
        wx.showLoading({ title: '添加中...' });
        wx.login({
          success: function(loginRes) {
            api.bindPhone(loginRes.code, phone).then(function(result) {
              var accounts = decorateAccounts(mergeAccounts(that.data.accounts || [], result.accounts || [result.customer]));
              wx.setStorageSync('wx_accounts', accounts);
              that.setData({ accounts: accounts });
              wx.hideLoading();
              wx.showToast({ title: accounts.length > 1 ? '已更新账号列表' : '添加成功', icon: 'success' });
            }).catch(function(err) {
              wx.hideLoading();
              // request.js 已弹窗
            });
          },
          fail: function(err) {
            wx.hideLoading();
            console.error('[添加账号微信登录失败]', err);
            wx.showToast({ title: '微信登录失败，请重试', icon: 'none' });
          }
        });
      }
    });
  },

  onPullDownRefresh: function() {
    return require('../../utils/pull-refresh').run(this.loadProfile());
  },

  goPage: function(e) {
    var p = e.currentTarget.dataset.page;
    var sr=require('../../utils/subscribe-helper'); sr.silentRenew(false, null, '我的-跳转' + p);
    wx.reLaunch({ url: '/pages/' + p + '/' + p });
  },

  renewCurrentPage: function() { var sr=require('../../utils/subscribe-helper'); sr.silentRenew(false, null, '我的-当前标签'); },

  openServiceAgreement: function() {
    wx.navigateTo({ url: '/pages/legal/service/service' });
  },

  openPrivacyPolicy: function() {
    wx.navigateTo({ url: '/pages/legal/privacy/privacy' });
  },

  doLogout: function() {
    wx.showModal({
      title: '退出登录',
      content: '确定退出当前账号吗？',
      success: function(res) {
        if (res.confirm) {
          authStorage.clearParentSession();
          app.globalData.token = '';
          app.globalData.isLogin = false;
          wx.reLaunch({ url: '/pages/login/login' });
        }
      }
    });
  }
});
