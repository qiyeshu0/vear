Page({
  openOfficialPrivacy: function() {
    if (!wx.openPrivacyContract) {
      wx.showToast({ title: '请将微信升级到最新版本后查看', icon: 'none' });
      return;
    }
    wx.openPrivacyContract({
      fail: function(error) {
        var message = error && error.errMsg || '';
        if (message.indexOf('cancel') < 0) {
          wx.showToast({ title: '暂时无法打开，请稍后重试', icon: 'none' });
        }
      }
    });
  },

  goService: function() {
    wx.navigateTo({ url: '/pages/legal/service/service' });
  }
});

