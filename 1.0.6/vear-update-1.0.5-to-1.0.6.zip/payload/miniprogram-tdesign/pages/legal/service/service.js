Page({
  goPrivacy: function() {
    wx.navigateTo({ url: '/pages/legal/privacy/privacy' });
  }
});

