const path = require("node:path");

const projectRoot = __dirname;

module.exports = {
  apps: [
    {
      name: "vear",
      cwd: projectRoot,
      script: path.join(projectRoot, "scripts", "pm2-entry.mjs"),
      interpreter: "node",
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      watch: false,
      restart_delay: 3000,
      kill_timeout: 5000,
      max_memory_restart: "512M",
      time: true,
      env: {
        NODE_ENV: "production",
        PORT: 3000,
        TZ: "Asia/Shanghai"
      }
    }
  ]
};
