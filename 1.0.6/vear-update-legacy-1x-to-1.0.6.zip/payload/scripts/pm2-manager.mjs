import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const backendRoot = path.join(projectRoot, "backend-后端");
const ecosystemFile = path.join(projectRoot, "ecosystem.config.cjs");
const npmCommand = process.platform === "win32" ? "npm.cmd" : "npm";
const pm2Command = process.env.PM2_BIN || (process.platform === "win32" ? "pm2.cmd" : "pm2");
const action = String(process.argv[2] || "start").toLowerCase();

function run(command, args, options = {}) {
  const result = spawnSync(command, args, {
    cwd: options.cwd || projectRoot,
    stdio: options.capture ? ["ignore", "pipe", "pipe"] : "inherit",
    encoding: options.capture ? "utf8" : undefined,
    env: { ...process.env, NODE_ENV: "production", PORT: process.env.PORT || "3000", TZ: "Asia/Shanghai" },
  });
  if (!options.allowFailure && result.status !== 0) process.exit(result.status || 1);
  return result;
}

function ensurePm2() {
  if (run(pm2Command, ["--version"], { capture: true, allowFailure: true }).status === 0) return;

  console.log("[PM2] 未检测到 PM2，开始自动安装");
  let result = run(npmCommand, ["install", "--global", "pm2", "--no-audit", "--no-fund"], { allowFailure: true });
  if (result.status !== 0) {
    console.warn("[PM2] 默认 npm 源安装失败，切换到 npmmirror 国内镜像重试");
    result = run(npmCommand, ["install", "--global", "pm2", "--no-audit", "--no-fund", "--registry", "https://registry.npmmirror.com"], { allowFailure: true });
  }
  if (result.status !== 0 || run(pm2Command, ["--version"], { capture: true, allowFailure: true }).status !== 0) {
    console.error("[PM2] 自动安装失败，请确认当前用户具有全局 npm 包安装权限");
    process.exit(result.status || 1);
  }
}

function normalize(value) {
  try { return fs.realpathSync(value); } catch { return path.resolve(String(value || "")); }
}

function removeLegacyProjectProcesses() {
  const result = run(pm2Command, ["jlist"], { capture: true, allowFailure: true });
  if (result.status !== 0) return;

  let processes = [];
  try { processes = JSON.parse(result.stdout || "[]"); } catch { return; }
  const expectedEntry = normalize(path.join(projectRoot, "scripts", "pm2-entry.mjs"));
  const legacyEntry = normalize(path.join(backendRoot, "src", "app.js"));

  for (const processInfo of processes) {
    if (processInfo?.name === "vear") continue;
    const execPath = normalize(processInfo?.pm2_env?.pm_exec_path || "");
    const cwd = normalize(processInfo?.pm2_env?.pm_cwd || "");
    const belongsToProject = execPath === legacyEntry || execPath === expectedEntry || cwd === normalize(backendRoot);
    if (!belongsToProject) continue;
    console.log(`[PM2] 移除当前项目遗留进程：${processInfo.name || processInfo.pm_id}`);
    run(pm2Command, ["delete", String(processInfo.pm_id)]);
  }
}

function checkHealth(timeoutMs = 15000) {
  const startedAt = Date.now();
  return new Promise((resolve, reject) => {
    const attempt = () => {
      const request = http.get({ host: "127.0.0.1", port: Number(process.env.PORT || 3000), path: "/health", timeout: 2000 }, response => {
        let body = "";
        response.on("data", chunk => { body += chunk; });
        response.on("end", () => {
          if (response.statusCode === 200 && body.includes('"message":"ok"')) resolve();
          else retry();
        });
      });
      request.on("timeout", () => request.destroy());
      request.on("error", retry);
    };
    const retry = () => {
      if (Date.now() - startedAt >= timeoutMs) return reject(new Error("健康检查超时"));
      setTimeout(attempt, 500);
    };
    attempt();
  });
}

ensurePm2();

if (["start", "restart", "reload"].includes(action)) {
  run(process.execPath, [path.join(projectRoot, "scripts", "bootstrap.mjs"), "--if-needed"]);
  removeLegacyProjectProcesses();
  run(pm2Command, ["startOrReload", ecosystemFile, "--only", "vear", "--update-env"]);
  run(pm2Command, ["save"]);
  try {
    await checkHealth();
    console.log(`[PM2] vear 已启动并通过健康检查：http://127.0.0.1:${process.env.PORT || 3000}`);
  } catch (error) {
    console.error(`[PM2] ${error.message}，请执行 npm run pm2:logs 查看原因`);
    process.exit(1);
  }
} else if (action === "stop") {
  run(pm2Command, ["stop", "vear"]);
  run(pm2Command, ["save"]);
} else if (action === "delete") {
  run(pm2Command, ["delete", "vear"]);
  run(pm2Command, ["save"]);
} else if (action === "status") {
  run(pm2Command, ["show", "vear"]);
} else {
  console.error(`不支持的 PM2 操作：${action}`);
  process.exit(1);
}
