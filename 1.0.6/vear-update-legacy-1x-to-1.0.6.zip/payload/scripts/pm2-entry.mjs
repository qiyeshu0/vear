import path from "node:path";
import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const backendRoot = path.join(projectRoot, "backend-后端");

process.env.NODE_ENV = process.env.NODE_ENV || "production";
process.env.PORT = process.env.PORT || "3000";
process.env.TZ = process.env.TZ || "Asia/Shanghai";

const bootstrap = spawnSync(
  process.execPath,
  [path.join(projectRoot, "scripts", "bootstrap.mjs"), "--if-needed"],
  { cwd: projectRoot, stdio: "inherit", env: process.env },
);

if (bootstrap.status !== 0) {
  console.error("[PM2] 启动检查失败，服务未启动");
  process.exit(bootstrap.status || 1);
}

process.chdir(backendRoot);
const require = createRequire(import.meta.url);
const app = require(path.join(backendRoot, "src", "app.js"));

if (typeof app.startServer !== "function") {
  throw new Error("当前后端缺少 startServer 入口，请使用完整发布包重新覆盖程序文件");
}

app.startServer();

