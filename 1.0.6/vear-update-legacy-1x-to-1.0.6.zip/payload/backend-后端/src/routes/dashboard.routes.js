const express = require("express");
const { auth, buildStoreScope, requireUserPermission } = require("../middleware/auth");
const { sendSuccess, sendFail } = require("../utils/response");
const { toCamelCase } = require("../utils/case");
const { pool } = require("../config/db");
const { ROLE_ADMIN } = require("../config/constants");
const { formatDateYmd, toChinaIsoString } = require("../utils/date");
const {
  ensureNotificationStateTable,
  buildNotificationStateMap,
} = require("../utils/notification");
const { createTables } = require("../install/schema");
const { getLowTimesThreshold } = require("../utils/system-settings");
const { getRuntimeConfig } = require("../utils/runtime-config");

const router = express.Router();
let dashboardSchemaReady = false;
let dashboardSchemaPromise = null;

function ensureDashboardSchema(options = {}) {
  const force = options === true || options?.force === true;

  if (!force && dashboardSchemaReady) return Promise.resolve();
  if (!force && dashboardSchemaPromise) return dashboardSchemaPromise;

  dashboardSchemaPromise = createTables(pool)
    .then(() => {
      dashboardSchemaReady = true;
    })
    .catch((error) => {
      dashboardSchemaReady = false;
      dashboardSchemaPromise = null;
      throw error;
    });

  return dashboardSchemaPromise;
}

function buildStoreWhere(user, field = "store_id") {
  const alias = field.endsWith(".store_id") ? field.slice(0, -9) : "";
  return buildStoreScope(user, alias);
}

function buildCustomerAlertItem(type, row) {
  const expireDate = row.expire_date || row.expireDate || null;
  const remainingTimes = Number(row.remaining_times ?? row.remainingTimes ?? 0);
  const createdAt = expireDate
    ? `${formatDateYmd(expireDate)} 00:00:00`
    : toChinaIsoString();

  const base = {
    id: `${type}-${row.id}`,
    type,
    customerId: Number(row.id || 0),
    childName: row.child_name || row.childName || "",
    parentPhone: row.parent_phone || row.parentPhone || "",
    trainingProject: row.training_project || row.trainingProject || "",
    remainingTimes,
    expireDate: expireDate ? formatDateYmd(expireDate) : null,
    storeId: row.store_id == null ? null : Number(row.store_id),
    createdAt,
    routePath: "/customers",
  };

  if (type === "expired") {
    return {
      ...base,
      level: "danger",
      title: "客户已过期",
      content: `${base.childName} 已过期，请尽快跟进续卡`,
    };
  }

  if (type === "low_times") {
    return {
      ...base,
      level: "warning",
      title: "客户次数不足",
      content: `${base.childName} 剩余 ${remainingTimes} 次，请及时提醒`,
    };
  }

  return {
    ...base,
    level: "warning",
    title: "客户即将到期",
    content: `${base.childName} 将于 ${base.expireDate || "-"} 到期`,
  };
}

async function getNotificationStateMap(connection, userId, list = []) {
  await ensureNotificationStateTable();

  const ids = list.map((item) => String(item.id || "")).filter(Boolean);
  if (!ids.length) {
    return new Map();
  }

  const placeholders = ids.map(() => "?").join(", ");
  const [rows] = await connection.query(
    `
      SELECT notification_id, is_read, read_at, handled_at, handled_note
      FROM user_notification_states
      WHERE user_id = ?
        AND notification_id IN (${placeholders})
    `,
    [Number(userId || 0), ...ids],
  );

  return buildNotificationStateMap(rows);
}

function mergeNotificationState(list = [], stateMap = new Map()) {
  return list.map((item) => {
    const state = stateMap.get(String(item.id || ""));
    return {
      ...item,
      isRead: Boolean(state?.isRead),
      readAt: state?.readAt || null,
      isHandled: Boolean(state?.isHandled),
      handledAt: state?.handledAt || null,
      handledNote: state?.handledNote || "",
    };
  });
}

function safeText(value, fallback = "") {
  if (value == null) return fallback;
  const text = String(value).trim();
  return text || fallback;
}

function getByPath(obj, pathText, fallback = undefined) {
  if (!pathText) return fallback;
  const parts = String(pathText).split(".").map(item => item.trim()).filter(Boolean);
  let current = obj;
  for (const part of parts) {
    if (current == null) return fallback;
    current = current[part];
  }
  return current == null ? fallback : current;
}

function formatWeatherDay(date, index, payload = {}) {
  const d = new Date(`${date || formatDateYmd(new Date())}T00:00:00`);
  const weekNames = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
  return {
    date: safeText(date, formatDateYmd(new Date())),
    week: weekNames[Number.isNaN(d.getTime()) ? index % 7 : d.getDay()],
    weather: safeText(payload.weather, "多云"),
    tempMin: payload.tempMin ?? "-",
    tempMax: payload.tempMax ?? "-",
    precipitation: payload.precipitation ?? "-",
    wind: payload.wind ?? "-",
  };
}

function weatherText(code) {
  const n = Number(code);
  if ([0].includes(n)) return "晴";
  if ([1, 2].includes(n)) return "少云";
  if ([3].includes(n)) return "阴";
  if ([45, 48].includes(n)) return "雾";
  if ([51, 53, 55, 56, 57].includes(n)) return "毛毛雨";
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(n)) return "雨";
  if ([71, 73, 75, 77, 85, 86].includes(n)) return "雪";
  if ([95, 96, 99].includes(n)) return "雷阵雨";
  return "多云";
}

function replaceWeatherPlaceholders(url, cfg) {
  return String(url || "")
    .replace(/\{lat\}/g, encodeURIComponent(cfg.latitude || "31.2304"))
    .replace(/\{lon\}/g, encodeURIComponent(cfg.longitude || "121.4737"))
    .replace(/\{lng\}/g, encodeURIComponent(cfg.longitude || "121.4737"))
    .replace(/\{city\}/g, encodeURIComponent(cfg.city || "上海"))
    .replace(/\{adcode\}/g, encodeURIComponent(cfg.adcode || "310000"))
    .replace(/\{key\}/g, encodeURIComponent(cfg.apiKey || ""));
}

function normalizeCoordinate(value, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < min || n > max) return "";
  return String(n);
}

function normalizeAccuracy(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0 || n > 1000000) return 0;
  return Math.round(n);
}

function normalizeLocationPart(value) {
  if (Array.isArray(value)) return normalizeLocationPart(value[0]);
  if (value == null || typeof value === "object") return "";
  return safeText(value);
}

function parseReverseLocation(data) {
  const address = data?.address || {};
  const amap = data?.regeocode?.addressComponent || {};
  const candidates = [
    data?.city,
    data?.locality,
    data?.localityInfo?.administrative?.find?.(item => item?.adminLevel === 6)?.name,
    address.city,
    address.town,
    address.municipality,
    address.county,
    address.village,
    amap.city,
    amap.district,
    data?.principalSubdivision,
    address.state,
    amap.province,
    data?.display_name,
  ];
  for (const candidate of candidates) {
    const text = normalizeLocationPart(candidate);
    if (text) return text;
  }
  return "";
}

async function reverseGeocode(cfg) {
  if (!cfg.reverseGeocodeEnabled || !cfg.reverseGeocodeUrl) return "";
  const url = replaceWeatherPlaceholders(cfg.reverseGeocodeUrl, cfg);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Number(process.env.WEATHER_GEOCODE_TIMEOUT_MS || 5000));
  try {
    const response = await fetch(url, {
      headers: { "Accept": "application/json", "User-Agent": "VearWeather/1.0" },
      signal: controller.signal,
    });
    if (!response.ok) return "";
    return parseReverseLocation(await response.json());
  } catch (error) {
    return "";
  } finally {
    clearTimeout(timer);
  }
}

function parseOpenMeteoWeather(data) {
  const daily = data?.daily || {};
  return (daily.time || []).slice(0, 7).map((date, index) => formatWeatherDay(date, index, {
    weather: weatherText(daily.weather_code?.[index]),
    tempMin: Math.round(Number(daily.temperature_2m_min?.[index] ?? 0)),
    tempMax: Math.round(Number(daily.temperature_2m_max?.[index] ?? 0)),
    wind: Math.round(Number(daily.wind_speed_10m_max?.[index] ?? 0)),
    precipitation: daily.precipitation_probability_max?.[index] ?? "-",
  }));
}

function parseQWeather(data) {
  const list = data?.daily || data?.data?.daily || [];
  return list.slice(0, 7).map((item, index) => formatWeatherDay(item.fxDate || item.date, index, {
    weather: item.textDay || item.text || item.weather,
    tempMin: item.tempMin ?? item.min,
    tempMax: item.tempMax ?? item.max,
    wind: item.windSpeedDay ?? item.wind,
    precipitation: item.precip ?? item.pop ?? "-",
  }));
}

function parseAmapWeather(data) {
  const casts = data?.forecasts?.[0]?.casts || data?.casts || [];
  return casts.slice(0, 7).map((item, index) => formatWeatherDay(item.date, index, {
    weather: item.dayweather || item.nightweather || item.weather,
    tempMin: item.nighttemp ?? item.tempMin,
    tempMax: item.daytemp ?? item.tempMax,
    wind: item.daypower || item.daywind || "-",
    precipitation: "-",
  }));
}

function amapErrorMessage(data, action) {
  const code = safeText(data?.infocode);
  const info = safeText(data?.info, "UNKNOWN_ERROR");
  const tips = {
    "10001": "Key 不正确或已经失效",
    "10003": "Key 的日调用量已超限",
    "10004": "Key 的访问过于频繁",
    "10009": "Key 平台类型不匹配，请使用服务平台为“Web服务”的 Key",
    "10010": "当前 IP 没有访问权限，请检查高德 Key 的 IP 白名单",
    "10012": "Key 没有调用当前服务的权限",
    "10016": "服务器负载较高，请稍后重试",
  };
  return `高德${action}失败（${code || info}）：${tips[code] || info}`;
}

async function requestAmap(pathname, params, action) {
  const url = new URL(`https://restapi.amap.com${pathname}`);
  Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, String(value ?? "")));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Number(process.env.WEATHER_FETCH_TIMEOUT_MS || 8000));
  try {
    const response = await fetch(url, { headers: { "Accept": "application/json" }, signal: controller.signal });
    if (!response.ok) throw new Error(`高德${action}请求失败：HTTP ${response.status}`);
    const data = await response.json();
    if (String(data?.status) !== "1") throw new Error(amapErrorMessage(data, action));
    return data;
  } catch (error) {
    if (error?.name === "AbortError") throw new Error(`高德${action}请求超时`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function resolveAmapLocation(cfg) {
  const data = await requestAmap("/v3/geocode/regeo", {
    location: `${cfg.longitude},${cfg.latitude}`,
    key: cfg.apiKey,
    extensions: "base",
  }, "定位城市");
  const component = data?.regeocode?.addressComponent || {};
  const adcode = normalizeLocationPart(component.adcode);
  if (!adcode) throw new Error("高德定位城市失败：返回结果中没有 adcode");
  const city = normalizeLocationPart(component.city)
    || normalizeLocationPart(component.province)
    || normalizeLocationPart(component.district)
    || "当前位置";
  return { adcode, city };
}

function parseCustomWeather(data, mappingText) {
  let mapping = {};
  try {
    mapping = JSON.parse(mappingText || "{}");
  } catch (error) {
    throw new Error("自定义天气字段映射不是合法 JSON");
  }
  const list = getByPath(data, mapping.list || "data", []);
  if (!Array.isArray(list)) throw new Error("自定义天气字段映射 list 没有指向数组");
  return list.slice(0, 7).map((item, index) => formatWeatherDay(getByPath(item, mapping.date || "date"), index, {
    weather: getByPath(item, mapping.weather || "weather"),
    tempMin: getByPath(item, mapping.tempMin || "tempMin"),
    tempMax: getByPath(item, mapping.tempMax || "tempMax"),
    wind: getByPath(item, mapping.wind || "wind"),
    precipitation: getByPath(item, mapping.precipitation || "precipitation", "-"),
  }));
}

function parseWeatherByProvider(provider, data, mappingText) {
  const type = String(provider || "open_meteo").toLowerCase();
  if (type === "qweather" || type === "hefeng") return parseQWeather(data);
  if (type === "amap" || type === "gaode") return parseAmapWeather(data);
  if (type === "custom") return parseCustomWeather(data, mappingText);
  return parseOpenMeteoWeather(data);
}

function buildWeatherConfig(map) {
  return {
    enabled: String(map["weather.enabled"] || "1") === "1",
    provider: map["weather.provider"] || "open_meteo",
    apiUrl: map["weather.api_url"] || "",
    apiKey: map["weather.api_key"] || "",
    apiKeyHeader: map["weather.api_key_header"] || "",
    locationName: map["weather.location_name"] || map["weather.city"] || "默认城市",
    city: map["weather.city"] || "上海",
    adcode: map["weather.adcode"] || "310000",
    latitude: map["weather.latitude"] || "31.2304",
    longitude: map["weather.longitude"] || "121.4737",
    customMapping: map["weather.custom_mapping"] || "",
    reverseGeocodeEnabled: String(map["weather.reverse_geocode_enabled"] || "1") === "1",
    reverseGeocodeUrl: map["weather.reverse_geocode_url"] || "https://api-bdc.io/data/reverse-geocode-client?latitude={lat}&longitude={lon}&localityLanguage=zh",
  };
}

router.get("/weather", auth(), requireUserPermission("dashboard:view"), async (req, res) => {
  try {
    const cfg = buildWeatherConfig(await getRuntimeConfig());
    const browserLatitude = normalizeCoordinate(req.query.latitude ?? req.query.lat, -90, 90);
    const browserLongitude = normalizeCoordinate(req.query.longitude ?? req.query.lng ?? req.query.lon, -180, 180);
    const browserAccuracy = normalizeAccuracy(req.query.accuracy);
    const useBrowserPosition = Boolean(browserLatitude && browserLongitude);
    if (useBrowserPosition) {
      cfg.latitude = browserLatitude;
      cfg.longitude = browserLongitude;
      cfg.locationName = "当前位置";
    }
    if (!cfg.enabled) {
      return sendSuccess(res, { enabled: false, location: cfg.locationName, source: "天气已关闭", list: [] }, "天气未启用");
    }
    if (!cfg.apiKey) return sendFail(res, "请先在运行配置中心填写高德 Web服务 Key", 400);

    const location = await resolveAmapLocation(cfg);
    cfg.adcode = location.adcode;
    cfg.locationName = location.city;
    const data = await requestAmap("/v3/weather/weatherInfo", {
      city: cfg.adcode,
      key: cfg.apiKey,
      extensions: "all",
    }, "天气查询");
    const list = parseAmapWeather(data);
    if (!list.length) throw new Error("高德天气查询成功，但没有返回天气预报数据");
    const accuracyText = browserAccuracy ? `，精度约 ±${browserAccuracy} 米` : "";
    return sendSuccess(res, {
      enabled: true,
      location: cfg.locationName,
      source: useBrowserPosition ? "浏览器定位 · 高德天气" : "默认位置 · 高德天气",
      forecastLabel: `未来 ${list.length} 天`,
      position: useBrowserPosition ? {
        latitude: cfg.latitude,
        longitude: cfg.longitude,
      } : null,
      positionTip: useBrowserPosition
        ? `已定位到 ${cfg.locationName}${accuracyText}`
        : `浏览器定位不可用，已使用默认位置：${cfg.locationName}`,
      list,
    }, "获取天气成功");
  } catch (error) {
    return sendFail(res, `天气暂时不可用：${error.message || error}`, 502);
  }
});

router.get("/overview", auth(), requireUserPermission("dashboard:view"), async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await ensureDashboardSchema();
    const user = req.user;
    const today = formatDateYmd(new Date());
    const monthStart = `${today.slice(0, 7)}-01`;
    const settings = await require("../utils/system-settings").getSettingsMap(connection);
    const lowTimesThreshold = Number(settings.low_times_threshold || 5);
    const soonExpireDays = Number(req.query.soonExpireDays || settings.soon_expire_days || 15);
    const safeSoonExpireDays = Number.isFinite(soonExpireDays) && soonExpireDays >= 1
      ? Math.min(Math.floor(soonExpireDays), 365)
      : 15;

    const customerScope = buildStoreWhere(user, "store_id");
    const verifyScope = buildStoreWhere(user, "store_id");
    const renewalScope = buildStoreWhere(user, "c.store_id");
    const logScope = buildStoreWhere(user, "store_id");

    // ── 合并查询：verify 统计（原 3 条 SQL → 1 条）──
    const [[verifyStatsRow]] = await connection.query(
      `
        SELECT
          COUNT(*) AS total_verify,
          SUM(CASE WHEN verify_date = ? THEN 1 ELSE 0 END) AS today_verify,
          SUM(CASE WHEN verify_date >= ? THEN 1 ELSE 0 END) AS month_verify
        FROM verify_records
        WHERE revoked = 0
          AND ${verifyScope.sql}
      `,
      [today, monthStart, ...verifyScope.params],
    );

    // ── 合并查询：客户统计（原 7 条 SQL → 1 条）──
    const [[customerStatsRow]] = await connection.query(
      `
        SELECT
          COUNT(*) AS total_customers,
          SUM(CASE WHEN status = 1 AND has_card = 1 THEN 1 ELSE 0 END) AS active_customers,
          SUM(CASE WHEN has_card = 0 THEN 1 ELSE 0 END) AS account_only,
          SUM(CASE WHEN has_card = 1 THEN 1 ELSE 0 END) AS carded,
          SUM(CASE WHEN open_card_date >= ? THEN 1 ELSE 0 END) AS month_new,
          SUM(CASE WHEN status = 1 AND has_card = 1 AND remaining_times > 0 AND remaining_times <= ? THEN 1 ELSE 0 END) AS low_times,
          SUM(CASE WHEN status = 1 AND has_card = 1 AND expire_date < CURDATE() THEN 1 ELSE 0 END) AS expired
        FROM customers
        WHERE ${customerScope.sql}
      `,
      [monthStart, lowTimesThreshold, ...customerScope.params],
    );

    const [[monthRenewalRow]] = await connection.query(
      `
        SELECT COUNT(*) AS total
        FROM customer_renewals cr
        INNER JOIN customers c ON c.id = cr.customer_id
        WHERE cr.created_at >= ?
          AND ${renewalScope.sql}
      `,
      [monthStart, ...renewalScope.params],
    );

    const [soonExpireList] = await connection.query(
      `
        SELECT
          id,
          child_name,
          parent_name,
          parent_phone,
          training_project,
          total_times,
          used_times,
          remaining_times,
          expire_date,
          store_id
        FROM customers
        WHERE status = 1
          AND has_card = 1
          AND ${customerScope.sql}
          AND (
            expire_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
            OR (remaining_times > 0 AND remaining_times <= ?)
          )
        ORDER BY
          CASE
            WHEN expire_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY) THEN 0
            ELSE 1
          END,
          remaining_times ASC,
          expire_date ASC,
          id DESC
        LIMIT 10
      `,
      [safeSoonExpireDays, lowTimesThreshold, safeSoonExpireDays, ...customerScope.params],
    );

    const [lowTimesList] = await connection.query(
      `
        SELECT
          id,
          child_name,
          parent_name,
          parent_phone,
          training_project,
          total_times,
          used_times,
          remaining_times,
          expire_date,
          store_id
        FROM customers
        WHERE remaining_times > 0
          AND remaining_times <= ?
          AND status = 1
          AND has_card = 1
          AND ${customerScope.sql}
        ORDER BY remaining_times ASC, expire_date ASC, id DESC
        LIMIT 10
      `,
      [lowTimesThreshold, ...customerScope.params],
    );

    const [expiredList] = await connection.query(
      `
        SELECT
          id,
          child_name,
          parent_name,
          parent_phone,
          training_project,
          total_times,
          used_times,
          remaining_times,
          expire_date,
          store_id
        FROM customers
        WHERE expire_date < CURDATE()
          AND status = 1
          AND has_card = 1
          AND ${customerScope.sql}
        ORDER BY expire_date ASC, id DESC
        LIMIT 10
      `,
      customerScope.params,
    );

    const [latestRecords] = await connection.query(
      `
        SELECT
          vr.id,
          vr.verify_no,
          vr.customer_id,
          vr.child_name,
          vr.training_project,
          vr.verify_date,
          vr.verify_time,
          vr.operator_name,
          vr.remark,
          s.store_name
        FROM verify_records vr
        LEFT JOIN stores s ON vr.store_id = s.id
        WHERE vr.revoked = 0
          AND ${buildStoreWhere(user, "vr.store_id").sql}
        ORDER BY vr.verify_time DESC, vr.id DESC
        LIMIT 10
      `,
      buildStoreWhere(user, "vr.store_id").params,
    );

    const visitScope = buildStoreWhere(user, "cv.store_id");
    const [todayVisitList] = await connection.query(
      `
        SELECT
          cv.id,
          cv.customer_id,
          cv.customer_name,
          cv.customer_phone,
          cv.arrived_at,
          DATE_FORMAT(cv.arrived_at, '%H:%i') AS arrival_time,
          cv.store_id,
          s.store_name,
          EXISTS(
            SELECT 1
            FROM customer_visit_verifications cvv
            INNER JOIN verify_records vr ON vr.id = cvv.verify_record_id
            WHERE cvv.visit_id = cv.id
              AND COALESCE(vr.revoked, 0) = 0
          ) AS has_verification,
          (
            SELECT GROUP_CONCAT(
              CONCAT(
                COALESCE(NULLIF(vr.training_project, ''), NULLIF(vr.card_name, ''), '核销'),
                CASE
                  WHEN NULLIF(TRIM(COALESCE(vr.remark, '')), '') IS NOT NULL
                  THEN CONCAT('（', TRIM(vr.remark), '）')
                  ELSE ''
                END
              )
              ORDER BY vr.verify_time ASC SEPARATOR '、'
            )
            FROM customer_visit_verifications cvv
            INNER JOIN verify_records vr ON vr.id = cvv.verify_record_id
            WHERE cvv.visit_id = cv.id
              AND COALESCE(vr.revoked, 0) = 0
          ) AS verify_description
        FROM customer_visits cv
        LEFT JOIN stores s ON s.id = cv.store_id
        WHERE cv.visit_date = ?
          AND cv.status <> 3
          AND ${visitScope.sql}
        ORDER BY cv.arrived_at DESC, cv.id DESC
        LIMIT 20
      `,
      [today, ...visitScope.params],
    );

    const [verifyTrendRows] = await connection.query(
      `
        SELECT
          vr.verify_date,
          COUNT(*) AS count
        FROM verify_records vr
        WHERE vr.verify_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
          AND vr.revoked = 0
          AND ${buildStoreWhere(user, "vr.store_id").sql}
        GROUP BY vr.verify_date
        ORDER BY vr.verify_date ASC
      `,
      buildStoreWhere(user, "vr.store_id").params,
    );

    const verifyTrendMap = {};
    for (const row of verifyTrendRows) {
      const date = formatDateYmd(row.verify_date);
      verifyTrendMap[date] = Number(row.count || 0);
    }

    const verifyTrend = [];
    for (let i = 6; i >= 0; i -= 1) {
      const date = new Date();
      date.setHours(0, 0, 0, 0);
      date.setDate(date.getDate() - i);
      const year = date.getFullYear();
      const month = `${date.getMonth() + 1}`.padStart(2, "0");
      const day = `${date.getDate()}`.padStart(2, "0");
      const dateText = `${year}-${month}-${day}`;
      verifyTrend.push({
        date: dateText,
        count: Number(verifyTrendMap[dateText] || 0),
      });
    }

    const [tagRows] = await connection.query(
      `
        SELECT tags
        FROM customers
        WHERE tags IS NOT NULL
          AND tags <> ''
          AND ${customerScope.sql}
      `,
      customerScope.params,
    );

    const tagMap = {};
    for (const row of tagRows) {
      const tags = String(row.tags || "")
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);

      for (const tag of tags) {
        tagMap[tag] = (tagMap[tag] || 0) + 1;
      }
    }

    const tagStats = Object.entries(tagMap)
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 20);

    let storeStats = [];
    let storeDistribution = [];
    if (Number(user.role) === ROLE_ADMIN) {
      const [rows] = await connection.query(`
        SELECT
          s.id,
          s.store_name,
          COALESCE(c.customer_count, 0) AS customer_count,
          COALESCE(vr.verify_count, 0) AS verify_count
        FROM stores s
        LEFT JOIN (
          SELECT store_id, COUNT(*) AS customer_count
          FROM customers
          GROUP BY store_id
        ) c ON c.store_id = s.id
        LEFT JOIN (
          SELECT store_id, COUNT(*) AS verify_count
          FROM verify_records
          WHERE revoked = 0
          GROUP BY store_id
        ) vr ON vr.store_id = s.id
        ORDER BY s.id ASC
      `);
      storeStats = rows;
      storeDistribution = rows.map((row) => ({
        name: row.store_name,
        value: Number(row.verify_count || 0),
      }));
    } else {
      const [rows] = await connection.query(
        `
          SELECT
            s.id,
            s.store_name,
            COALESCE(vr.verify_count, 0) AS verify_count
          FROM stores s
          LEFT JOIN (
            SELECT store_id, COUNT(*) AS verify_count
            FROM verify_records
            WHERE revoked = 0
            GROUP BY store_id
          ) vr ON vr.store_id = s.id
          WHERE s.id = ?
          GROUP BY s.id, s.store_name
          ORDER BY s.id ASC
        `,
        [Number(user.storeId || 0)],
      );
      storeDistribution = rows.map((row) => ({
        name: row.store_name,
        value: Number(row.verify_count || 0),
      }));
    }

    const [recentLogs] = await connection.query(
      `
        SELECT
          id,
          module,
          action,
          biz_type,
          biz_id,
          biz_no,
          content,
          operator_name,
          created_at
        FROM operation_logs
        WHERE ${logScope.sql}
        ORDER BY created_at DESC, id DESC
        LIMIT 10
      `,
      logScope.params,
    );

    return sendSuccess(
      res,
      {
        totalCustomers: Number(customerStatsRow?.total_customers || 0),
        activeCustomers: Number(customerStatsRow?.active_customers || 0),
        accountOnlyCustomers: Number(customerStatsRow?.account_only || 0),
        cardedCustomers: Number(customerStatsRow?.carded || 0),
        expiredCustomers: Number(customerStatsRow?.expired || 0),
        lowTimesCustomers: Number(customerStatsRow?.low_times || 0),
        todayVerifyCount: Number(verifyStatsRow?.today_verify || 0),
        todayVisitCount: Number(todayVisitList.length || 0),
        todayVisitList: toCamelCase(todayVisitList),
        monthVerifyCount: Number(verifyStatsRow?.month_verify || 0),
        monthNewCustomers: Number(customerStatsRow?.month_new || 0),
        monthRenewals: Number(monthRenewalRow?.total || 0),
        soonExpireList: toCamelCase(soonExpireList),
        lowTimesList: toCamelCase(lowTimesList),
        expiredList: toCamelCase(expiredList),
        latestRecords: toCamelCase(latestRecords),
        recentLogs: toCamelCase(recentLogs),
        verifyTrend,
        storeDistribution,
        tagStats,
        storeStats: toCamelCase(storeStats),
        currentDate: today,
        warningSummary: {
          expiringSoon: Number(soonExpireList.length || 0),
          lowTimes: Number(customerStatsRow?.low_times || 0),
          expired: Number(customerStatsRow?.expired || 0),
        },
        settings: {
          lowTimesThreshold,
          soonExpireDays: safeSoonExpireDays,
          systemName: settings.system_name,
        },
      },
      "获取首页看板成功",
    );
  } catch (error) {
    console.error("dashboard overview error:", error);
    return sendFail(res, "获取首页看板失败", 500);
  } finally {
    connection.release();
  }
});

router.get("/notifications", auth(), requireUserPermission("dashboard:view"), async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await ensureDashboardSchema();
    const user = req.user;
    const settings = await require("../utils/system-settings").getSettingsMap(connection);
    const lowTimesThreshold = Number(settings.low_times_threshold || 5);
    const soonExpireDays = Number(settings.soon_expire_days || 15);
    const safeSoonExpireDays = Number.isFinite(soonExpireDays) && soonExpireDays >= 1
      ? Math.min(Math.floor(soonExpireDays), 365)
      : 15;
    const customerScope = buildStoreWhere(user, "store_id");

    const [soonExpireRows] = await connection.query(
      `
        SELECT
          id,
          child_name,
          parent_phone,
          training_project,
          remaining_times,
          expire_date,
          store_id
        FROM customers
        WHERE status = 1
          AND has_card = 1
          AND ${customerScope.sql}
          AND expire_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
        ORDER BY expire_date ASC, id DESC
        LIMIT 12
      `,
      [safeSoonExpireDays, ...customerScope.params],
    );

    const [lowTimesRows] = await connection.query(
      `
        SELECT
          id,
          child_name,
          parent_phone,
          training_project,
          remaining_times,
          expire_date,
          store_id
        FROM customers
        WHERE status = 1
          AND has_card = 1
          AND remaining_times > 0
          AND remaining_times <= ?
          AND ${customerScope.sql}
        ORDER BY remaining_times ASC, expire_date ASC, id DESC
        LIMIT 12
      `,
      [lowTimesThreshold, ...customerScope.params],
    );

    const [expiredRows] = await connection.query(
      `
        SELECT
          id,
          child_name,
          parent_phone,
          training_project,
          remaining_times,
          expire_date,
          store_id
        FROM customers
        WHERE status = 1
          AND has_card = 1
          AND expire_date < CURDATE()
          AND ${customerScope.sql}
        ORDER BY expire_date ASC, id DESC
        LIMIT 12
      `,
      customerScope.params,
    );

    const rawList = [
      ...expiredRows.map((row) => buildCustomerAlertItem("expired", row)),
      ...soonExpireRows.map((row) => buildCustomerAlertItem("expire_soon", row)),
      ...lowTimesRows.map((row) => buildCustomerAlertItem("low_times", row)),
    ]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 30);
    const stateMap = await getNotificationStateMap(connection, user.userId, rawList);
    const list = mergeNotificationState(rawList, stateMap).sort((a, b) => {
      if (Number(a.isRead) !== Number(b.isRead)) {
        return Number(a.isRead) - Number(b.isRead);
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    const unread = list.filter((item) => !item.isRead).length;

    return sendSuccess(
      res,
      {
        total: list.length,
        unread,
        list,
      },
      "获取通知成功",
    );
  } catch (error) {
    console.error("dashboard notifications error:", error);
    return sendFail(res, "获取通知失败", 500);
  } finally {
    connection.release();
  }
});

router.post("/notifications/read-all", auth(), requireUserPermission("dashboard:notification"), async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await ensureDashboardSchema();
    const user = req.user;
    const settings = await require("../utils/system-settings").getSettingsMap(connection);
    const lowTimesThreshold = Number(settings.low_times_threshold || 5);
    const soonExpireDays = Number(settings.soon_expire_days || 15);
    const safeSoonExpireDays = Number.isFinite(soonExpireDays) && soonExpireDays >= 1
      ? Math.min(Math.floor(soonExpireDays), 365)
      : 15;
    const customerScope = buildStoreWhere(user, "store_id");

    const [rows] = await connection.query(
      `
        SELECT id, child_name, parent_phone, training_project, remaining_times, expire_date, store_id,
          CASE
            WHEN expire_date < CURDATE() THEN 'expired'
            WHEN remaining_times > 0 AND remaining_times <= ? THEN 'low_times'
            ELSE 'expire_soon'
          END AS notice_type
        FROM customers
        WHERE status = 1
          AND has_card = 1
          AND ${customerScope.sql}
          AND (
            expire_date < CURDATE()
            OR expire_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
            OR (remaining_times > 0 AND remaining_times <= ?)
          )
        LIMIT 100
      `,
      [lowTimesThreshold, safeSoonExpireDays, lowTimesThreshold, ...customerScope.params],
    );

    const items = rows.map((row) => buildCustomerAlertItem(row.notice_type, row));
    await ensureNotificationStateTable();

    for (const item of items) {
      await connection.execute(
        `
          INSERT INTO user_notification_states (user_id, notification_id, is_read, read_at)
          VALUES (?, ?, 1, NOW())
          ON DUPLICATE KEY UPDATE is_read = 1, read_at = NOW()
        `,
        [Number(user.userId || 0), String(item.id)],
      );
    }

    return sendSuccess(res, null, "已全部标记为已读");
  } catch (error) {
    console.error("notification read-all error:", error);
    return sendFail(res, "批量已读失败", 500);
  } finally {
    connection.release();
  }
});

router.post("/notifications/:id/read", auth(), requireUserPermission("dashboard:notification"), async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await ensureDashboardSchema();
    await ensureNotificationStateTable();
    await connection.execute(
      `
        INSERT INTO user_notification_states (user_id, notification_id, is_read, read_at)
        VALUES (?, ?, 1, NOW())
        ON DUPLICATE KEY UPDATE is_read = 1, read_at = NOW()
      `,
      [Number(req.user.userId || 0), String(req.params.id || "")],
    );

    return sendSuccess(res, null, "已标记为已读");
  } catch (error) {
    console.error("notification read error:", error);
    return sendFail(res, "标记已读失败", 500);
  } finally {
    connection.release();
  }
});

router.post("/notifications/:id/handle", auth(), requireUserPermission("dashboard:notification"), async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await ensureDashboardSchema();
    await ensureNotificationStateTable();
    await connection.execute(
      `
        INSERT INTO user_notification_states (user_id, notification_id, is_read, read_at, handled_at, handled_note)
        VALUES (?, ?, 1, NOW(), NOW(), ?)
        ON DUPLICATE KEY UPDATE
          is_read = 1,
          read_at = COALESCE(read_at, NOW()),
          handled_at = NOW(),
          handled_note = VALUES(handled_note)
      `,
      [
        Number(req.user.userId || 0),
        String(req.params.id || ""),
        String(req.body.note || "").trim() || null,
      ],
    );

    return sendSuccess(res, null, "已标记为已处理");
  } catch (error) {
    console.error("notification handle error:", error);
    return sendFail(res, "标记处理失败", 500);
  } finally {
    connection.release();
  }
});

router.ensureDashboardSchema = ensureDashboardSchema;

module.exports = router;
