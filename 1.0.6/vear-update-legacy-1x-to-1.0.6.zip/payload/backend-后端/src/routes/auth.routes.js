const express = require("express");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");

const { pool } = require("../config/db");
const { auth } = require("../middleware/auth");
const { sendSuccess, sendFail } = require("../utils/response");
const { registerLimiter } = require("../config/rate-limiter");
const { ROLE_MAP } = require("../config/constants");
const { getUserPermissionCodes } = require("../utils/permission");
const { toChinaIsoString } = require("../utils/date");

const router = express.Router();

function signToken(payload) {
  const jwt = require("jsonwebtoken");
  const secret = process.env.JWT_SECRET || "verify-system-secret";
  const expiresIn = process.env.JWT_EXPIRES_IN || "7d";
  return jwt.sign(payload, secret, { expiresIn });
}

function formatUser(row) {
  if (!row) return null;

  return {
    userId: Number(row.id),
    username: row.username,
    realName: row.real_name,
    role: Number(row.role),
    roleLabel: ROLE_MAP[Number(row.role)] || "未知角色",
    storeId: row.store_id ? Number(row.store_id) : null,
    storeName: row.store_name || null,
    status: Number(row.status),
    lastLoginAt: row.last_login_at || null,
    lastLoginIp: row.last_login_ip || null
  };
}

async function createSession(userId, req) {
  const refreshToken = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

  await pool.execute(
    `
      INSERT INTO user_sessions
      (user_id, refresh_token, expired_at, ip, user_agent)
      VALUES (?, ?, ?, ?, ?)
    `,
    [
      userId,
      refreshToken,
      expiresAt,
      req.ip || "",
      (req.headers["user-agent"] || "").slice(0, 500)
    ]
  );

  return {
    refreshToken,
    refreshExpiresAt: toChinaIsoString(expiresAt)
  };
}

async function ensureRegistrationTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`user_registrations\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`username\` varchar(50) NOT NULL COMMENT '登录账号',
      \`password_hash\` varchar(255) NOT NULL COMMENT '密码哈希',
      \`real_name\` varchar(50) NOT NULL COMMENT '真实姓名',
      \`phone\` varchar(20) DEFAULT NULL COMMENT '联系电话',
      \`store_id\` bigint unsigned DEFAULT NULL COMMENT '所属门店ID',
      \`role\` tinyint DEFAULT NULL COMMENT '分配角色',
      \`status\` tinyint NOT NULL DEFAULT 0 COMMENT '状态：0待审核 1通过 2拒绝',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`review_note\` varchar(255) DEFAULT NULL COMMENT '审核意见',
      \`reviewed_by\` bigint unsigned DEFAULT NULL COMMENT '审核人ID',
      \`reviewed_at\` datetime DEFAULT NULL COMMENT '审核时间',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_reg_username\` (\`username\`),
      KEY \`idx_reg_status\` (\`status\`),
      KEY \`idx_reg_store_id\` (\`store_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户注册申请表'
  `);
}

router.post("/register", registerLimiter, async (req, res, next) => {
  try {
    await ensureRegistrationTable();

    const username = String(req.body.username || "").trim();
    const password = String(req.body.password || "").trim();
    const realName = String(req.body.realName || "").trim();
    const phone = String(req.body.phone || "").trim();
    const remark = String(req.body.remark || "").trim();

    if (!username || !password || !realName) {
      return sendFail(res, "请填写完整信息", 400, { errorCode: "MISSING_FIELDS" });
    }

    if (password.length < 6) {
      return sendFail(res, "密码长度不能少于6位", 400, { errorCode: "INVALID_PASSWORD" });
    }

    const [existsUser] = await pool.execute(
      "SELECT id FROM users WHERE username = ? LIMIT 1",
      [username]
    );
    if (existsUser.length) {
      return sendFail(res, "账号已存在，请直接登录", 400, { errorCode: "USER_EXISTS" });
    }

    const [regRows] = await pool.execute(
      "SELECT id, status FROM user_registrations WHERE username = ? LIMIT 1",
      [username]
    );
    if (regRows.length) {
      const reg = regRows[0];
      const status = Number(reg.status || 0);
      if (status === 0) {
        return sendFail(res, "账号已提交待审核", 400, { errorCode: "PENDING" });
      }
      if (status === 1) {
        return sendFail(res, "账号已审核通过，请直接登录", 400, { errorCode: "APPROVED" });
      }
    }

    const passwordHash = await bcrypt.hash(password, 10);

    if (regRows.length) {
      await pool.execute(
        `
          UPDATE user_registrations
          SET
            password_hash = ?,
            real_name = ?,
            phone = ?,
            remark = ?,
            status = 0,
            role = NULL,
            store_id = NULL,
            review_note = NULL,
            reviewed_by = NULL,
            reviewed_at = NULL
          WHERE id = ?
        `,
        [passwordHash, realName, phone || null, remark || null, regRows[0].id]
      );
    } else {
      await pool.execute(
        `
          INSERT INTO user_registrations
          (username, password_hash, real_name, phone, remark, status)
          VALUES (?, ?, ?, ?, ?, 0)
        `,
        [username, passwordHash, realName, phone || null, remark || null]
      );
    }

    return sendSuccess(res, null, "注册申请已提交，请等待管理员审核");
  } catch (error) {
    next(error);
  }
});

router.post("/login", async (req, res, next) => {
  try {
    const username = String(req.body.username || "").trim();
    const password = String(req.body.password || "").trim();

    if (!username || !password) {
      return sendFail(res, "请输入账号和密码", 400);
    }

    const [rows] = await pool.execute(
      `
        SELECT
          u.id,
          u.username,
          u.password_hash,
          u.real_name,
          u.role,
          u.store_id,
          u.status,
          u.last_login_at,
          u.last_login_ip,
          s.store_name
        FROM users u
        LEFT JOIN stores s ON s.id = u.store_id
        WHERE u.username = ?
        LIMIT 1
      `,
      [username]
    );

    const user = rows[0];

    if (!user) {
      return sendFail(res, "账号或密码错误", 400);
    }

    if (Number(user.status) !== 1) {
      return sendFail(res, "账号已被禁用，请联系管理员", 403);
    }

    const matched = await bcrypt.compare(password, user.password_hash);
    if (!matched) {
      return sendFail(res, "账号或密码错误", 400);
    }

    const tokenPayload = {
      userId: Number(user.id),
      username: user.username,
      realName: user.real_name,
      role: Number(user.role),
      storeId: user.store_id ? Number(user.store_id) : null,
      status: Number(user.status)
    };

    const accessToken = signToken(tokenPayload);
    const loginAt = toChinaIsoString();

    // 登录只等待必要数据：session 和权限。最后登录时间/日志是非关键写入，不能挡用户进入系统。
    const [session, permissions] = await Promise.all([
      createSession(user.id, req),
      getUserPermissionCodes(user.id, user.role)
    ]);

    Promise.allSettled([
      pool.execute(
        `
          UPDATE users
          SET last_login_at = NOW(), last_login_ip = ?
          WHERE id = ?
        `,
        [req.ip || "", user.id]
      ),
      pool.execute(
        `
          INSERT INTO operation_logs
          (operator_id, operator_name, operator_role, store_id, module, action, biz_type, biz_id, content, ip, user_agent)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [
          user.id,
          user.real_name,
          user.role,
          user.store_id || null,
          "auth",
          "login",
          "user",
          user.id,
          `用户登录：${user.username}`,
          req.ip || "",
          (req.headers["user-agent"] || "").slice(0, 500)
        ]
      )
    ]).catch(() => {});

    return sendSuccess(
      res,
      {
        accessToken,
        refreshToken: session.refreshToken,
        refreshExpiresAt: session.refreshExpiresAt,
        permissions,
        user: formatUser({
          ...user,
          last_login_at: loginAt,
          last_login_ip: req.ip || ""
        })
      },
      "登录成功"
    );
  } catch (error) {
    next(error);
  }
});

router.post("/refresh", async (req, res, next) => {
  try {
    const refreshToken = String(req.body.refreshToken || "").trim();

    if (!refreshToken) {
      return sendFail(res, "缺少刷新令牌", 400);
    }

    const [rows] = await pool.execute(
      `
        SELECT
          us.id AS session_id,
          us.user_id,
          us.expired_at,
          u.username,
          u.real_name,
          u.role,
          u.store_id,
          u.status,
          s.store_name
        FROM user_sessions us
        INNER JOIN users u ON u.id = us.user_id
        LEFT JOIN stores s ON s.id = u.store_id
        WHERE us.refresh_token = ?
        LIMIT 1
      `,
      [refreshToken]
    );

    const session = rows[0];

    if (!session) {
      return sendFail(res, "刷新令牌无效", 401);
    }

    if (new Date(session.expired_at).getTime() < Date.now()) {
      await pool.execute("DELETE FROM user_sessions WHERE id = ?", [session.session_id]);
      return sendFail(res, "刷新令牌已过期，请重新登录", 401);
    }

    if (Number(session.status) !== 1) {
      return sendFail(res, "账号已被禁用，请重新登录", 401);
    }

    const accessToken = signToken({
      userId: Number(session.user_id),
      username: session.username,
      realName: session.real_name,
      role: Number(session.role),
      storeId: session.store_id ? Number(session.store_id) : null,
      status: Number(session.status)
    });

    return sendSuccess(
      res,
      {
        accessToken,
        permissions: await getUserPermissionCodes(session.user_id, session.role),
        user: formatUser({
          id: session.user_id,
          username: session.username,
          real_name: session.real_name,
          role: session.role,
          store_id: session.store_id,
          status: session.status,
          store_name: session.store_name
        })
      },
      "刷新成功"
    );
  } catch (error) {
    next(error);
  }
});

router.post("/logout", auth(), async (req, res, next) => {
  try {
    const refreshToken = String(req.body.refreshToken || "").trim();

    if (refreshToken) {
      await pool.execute(
        "DELETE FROM user_sessions WHERE refresh_token = ? AND user_id = ?",
        [refreshToken, req.user.userId]
      );
    }

    await pool.execute(
      `
        INSERT INTO operation_logs
        (operator_id, operator_name, operator_role, store_id, module, action, biz_type, biz_id, content, ip, user_agent)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        req.user.userId,
        req.user.realName,
        req.user.role,
        req.user.storeId || null,
        "auth",
        "logout",
        "user",
        req.user.userId,
        `用户退出登录：${req.user.username}`,
        req.ip || "",
        (req.headers["user-agent"] || "").slice(0, 500)
      ]
    );
    return sendSuccess(res, null, "退出成功");
  } catch (error) {
    next(error);
  }
});

router.get("/profile", auth(), async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `
        SELECT
          u.id,
          u.username,
          u.real_name,
          u.role,
          u.store_id,
          u.status,
          u.last_login_at,
          u.last_login_ip,
          s.store_name
        FROM users u
        LEFT JOIN stores s ON s.id = u.store_id
        WHERE u.id = ?
        LIMIT 1
      `,
      [req.user.userId]
    );

    const user = rows[0];

    if (!user) {
      return sendFail(res, "用户不存在", 404);
    }

    return sendSuccess(
      res,
      {
        ...formatUser(user),
        permissions: await getUserPermissionCodes(user.id, user.role)
      },
      "获取成功"
    );
  } catch (error) {
    next(error);
  }
});

router.put("/password", auth(), async (req, res, next) => {
  try {
    const oldPassword = String(req.body.oldPassword || "").trim();
    const newPassword = String(req.body.newPassword || "").trim();

    if (!oldPassword || !newPassword) {
      return sendFail(res, "请输入原密码和新密码", 400);
    }

    if (newPassword.length < 6) {
      return sendFail(res, "新密码长度不能少于6位", 400);
    }

    const [rows] = await pool.execute(
      "SELECT id, username, password_hash, real_name, role, store_id FROM users WHERE id = ? LIMIT 1",
      [req.user.userId]
    );

    const user = rows[0];
    if (!user) {
      return sendFail(res, "用户不存在", 404);
    }

    const matched = await bcrypt.compare(oldPassword, user.password_hash);
    if (!matched) {
      return sendFail(res, "原密码不正确", 400);
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);

    await pool.execute("UPDATE users SET password_hash = ? WHERE id = ?", [
      passwordHash,
      req.user.userId
    ]);

    await pool.execute(
      `
        INSERT INTO operation_logs
        (operator_id, operator_name, operator_role, store_id, module, action, biz_type, biz_id, content, ip, user_agent)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        req.user.userId,
        req.user.realName,
        req.user.role,
        req.user.storeId || null,
        "auth",
        "change_password",
        "user",
        req.user.userId,
        `用户修改密码：${req.user.username}`,
        req.ip || "",
        (req.headers["user-agent"] || "").slice(0, 500)
      ]
    );

    await pool.execute("DELETE FROM user_sessions WHERE user_id = ?", [req.user.userId]);

    return sendSuccess(res, null, "密码修改成功，请重新登录");
  } catch (error) {
    next(error);
  }
});

module.exports = router;
