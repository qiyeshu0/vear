const mysql = require("mysql2/promise");
const { CHINA_TIME_ZONE } = require("../utils/date");

if (!process.env.TZ) process.env.TZ = CHINA_TIME_ZONE;

let currentPool = null;
let currentSignature = "";
const DEFAULT_QUERY_TIMEOUT = Number(process.env.DB_QUERY_TIMEOUT || "5000");

function getDbConfig(overrides = {}) {
  return {
    host: String(overrides.host ?? process.env.DB_HOST ?? "127.0.0.1"),
    port: Number(overrides.port ?? process.env.DB_PORT ?? "3306"),
    user: String(overrides.user ?? process.env.DB_USER ?? "root"),
    password: String(overrides.password ?? process.env.DB_PASSWORD ?? ""),
    database: String(overrides.database ?? process.env.DB_NAME ?? "verification_system"),
    connectionLimit: Number(
      overrides.connectionLimit ?? process.env.DB_CONNECTION_LIMIT ?? "10"
    )
  };
}

function buildPoolConfig(config) {
  return {
    host: config.host,
    port: config.port,
    user: config.user,
    password: config.password,
    database: config.database,
    waitForConnections: true,
    connectionLimit: config.connectionLimit,
    queueLimit: 0,
    charset: "utf8mb4",
    timezone: "+08:00",
    connectTimeout: Number(process.env.DB_CONNECT_TIMEOUT || "3000"),
    dateStrings: true, // 防止 MySQL 日期被转为 UTC Date 对象再 JSON 序列化时出现时差
    enableKeepAlive: true,
    keepAliveInitialDelay: 0
  };
}

function isTransientDbError(error) {
  const code = error?.code || error?.errno || "";
  return [
    "ETIMEDOUT",
    "ECONNRESET",
    "ECONNREFUSED",
    "EPIPE",
    "PROTOCOL_CONNECTION_LOST",
    "PROTOCOL_ENQUEUE_AFTER_FATAL_ERROR",
    "PROTOCOL_SEQUENCE_TIMEOUT"
  ].includes(String(code));
}

function withQueryTimeoutArgs(args) {
  const nextArgs = Array.from(args);
  const first = nextArgs[0];

  if (typeof first === "string") {
    nextArgs[0] = { sql: first, timeout: DEFAULT_QUERY_TIMEOUT };
    return nextArgs;
  }

  if (first && typeof first === "object" && first.timeout == null) {
    nextArgs[0] = { ...first, timeout: DEFAULT_QUERY_TIMEOUT };
  }

  return nextArgs;
}

function wrapConnection(connection) {
  if (!connection || connection.__verifySystemWrapped) return connection;

  const rawQuery = connection.query.bind(connection);
  const rawExecute = connection.execute.bind(connection);

  connection.query = (...args) => rawQuery(...withQueryTimeoutArgs(args));
  connection.execute = (...args) => rawExecute(...withQueryTimeoutArgs(args));
  Object.defineProperty(connection, "__verifySystemWrapped", {
    value: true,
    enumerable: false
  });

  return connection;
}

async function withTransientRetry(operation) {
  try {
    return await operation(ensurePool());
  } catch (error) {
    if (!isTransientDbError(error)) throw error;

    console.warn("[数据库连接重试]", error.code || error.message || error);
    await resetPool();
    return operation(ensurePool());
  }
}

function buildSignature(config) {
  return JSON.stringify(config);
}

function ensurePool() {
  const config = getDbConfig();
  const nextSignature = buildSignature(config);

  if (!currentPool || currentSignature !== nextSignature) {
    currentPool = mysql.createPool(buildPoolConfig(config));
    currentPool.on("connection", connection => {
      connection.query("SET time_zone = '+08:00'", error => {
        if (error) console.warn("[数据库时区设置失败]", error.message || error);
      });
    });
    currentSignature = nextSignature;
  }

  return currentPool;
}

async function resetPool(overrides = {}) {
  const previousPool = currentPool;

  if (Object.keys(overrides).length > 0) {
    if (overrides.host !== undefined) process.env.DB_HOST = String(overrides.host);
    if (overrides.port !== undefined) process.env.DB_PORT = String(overrides.port);
    if (overrides.user !== undefined) process.env.DB_USER = String(overrides.user);
    if (overrides.password !== undefined) process.env.DB_PASSWORD = String(overrides.password);
    if (overrides.database !== undefined) process.env.DB_NAME = String(overrides.database);
    if (overrides.connectionLimit !== undefined) {
      process.env.DB_CONNECTION_LIMIT = String(overrides.connectionLimit);
    }
  }

  currentPool = null;
  currentSignature = "";

  if (previousPool) {
    // 旧连接池里可能含有半死不活的远程连接，end() 不能阻塞用户请求。
    // 快速切到新池，旧池后台回收即可。
    Promise.race([
      previousPool.end(),
      new Promise((resolve) => setTimeout(resolve, 500)),
    ]).catch(() => {});
  }

  return ensurePool();
}

const pool = new Proxy({}, {
  get(_target, property) {
    if (property === "query" || property === "execute") {
      return (...args) => withTransientRetry(activePool =>
        activePool[property](...withQueryTimeoutArgs(args))
      );
    }

    if (property === "getConnection") {
      return () => withTransientRetry(async activePool =>
        wrapConnection(await activePool.getConnection())
      );
    }

    if (property === "end") {
      return async () => {
        const activePool = currentPool;
        currentPool = null;
        currentSignature = "";
        if (activePool) return activePool.end();
      };
    }

    const activePool = ensurePool();
    const value = activePool[property];
    return typeof value === "function" ? value.bind(activePool) : value;
  }
});

async function testDbConnection() {
  const connection = await ensurePool().getConnection();
  try {
    await connection.ping();
    return true;
  } finally {
    connection.release();
  }
}

module.exports = {
  pool,
  testDbConnection,
  resetPool,
  getDbConfig
};
