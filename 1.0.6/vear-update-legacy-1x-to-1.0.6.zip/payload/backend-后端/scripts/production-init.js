#!/usr/bin/env node
/**
 * 正式上线初始化脚本
 *
 * 设计目标：
 * 1. 只面向服务器首次上线/新库初始化，不把测试库数据带到生产。
 * 2. 默认保护已有业务数据，除非显式 --force，否则不会在非空业务库上继续执行。
 * 3. 初始化后补齐：数据表、默认门店、超级管理员、训练项目、卡项模板、权限、系统设置和短信基础数据。
 */
require("dotenv").config();

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const mysql = require("mysql2/promise");

const { pool, getDbConfig } = require("../src/config/db");
const { createTables } = require("../src/install/schema");
const { seedDefaultBusinessData } = require("../src/install/default-business-data");
const { saveSettings, DEFAULT_SETTINGS } = require("../src/utils/system-settings");
const { ensurePermissionTables, ensureDefaultUserPermissions } = require("../src/utils/permission");
const { ensureSmsSchema } = require("../src/services/sms.service");
const { ensureRuntimeConfigSchema } = require("../src/utils/runtime-config");
const { ROLE_ADMIN } = require("../src/config/constants");
const { toChinaIsoString } = require("../src/utils/date");

const PROJECT_ROOT = path.resolve(__dirname, "..");
const ENV_FILE = path.join(PROJECT_ROOT, ".env");
const INSTALL_LOCK_FILE = path.join(PROJECT_ROOT, ".installed");
const INIT_RESULT_FILE = path.join(PROJECT_ROOT, ".production-init-result.json");

const CORE_TABLES = [
  "stores",
  "users",
  "customers",
  "customer_cards",
  "verify_records",
  "customer_attachments",
];
const BUSINESS_TABLES = [
  "customers",
  "customer_cards",
  "customer_renewals",
  "customer_card_usage_logs",
  "refund_records",
  "verify_records",
  "revoke_requests",
  "wx_user_bindings",
  "wx_reservations",
];
const WEAK_JWT_VALUES = [
  "please_change_this_to_a_strong_secret",
  "please_change_this_to_a_long_random_secret",
  "verify-system-secret",
  "change_me",
  "your-secret-key",
  "123456",
];
const PLACEHOLDER_VALUES = [
  "请填写",
  "please_change",
  "your-",
  "change_me",
  "placeholder",
];

const argv = new Set(process.argv.slice(2));
const options = {
  dryRun: argv.has("--dry-run"),
  force: argv.has("--force"),
  skipLock: argv.has("--skip-lock"),
};

function log(message = "") {
  console.log(message);
}
function ok(message) {
  console.log(`✅ ${message}`);
}
function warn(message) {
  console.log(`⚠️  ${message}`);
}
function fail(message) {
  console.log(`❌ ${message}`);
}
function mask(value) {
  const text = String(value || "");
  if (!text) return "";
  if (text.length <= 6) return "******";
  return `${text.slice(0, 3)}******${text.slice(-3)}`;
}
function hasPlaceholder(value) {
  const text = String(value || "").trim().toLowerCase();
  if (!text) return true;
  return PLACEHOLDER_VALUES.some(item => text.includes(item));
}
function isWeakJwt(secret) {
  const text = String(secret || "").trim();
  const lower = text.toLowerCase();
  if (text.length < 32) return true;
  return WEAK_JWT_VALUES.includes(lower) || WEAK_JWT_VALUES.some(item => lower.startsWith(`${item}_`));
}
function parseCorsOrigins(value) {
  return String(value || "")
    .split(",")
    .map(item => item.trim())
    .filter(Boolean);
}
function generatePassword() {
  // 去掉容易混淆的字符，方便用户第一次登录复制。
  return crypto.randomBytes(18).toString("base64url").replace(/[IlO0]/g, "x").slice(0, 20);
}
function readEnvPairs() {
  if (!fs.existsSync(ENV_FILE)) return {};
  const dotenv = require("dotenv");
  return dotenv.parse(fs.readFileSync(ENV_FILE));
}

function validateEnv() {
  const errors = [];
  const warnings = [];
  const envPairs = readEnvPairs();
  const required = ["DB_HOST", "DB_PORT", "DB_NAME", "DB_USER", "DB_PASSWORD", "JWT_SECRET"];

  if (!fs.existsSync(ENV_FILE)) {
    errors.push("缺少 backend-后端/.env，请先从 .env.example 复制并填写正式服务器配置");
  }

  for (const key of required) {
    if (!String(process.env[key] || "").trim()) errors.push(`${key} 未配置`);
  }

  if (process.env.NODE_ENV !== "production") {
    errors.push("NODE_ENV 必须为 production");
  }
  if (isWeakJwt(process.env.JWT_SECRET)) {
    errors.push("JWT_SECRET 过短或仍是默认弱密钥，请使用 32 位以上强随机字符串");
  }
  if (!String(process.env.CONFIG_ENCRYPTION_KEY || "").trim() || hasPlaceholder(process.env.CONFIG_ENCRYPTION_KEY) || String(process.env.CONFIG_ENCRYPTION_KEY || "").length < 32) {
    warnings.push("CONFIG_ENCRYPTION_KEY 未配置强随机值，将临时退回使用 JWT_SECRET 派生密钥；正式交付建议单独配置");
  }
  if (hasPlaceholder(process.env.DB_PASSWORD)) {
    errors.push("DB_PASSWORD 仍像占位符，请填写正式数据库密码");
  }
  if (String(process.env.WX_LOGIN_MOCK || "0") !== "0") {
    errors.push("WX_LOGIN_MOCK 必须为 0，正式上线不能使用微信模拟登录");
  }
  if (hasPlaceholder(process.env.WX_APPID)) {
    errors.push("WX_APPID 未填写正式值");
  }
  if (hasPlaceholder(process.env.WX_APPSECRET)) {
    errors.push("WX_APPSECRET 未填写正式值");
  }

  const origins = parseCorsOrigins(process.env.CORS_ORIGIN);
  if (!origins.length) {
    warnings.push("CORS_ORIGIN 未配置，建议填写正式 HTTPS 后台域名");
  } else if (!origins.some(item => item.startsWith("https://"))) {
    warnings.push("CORS_ORIGIN 没有 HTTPS 域名，正式上线建议只开放 HTTPS 正式域名");
  }

  if (String(process.env.SMS_MOCK || "0") === "1") {
    warnings.push("SMS_MOCK=1，短信当前为模拟发送；正式真发前请改为 0 并配置服务商密钥");
  } else {
    if (hasPlaceholder(process.env.SMS_PROVIDER || "aliyun")) errors.push("SMS_PROVIDER 未配置");
    if (hasPlaceholder(process.env.SMS_SIGN_NAME)) errors.push("SMS_SIGN_NAME 未填写短信签名");
    const ak = process.env.ALIYUN_SMS_ACCESS_KEY_ID || process.env.SMS_ACCESS_KEY_ID;
    const sk = process.env.ALIYUN_SMS_ACCESS_KEY_SECRET || process.env.SMS_ACCESS_KEY_SECRET;
    if (hasPlaceholder(ak)) errors.push("阿里云短信 AccessKeyId 未配置");
    if (hasPlaceholder(sk)) errors.push("阿里云短信 AccessKeySecret 未配置");
  }

  return { errors, warnings, envPairs };
}

async function connectDatabase() {
  const config = getDbConfig();
  const connection = await mysql.createConnection({
    host: config.host,
    port: config.port,
    user: config.user,
    password: config.password,
    database: config.database,
    charset: "utf8mb4",
    dateStrings: true,
    connectTimeout: Number(process.env.DB_CONNECT_TIMEOUT || "5000"),
  });
  return connection;
}

async function listTables(connection) {
  const [rows] = await connection.query(
    "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME ASC"
  );
  return rows.map(row => row.TABLE_NAME);
}
async function tableExists(connection, table) {
  const [[row]] = await connection.query(
    "SELECT COUNT(*) AS total FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?",
    [table]
  );
  return Number(row.total || 0) > 0;
}
async function countRows(connection, table) {
  if (!(await tableExists(connection, table))) return 0;
  const [[row]] = await connection.query(`SELECT COUNT(*) AS total FROM \`${table}\``);
  return Number(row.total || 0);
}
async function inspectDatabase(connection) {
  const tables = await listTables(connection);
  const counts = {};
  for (const table of Array.from(new Set([...CORE_TABLES, ...BUSINESS_TABLES, "permissions", "permission_templates", "sms_templates"]))) {
    counts[table] = await countRows(connection, table);
  }
  const coreTablesPresent = CORE_TABLES.every(table => tables.includes(table));
  const hasBusinessData = BUSINESS_TABLES.some(table => Number(counts[table] || 0) > 0);
  const hasAnyCoreData = CORE_TABLES.some(table => Number(counts[table] || 0) > 0);
  return {
    tables,
    counts,
    coreTablesPresent,
    hasBusinessData,
    hasAnyCoreData,
  };
}

function assertDatabaseSafeForInit(state) {
  if (options.force) return;
  if (state.hasBusinessData) {
    throw new Error("目标数据库已经存在客户/核销/资金等业务数据。为避免误伤生产库，默认禁止初始化；确认要补表升级时才可使用 --force。");
  }
  if (state.hasAnyCoreData && state.coreTablesPresent) {
    throw new Error("目标数据库已经存在门店或用户数据。为避免覆盖已有生产库，默认禁止初始化；确认要补表升级时才可使用 --force。");
  }
}

async function ensureDefaultStore(connection) {
  const [[existing]] = await connection.query(
    "SELECT id, store_name FROM stores WHERE status = 1 ORDER BY id ASC LIMIT 1"
  );
  if (existing?.id) {
    return { id: Number(existing.id), created: false, name: existing.store_name };
  }

  const [result] = await connection.query(
    `INSERT INTO stores (store_name, store_code, contact_name, contact_phone, address, status, remark)
     VALUES (?, ?, ?, ?, ?, 1, ?)`,
    ["总部", "HQ", "系统管理员", "13800000000", "总部地址", "正式初始化默认门店"]
  );
  return { id: Number(result.insertId), created: true, name: "总部" };
}

async function ensureAdminUser(connection, storeId) {
  const [[admin]] = await connection.query(
    "SELECT id, username, real_name FROM users WHERE role = ? ORDER BY id ASC LIMIT 1",
    [ROLE_ADMIN]
  );
  if (admin?.id) {
    return { id: Number(admin.id), username: admin.username, created: false, generatedPassword: "" };
  }

  const [[anyUser]] = await connection.query(
    "SELECT id, username FROM users ORDER BY id ASC LIMIT 1"
  );
  if (anyUser?.id && !options.force) {
    throw new Error("users 表已有用户但没有超级管理员。请先核对数据，确认后使用 --force 补齐超级管理员。");
  }

  const username = String(process.env.SEED_ADMIN_USERNAME || "admin").trim() || "admin";
  const realName = String(process.env.SEED_ADMIN_REAL_NAME || "超级管理员").trim() || "超级管理员";
  let password = String(process.env.SEED_ADMIN_PASSWORD || "").trim();
  let generatedPassword = "";
  if (!password || hasPlaceholder(password) || password.length < 8) {
    generatedPassword = generatePassword();
    password = generatedPassword;
  }
  const passwordHash = await bcrypt.hash(password, 10);

  const [result] = await connection.query(
    `INSERT INTO users (username, password_hash, real_name, role, store_id, status, remark)
     VALUES (?, ?, ?, ?, ?, 1, ?)`,
    [username, passwordHash, realName, ROLE_ADMIN, storeId || null, "正式初始化超级管理员"]
  );
  return { id: Number(result.insertId), username, created: true, generatedPassword };
}

async function writeInstallLock(summary) {
  if (options.skipLock) return;
  const origins = parseCorsOrigins(process.env.CORS_ORIGIN);
  const payload = {
    installedAt: toChinaIsoString(),
    installMode: "production-cli",
    reusedDatabase: false,
    dbHost: process.env.DB_HOST || "",
    dbName: process.env.DB_NAME || "",
    adminUsername: summary.admin.username,
    origins,
  };
  fs.writeFileSync(INSTALL_LOCK_FILE, JSON.stringify(payload, null, 2));
}

function writeInitResult(summary) {
  const payload = {
    generatedAt: toChinaIsoString(),
    dbHost: process.env.DB_HOST || "",
    dbName: process.env.DB_NAME || "",
    adminUsername: summary.admin.username,
    adminCreated: summary.admin.created,
    adminGeneratedPassword: summary.admin.generatedPassword || undefined,
    warnings: summary.warnings,
  };
  fs.writeFileSync(INIT_RESULT_FILE, JSON.stringify(payload, null, 2));
}

async function runPostChecks(connection) {
  const checks = [];
  const adminCount = await countRows(connection, "users");
  const storeCount = await countRows(connection, "stores");
  const permissionCount = await countRows(connection, "permissions");
  const templateCount = await countRows(connection, "permission_templates");
  const smsTemplateCount = await countRows(connection, "sms_templates");
  const trainingProjectCount = await countRows(connection, "training_projects");
  const cardTemplateCount = await countRows(connection, "card_templates");
  checks.push([adminCount > 0, `用户数量 ${adminCount}`]);
  checks.push([storeCount > 0, `门店数量 ${storeCount}`]);
  checks.push([permissionCount > 0, `权限点数量 ${permissionCount}`]);
  checks.push([templateCount > 0, `权限模板数量 ${templateCount}`]);
  checks.push([smsTemplateCount > 0, `短信模板数量 ${smsTemplateCount}`]);
  checks.push([trainingProjectCount > 0, `训练项目数量 ${trainingProjectCount}`]);
  checks.push([cardTemplateCount > 0, `卡项模板数量 ${cardTemplateCount}`]);

  const failed = checks.filter(([pass]) => !pass).map(([, message]) => message);
  return { checks, failed };
}

async function main() {
  log("Vear 正式上线初始化");
  log("====================");
  if (options.dryRun) warn("当前为 --dry-run，只检查配置和数据库状态，不写入任何数据");
  if (options.force) warn("当前启用 --force，会允许在已有表/已有数据的数据库上执行补表和基础数据补齐");

  const { errors, warnings } = validateEnv();
  warnings.forEach(warn);
  if (errors.length) {
    errors.forEach(fail);
    throw new Error("上线配置校验不通过，请先修正 .env");
  }

  const db = getDbConfig();
  ok(`配置校验通过：${db.host}:${db.port}/${db.database}，用户 ${db.user}，密码 ${mask(db.password)}`);

  const connection = await connectDatabase();
  try {
    ok("数据库连接成功");
    const before = await inspectDatabase(connection);
    log(`数据库当前表数量：${before.tables.length}`);
    log(`核心数据：门店 ${before.counts.stores || 0}，用户 ${before.counts.users || 0}，客户 ${before.counts.customers || 0}，核销 ${before.counts.verify_records || 0}`);
    assertDatabaseSafeForInit(before);
    ok("数据库安全检查通过");

    if (options.dryRun) {
      ok("dry-run 完成：配置和数据库安全检查通过，可以在服务器执行 npm run init:production");
      return;
    }
  } finally {
    await connection.end();
  }

  await createTables(pool);
  ok("数据库表结构创建/升级完成");

  const conn = await pool.getConnection();
  let summary;
  try {
    await conn.beginTransaction();
    const store = await ensureDefaultStore(conn);
    const admin = await ensureAdminUser(conn, store.id);
    const businessDefaults = await seedDefaultBusinessData(conn, { operatorId: admin.id });
    await conn.commit();

    summary = { store, admin, businessDefaults, warnings };
    ok(`${store.created ? "已创建" : "已复用"}默认门店：${store.name}（ID ${store.id}）`);
    ok(`${admin.created ? "已创建" : "已复用"}超级管理员：${admin.username}（ID ${admin.id}）`);
    ok(businessDefaults.inserted
      ? `已写入默认训练项目 ${businessDefaults.trainingProjects} 项、卡项模板 ${businessDefaults.cardTemplates} 项`
      : businessDefaults.reason);
  } catch (error) {
    await conn.rollback();
    throw error;
  } finally {
    conn.release();
  }

  await ensurePermissionTables({ force: true });
  await ensureDefaultUserPermissions({ force: true });
  ok("权限点、权限模板、普通用户默认权限已补齐");

  await saveSettings({
    systemName: process.env.SEED_SYSTEM_NAME || DEFAULT_SETTINGS.system_name,
    soonExpireDays: process.env.SEED_SOON_EXPIRE_DAYS || DEFAULT_SETTINGS.soon_expire_days,
    lowTimesThreshold: process.env.SEED_LOW_TIMES_THRESHOLD || DEFAULT_SETTINGS.low_times_threshold,
    remark: "正式初始化默认系统设置",
  });
  ok("系统设置默认值已补齐");

  await ensureSmsSchema();
  await ensureRuntimeConfigSchema();
  ok("短信中心表结构、配置、内置模板和运行配置中心已补齐");

  const verifyConn = await pool.getConnection();
  try {
    const post = await runPostChecks(verifyConn);
    for (const [pass, message] of post.checks) {
      pass ? ok(message) : fail(message);
    }
    if (post.failed.length) throw new Error(`初始化后检查失败：${post.failed.join("；")}`);
  } finally {
    verifyConn.release();
  }

  await writeInstallLock(summary);
  writeInitResult(summary);
  ok(`安装锁已写入：${INSTALL_LOCK_FILE}`);
  ok(`初始化结果已写入：${INIT_RESULT_FILE}`);

  if (summary.admin.generatedPassword) {
    log("");
    warn("SEED_ADMIN_PASSWORD 未设置或仍是占位符，脚本已生成一次性管理员密码：");
    log(`账号：${summary.admin.username}`);
    log(`密码：${summary.admin.generatedPassword}`);
    warn("请立刻保存该密码，登录后马上修改。该密码也临时写入 .production-init-result.json，确认保存后建议删除该文件。")
  }

  log("");
  ok("正式初始化完成。下一步请执行：npm run check:release && npm run check:finance，然后启动服务。 ");
}

main()
  .catch((error) => {
    fail(error?.message || error);
    process.exitCode = 1;
  })
  .finally(async () => {
    try { await pool.end(); } catch (_error) {}
  });
