var authStorage = require('../../../utils/auth-storage');
var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');


function getActiveFormalCards(info) {
  return ((info && info.customerCards) || []).filter(function(card) {
    return card && !card.isPromotion && Number(card.status) === 1;
  });
}

function cardActionLabel(card) {
  return (card.cardName || card.trainingProject || '训练卡') + '（剩' + (card.remainingTimes || 0) + '次）';
}

var GLASSES_STATUS_LABELS = { 1: '已下单', 2: '定制中', 3: '制作中', 4: '待取镜', 5: '已交付', 6: '异常处理中', 7: '已取消' };
var GLASSES_FLOW = [1, 2, 3, 4, 5];
var GLASSES_STATUS_ACTIONS = [2, 3, 4, 5, 6, 7];

function normalizeGlassesStatus(status) {
  status = Number(status) || 1;
  return GLASSES_STATUS_LABELS[status] ? status : 1;
}

function glassesTagClass(status) {
  status = normalizeGlassesStatus(status);
  if (status === 5) return 'tag-green';
  if (status === 6 || status === 7) return 'tag-red';
  if (status === 2 || status === 3) return 'tag-blue';
  return 'tag-orange';
}

function decorateGlassesLog(log) {
  log = log || {};
  var fromStatus = Number(log.fromStatus || log.from_status || 0);
  var toStatus = normalizeGlassesStatus(log.toStatus || log.to_status);
  log._summary = fromStatus ? (GLASSES_STATUS_LABELS[fromStatus] + ' → ' + GLASSES_STATUS_LABELS[toStatus]) : ('创建为 ' + GLASSES_STATUS_LABELS[toStatus]);
  log._remark = log.remark || '无备注';
  log._operator = log.operatorName || log.operator_name || '系统';
  log._time = log.createdAt || log.created_at || '';
  return log;
}

function decorateGlassesRecord(g) {
  g = g || {};
  var status = normalizeGlassesStatus(g.deliveryStatus);
  g.deliveryStatus = status;
  g._deliveryText = g.deliveryStatusLabel || GLASSES_STATUS_LABELS[status] || '已下单';
  g._deliveryClass = glassesTagClass(status);
  g._nextStatus = status >= 1 && status < 5 ? status + 1 : 0;
  g._nextText = g._nextStatus ? ('推进到' + GLASSES_STATUS_LABELS[g._nextStatus]) : '';
  g._flowSteps = GLASSES_FLOW.map(function(value) {
    return {
      value: value,
      label: GLASSES_STATUS_LABELS[value],
      cls: status >= value && status <= 5 ? 'done' : '',
      dotCls: status === value ? 'current' : (status > value && status <= 5 ? 'done' : '')
    };
  });
  g._flowExtra = status === 6 || status === 7 ? GLASSES_STATUS_LABELS[status] : '';
  var logs = (g.statusLogs || []).map(decorateGlassesLog);
  g._statusLogs = logs.slice().reverse().slice(0, 3);
  g._hasLogs = g._statusLogs.length > 0;
  return g;
}

function decorateDetail(detail) {
  detail = detail || {};
  detail._tagsLabel = detail.tags && detail.tags.length ? detail.tags.join('、') : '—';
  detail._statusText = Number(detail.status) === 1 ? '正常' : '停用';
  detail._statusClass = Number(detail.status) === 1 ? 'tag-green' : 'tag-red';
  detail._statusActionText = Number(detail.status) === 1 ? '停用' : '启用';
  detail._genderText = Number(detail.gender) === 1 ? '男' : (Number(detail.gender) === 2 ? '女' : '—');
  (detail.customerCards || []).forEach(function(card) {
    card._typeText = card.isPromotion ? '活动卡' : '常规卡';
    card._typeClass = card.isPromotion ? 'tag-orange' : 'tag-blue';
  });
  (detail.glassesRecords || []).forEach(decorateGlassesRecord);
  (detail.verifyRecords || []).forEach(function(v) {
    v._tagText = v.cardName || v.trainingProject || '核销';
    v._tagClass = v.cardName ? 'tag-orange' : 'tag-blue';
  });
  return detail;
}

Page({
  data: { info: null, loading: true, isExpired: false, expiredClass: '', id: 0 },

  onLoad: function(options) {
    var id = parseInt(options.id) || 0;
    if (!id) { wx.showToast({ title: '参数错误', icon: 'none' }); return; }
    var user = authStorage.getStaffUser() || {};
    this.setData({
      id: id,
      canOperate: authStorage.hasAnyStaffPermission(['customer:update','customer:card:open','customer:card:renew','customer:refund','customer:attachment']),
      canEdit: authStorage.hasStaffPermission('customer:update'),
      canOpenCard: authStorage.hasStaffPermission('customer:card:open'),
      canRenewCard: authStorage.hasStaffPermission('customer:card:renew'),
      canRefund: authStorage.hasStaffPermission('customer:refund'),
      canUploadAttachment: authStorage.hasStaffPermission('customer:attachment'),
      canStatus: authStorage.hasStaffPermission('customer:status'),
      canPhone: authStorage.hasStaffPermission('customer:phone'),
      canFollow: authStorage.hasStaffPermission('customer:follow'),
      canVisit: authStorage.hasStaffPermission('customer:visit'),
      canGlasses: authStorage.hasStaffPermission('customer:glasses'),
      canActivityCard: authStorage.hasStaffPermission('customer:activity-card')
    });
    this.load(id);
  },

  load: async function(id) {
    try {
      var detail = await api.getCustomerDetail(id);
      // 附件加文件大小标签
      (detail.attachments || []).forEach(function(a) {
        a._sizeLabel = a.fileSize ? (a.fileSize / 1024).toFixed(1) + 'KB' : '';
      });
      var isExpired = detail.expireDate && new Date(detail.expireDate) < new Date();
      this.setData({ info: decorateDetail(detail), isExpired: isExpired, expiredClass: isExpired ? 'text-danger' : '', loading: false });
    } catch(e) { this.setData({ loading: false }); }
  },

  quickVerify: function() {
    var that = this;
    var info = this.data.info || {};
    var cards = getActiveFormalCards(info);

    function confirmVerify(card) {
      var content = '为「' + (info.childName || '') + '」核销 1 次吗？';
      if (card) content += '\n卡项：' + (card.cardName || card.trainingProject || '训练卡');
      wx.showModal({
        title: '确认核销',
        content: content,
        success: async function(res) {
          if (!res.confirm) return;
          try {
            await api.doVerify(that.data.id, '', card && card.id);
            wx.showToast({ title: '核销成功', icon: 'success' });
            setTimeout(function() { that.load(that.data.id); }, 800);
          } catch(err) { console.error('[快捷核销失败]', err); errorUtil.modal('快捷核销失败', err, '核销失败，请检查卡次数、有效期或权限'); }
        }
      });
    }

    if (cards.length > 1) {
      wx.showActionSheet({
        itemList: cards.map(cardActionLabel),
        success: function(res) { confirmVerify(cards[res.tapIndex]); }
      });
      return;
    }
    confirmVerify(cards[0] || info.currentCard || null);
  },

  goEdit: function() { wx.navigateTo({ url: '/pages/staff/edit-customer/edit-customer?id=' + this.data.id }); },
  uploadFile: function() {
    var that = this;
    // 先触发隐私授权（如果未授权过）
    if (wx.requirePrivacyAuthorize) {
      wx.requirePrivacyAuthorize({
        success: function() { that._pickFile(); },
        fail: function() { wx.showToast({ title: '需要同意隐私协议', icon: 'none' }); }
      });
    } else {
      this._pickFile();
    }
  },

  _pickFile: function() {
    var that = this;
    wx.showActionSheet({
      itemList: ['拍照', '从相册选择', '选择文件'],
      success: function(actRes) {
        if (actRes.tapIndex === 0) {
          wx.chooseImage({
            count: 1, sizeType: ['compressed'], sourceType: ['camera'],
            success: function(r) { that._doUpload(r.tempFilePaths); },
            fail: function(e) { that._showErr('拍照', e); }
          });
        } else if (actRes.tapIndex === 1) {
          wx.chooseImage({
            count: 5, sizeType: ['compressed'], sourceType: ['album'],
            success: function(r) { that._doUpload(r.tempFilePaths); },
            fail: function(e) { that._showErr('相册', e); }
          });
        } else {
          wx.chooseMessageFile({
            count: 5, type: 'all',
            success: function(r) { that._doUpload((r.tempFiles||[]).map(function(f){ return f.path; })); },
            fail: function(e) { that._showErr('文件', e); }
          });
        }
      }
    });
  },

  _showErr: function(tag, e) {
    var msg = (e && e.errMsg) || '';
    if (msg.indexOf('cancel') >= 0) return;
    wx.showModal({ title: tag + '失败', content: msg || '未知错误', showCancel: false });
  },

  _doUpload: async function(files) {
    if (!files || !files.length) { wx.showToast({ title: '未选择文件', icon: 'none' }); return; }
    wx.showLoading({ title: '上传中...' });
    var ok = 0, total = files.length;
    for (var i = 0; i < total; i++) {
      var f = files[i];
      var fp = typeof f === 'string' ? f : (f.tempFilePath || f.path || '');
      if (!fp) continue;
      try { await api.uploadAttachment(this.data.id, fp); ok++; }
      catch(e) { console.error('[附件上传失败]', e); errorUtil.modal('附件上传失败', e, '附件上传失败，请检查文件大小、格式或权限'); }
    }
    wx.hideLoading();
    if (ok > 0) {
      wx.showToast({ title: '已上传 ' + ok + ' 个文件', icon: 'success' });
      this.load(this.data.id);
    } else if (total > 0) {
      wx.showToast({ title: '上传失败', icon: 'none' });
    }
  },

  doRefund: function() {
    var that = this;
    var info = this.data.info || {};
    var cards = getActiveFormalCards(info);

    function askReason(card) {
      wx.showModal({
        title: '退卡确认',
        editable: true,
        placeholderText: '请输入退卡原因',
        content: '此操作将停用所选训练卡并记录退卡流水。' + (card ? '\n卡项：' + (card.cardName || card.trainingProject || '训练卡') : '') + '\n退卡原因：',
        success: async function(res) {
          if (!res.confirm) return;
          var reason = (res.content || '').trim();
          if (!reason) { wx.showToast({ title: '请输入退卡原因', icon: 'none' }); return; }
          wx.showLoading({ title: '处理中' });
          try {
            await api.refundCustomer(that.data.id, { cardId: card && card.id, reason: reason });
            wx.hideLoading();
            wx.showToast({ title: '退卡成功', icon: 'success', duration: 2000 });
            setTimeout(function() { that.load(that.data.id); }, 1000);
          } catch(e) { wx.hideLoading(); errorUtil.modal('退卡失败', e, '退卡失败，请检查客户卡状态或权限'); }
        }
      });
    }

    if (cards.length > 1) {
      wx.showActionSheet({
        itemList: cards.map(cardActionLabel),
        success: function(res) { askReason(cards[res.tapIndex]); }
      });
      return;
    }
    askReason(cards[0] || info.currentCard || null);
  },

  goOpenCard: function() { wx.navigateTo({ url: '/pages/staff/open-card/open-card?id=' + this.data.id }); },
  goRenewCard: function() {
    var info = this.data.info || {};
    wx.navigateTo({ url: '/pages/staff/renew-card/renew-card?id=' + this.data.id + '&expire=' + (info.expireDate || '') + '&total=' + (info.totalTimes || 0) + '&used=' + (info.usedTimes || 0) });
  },


  toggleStatus: function() {
    var that = this;
    var next = Number((this.data.info || {}).status) === 1 ? 0 : 1;
    wx.showModal({
      title: next === 1 ? '启用客户' : '停用客户',
      content: '确定' + (next === 1 ? '启用' : '停用') + '该客户吗？',
      success: async function(res) {
        if (!res.confirm) return;
        try { await api.updateCustomerStatus(that.data.id, next); wx.showToast({ title: next === 1 ? '已启用' : '已停用', icon: 'success' }); that.load(that.data.id); }
        catch(e) { console.error('[客户状态更新失败]', e); errorUtil.modal('客户状态更新失败', e, '客户状态更新失败'); }
      }
    });
  },
  goPhones: function() { wx.navigateTo({ url: '/pages/staff/phones/phones?id=' + this.data.id }); },
  goFollowUp: function() { wx.navigateTo({ url: '/pages/staff/follow-up/follow-up?id=' + this.data.id }); },
  goVisitCheck: function() { wx.navigateTo({ url: '/pages/staff/visit-check/visit-check?id=' + this.data.id }); },
  goGlassesRecord: function() { wx.navigateTo({ url: '/pages/staff/glasses-record/glasses-record?id=' + this.data.id }); },
  advanceGlassesStatus: function(e) {
    var dataset = e.currentTarget.dataset || {};
    var recordId = Number(dataset.id) || 0;
    var status = Number(dataset.next) || 0;
    if (!recordId || !status) return;
    this._confirmGlassesStatus(recordId, status, '正常推进');
  },
  chooseGlassesStatus: function(e) {
    var that = this;
    var dataset = e.currentTarget.dataset || {};
    var recordId = Number(dataset.id) || 0;
    var current = normalizeGlassesStatus(dataset.current);
    if (!recordId) return;
    var actions = GLASSES_STATUS_ACTIONS.filter(function(status) { return status !== current; });
    wx.showActionSheet({
      itemList: actions.map(function(status) { return GLASSES_STATUS_LABELS[status]; }),
      success: function(res) {
        var status = actions[res.tapIndex];
        that._confirmGlassesStatus(recordId, status, status === 6 || status === 7 ? '请填写原因' : '状态调整');
      }
    });
  },
  _confirmGlassesStatus: function(recordId, status, placeholder) {
    var that = this;
    var label = GLASSES_STATUS_LABELS[status] || '新状态';
    wx.showModal({
      title: '更新配镜进度',
      content: '确认将该配镜记录更新为「' + label + '」吗？\n可在下方填写备注，方便追踪。',
      editable: true,
      placeholderText: placeholder || '填写备注，可留空',
      success: async function(res) {
        if (!res.confirm) return;
        wx.showLoading({ title: '更新中' });
        try {
          await api.updateGlassesStatus(that.data.id, recordId, { status: status, remark: res.content || '' });
          wx.hideLoading();
          wx.showToast({ title: '已更新', icon: 'success' });
          that.load(that.data.id);
        } catch(err) {
          wx.hideLoading();
          console.error('[配镜进度更新失败]', err);
          errorUtil.modal('配镜进度更新失败', err, '配镜进度更新失败，请检查权限或状态');
        }
      }
    });
  },
  goActivityCard: function() { wx.navigateTo({ url: '/pages/staff/activity-card/activity-card?id=' + this.data.id + '&mode=create' }); },
  consumeActivityCard: function(e) {
    var card = e.currentTarget.dataset || {};
    wx.navigateTo({ url: '/pages/staff/activity-card/activity-card?id=' + this.data.id + '&mode=consume&cardId=' + card.id + '&cardName=' + encodeURIComponent(card.name || '活动卡') });
  },
  deleteAttachment: function(e) {
    var that = this;
    var aid = e.currentTarget.dataset.id;
    wx.showModal({ title: '删除附件', content: '确定删除该附件吗？', success: async function(res) {
      if (!res.confirm) return;
      try { await api.deleteAttachment(that.data.id, aid); wx.showToast({ title: '已删除', icon: 'success' }); that.load(that.data.id); }
      catch(err) { console.error('[删除附件失败]', err); errorUtil.modal('删除附件失败', err, '删除附件失败，请检查权限'); }
    }});
  },

  previewFile: function(e) {
    var url = e.currentTarget.dataset.url;
    var type = e.currentTarget.dataset.type || '';
    var app = getApp();
    var base = (app.globalData.apiBase || '').replace('/api/wx', '');
    var fullUrl = base + (url || '');

    if (type.indexOf('image') === 0) {
      wx.previewImage({ urls: [fullUrl], current: fullUrl });
    } else {
      wx.showLoading({ title: '加载中' });
      wx.downloadFile({
        url: fullUrl,
        timeout: 30000,
        success: function(res) {
          wx.hideLoading();
          wx.openDocument({ filePath: res.tempFilePath, showMenu: false });
        },
        fail: function() { wx.hideLoading(); wx.showToast({ title: '文件加载失败', icon: 'none' }); }
      });
    }
  },

  onPullDownRefresh: function() {
    return require('../../../utils/pull-refresh').run(this.load(this.data.id));
  },

  goPage: function(e) {
    var p = e.currentTarget.dataset.page;
    wx.reLaunch({ url: '/pages/' + p + '/' + p.split('/').pop() });
  },
});
