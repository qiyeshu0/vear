var authStorage = require('../../../utils/auth-storage');
var api = require('../utils/admin-api');
var localVersion = require('../../../utils/version');

function pad2(n) {
  n = Number(n) || 0;
  return n < 10 ? '0' + n : '' + n;
}

function decorateVerifyItem(item) {
  item = item || {};
  item._projectText = item.trainingProject === '退卡' ? '⚠ 退卡' : (item.trainingProject || '—');
  item._projectClass = item.trainingProject === '退卡' ? 'tag-red' : 'tag-blue';
  return item;
}

function decorateVisitItem(item) {
  item = item || {};
  item._recordText = item.verifyDescription || '保健';
  item._recordClass = Number(item.hasVerification) === 1 ? 'tag-green' : 'tag-blue';
  item._timeText = item.arrivalTime || '';
  return item;
}

function getMiniprogramVersion() {
  try {
    var account = wx.getAccountInfoSync();
    var mini = account && account.miniProgram || {};
    return {
      version: mini.version || localVersion.version,
      envVersion: mini.envVersion || 'develop'
    };
  } catch (e) {
    return { version: localVersion.version, envVersion: 'develop' };
  }
}

Page({
  data: {
    pageReady: true,
    loadError: '',
    greeting: '您好', roleLabel: '', currentDate: '',
    todayVerify: 0, totalCustomers: 0, lowTimes: 0, expired: 0,
    lowTimesList: [], expireSoonList: [], expiredList: [], todayVisitList: [], todayList: [],
    miniVersion: localVersion.version,
    compatibleSystem: localVersion.compatibleSystem,
    versionChannel: localVersion.channel
  },

  onShow: function() {
    if (!authStorage.getStaffToken()) {
      wx.reLaunch({ url: '/pages/login/login' });
      return;
    }
    this.setData({ pageReady: true, loadError: '' });
    var user = authStorage.getStaffUser() || {};
    var h = new Date().getHours();
    var g = h < 12 ? '早上好' : h < 14 ? '中午好' : h < 18 ? '下午好' : '晚上好';
    var r = {1:'超级管理员',2:'门店店长',3:'门店店员',4:'门店老板'};
    var d = new Date();
    var dateStr = d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
    var runtimeVersion = getMiniprogramVersion();
    this.setData({
      greeting: g + '，' + (user.username || user.realName || ''),
      roleLabel: r[user.role] || '',
      currentDate: dateStr,
      miniVersion: runtimeVersion.version,
      versionChannel: runtimeVersion.envVersion === 'release' ? '正式版' : runtimeVersion.envVersion === 'trial' ? '体验版' : '开发版',
      isAdmin: (Number(user.role) === 1),
      canApproveRevoke: authStorage.hasStaffPermission('record:revoke:approve'),
      canViewLogs: authStorage.hasStaffPermission('log:view'),
      canExportRecords: authStorage.hasStaffPermission('record:export'),
    });
    this.loadDashboard();
    if (authStorage.hasStaffPermission('record:revoke:approve')) this.loadPendingCount();
  },

  loadPendingCount: async function() {
    try {
      var list = await api.getPendingRevokes();
      this.setData({ pendingRevokeCount: (list || []).length });
    } catch(e) { console.error('[待审批数量加载失败]', e); }
  },

  loadDashboard: async function() {
    try {
      var d = await api.getDashboard();
      if (!d) return;
      this.setData({
        todayVerify: d.todayVerifyCount || 0,
        totalCustomers: d.totalCustomers || 0,
        lowTimes: d.warningSummary ? d.warningSummary.lowTimes || 0 : 0,
        expired: d.warningSummary ? d.warningSummary.expired || 0 : 0,
        lowTimesList: (d.lowTimesList || []).slice(0, 5),
        expireSoonList: (d.soonExpireList || []).slice(0, 5),
        expiredList: (d.expiredList || []).slice(0, 5),
        todayVisitList: (d.todayVisitList || []).slice(0, 10).map(decorateVisitItem)
      });
    } catch(e) { console.error('[首页看板加载失败]', e); this.setData({ loadError: '首页数据加载失败，请检查后端服务或网络设置' }); wx.showToast({ title: '首页数据加载失败', icon: 'none' }); }

    // 今日核销列表
    try {
      var t = await api.getTodayVerify();
      this.setData({ todayList: (t && t.list || []).slice(0, 10).map(decorateVerifyItem) });
    } catch(e) { console.error('[今日核销加载失败]', e); }
  },

  onPullDownRefresh: function() {
    var tasks = [this.loadDashboard()];
    if (authStorage.hasStaffPermission('record:revoke:approve')) tasks.push(this.loadPendingCount());
    return require('../../../utils/pull-refresh').run(Promise.all(tasks));
  },

  goVerify: function() { wx.reLaunch({ url: '/pages/staff/verify/verify' }); },
  goCustomers: function() { wx.reLaunch({ url: '/pages/staff/customers/customers' }); },
  goRecords: function() { wx.reLaunch({ url: '/pages/staff/records/records' }); },
  goApprovals: function() { wx.reLaunch({ url: '/pages/staff/approvals/approvals' }); },
  goLogs: function() { wx.reLaunch({ url: '/pages/staff/logs/logs' }); },
  goExport: function() { wx.reLaunch({ url: '/pages/staff/export-data/export-data' }); },
  goTodayRecords: function() { wx.reLaunch({ url: '/pages/staff/records/records?filter=today' }); },
  goVisitCustomer: function(e) {
    var id = Number(e.currentTarget.dataset.id || 0);
    if (id) wx.navigateTo({ url: '/pages/staff/detail/detail?id=' + id });
  },
  goLowTimes: function() {
    var ids = (this.data.lowTimesList || []).map(function(item) { return item.id; }).join(',');
    wx.reLaunch({ url: '/pages/staff/customers/customers?filter=lowTimes&ids=' + ids });
  },
  goExpired: function() {
    var ids = (this.data.expiredList || []).map(function(item) { return item.id; }).join(',');
    wx.reLaunch({ url: '/pages/staff/customers/customers?filter=expired&ids=' + ids });
  },
  doLogout: function() {
    var that = this;
    wx.showModal({
      title: '退出登录', content: '确定退出管理端吗？',
      success: function(r) {
        if (!r.confirm) return;
        authStorage.clearStaffSession();
        wx.reLaunch({ url: '/pages/login/login' });
      }
    });
  },

  switchToParent: function() {
    if (authStorage.getParentToken()) {
      wx.setStorageSync('loginMode', 'parent');
      wx.reLaunch({ url: '/pages/home/home' });
      return;
    }
    wx.removeStorageSync('loginMode');
    wx.reLaunch({ url: '/pages/login/login' });
  },

  goPage: function(e) {
    var p = e.currentTarget.dataset.page;
    wx.reLaunch({ url: '/pages/' + p + '/' + p.split('/').pop() });
  },
});
