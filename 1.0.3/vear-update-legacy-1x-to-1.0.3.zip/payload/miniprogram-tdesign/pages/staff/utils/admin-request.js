/**
 * 员工端 HTTP 请求（调 /api/* 管理后台接口）
 */
var authStorage = require('../../../utils/auth-storage');
var config = require('../../../utils/config');
var errorUtil = require('./error');
function isDebugEnv() { return config.getEnv() === 'dev'; }
function getBase() {
  var app = getApp();
  return (app.globalData.apiBase || '').replace('/api/wx', '');
}

function request(options) {
  return new Promise(function(resolve, reject) {
    var token = authStorage.getStaffToken();
    var url = getBase() + options.url;
    wx.request({
      url: url, method: options.method || 'GET', data: options.data || {},
      header: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
      timeout: 15000,
      success: function(res) {
        if (res.statusCode === 200) {
          var body = res.data;
          if (body.success !== false) {
            resolve(body.data != null ? body.data : body);
          } else {
            body._message = errorUtil.getErrorMessage(body, '请求失败');
            reject(body);
          }
        } else if (res.statusCode === 401) {
          authStorage.clearStaffSession();
          wx.showToast({ title: '登录已过期，请重新登录', icon: 'none' });
          wx.reLaunch({ url: '/pages/login/login' });
          reject(new Error('登录已过期'));
        } else if (res.statusCode === 403) {
          var forbidden = res.data || new Error('无操作权限');
          forbidden._message = errorUtil.getErrorMessage(forbidden, '无操作权限');
          reject(forbidden);
        } else {
          var serverErr = res.data || new Error('服务器错误(' + res.statusCode + ')');
          serverErr._message = errorUtil.getErrorMessage(serverErr, '服务器错误(' + res.statusCode + ')');
          reject(serverErr);
        }
      },
      fail: function(err) {
        var msg = (err && err.errMsg) || '';
        if (isDebugEnv()) console.error('[员工端请求失败]', url, msg);
        else console.error('[员工端请求失败]', msg);
        if (!isDebugEnv()) {
          if (msg.indexOf('timeout') >= 0) wx.showToast({ title: '请求超时，请稍后重试', icon: 'none' });
          else wx.showModal({ title: '网络连接失败', content: '暂时无法连接服务，请检查手机网络后重试。', showCancel: false });
          reject(err || new Error('网络异常'));
          return;
        }
        if (msg.indexOf('url not in domain list') >= 0 || msg.indexOf('url not in') >= 0) {
          wx.showModal({ title: '网络连接失败', content: '请在微信开发者工具中勾选“不校验合法域名”，或确认已配置正式 HTTPS 域名。', showCancel: false });
        } else if (msg.indexOf('refused') >= 0 || msg.indexOf('failed') >= 0 || msg.indexOf('CONNECTION') >= 0) {
          wx.showModal({ title: '无法连接服务器', content: '请确认后端服务已启动，当前请求：' + url, showCancel: false });
        } else if (msg.indexOf('timeout') >= 0) {
          wx.showToast({ title: '请求超时，请稍后重试', icon: 'none' });
        } else {
          wx.showToast({ title: '网络异常，请重试', icon: 'none' });
        }
        reject(err || new Error('网络异常'));
      }
    });
  });
}

module.exports = { request: request };
