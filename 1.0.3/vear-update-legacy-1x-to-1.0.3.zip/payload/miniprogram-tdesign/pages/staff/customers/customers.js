var authStorage = require('../../../utils/auth-storage');
var api = require('../utils/admin-api');

function decorateCustomer(item) {
  item = item || {};
  item._statusText = Number(item.status) === 1 ? '正常' : '停用';
  item._statusClass = Number(item.status) === 1 ? 'tag-green' : 'tag-red';
  item._projectText = item.trainingProject || '未开卡';
  item._timesText = (item.remainingTimes || 0) + '次';
  return item;
}

function emptyTextByFilter(filter) {
  if (filter === 'lowTimes') return '暂无次数不足客户';
  if (filter === 'expired') return '暂无已到期客户';
  return '暂无客户';
}

Page({
  data: { keyword: '', list: [], page: 1, hasMore: false, loading: false, loadError: '', _timer: 0, filter: '', emptyText: '暂无客户', canEdit: false },

  onLoad: function(options) {
    var user = authStorage.getStaffUser() || {};
    this.setData({ canEdit: authStorage.hasStaffPermission('customer:create') });
    var filter = options.filter || '';
    this.setData({ filter: filter, emptyText: emptyTextByFilter(filter) });
    if (filter === 'lowTimes') wx.setNavigationBarTitle({ title: '次数不足' });
    if (filter === 'expired') wx.setNavigationBarTitle({ title: '已到期' });
  },

  onShow: function() { this.search(1); },

  onReachBottom: function() {
    if (this.data.hasMore && !this.data.loading) this.search(this.data.page + 1);
  },

  onSearch: function(e) {
    var v = e.detail.value; this.setData({ keyword: v });
    clearTimeout(this.data._timer);
    var that = this;
    this.data._timer = setTimeout(function() { that.search(1); }, 400);
  },

  search: async function(page) {
    if (page > 1 && this.data.loading) return;
    this.setData({ loading: true, loadError: '' });
    try {
      var extra = {};
      if (this.data.filter === 'lowTimes') extra.alertType = 'lowTimes';
      if (this.data.filter === 'expired') extra.alertType = 'expired';
      var r = await api.getCustomers(page, this.data.keyword, '', extra);
      var raw = (r && r.list || []).map(decorateCustomer);
      var list = page === 1 ? raw : this.data.list.concat(raw);
      var hasMore = Boolean(r && (r.hasMore || (r.total && r.total > page * 15) || raw.length >= 15));
      this.setData({ list: list, page: page, hasMore: hasMore });
    } catch(e) {
      console.error('[客户列表加载失败]', e);
      this.setData({ loadError: '客户数据加载失败，请下拉或点击重试' });
    } finally {
      this.setData({ loading: false });
    }
  },

  onPullDownRefresh: function() {
    return require('../../../utils/pull-refresh').run(this.search(1));
  },

  retry: function() { this.search(1); },

  goAddCustomer: function() { wx.navigateTo({ url: '/pages/staff/add-customer/add-customer' }); },
  goDetail: function(e) { wx.navigateTo({ url: '/pages/staff/detail/detail?id=' + e.currentTarget.dataset.id }); },
  goPage: function(e) { var p = e.currentTarget.dataset.page; wx.reLaunch({ url: '/pages/' + p + '/' + p.split('/').pop() }); },
});
