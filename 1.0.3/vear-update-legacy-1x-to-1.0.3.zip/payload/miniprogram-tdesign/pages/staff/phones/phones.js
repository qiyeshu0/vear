var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');

function decoratePhone(item) {
  item = item || {};
  item._statusText = Number(item.status) === 1 ? '启用' : '停用';
  item._statusClass = Number(item.status) === 1 ? 'tag-blue' : 'tag-red';
  item._toggleText = Number(item.status) === 1 ? '停用' : '启用';
  item._canSetPrimary = !item.isPrimary && Number(item.status) === 1;
  item._relationText = item.relationName || '—';
  return item;
}
Page({
  data:{id:0,list:[],phone:'',relationName:'',isPrimary:false,loading:false},
  onLoad:function(o){this.setData({id:Number(o.id)||0}); if(!this.data.id){wx.showToast({title:'客户参数错误',icon:'none'});return;} this.load();},
  onInput:function(e){var d={};d[e.currentTarget.dataset.key]=e.detail.value;this.setData(d);},
  onPrimary:function(e){this.setData({isPrimary:Array.isArray(e.detail.value) && e.detail.value.length > 0});},
  load:async function(){try{var list=await api.getCustomerPhones(this.data.id);this.setData({list:(list||[]).map(decoratePhone)});}catch(e){console.error('[手机号加载失败]',e);}},
  add:async function(){var phone=this.data.phone.trim(); if(phone.length!==11)return wx.showToast({title:'请输入11位手机号',icon:'none'}); this.setData({loading:true}); try{await api.addCustomerPhone(this.data.id,{phone:phone,relationName:this.data.relationName,isPrimary:this.data.isPrimary}); wx.showToast({title:'已保存',icon:'success'}); this.setData({phone:'',relationName:'',isPrimary:false}); this.load();}catch(e){console.error('[手机号保存失败]',e); errorUtil.modal('手机号保存失败', e, '手机号保存失败，请检查号码是否重复');}finally{this.setData({loading:false});}},
  setPrimary:function(e){var pid=e.currentTarget.dataset.id; var that=this; wx.showModal({title:'设为主手机号',content:'确定将该号码设为主手机号吗？',success:async function(r){if(!r.confirm)return;try{await api.setPhonePrimary(that.data.id,pid);wx.showToast({title:'已设置',icon:'success'});that.load();}catch(e){console.error('[设置主手机号失败]', e); errorUtil.modal('设置主手机号失败', e, '设置主手机号失败');}}});},
  toggle:function(e){var pid=e.currentTarget.dataset.id,status=Number(e.currentTarget.dataset.status)===1?0:1;var that=this;api.updatePhoneStatus(this.data.id,pid,status).then(function(){wx.showToast({title:status===1?'已启用':'已停用',icon:'success'});that.load();}).catch(function(err){console.error('[手机号状态更新失败]',err); errorUtil.modal('手机号状态更新失败', err, '手机号状态更新失败');});},
  onPullDownRefresh:function(){return require('../../../utils/pull-refresh').run(this.load());}
});
