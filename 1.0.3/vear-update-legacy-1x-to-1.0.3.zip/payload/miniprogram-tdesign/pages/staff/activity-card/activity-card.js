function pad2(n) { n = Number(n) || 0; return n < 10 ? '0' + n : '' + n; }
var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');

function today() {
  var d = new Date();
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
}

Page({
  data: {
    id: 0,
    mode: 'create',
    templateList: [],
    templateIndex: -1,
    selectedTemplateName: '选择活动模板',
    cardId: 0,
    cardName: '',
    trainingProject: '',
    totalTimes: '',
    salePrice: '',
    openCardDate: '',
    expireDate: '',
    expireDateLabel: '可不填',
    quantity: 1,
    remark: '',
    submitText: '开活动卡',
    submitting: false
  },

  onLoad: function(o) {
    var mode = o.mode || 'create';
    this.setData({
      id: Number(o.id) || 0,
      mode: mode,
      cardId: Number(o.cardId) || 0,
      cardName: decodeURIComponent(o.cardName || ''),
      openCardDate: today(),
      submitText: mode === 'consume' ? '确认核销' : '开活动卡'
    });
    if (!this.data.id) wx.showToast({ title: '客户参数错误', icon: 'none' });
    if (mode === 'create') this.loadTemplates();
  },

  loadTemplates: async function() {
    try {
      var t = await api.getCardTemplates();
      this.setData({ templateList: (t || []).filter(function(x) { return x.isPromotion; }) });
    } catch (e) {
      console.error('[活动卡模板加载失败]', e);
    }
  },

  onInput: function(e) {
    var key = e.currentTarget.dataset.key;
    var d = {};
    d[key] = e.detail.value;
    if (key === 'expireDate') d.expireDateLabel = e.detail.value || '可不填';
    this.setData(d);
  },

  onTemplateChange: function(e) {
    var idx = Number(e.detail.value);
    var t = this.data.templateList[idx] || {};
    this.setData({
      templateIndex: idx,
      selectedTemplateName: t.cardName || '选择活动模板',
      cardName: t.cardName || '',
      trainingProject: t.trainingProject || '',
      totalTimes: t.defaultTimes || '',
      salePrice: (t.priceOptions && t.priceOptions[0]) || ''
    });
  },

  onPullDownRefresh: function() {
    var task = this.data.mode === 'create' ? this.loadTemplates() : undefined;
    return require('../../../utils/pull-refresh').run(task);
  },

  submit: async function() {
    if (!this.data.id) return wx.showToast({ title: '客户参数错误', icon: 'none' });

    if (this.data.mode === 'consume') {
      if (!this.data.cardId) return wx.showToast({ title: '卡片参数错误', icon: 'none' });
      if ((Number(this.data.quantity) || 0) <= 0) return wx.showToast({ title: '扣减次数需大于0', icon: 'none' });
    } else {
      if (!this.data.cardName.trim()) return wx.showToast({ title: '请填写活动名称', icon: 'none' });
      if (!this.data.trainingProject.trim()) return wx.showToast({ title: '请填写项目', icon: 'none' });
      if ((Number(this.data.totalTimes) || 0) <= 0) return wx.showToast({ title: '次数需大于0', icon: 'none' });
    }

    this.setData({ submitting: true });
    try {
      if (this.data.mode === 'consume') {
        await api.consumeActivityCard(this.data.id, this.data.cardId, {
          quantity: Number(this.data.quantity) || 1,
          remark: this.data.remark
        });
        wx.showToast({ title: '已核销', icon: 'success' });
      } else {
        await api.createActivityCard(this.data.id, {
          cardTemplateId: (this.data.templateList[this.data.templateIndex] || {}).id,
          cardName: this.data.cardName,
          trainingProject: this.data.trainingProject,
          totalTimes: Number(this.data.totalTimes) || 0,
          salePrice: this.data.salePrice,
          openCardDate: this.data.openCardDate,
          expireDate: this.data.expireDate,
          remark: this.data.remark
        });
        wx.showToast({ title: '已开活动卡', icon: 'success' });
      }
      setTimeout(function() { wx.navigateBack(); }, 800);
    } catch (e) {
      console.error('[活动卡操作失败]', e);
      errorUtil.modal(this.data.mode === 'consume' ? '活动卡核销失败' : '活动卡开卡失败', e, '活动卡操作失败，请检查模板、次数或客户状态');
    } finally {
      this.setData({ submitting: false });
    }
  }
});
