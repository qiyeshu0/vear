/**
 * 静默续订——仅对勾过「总是保持」的用户生效，不弹窗
 */
var publicConfig = require('./public-config');
var NOTIFY_SCENES = publicConfig.NOTIFY_SCENES;
var renewing = false;
var lastRenewAt = 0;
var RENEW_COOLDOWN_MS = 1000;

function isDevelopEnv() {
  try {
    var info = typeof wx.getAccountInfoSync === 'function' ? wx.getAccountInfoSync() : null;
    return Boolean(info && info.miniProgram && info.miniProgram.envVersion === 'develop');
  } catch (e) {
    return false;
  }
}

var debugEnabled = isDevelopEnv();

function debugLog(message, data) {
  if (!debugEnabled || typeof console === 'undefined') return;
  if (data === undefined) console.log('[订阅续订调试] ' + message);
  else console.log('[订阅续订调试] ' + message, data);
}

function getDefaultScenes() {
  // 默认只处理客户高频、强相关的两个场景，避免一次性申请过多模板造成体验打扰。
  return [NOTIFY_SCENES.VERIFY_SUCCESS, NOTIFY_SCENES.GLASSES_STATUS];
}

function silentRenew(refreshed, scenes, source) {
  var app = getApp();
  var tmplIds = publicConfig.getNotificationTemplates(scenes || getDefaultScenes());
  var triggerSource = source || '未标记入口';
  debugLog('收到触发：' + triggerSource, { templateCount: tmplIds.length });
  if (!tmplIds.length) {
    if (!refreshed && app.refreshPublicConfig) {
      debugLog('本地没有模板，正在刷新后台配置');
      app.refreshPublicConfig(function() { silentRenew(true, scenes, triggerSource); });
    } else {
      debugLog('未找到可用模板，本次不续订');
    }
    return;
  }

  var now = Date.now();
  if (renewing) {
    debugLog('已有续订请求处理中，本次忽略');
    return;
  }
  if (now - lastRenewAt < RENEW_COOLDOWN_MS) {
    debugLog('处于 ' + (RENEW_COOLDOWN_MS / 1000) + ' 秒冷却期，本次忽略', { remainingMs: RENEW_COOLDOWN_MS - (now - lastRenewAt) });
    return;
  }
  renewing = true;
  lastRenewAt = now;
  debugLog('开始检查微信长期订阅状态');

  // 查用户是否勾了「总是保持以上选择」
  if (typeof wx.getSetting === 'function') {
    wx.getSetting({
      withSubscriptions: true,
      success: function(res) {
        var settings = res.subscriptionsSetting || {};
        var itemSettings = settings.itemSettings || {};
        var accepted = tmplIds.filter(function(id) { return itemSettings[id] === 'accept'; });
        debugLog('长期授权检查完成', { acceptedCount: accepted.length, templateCount: tmplIds.length });
        if (accepted.length) {
          // 已勾「总是保持」→ 静默续订，不弹窗
          debugLog('调用 wx.requestSubscribeMessage 静默续订', { requestCount: accepted.length });
          try {
            wx.requestSubscribeMessage({
              tmplIds: accepted,
              complete: function(result) {
                renewing = false;
                debugLog('微信续订接口完成', { errMsg: result && result.errMsg ? result.errMsg : 'complete' });
              }
            });
          } catch (error) {
            renewing = false;
            debugLog('微信续订接口调用异常', { message: error && error.message ? error.message : String(error || '') });
          }
        } else {
          renewing = false;
          debugLog('用户未对模板选择“总是保持”，本次不续订');
        }
        // 没勾 → 什么都不做
      },
      fail: function(error) {
        renewing = false;
        debugLog('读取微信订阅设置失败', { errMsg: error && error.errMsg ? error.errMsg : 'getSetting fail' });
      }
    });
  } else {
    renewing = false;
    debugLog('当前基础库不支持 wx.getSetting');
  }
}

module.exports = {
  silentRenew: silentRenew,
  getDefaultScenes: getDefaultScenes,
  isDebugEnabled: function() { return debugEnabled; }
};
