module.exports = {
  version: '1.0.1',
  compatibleSystem: '1.0.x',
  channel: '正式版'
};
