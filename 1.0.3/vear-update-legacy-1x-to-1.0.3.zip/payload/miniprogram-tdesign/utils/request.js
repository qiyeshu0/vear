/**
 * HTTP 请求封装
 */
var authStorage = require('./auth-storage');
var config = require('./config');

// 默认 API 地址（开发时用）
var DEFAULT_API_BASE = config.getConfig().apiBase;

function getApiBase() {
  try {
    var app = getApp();
    if (app && app.globalData && app.globalData.apiBase) {
      return app.globalData.apiBase;
    }
  } catch (e) {
    console.warn('[配置读取失败]', e);
  }
  return DEFAULT_API_BASE;
}

function isDebugEnv() {
  return config.getEnv() === 'dev';
}

function formatBusinessError(message, errorCode) {
  if (!errorCode || !isDebugEnv()) return message;
  return message + '\n错误码：' + errorCode;
}

function sanitizeBusinessError(body) {
  if (isDebugEnv() || !body || !body.data || typeof body.data !== 'object') return body;
  var safeBody = Object.assign({}, body);
  delete safeBody.errorCode;
  safeBody.data = Object.assign({}, body.data);
  delete safeBody.data.errorCode;
  return safeBody;
}

function request(options) {
  return new Promise(function (resolve, reject) {
    var token = authStorage.getParentToken();
    var url = getApiBase() + options.url;

    wx.request({
      url: url,
      method: options.method || 'GET',
      data: options.data || {},
      timeout: Number(options.timeout || 15000),
      header: {
        'Content-Type': 'application/json',
        'Authorization': token ? 'Bearer ' + token : ''
      },
      success: function (res) {
        if (res.statusCode === 200) {
          var body = res.data;
          if (body.success !== false) {
            resolve(body.data != null ? body.data : body);
          } else {
            wx.showToast({ title: body.message || '请求失败', icon: 'none' });
            reject(sanitizeBusinessError(body));
          }
        } else if (res.statusCode === 401) {
          authStorage.clearParentSession();
          wx.reLaunch({ url: '/pages/login/login' });
          reject(new Error('登录已过期'));
        } else if (res.statusCode === 429) {
          wx.showToast({ title: '请求太频繁，请稍后', icon: 'none' });
          reject(new Error('rate limited'));
        } else {
          var body = res.data || {};
          var msg = body.message || '服务器错误(' + res.statusCode + ')';
          var errorCode = body.data && body.data.errorCode ? body.data.errorCode : '';
          if (isDebugEnv()) {
            console.error('[接口错误]', res.statusCode, url, body);
          } else {
            console.error('[接口错误]', res.statusCode, msg);
          }
          if (res.statusCode === 400) {
            wx.showModal({
              title: '请求失败',
              content: formatBusinessError(msg, errorCode),
              showCancel: false
            });
          } else {
            wx.showToast({ title: msg, icon: 'none' });
          }
          reject(sanitizeBusinessError(body));
        }
      },
      fail: function (err) {
        var msg = (err && err.errMsg) || (err && err.message) || '';
        if (isDebugEnv()) console.error('[请求失败]', url, msg);
        else console.error('[请求失败]', msg);

        if (!isDebugEnv()) {
          if (msg.indexOf('timeout') >= 0) {
            wx.showToast({ title: '请求超时，请稍后重试', icon: 'none' });
          } else {
            wx.showModal({
              title: '网络连接失败',
              content: '暂时无法连接服务，请检查手机网络后重试。',
              showCancel: false
            });
          }
          reject(err);
          return;
        }

        // 域名校验失败
        if (msg.indexOf('url not in domain list') >= 0 || msg.indexOf('url not in') >= 0) {
          wx.showModal({
            title: '网络连接失败',
            content: '请在微信开发者工具中：\n右上角「详情」→「本地设置」→ 勾选「不校验合法域名」',
            showCancel: false
          });
        // 连接被拒绝 = 后端没启动
        } else if (msg.indexOf('refused') >= 0 || msg.indexOf('failed') >= 0 || msg.indexOf('CONNECTION') >= 0) {
          wx.showModal({
            title: '无法连接服务器',
            content: '请确认：\n1. 后端已执行 npm start\n2. 端口 3000 未被占用\n\n当前请求: ' + url,
            showCancel: false
          });
        } else if (msg.indexOf('timeout') >= 0) {
          wx.showToast({ title: '请求超时，请检查网络', icon: 'none' });
        } else {
          wx.showModal({
            title: '网络请求失败',
            content: '请确认：\n1. 后端已启动\n2. 域名校验已关闭\n\n错误: ' + (msg || '未知') + '\n请求: ' + url,
            showCancel: false
          });
        }
        reject(err);
      }
    });
  });
}

module.exports = { request: request };
