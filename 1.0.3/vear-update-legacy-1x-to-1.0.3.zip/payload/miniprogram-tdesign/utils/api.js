/**
 * API 接口定义
 */
const { request } = require('./request');
var config = require('./config');

module.exports = {
  // 员工登录（直调 /api/auth/login）
  staffLogin: function(username, password) {
    var app = getApp();
    var base = (app.globalData.apiBase || '').replace('/api/wx', '');
    return new Promise(function(resolve, reject) {
      wx.request({
        url: base + '/api/auth/login',
        method: 'POST',
        data: { username: username, password: password },
        header: { 'Content-Type': 'application/json' },
        timeout: 15000,
        success: function(res) {
          if (res.statusCode === 200 && res.data && res.data.success !== false) {
            resolve(res.data.data);
          } else {
            wx.showToast({ title: (res.data && res.data.message) || '登录失败', icon: 'none' });
            reject(res.data);
          }
        },
        fail: function(err) {
          var msg = (err && err.errMsg) || '';
          if (config.getEnv() === 'dev') console.error('[员工登录失败]', base + '/api/auth/login', msg);
          else console.error('[员工登录失败]', msg);
          if (config.getEnv() !== 'dev') {
            if (msg.indexOf('timeout') >= 0) wx.showToast({ title: '登录超时，请重试', icon: 'none' });
            else wx.showModal({ title: '登录连接失败', content: '暂时无法连接服务，请检查手机网络后重试。', showCancel: false });
            reject(err);
            return;
          }
          if (msg.indexOf('url not in domain list') >= 0 || msg.indexOf('url not in') >= 0) {
            wx.showModal({ title: '登录连接失败', content: '请在开发者工具中勾选“不校验合法域名”，或使用已备案 HTTPS 正式域名。', showCancel: false });
          } else if (msg.indexOf('refused') >= 0 || msg.indexOf('failed') >= 0 || msg.indexOf('CONNECTION') >= 0) {
            wx.showModal({ title: '无法连接服务器', content: '请确认后端服务已启动。当前地址：' + base + '/api/auth/login', showCancel: false });
          } else if (msg.indexOf('timeout') >= 0) {
            wx.showToast({ title: '登录超时，请重试', icon: 'none' });
          } else {
            wx.showToast({ title: '网络异常', icon: 'none' });
          }
          reject(err);
        }
      });
    });
  },

  // 静默登录 → 返回已绑账号列表
  silentLogin(code) {
    return request({ url: '/silent-login', method: 'POST', data: { code } });
  },
  // 选账号登录
  selectAccount(code, customerId) {
    return request({ url: '/select-account', method: 'POST', data: { code, customerId } });
  },
  // 手机绑定
  bindPhone(code, phone) {
    return request({ url: '/bind-phone', method: 'POST', data: { code, phone } });
  },
  // 解绑
  unbindAccount(code, customerId) {
    return request({ url: '/unbind', method: 'POST', data: { code, customerId } });
  },
  // 微信一键登录（授权手机号）
  wechatLogin(code, phoneCode) {
    return request({ url: '/wechat-login', method: 'POST', data: { code, phoneCode } });
  },

  // 档案
  getProfile() {
    return request({ url: '/profile' });
  },

  // 核销记录
  getVerifyRecords(pageNum = 1, pageSize = 20) {
    return request({ url: '/verify-records', data: { pageNum, pageSize } });
  },

  // 到店检查
  getVisitChecks(pageNum = 1, pageSize = 20) {
    return request({ url: '/visit-checks', data: { pageNum, pageSize } });
  },

  // 续卡记录
  getRenewals(pageNum = 1, pageSize = 20) {
    return request({ url: '/renewals', data: { pageNum, pageSize } });
  },

  // 配镜记录
  getGlassesRecords(pageNum = 1, pageSize = 20) {
    return request({ url: '/glasses-records', data: { pageNum, pageSize } });
  },

  // 视力档案
  getVisionReport(limit = 20) {
    return request({ url: '/vision-report', data: { limit } });
  }
};
