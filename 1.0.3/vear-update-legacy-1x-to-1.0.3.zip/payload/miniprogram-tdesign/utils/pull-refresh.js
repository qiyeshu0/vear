var STOP_TIMEOUT = 15000;

function stop() {
  try { wx.stopPullDownRefresh(); } catch (e) {}
}

function run(task) {
  var timer = setTimeout(stop, STOP_TIMEOUT);
  var result;
  try {
    result = typeof task === 'function' ? task() : task;
  } catch (error) {
    clearTimeout(timer);
    stop();
    return Promise.resolve(undefined);
  }

  return Promise.resolve(result).then(function(value) {
    clearTimeout(timer);
    stop();
    return value;
  }, function(error) {
    clearTimeout(timer);
    stop();
    return undefined;
  });
}

module.exports = {
  run: run,
  stop: stop
};
