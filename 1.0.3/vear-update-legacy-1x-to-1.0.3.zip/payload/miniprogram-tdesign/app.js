var authStorage = require('./utils/auth-storage');
var config = require('./utils/config');
var publicConfig = require('./utils/public-config');
var initialPublicConfig = publicConfig.getPublicConfig();
App({
  onLaunch() {
    this.loadCachedPublicConfig();
    this.refreshPublicConfig();
    var token = authStorage.getParentToken();
    var mode = wx.getStorageSync('loginMode') || 'parent';
    if (token) {
      this.globalData.token = token;
      this.globalData.isLogin = true;
    }
    // 员工模式不静默登录（用token硬验证，不自续）
    // 家长模式才静默续期（openid → select-account → 刷新token）
    if (mode !== 'staff') {
      this.silentLogin();
    }
  },

  loadCachedPublicConfig() {
    publicConfig.applyToGlobalData(this, publicConfig.getPublicConfig());
  },

  refreshPublicConfig(callback) {
    var that = this;
    publicConfig.refreshPublicConfig(function(next) {
      if (next) publicConfig.applyToGlobalData(that, next);
      if (typeof callback === 'function') callback(next);
    });
  },

  silentLogin() {
    var that = this;
    var isDev = config.getEnv() === 'dev';
    wx.login({
      success: function(res) {
        if (!res.code) return;
        wx.request({
          url: that.globalData.apiBase + '/silent-login',
          method: 'POST',
          data: { code: res.code },
          timeout: 12000,
          success: function(result) {
            var data = result.data;
            if (result.statusCode !== 200 || (data && data.success === false)) {
              if (isDev) console.warn('[静默登录未完成]', result.statusCode, data && data.message ? data.message : data);
              return;
            }
            if (data && data.success !== false && data.data) {
              var d = data.data;
              if (d.needBind) {
                // 未绑定账号，保持登录页
              } else if (d.accounts && d.accounts.length === 1) {
                // 只有1个 → 直接自动登录
                that._autoLogin(d.accounts[0]);
              } else if (d.accounts && d.accounts.length > 1) {
                // 多个 → 存列表，登录页选择
                wx.setStorageSync('wx_accounts', d.accounts);
              }
            }
          },
          fail: function(err) {
            if (isDev) console.warn('[静默登录请求失败]', err && err.errMsg ? err.errMsg : err);
          }
        });
      },
      fail: function(err) {
        if (isDev) console.warn('[微信登录凭证获取失败]', err && err.errMsg ? err.errMsg : err);
      }
    });
  },

  _autoLogin(account) {
    var that = this;
    var isDev = config.getEnv() === 'dev';
    wx.login({
      success: function(res) {
        if (!res.code) return;
        wx.request({
          url: that.globalData.apiBase + '/select-account',
          method: 'POST',
          data: { code: res.code, customerId: account.id },
          timeout: 12000,
          success: function(result) {
            var data = result.data;
            if (result.statusCode !== 200 || (data && data.success === false)) {
              if (isDev) console.warn('[自动切换账号登录未完成]', result.statusCode, data && data.message ? data.message : data);
              return;
            }
            if (data && data.success !== false && data.data) {
              var d = data.data;
              authStorage.setParentSession(d.accessToken, d.customer);
              authStorage.clearLegacyMixedSession();
              wx.setStorageSync('wx_bound', true);
              that.globalData.token = d.accessToken;
              that.globalData.isLogin = true;
              that.globalData.customerInfo = d.customer;
              var pages = getCurrentPages();
              var current = pages && pages.length ? pages[pages.length - 1] : null;
              if (current && current.route === 'pages/login/login') {
                wx.reLaunch({ url: '/pages/home/home' });
              }
            }
          },
          fail: function(err) {
            if (isDev) console.warn('[自动切换账号请求失败]', err && err.errMsg ? err.errMsg : err);
          }
        });
      },
      fail: function(err) {
        if (isDev) console.warn('[微信登录凭证获取失败]', err && err.errMsg ? err.errMsg : err);
      }
    });
  },

  globalData: {
    token: '',
    isLogin: false,
    customerInfo: null,
    env: config.getEnv(),
    apiBase: config.getConfig().apiBase,
    publicConfig: publicConfig.getPublicConfig(),
    notificationTemplates: initialPublicConfig.notificationTemplates,
    systemTitle: initialPublicConfig.system.name,
    systemSubtitle: initialPublicConfig.system.subtitle,
    features: initialPublicConfig.features,
    homeConfig: initialPublicConfig.home,
    enableStaffHiddenEntry: initialPublicConfig.features.enableStaffHiddenEntry,
    subscribeTmplId: initialPublicConfig.subscribeTmplId,
    glassesSubscribeTmplId: initialPublicConfig.glassesSubscribeTmplId
  }
});
