const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");
const { pool } = require("../config/db");
const { createTables } = require("../install/schema");
const { sendSuccess, sendFail } = require("../utils/response");
const { writeOperationLog } = require("../utils/operation-log");
const { ensurePermissionTables } = require("../utils/permission");
const { ensureSmsSchema } = require("../services/sms.service");
const { ensureInternalSystemTables } = require("../utils/internal-schema");

const BACKUP_FILE_TYPE = "vision-verify-backup";
const ATTACHMENT_BACKUP_FILE_TYPE = "vision-verify-attachment-backup";
const PROJECT_BACKUP_FILE_TYPE = "vision-verify-project-backup";
const BACKUP_VERSION = 2;
const BACKUP_DB_QUERY_TIMEOUT = Number(process.env.BACKUP_DB_QUERY_TIMEOUT || "60000");
const BACKUP_TYPES = new Set(["database", "attachments", "full", "project"]);
const ENVIRONMENT_LOCAL_TABLES = new Set([
  "system_seed_history",
  "system_update_history",
  "schema_migrations",
  "user_sessions",
]);

const BACKEND_ROOT = path.join(__dirname, "..", "..");
const APP_ROOT = path.resolve(BACKEND_ROOT, "..");
const UPLOAD_ROOT = path.join(BACKEND_ROOT, "src", "uploads", "customer_attach");
const INSTALL_LOCK_FILE = path.join(BACKEND_ROOT, ".installed");
const BACKUP_ROOT = path.join(BACKEND_ROOT, "backups");
const AUTO_BACKUP_CONFIG_FILE = path.join(BACKEND_ROOT, "data-center-backup.config.json");

// 优先按业务依赖顺序备份/恢复；实际备份时还会自动补上当前库里存在的新表，避免后续新增功能漏备份。
const KNOWN_TABLE_ORDER = [
  "stores",
  "users",
  "user_registrations",
  "permissions",
  "permission_templates",
  "user_permissions",
  "training_projects",
  "card_templates",
  "customers",
  "customer_phones",
  "wx_user_bindings",
  "customer_cards",
  "customer_eye_profiles",
  "customer_attachments",
  "verify_records",
  "customer_visits",
  "customer_visit_verifications",
  "revoke_requests",
  "customer_card_usage_logs",
  "refund_records",
  "customer_renewals",
  "customer_follow_ups",
  "customer_visit_checks",
  "customer_glasses_records",
  "customer_glasses_status_logs",
  "wx_reservations",
  "notification_queue",
  "sms_config",
  "sms_templates",
  "sms_tasks",
  "sms_records",
  "customer_sms_preferences",
  "system_settings",
  "external_api_keys",
  "external_api_key_logs",
  "user_notification_states",
  "user_sessions",
  "operation_logs",
];
const CLEAR_ONLY_TABLES = ["user_sessions"];

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function ensureUploadRoot() {
  ensureDir(UPLOAD_ROOT);
}

function ensureBackupRoot() {
  ensureDir(BACKUP_ROOT);
}

function readInstallInfo() {
  if (!fs.existsSync(INSTALL_LOCK_FILE)) return null;
  try {
    return JSON.parse(fs.readFileSync(INSTALL_LOCK_FILE, "utf8"));
  } catch {
    return null;
  }
}

function toDateTimeString(value) {
  if (!value) return null;
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString();
}

function pad(value) {
  return String(value).padStart(2, "0");
}

function buildStamp(date = new Date()) {
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
}

function formatBytes(value) {
  const size = Number(value || 0);
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  if (size < 1024 * 1024 * 1024) return `${(size / 1024 / 1024).toFixed(1)} MB`;
  return `${(size / 1024 / 1024 / 1024).toFixed(1)} GB`;
}

function buildBackupFileName(type = "full", ext = "vvbak") {
  return `vision-verify-${type}-${buildStamp()}.${ext}`;
}

function getAttachmentRelativePath(filePath) {
  const cleaned = String(filePath || "").replace(/^\/+/, "").replace(/\\/g, "/");
  if (cleaned.startsWith("uploads/customer_attach/")) return cleaned;
  if (cleaned.startsWith("customer_attach/")) return `uploads/${cleaned}`;
  return `uploads/customer_attach/${path.basename(cleaned)}`;
}

function getAttachmentAbsolutePath(filePath) {
  const relativePath = getAttachmentRelativePath(filePath);
  return path.join(BACKEND_ROOT, "src", relativePath);
}

function addJsonFileToZip(zip, entryName, payload) {
  zip.addFile(entryName, Buffer.from(JSON.stringify(payload, null, 2), "utf8"));
}

function queryLong(connection, sql, params = []) {
  return connection.query({ sql, timeout: BACKUP_DB_QUERY_TIMEOUT }, params);
}

function readZipJson(zip, entryName, defaultValue) {
  const entry = zip.getEntry(entryName);
  if (!entry) return defaultValue;
  return JSON.parse(zip.readAsText(entry));
}

function ensureBackupFile(req) {
  if (!req.file || !req.file.buffer) throw new Error("请上传备份文件");
}

async function ensureSupplementTables() {
  await createTables(pool);
  await ensurePermissionTables();
  await ensureSmsSchema();
  await ensureInternalSystemTables(pool);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS revoke_requests (
      id int NOT NULL AUTO_INCREMENT,
      verify_record_id int NOT NULL,
      requested_by int NOT NULL DEFAULT 0,
      requested_by_name varchar(100) DEFAULT NULL,
      reason varchar(500) DEFAULT NULL,
      status tinyint NOT NULL DEFAULT 0 COMMENT '0待审批 1通过 2拒绝',
      reviewed_by int DEFAULT NULL,
      reviewed_by_name varchar(100) DEFAULT NULL,
      review_note varchar(500) DEFAULT NULL,
      created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_revoke_requests_record (verify_record_id),
      KEY idx_revoke_requests_status (status),
      KEY idx_revoke_requests_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
}

function getTransferableTableNames(tableNames = []) {
  return tableNames.filter((name) => !ENVIRONMENT_LOCAL_TABLES.has(String(name)));
}

async function getExistingTables(connection) {
  const [rows] = await connection.query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
  const tableNames = rows
    .map((row) => Object.values(row)[0])
    .filter(Boolean)
    .map(String);
  const ordered = [];
  const seen = new Set();
  for (const name of KNOWN_TABLE_ORDER) {
    if (tableNames.includes(name)) {
      ordered.push(name);
      seen.add(name);
    }
  }
  for (const name of tableNames.sort()) {
    if (!seen.has(name)) ordered.push(name);
  }
  return ordered;
}

async function getTableColumns(connection, tableName) {
  const [columns] = await connection.query(`SHOW FULL COLUMNS FROM \`${tableName}\``);
  return columns
    .filter((column) => !String(column.Extra || "").toLowerCase().includes("generated"))
    .map((column) => column.Field);
}

async function getTableCount(connection, tableName) {
  const [[row]] = await connection.query(`SELECT COUNT(*) AS total FROM \`${tableName}\``);
  return Number(row.total || 0);
}

async function getTableRows(connection, tableName, columns) {
  if (!columns.length) return [];
  const columnSql = columns.map((column) => `\`${column}\``).join(", ");
  const [rows] = await connection.query(`SELECT ${columnSql} FROM \`${tableName}\` ORDER BY ${columns.includes("id") ? "`id` ASC" : "1 ASC"}`);
  return rows;
}

async function buildAttachmentSummary(connection, sampleLimit = 20) {
  ensureUploadRoot();
  const tables = await getExistingTables(connection);
  if (!tables.includes("customer_attachments")) {
    return { total: 0, totalRecords: 0, existing: 0, existingFiles: 0, missing: 0, missingFiles: 0, orphan: 0, orphanFiles: 0, examples: [], missingExamples: [], missingSamples: [], list: [], items: [] };
  }

  const [rows] = await connection.query(`
    SELECT a.id, a.customer_id, a.file_name, a.file_path, a.created_at, c.child_name
    FROM customer_attachments a
    LEFT JOIN customers c ON c.id = a.customer_id
    ORDER BY a.id DESC
  `);

  let existingFiles = 0;
  let missingFiles = 0;
  const missingSamples = [];
  const items = [];
  const mappedFileNames = new Set();

  for (const row of rows) {
    const basename = path.basename(row.file_path || row.file_name || "");
    if (basename) mappedFileNames.add(basename);
    const absolutePath = getAttachmentAbsolutePath(row.file_path);
    if (fs.existsSync(absolutePath)) {
      existingFiles += 1;
      items.push({ id: Number(row.id || 0), customerId: Number(row.customer_id || 0), customerName: row.child_name || "", fileName: row.file_name || basename, filePath: row.file_path || "", status: "ok", remark: "附件文件存在", updatedAt: toDateTimeString(row.created_at) });
    } else {
      missingFiles += 1;
      items.push({ id: Number(row.id || 0), customerId: Number(row.customer_id || 0), customerName: row.child_name || "", fileName: row.file_name || basename, filePath: row.file_path || "", status: "missing", remark: "数据库记录存在，但文件缺失", updatedAt: toDateTimeString(row.created_at) });
      if (missingSamples.length < sampleLimit) missingSamples.push(row.file_name || basename || row.file_path || "");
    }
  }

  let orphanFiles = 0;
  if (fs.existsSync(UPLOAD_ROOT)) {
    const localFiles = fs.readdirSync(UPLOAD_ROOT, { withFileTypes: true }).filter((entry) => entry.isFile());
    for (const entry of localFiles) {
      if (mappedFileNames.has(entry.name)) continue;
      orphanFiles += 1;
      items.push({ id: `orphan:${entry.name}`, fileName: entry.name, filePath: `/uploads/customer_attach/${entry.name}`, status: "orphan", remark: "附件文件存在，但数据库中没有对应记录", updatedAt: null });
    }
  }

  return {
    total: rows.length,
    totalRecords: rows.length,
    existing: existingFiles,
    existingFiles,
    missing: missingFiles,
    missingFiles,
    orphan: orphanFiles,
    orphanFiles,
    examples: missingSamples,
    missingExamples: missingSamples,
    missingSamples,
    list: items.slice(0, Math.max(sampleLimit, 30)),
    items: items.slice(0, Math.max(sampleLimit, 30)),
  };
}

async function getLatestOperationMeta(connection, action) {
  const tables = await getExistingTables(connection);
  if (!tables.includes("operation_logs")) return null;
  const [[row]] = await connection.query(`SELECT id, created_at, content FROM operation_logs WHERE module = 'system' AND action = ? ORDER BY id DESC LIMIT 1`, [action]);
  if (!row) return null;
  return { id: Number(row.id || 0), createdAt: toDateTimeString(row.created_at), content: row.content || "" };
}

async function getOperationCount(connection, action) {
  const tables = await getExistingTables(connection);
  if (!tables.includes("operation_logs")) return 0;
  const [[row]] = await connection.query(`SELECT COUNT(*) AS total FROM operation_logs WHERE module = 'system' AND action = ?`, [action]);
  return Number(row?.total || 0);
}

function defaultAutoBackupConfig() {
  return {
    enabled: false,
    types: ["full"],
    scheduleMode: "interval",
    time: "03:00",
    intervalDays: 1,
    weekdays: [1, 2, 3, 4, 5, 6, 7],
    backupDir: BACKUP_ROOT,
    retentionDays: 30,
    retentionCount: 30,
    lastRunAt: null,
    lastStatus: "idle",
    lastMessage: "尚未执行自动备份",
    lastRunKey: null,
    lastAutoRunAt: null,
    scheduleAnchorAt: null,
    nextRunAt: null,
  };
}

function normalizeBackupTypes(types) {
  const arr = Array.isArray(types) ? types : [types || "full"];
  const normalized = Array.from(new Set(arr.map((item) => String(item || "").trim()).filter((item) => BACKUP_TYPES.has(item))));
  return normalized.length ? normalized : ["full"];
}

function normalizeAutoBackupConfig(input = {}) {
  const base = defaultAutoBackupConfig();
  const time = /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(String(input.time || "")) ? String(input.time) : base.time;
  const retentionDays = Math.min(Math.max(Number(input.retentionDays || base.retentionDays), 1), 3650);
  const retentionCount = Math.min(Math.max(Number(input.retentionCount || base.retentionCount), 1), 500);
  const intervalDays = Math.min(Math.max(Number(input.intervalDays || base.intervalDays), 1), 365);
  const scheduleMode = input.scheduleMode === "weekly" ? "weekly" : "interval";
  const weekdays = Array.from(new Set(
    (Array.isArray(input.weekdays) ? input.weekdays : base.weekdays)
      .map(Number)
      .filter((item) => Number.isInteger(item) && item >= 1 && item <= 7),
  )).sort((a, b) => a - b);
  const configuredDir = String(input.backupDir || base.backupDir).trim();
  return {
    ...base,
    ...input,
    enabled: Boolean(input.enabled),
    types: normalizeBackupTypes(input.types),
    scheduleMode,
    time,
    intervalDays,
    weekdays: weekdays.length ? weekdays : base.weekdays,
    backupDir: configuredDir || base.backupDir,
    retentionDays,
    retentionCount,
  };
}

function parseConfigDate(value) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function setConfigTime(date, config) {
  const [hour, minute] = String(config.time || "03:00").split(":").map(Number);
  const result = new Date(date);
  result.setHours(hour || 0, minute || 0, 0, 0);
  return result;
}

function localWeekday(date) {
  return date.getDay() || 7;
}

function localDateKey(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function computeNextRunAt(config, fromDate = new Date()) {
  if (!config.enabled) return null;
  const normalized = normalizeAutoBackupConfig(config);

  if (normalized.scheduleMode === "weekly") {
    const selected = new Set(normalized.weekdays);
    for (let offset = 0; offset <= 7; offset += 1) {
      const candidate = setConfigTime(fromDate, normalized);
      candidate.setDate(candidate.getDate() + offset);
      if (selected.has(localWeekday(candidate)) && candidate > fromDate) {
        return candidate.toISOString();
      }
    }
    return null;
  }

  const intervalDays = Number(normalized.intervalDays || 1);
  const lastAutoRunAt = parseConfigDate(normalized.lastAutoRunAt);
  const scheduleAnchorAt = parseConfigDate(normalized.scheduleAnchorAt);
  const anchor = lastAutoRunAt || scheduleAnchorAt;
  let next;

  if (anchor) {
    next = setConfigTime(anchor, normalized);
    if (lastAutoRunAt || next <= anchor) next.setDate(next.getDate() + intervalDays);
  } else {
    next = setConfigTime(fromDate, normalized);
    if (next <= fromDate) next.setDate(next.getDate() + intervalDays);
  }

  while (next <= fromDate) next.setDate(next.getDate() + intervalDays);
  return next.toISOString();
}

function shouldRunAutoBackupAt(config, now = new Date()) {
  const normalized = normalizeAutoBackupConfig(config);
  if (!normalized.enabled) return false;
  const [hour, minute] = normalized.time.split(":").map(Number);
  if (now.getHours() !== hour || now.getMinutes() !== minute) return false;
  const currentKey = localDateKey(now);
  if (normalized.lastRunKey === currentKey) return false;

  if (normalized.scheduleMode === "weekly") {
    return normalized.weekdays.includes(localWeekday(now));
  }

  const lastAutoRunAt = parseConfigDate(normalized.lastAutoRunAt);
  const scheduleAnchorAt = parseConfigDate(normalized.scheduleAnchorAt);
  const anchor = lastAutoRunAt || scheduleAnchorAt;
  if (!anchor) return true;

  const firstDue = setConfigTime(anchor, normalized);
  if (lastAutoRunAt || firstDue <= anchor) {
    firstDue.setDate(firstDue.getDate() + Number(normalized.intervalDays || 1));
  }
  return firstDue <= now;
}

function readAutoBackupConfig() {
  try {
    if (fs.existsSync(AUTO_BACKUP_CONFIG_FILE)) {
      const saved = JSON.parse(fs.readFileSync(AUTO_BACKUP_CONFIG_FILE, "utf8"));
      const normalized = normalizeAutoBackupConfig(saved);
      normalized.nextRunAt = computeNextRunAt(normalized);
      return normalized;
    }
  } catch (error) {
    console.warn("[自动备份配置读取失败]", error?.message || error);
  }
  const config = defaultAutoBackupConfig();
  config.nextRunAt = computeNextRunAt(config);
  return config;
}

function saveAutoBackupConfig(config) {
  ensureDir(path.dirname(AUTO_BACKUP_CONFIG_FILE));
  const normalized = normalizeAutoBackupConfig(config);
  normalized.nextRunAt = computeNextRunAt(normalized);
  fs.writeFileSync(AUTO_BACKUP_CONFIG_FILE, JSON.stringify(normalized, null, 2), "utf8");
  return normalized;
}

function safeBackupDir(config) {
  const dir = path.resolve(config.backupDir || BACKUP_ROOT);
  ensureDir(dir);
  return dir;
}

function shouldExcludeProjectPath(fullPath) {
  const relative = path.relative(APP_ROOT, fullPath).replace(/\\/g, "/");
  if (!relative) return false;
  if (relative.startsWith("..")) return true;
  const parts = relative.split("/");
  const excludes = new Set(["node_modules", ".git", "dist", ".npm-cache", "release-packages", "backups", ".DS_Store"]);
  return parts.some((part) => excludes.has(part)) || relative.includes("/backups/");
}

function addDirectoryToZip(zip, dir, zipPrefix = "") {
  if (!fs.existsSync(dir) || shouldExcludeProjectPath(dir)) return 0;
  let count = 0;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (shouldExcludeProjectPath(fullPath)) continue;
    const entryName = zipPrefix ? `${zipPrefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      count += addDirectoryToZip(zip, fullPath, entryName);
    } else if (entry.isFile()) {
      zip.addLocalFile(fullPath, path.dirname(entryName) === "." ? "" : path.dirname(entryName), path.basename(entryName));
      count += 1;
    }
  }
  return count;
}

async function addDatabaseToZip(connection, zip) {
  await ensureSupplementTables();
  const tables = getTransferableTableNames(await getExistingTables(connection));
  const tableCounts = {};
  const tableColumns = {};

  for (const tableName of tables) {
    const columns = await getTableColumns(connection, tableName);
    tableColumns[tableName] = columns;
    const rows = await getTableRows(connection, tableName, columns);
    tableCounts[tableName] = rows.length;
    addJsonFileToZip(zip, `data/${tableName}.json`, rows);
  }

  return { tables, tableCounts, tableColumns };
}

async function addAttachmentsToZip(connection, zip) {
  ensureUploadRoot();
  const tables = await getExistingTables(connection);
  let attachmentRows = [];
  if (tables.includes("customer_attachments")) {
    const [rows] = await connection.query(`SELECT id, customer_id, file_name, file_path FROM customer_attachments ORDER BY id ASC`);
    attachmentRows = rows;
  }

  let includedFiles = 0;
  let missingFiles = 0;
  let orphanIncludedFiles = 0;
  const added = new Set();

  for (const row of attachmentRows) {
    const absolutePath = getAttachmentAbsolutePath(row.file_path);
    const relativePath = getAttachmentRelativePath(row.file_path);
    if (!fs.existsSync(absolutePath)) {
      missingFiles += 1;
      continue;
    }
    const zipKey = relativePath.replace(/\\/g, "/");
    if (added.has(zipKey)) continue;
    zip.addLocalFile(absolutePath, path.dirname(relativePath), path.basename(relativePath));
    includedFiles += 1;
    added.add(zipKey);
  }

  // 发布级备份不能只相信数据库记录：附件目录中的孤立文件也必须兜底备份。
  // 否则恢复时清空附件目录会把“文件存在但数据库暂时没记录”的资料误删。
  if (fs.existsSync(UPLOAD_ROOT)) {
    const localFiles = fs.readdirSync(UPLOAD_ROOT, { withFileTypes: true }).filter((entry) => entry.isFile());
    for (const entry of localFiles) {
      const relativePath = `uploads/customer_attach/${entry.name}`;
      if (added.has(relativePath)) continue;
      zip.addLocalFile(path.join(UPLOAD_ROOT, entry.name), "uploads/customer_attach", entry.name);
      includedFiles += 1;
      orphanIncludedFiles += 1;
      added.add(relativePath);
    }
  }

  return { totalRecords: attachmentRows.length, includedFiles, missingFiles, orphanIncludedFiles };
}

async function buildBackupArchive(type = "full") {
  const normalizedType = BACKUP_TYPES.has(type) ? type : "full";
  const zip = new AdmZip();
  const connection = await pool.getConnection();
  try {
    let databaseMeta = null;
    let attachmentsMeta = null;
    let projectMeta = null;

    if (["database", "full"].includes(normalizedType)) {
      databaseMeta = await addDatabaseToZip(connection, zip);
    }
    if (["attachments", "full"].includes(normalizedType)) {
      attachmentsMeta = await addAttachmentsToZip(connection, zip);
    }
    if (normalizedType === "project") {
      const fileCount = addDirectoryToZip(zip, APP_ROOT, "project");
      projectMeta = { rootName: path.basename(APP_ROOT), includedFiles: fileCount, excluded: ["node_modules", ".git", "dist", "release-packages", "backups", ".npm-cache"] };
    }

    const manifest = {
      type: normalizedType === "attachments" ? ATTACHMENT_BACKUP_FILE_TYPE : normalizedType === "project" ? PROJECT_BACKUP_FILE_TYPE : BACKUP_FILE_TYPE,
      backupType: normalizedType,
      version: BACKUP_VERSION,
      exportedAt: new Date().toISOString(),
      database: process.env.DB_NAME || "",
      installInfo: readInstallInfo(),
      tables: databaseMeta?.tables || [],
      tableCounts: databaseMeta?.tableCounts || {},
      tableColumns: databaseMeta?.tableColumns || {},
      excludedTables: [...ENVIRONMENT_LOCAL_TABLES],
      attachments: attachmentsMeta || null,
      project: projectMeta,
    };
    addJsonFileToZip(zip, "manifest.json", manifest);
    return { buffer: zip.toBuffer(), manifest };
  } finally {
    connection.release();
  }
}

function clearUploadRoot() {
  if (fs.existsSync(UPLOAD_ROOT)) fs.rmSync(UPLOAD_ROOT, { recursive: true, force: true });
  fs.mkdirSync(UPLOAD_ROOT, { recursive: true });
}

function importAttachmentEntriesFromZip(zip, clearFirst = false) {
  ensureUploadRoot();
  if (clearFirst) clearUploadRoot();

  let importedFiles = 0;
  for (const entry of zip.getEntries()) {
    if (entry.isDirectory) continue;
    const entryName = String(entry.entryName || "").replace(/\\/g, "/");
    let fileName = "";
    if (entryName.startsWith("uploads/customer_attach/")) fileName = path.basename(entryName);
    else if (entryName.startsWith("customer_attach/")) fileName = path.basename(entryName);
    else if (entryName.startsWith("project/backend-后端/src/uploads/customer_attach/")) fileName = path.basename(entryName);
    else if (!entryName.includes("/")) fileName = path.basename(entryName);
    if (!fileName || fileName === "manifest.json") continue;
    fs.writeFileSync(path.join(UPLOAD_ROOT, fileName), entry.getData());
    importedFiles += 1;
  }
  return importedFiles;
}

function buildInsertSql(tableName, columns) {
  const columnSql = columns.map((column) => `\`${column}\``).join(", ");
  const valueSql = columns.map(() => "?").join(", ");
  const updateColumns = columns.filter((column) => column !== "id");
  const updateSql = (updateColumns.length ? updateColumns : columns)
    .map((column) => `\`${column}\` = VALUES(\`${column}\`)`)
    .join(", ");
  return `INSERT INTO \`${tableName}\` (${columnSql}) VALUES (${valueSql}) ON DUPLICATE KEY UPDATE ${updateSql}`;
}

async function insertRows(connection, tableName, rows = []) {
  if (!rows.length) return 0;
  const actualColumns = new Set(await getTableColumns(connection, tableName));
  const columns = Object.keys(rows[0]).filter((column) => actualColumns.has(column));
  if (!columns.length) return 0;

  const columnSql = columns.map((column) => `\`${column}\``).join(", ");
  const valueSql = `(${columns.map(() => "?").join(", ")})`;
  const updateColumns = columns.filter((column) => column !== "id");
  const updateSql = (updateColumns.length ? updateColumns : columns)
    .map((column) => `\`${column}\` = VALUES(\`${column}\`)`)
    .join(", ");
  const chunkSize = Number(process.env.BACKUP_RESTORE_CHUNK_SIZE || "100");

  for (let index = 0; index < rows.length; index += chunkSize) {
    const chunk = rows.slice(index, index + chunkSize);
    const placeholders = chunk.map(() => valueSql).join(", ");
    const sql = `INSERT INTO \`${tableName}\` (${columnSql}) VALUES ${placeholders} ON DUPLICATE KEY UPDATE ${updateSql}`;
    const params = [];
    for (const row of chunk) {
      for (const column of columns) {
        const value = row[column];
        if (value === undefined) params.push(null);
        else if (value && typeof value === "object" && !(value instanceof Date) && !Buffer.isBuffer(value)) params.push(JSON.stringify(value));
        else params.push(value);
      }
    }
    await queryLong(connection, sql, params);
  }

  // 不在恢复事务里执行 ALTER TABLE AUTO_INCREMENT：MySQL DDL 会隐式提交，影响恢复原子性。
  // InnoDB 插入显式 id 后会自动推进自增计数，实际新增数据不会撞号。
  return rows.length;
}

async function clearTables(connection, tableNames) {
  const existing = await getExistingTables(connection);
  const clearSet = new Set([...CLEAR_ONLY_TABLES, ...tableNames].filter((name) => existing.includes(name)));
  const ordered = [...KNOWN_TABLE_ORDER].reverse().filter((name) => clearSet.has(name));
  for (const name of [...clearSet].sort().reverse()) if (!ordered.includes(name)) ordered.push(name);
  await queryLong(connection, "SET FOREIGN_KEY_CHECKS = 0");
  try {
    for (const tableName of ordered) {
      await queryLong(connection, `DELETE FROM \`${tableName}\``);
    }
  } finally {
    await queryLong(connection, "SET FOREIGN_KEY_CHECKS = 1");
  }
}

async function getDataCenterSummary(req, res) {
  const connection = await pool.getConnection();
  try {
    const tables = await getExistingTables(connection);
    const tableCounts = {};
    for (const tableName of tables) tableCounts[tableName] = await getTableCount(connection, tableName);

    const [attachmentSummary, latestExport, latestRestore, latestAuto, exportCount] = await Promise.all([
      buildAttachmentSummary(connection),
      getLatestOperationMeta(connection, "backup_export"),
      getLatestOperationMeta(connection, "backup_restore"),
      getLatestOperationMeta(connection, "backup_auto"),
      getOperationCount(connection, "backup_export"),
    ]);
    const autoBackup = readAutoBackupConfig();
    const warnings = [];
    if (attachmentSummary.missingFiles > 0) warnings.push(`检测到 ${attachmentSummary.missingFiles} 个附件记录缺少文件，可使用“附件导入”或完整备份恢复补回。`);
    if (attachmentSummary.orphanFiles > 0) warnings.push(`检测到 ${attachmentSummary.orphanFiles} 个孤立附件文件，建议核对后清理。`);
    if (!autoBackup.enabled) warnings.push("自动备份尚未开启。正式上线建议至少开启“完整备份”或“附件备份”的每日自动备份。");

    return sendSuccess(res, {
      installInfo: readInstallInfo(),
      database: { host: process.env.DB_HOST || "127.0.0.1", port: Number(process.env.DB_PORT || 3306), database: process.env.DB_NAME || "", name: process.env.DB_NAME || "", user: process.env.DB_USER || "", installMode: readInstallInfo()?.installMode || "init", installedAt: readInstallInfo()?.installedAt || null },
      tableCounts,
      overview: { stores: tableCounts.stores || 0, users: tableCounts.users || 0, customers: tableCounts.customers || 0, trainingProjects: tableCounts.training_projects || 0, verifyRecords: tableCounts.verify_records || 0, renewals: tableCounts.customer_renewals || 0, attachments: tableCounts.customer_attachments || 0, apiKeys: tableCounts.external_api_keys || 0, logs: tableCounts.operation_logs || 0, smsRecords: tableCounts.sms_records || 0, wxBindings: tableCounts.wx_user_bindings || 0 },
      backup: { lastExportAt: latestExport?.createdAt || null, lastRestoreAt: latestRestore?.createdAt || null, lastAutoAt: latestAuto?.createdAt || autoBackup.lastRunAt || null, backupCount: exportCount, autoBackup },
      attachments: attachmentSummary,
      warnings,
      notes: ["完整恢复适合空库或已提前做好备份的数据库环境。", "附件是客户资料的高风险资产：建议单独开启附件自动备份，并定期下载到服务器外部保存。"],
    }, "获取数据中心摘要成功");
  } catch (error) {
    console.error("data center summary error:", error);
    return sendFail(res, `获取数据中心摘要失败：${error.message}`, 500);
  } finally {
    connection.release();
  }
}

async function exportSystemBackup(req, res) {
  try {
    const type = BACKUP_TYPES.has(String(req.query.type || "")) ? String(req.query.type) : "full";
    const { buffer, manifest } = await buildBackupArchive(type);
    await writeOperationLog(req, { module: "system", action: "backup_export", bizType: "data_center", bizId: 0, bizNo: process.env.DB_NAME || "", content: `导出${type}备份成功，大小 ${formatBytes(buffer.length)}` });
    const ext = type === "database" || type === "full" ? "vvbak" : "zip";
    const filename = buildBackupFileName(type, ext);
    res.setHeader("Content-Type", "application/octet-stream");
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    res.setHeader("X-Backup-Type", manifest.backupType);
    res.end(buffer);
  } catch (error) {
    console.error("export backup error:", error);
    return sendFail(res, `导出备份失败：${error.message}`, 500);
  }
}

async function restoreSystemBackup(req, res) {
  const connection = await pool.getConnection();
  try {
    ensureBackupFile(req);
    const zip = new AdmZip(req.file.buffer);
    const manifest = readZipJson(zip, "manifest.json", null);
    if (!manifest || manifest.type !== BACKUP_FILE_TYPE) return sendFail(res, "备份文件格式无效：请选择完整备份或数据库备份文件", 400);
    if (String(req.body.confirmText || "").trim() !== "确认恢复") {
      return sendFail(res, "为了防止误操作，请输入“确认恢复”后再执行恢复", 400);
    }

    // 恢复前先生成当前环境保护备份。这个动作失败就不继续恢复，避免误操作后无回退点。
    const preBackupDir = path.join(BACKUP_ROOT, "pre-restore", buildStamp());
    ensureDir(preBackupDir);
    const preBackup = await buildBackupArchive("full");
    const preBackupPath = path.join(preBackupDir, buildBackupFileName("pre-restore", "vvbak"));
    fs.writeFileSync(preBackupPath, preBackup.buffer);

    await ensureSupplementTables();
    await connection.beginTransaction();
    const tableNames = getTransferableTableNames(Array.isArray(manifest.tables) && manifest.tables.length ? manifest.tables : KNOWN_TABLE_ORDER.filter((name) => zip.getEntry(`data/${name}.json`)));
    await clearTables(connection, tableNames);

    const restoredCounts = {};
    const existingSet = new Set(await getExistingTables(connection));
    await queryLong(connection, "SET FOREIGN_KEY_CHECKS = 0");
    try {
      for (const tableName of tableNames) {
        const rows = readZipJson(zip, `data/${tableName}.json`, []);
        if (!existingSet.has(tableName)) throw new Error(`当前系统缺少数据表 ${tableName}，请先升级后端版本后再恢复`);
        restoredCounts[tableName] = await insertRows(connection, tableName, rows);
      }
    } finally {
      await queryLong(connection, "SET FOREIGN_KEY_CHECKS = 1");
    }

    const importedFiles = manifest.backupType === "database" ? 0 : importAttachmentEntriesFromZip(zip, true);
    await connection.commit();
    await writeOperationLog(req, { module: "system", action: "backup_restore", bizType: "data_center", bizId: 0, bizNo: process.env.DB_NAME || "", content: `恢复备份成功，数据表 ${Object.keys(restoredCounts).length} 个，附件 ${importedFiles} 个` });
    return sendSuccess(res, { manifest, restoredCounts, importedFiles, preRestoreBackup: path.relative(BACKUP_ROOT, preBackupPath).replace(/\\/g, "/") }, "恢复备份成功");
  } catch (error) {
    try { await connection.rollback(); } catch {}
    console.error("restore backup error:", error);
    return sendFail(res, `恢复备份失败：${error.message}`, 500);
  } finally {
    connection.release();
  }
}

async function precheckBackupFile(req, res) {
  const connection = await pool.getConnection();
  try {
    ensureBackupFile(req);
    const zip = new AdmZip(req.file.buffer);
    const manifest = readZipJson(zip, "manifest.json", null);
    if (!manifest) return sendFail(res, "备份包缺少 manifest.json，无法识别", 400);

    const entries = zip.getEntries().filter((entry) => !entry.isDirectory);
    const dataEntries = entries.filter((entry) => String(entry.entryName || "").startsWith("data/"));
    const attachmentEntries = entries.filter((entry) => String(entry.entryName || "").replace(/\\/g, "/").startsWith("uploads/customer_attach/"));
    await ensureSupplementTables();
    const tables = await getExistingTables(connection);
    const currentCounts = {};
    for (const tableName of tables) currentCounts[tableName] = await getTableCount(connection, tableName);

    const sourceBackupTables = Array.isArray(manifest.tables) ? manifest.tables : [];
    const skippedTables = sourceBackupTables.filter((name) => ENVIRONMENT_LOCAL_TABLES.has(String(name)));
    const backupTables = getTransferableTableNames(sourceBackupTables);
    const missingTables = backupTables.filter((name) => !tables.includes(name));
    const currentTotal = Object.values(currentCounts).reduce((sum, value) => sum + Number(value || 0), 0);
    const warnings = [];
    if (manifest.type !== BACKUP_FILE_TYPE && manifest.type !== ATTACHMENT_BACKUP_FILE_TYPE && manifest.type !== PROJECT_BACKUP_FILE_TYPE) warnings.push("备份包类型不是本系统标准格式。")
    if (skippedTables.length) warnings.push(`已自动忽略 ${skippedTables.length} 张服务器内部运行表：${skippedTables.join("、")}。这些表会由目标服务器自行维护。`);
    if (missingTables.length) warnings.push(`当前系统缺少 ${missingTables.length} 张备份表：${missingTables.slice(0, 5).join("、")}${missingTables.length > 5 ? "等" : ""}`);
    if (currentTotal > 0) warnings.push("当前数据库已有数据。正式恢复前系统会自动生成一份恢复前保护备份。")
    if (manifest.type === BACKUP_FILE_TYPE && !attachmentEntries.length) warnings.push("备份包中未检测到附件文件，如客户资料含附件，请确认是否另有附件备份。")

    return sendSuccess(res, {
      manifest,
      backupType: manifest.backupType || "unknown",
      fileSize: req.file.size,
      fileSizeText: formatBytes(req.file.size),
      entries: entries.length,
      dataFiles: dataEntries.length,
      attachmentFiles: attachmentEntries.length,
      currentTables: tables.length,
      currentTotal,
      missingTables,
      skippedTables,
      warnings,
      canRestore: manifest.type === BACKUP_FILE_TYPE && missingTables.length === 0,
    }, "备份文件预检查完成");
  } catch (error) {
    console.error("precheck backup error:", error);
    return sendFail(res, `备份文件预检查失败：${error.message}`, 500);
  } finally {
    connection.release();
  }
}

async function importAttachmentArchive(req, res) {
  try {
    ensureBackupFile(req);
    const clearFirst = ["1", "true", "yes"].includes(String(req.body.clearFirst || "").trim().toLowerCase());
    const zip = new AdmZip(req.file.buffer);
    const importedFiles = importAttachmentEntriesFromZip(zip, clearFirst);
    const connection = await pool.getConnection();
    try {
      const attachments = await buildAttachmentSummary(connection);
      await writeOperationLog(req, { module: "system", action: "attachment_import", bizType: "data_center", bizId: 0, bizNo: process.env.DB_NAME || "", content: `导入附件成功，共 ${importedFiles} 个文件` });
      return sendSuccess(res, { importedFiles, attachments }, "导入附件成功");
    } finally {
      connection.release();
    }
  } catch (error) {
    console.error("import attachment archive error:", error);
    return sendFail(res, `导入附件失败：${error.message}`, 500);
  }
}

function listBackupFilesInDir(dir, baseDir = dir, result = []) {
  if (!fs.existsSync(dir)) return result;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      listBackupFilesInDir(fullPath, baseDir, result);
    } else if (entry.isFile() && /\.(vvbak|zip)$/i.test(entry.name)) {
      const stat = fs.statSync(fullPath);
      result.push({ name: entry.name, path: path.relative(baseDir, fullPath).replace(/\\/g, "/"), size: stat.size, sizeText: formatBytes(stat.size), createdAt: stat.birthtime.toISOString(), updatedAt: stat.mtime.toISOString(), type: entry.name.includes("attachments") ? "attachments" : entry.name.includes("project") ? "project" : entry.name.includes("database") ? "database" : "full" });
    }
  }
  return result.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
}

function resolveBackupPath(relativePath, config = readAutoBackupConfig()) {
  const root = safeBackupDir(config);
  const fullPath = path.resolve(root, String(relativePath || ""));
  if (!fullPath.startsWith(root + path.sep) && fullPath !== root) throw new Error("备份文件路径无效");
  return fullPath;
}

async function cleanupOldBackups(config) {
  const dir = safeBackupDir(config);
  const files = listBackupFilesInDir(dir);
  const keep = Number(config.retentionCount || 30);
  const cutoff = Date.now() - Number(config.retentionDays || 30) * 24 * 60 * 60 * 1000;
  let deleted = 0;
  for (let index = 0; index < files.length; index += 1) {
    const file = files[index];
    const tooMany = index >= keep;
    const tooOld = new Date(file.updatedAt).getTime() < cutoff;
    if (!tooMany && !tooOld) continue;
    try {
      fs.unlinkSync(path.join(dir, file.path));
      deleted += 1;
    } catch {}
  }
  return deleted;
}

async function runBackupJob(source = "manual") {
  let config = readAutoBackupConfig();
  const backupDir = safeBackupDir(config);
  const runDir = path.join(backupDir, source === "auto" ? "auto" : "manual", buildStamp());
  ensureDir(runDir);

  const files = [];
  for (const type of normalizeBackupTypes(config.types)) {
    const { buffer } = await buildBackupArchive(type);
    const ext = type === "database" || type === "full" ? "vvbak" : "zip";
    const filename = buildBackupFileName(type, ext);
    const filePath = path.join(runDir, filename);
    fs.writeFileSync(filePath, buffer);
    files.push({ type, name: filename, path: path.relative(backupDir, filePath).replace(/\\/g, "/"), size: buffer.length, sizeText: formatBytes(buffer.length) });
  }

  const deleted = await cleanupOldBackups(config);
  const completedAt = new Date();
  config = saveAutoBackupConfig({
    ...config,
    lastRunAt: completedAt.toISOString(),
    lastAutoRunAt: source === "auto" ? completedAt.toISOString() : config.lastAutoRunAt,
    lastStatus: "success",
    lastMessage: `${source === "auto" ? "自动" : "手动"}备份成功，生成 ${files.length} 个文件，清理 ${deleted} 个旧文件`,
    lastRunKey: source === "auto" ? localDateKey(completedAt) : config.lastRunKey,
  });
  await writeOperationLog(null, { module: "system", action: source === "auto" ? "backup_auto" : "backup_manual", bizType: "data_center", bizId: 0, bizNo: process.env.DB_NAME || "", content: config.lastMessage });
  return { config, files, deleted };
}

async function createUpdateSafetyBackup() {
  const config = readAutoBackupConfig();
  const backupDir = safeBackupDir(config);
  const runDir = path.join(backupDir, "pre-update", buildStamp());
  ensureDir(runDir);
  const { buffer } = await buildBackupArchive("full");
  const filename = buildBackupFileName("pre-update", "vvbak");
  const filePath = path.join(runDir, filename);
  fs.writeFileSync(filePath, buffer);
  return {
    path: path.relative(backupDir, filePath).replace(/\\/g, "/"),
    absolutePath: filePath,
    size: buffer.length,
    sizeText: formatBytes(buffer.length)
  };
}

async function getAutoBackupConfig(req, res) {
  return sendSuccess(res, readAutoBackupConfig(), "获取自动备份配置成功");
}

async function saveAutoBackupConfigApi(req, res) {
  try {
    const previous = readAutoBackupConfig();
    const requested = normalizeAutoBackupConfig({ ...previous, ...(req.body || {}) });
    const previousSchedule = JSON.stringify({
      enabled: previous.enabled,
      scheduleMode: previous.scheduleMode,
      time: previous.time,
      intervalDays: previous.intervalDays,
      weekdays: previous.weekdays,
    });
    const nextSchedule = JSON.stringify({
      enabled: requested.enabled,
      scheduleMode: requested.scheduleMode,
      time: requested.time,
      intervalDays: requested.intervalDays,
      weekdays: requested.weekdays,
    });
    const scheduleChanged = previousSchedule !== nextSchedule;
    const config = saveAutoBackupConfig({
      ...requested,
      lastRunAt: previous.lastRunAt,
      lastAutoRunAt: previous.lastAutoRunAt,
      lastRunKey: scheduleChanged ? null : previous.lastRunKey,
      lastStatus: previous.lastStatus,
      lastMessage: previous.lastMessage,
      scheduleAnchorAt: scheduleChanged ? new Date().toISOString() : previous.scheduleAnchorAt,
    });
    return sendSuccess(res, config, "保存自动备份配置成功");
  } catch (error) {
    return sendFail(res, `保存自动备份配置失败：${error.message}`, 500);
  }
}

async function runAutoBackupNow(req, res) {
  try {
    const result = await runBackupJob("manual");
    return sendSuccess(res, result, "立即备份完成");
  } catch (error) {
    const config = saveAutoBackupConfig({ ...readAutoBackupConfig(), lastRunAt: new Date().toISOString(), lastStatus: "failed", lastMessage: error.message });
    return sendFail(res, `立即备份失败：${error.message}`, 500, { config });
  }
}

async function listBackupFiles(req, res) {
  try {
    const config = readAutoBackupConfig();
    const files = listBackupFilesInDir(safeBackupDir(config));
    return sendSuccess(res, { root: safeBackupDir(config), list: files, total: files.length }, "获取备份文件列表成功");
  } catch (error) {
    return sendFail(res, `获取备份文件列表失败：${error.message}`, 500);
  }
}

async function downloadBackupFile(req, res) {
  try {
    const filePath = resolveBackupPath(req.query.path);
    if (!fs.existsSync(filePath)) return sendFail(res, "备份文件不存在", 404);
    const filename = path.basename(filePath);
    res.setHeader("Content-Type", "application/octet-stream");
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    fs.createReadStream(filePath).pipe(res);
  } catch (error) {
    return sendFail(res, `下载备份失败：${error.message}`, 500);
  }
}

async function deleteBackupFile(req, res) {
  try {
    const filePath = resolveBackupPath(req.query.path || req.body?.path);
    if (!fs.existsSync(filePath)) return sendFail(res, "备份文件不存在", 404);
    fs.unlinkSync(filePath);
    return sendSuccess(res, null, "删除备份文件成功");
  } catch (error) {
    return sendFail(res, `删除备份失败：${error.message}`, 500);
  }
}

let schedulerTimer = null;
let schedulerRunning = false;
async function tickAutoBackupScheduler() {
  if (schedulerRunning) return;
  const config = readAutoBackupConfig();
  if (!config.enabled) return;
  const now = new Date();
  if (!shouldRunAutoBackupAt(config, now)) return;
  schedulerRunning = true;
  try {
    await runBackupJob("auto");
  } catch (error) {
    saveAutoBackupConfig({ ...readAutoBackupConfig(), lastRunAt: new Date().toISOString(), lastStatus: "failed", lastMessage: `自动备份失败：${error.message}` });
    console.warn("[自动备份失败]", error?.message || error);
  } finally {
    schedulerRunning = false;
  }
}

function startAutoBackupScheduler() {
  if (schedulerTimer) return;
  ensureBackupRoot();
  schedulerTimer = setInterval(() => {
    tickAutoBackupScheduler().catch((error) => console.warn("[自动备份调度异常]", error?.message || error));
  }, 60 * 1000);
  tickAutoBackupScheduler().catch(() => {});
  console.log("[数据中心] 自动备份调度已启动");
}

module.exports = {
  getDataCenterSummary,
  exportSystemBackup,
  restoreSystemBackup,
  precheckBackupFile,
  importAttachmentArchive,
  getAutoBackupConfig,
  saveAutoBackupConfig: saveAutoBackupConfigApi,
  runAutoBackupNow,
  listBackupFiles,
  downloadBackupFile,
  deleteBackupFile,
  createUpdateSafetyBackup,
  startAutoBackupScheduler,
  _schedulerInternals: {
    normalizeAutoBackupConfig,
    computeNextRunAt,
    shouldRunAutoBackupAt,
    localDateKey,
  },
  _backupInternals: {
    getTransferableTableNames,
    environmentLocalTables: [...ENVIRONMENT_LOCAL_TABLES],
  },
};
