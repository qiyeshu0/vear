const jwt = require("jsonwebtoken");
const { pool } = require("../config/db");
const {
  ROLE_ADMIN,
  ROLE_OWNER,
  ROLE_MANAGER,
  ROLE_STAFF
} = require("../config/constants");
const { getUserPermissionCodes, hasPermission } = require("../utils/permission");
const {
  ensureApiKeyTable,
  hashApiKey,
  normalizeScopes,
  isScopeAllowed,
  recordApiKeyUsageLog,
} = require("../utils/api-key");

function getTokenFromHeader(req) {
  const authorization = req.headers.authorization || "";
  if (!authorization.startsWith("Bearer ")) return null;
  return authorization.slice(7).trim() || null;
}

function getRawApiKey(req) {
  return String(req.headers["x-api-key"] || "").trim() || null;
}

async function getApiKeyIdentity(rawKey, req) {
  if (!rawKey) return null;

  await ensureApiKeyTable();

  const [rows] = await pool.query(
    `
      SELECT
        k.id AS api_key_id,
        k.name AS api_key_name,
        k.scopes,
        k.status AS api_key_status,
        k.expires_at,
        u.id AS user_id,
        u.username,
        u.real_name,
        u.role,
        u.store_id,
        u.status AS user_status
      FROM external_api_keys k
      INNER JOIN users u ON u.id = k.user_id
      WHERE k.key_hash = ?
      LIMIT 1
    `,
    [hashApiKey(rawKey)],
  );

  const row = rows[0];
  if (!row) return null;

  if (Number(row.api_key_status) !== 1 || Number(row.user_status) !== 1) {
    return { invalid: true, message: "API Key 已停用或绑定用户不可用", apiKeyId: Number(row.api_key_id), userId: Number(row.user_id) };
  }

  if (row.expires_at && new Date(row.expires_at).getTime() < Date.now()) {
    return { invalid: true, message: "API Key 已过期", apiKeyId: Number(row.api_key_id), userId: Number(row.user_id) };
  }

  const scopes = normalizeScopes(row.scopes);
  const requestPath = req.originalUrl.split("?")[0];
  if (!isScopeAllowed(scopes, requestPath, req.method)) {
    return { forbidden: true, message: "API Key 无权访问当前接口", apiKeyId: Number(row.api_key_id), userId: Number(row.user_id) };
  }

  await pool.execute(
    `
      UPDATE external_api_keys
      SET last_used_at = NOW(), last_used_ip = ?
      WHERE id = ?
    `,
    [req.ip || "", row.api_key_id],
  );

  return {
    userId: Number(row.user_id),
    username: row.username,
    realName: row.real_name,
    role: Number(row.role),
    storeId: Number(row.store_id || 0),
    status: Number(row.user_status || 1),
    permissions: await getUserPermissionCodes(row.user_id, row.role),
    authType: "api_key",
    apiKeyId: Number(row.api_key_id),
    apiKeyName: row.api_key_name || "",
    apiKeyScopes: scopes,
  };
}

function sendUnauthorized(res, message = "未登录或登录已过期") {
  return res.status(401).json({
    code: 401,
    message,
    data: null
  });
}

function sendForbidden(res, message = "无权限访问") {
  return res.status(403).json({
    code: 403,
    message,
    data: null
  });
}

function auth(required = true) {
  return async (req, res, next) => {
    const token = getTokenFromHeader(req);
    const rawApiKey = getRawApiKey(req);

    if (!token && rawApiKey) {
      try {
        const apiKeyUser = await getApiKeyIdentity(rawApiKey, req);

        if (apiKeyUser?.invalid) {
          await recordApiKeyUsageLog({ apiKeyId: apiKeyUser.apiKeyId, userId: apiKeyUser.userId, requestMethod: req.method, requestPath: req.originalUrl.split("?")[0], statusCode: 401, durationMs: 0, ip: req.ip || "" }).catch(() => {});
          return sendUnauthorized(res, apiKeyUser.message);
        }

        if (apiKeyUser?.forbidden) {
          await recordApiKeyUsageLog({ apiKeyId: apiKeyUser.apiKeyId, userId: apiKeyUser.userId, requestMethod: req.method, requestPath: req.originalUrl.split("?")[0], statusCode: 403, durationMs: 0, ip: req.ip || "" }).catch(() => {});
          return sendForbidden(res, apiKeyUser.message);
        }

        if (apiKeyUser) {
          req.user = apiKeyUser;
          if (!req._apiKeyAuditAttached) {
            req._apiKeyAuditAttached = true;
            const startTime = Date.now();
            res.on("finish", () => {
              if (!req.user || req.user.authType !== "api_key") return;

              recordApiKeyUsageLog({
                apiKeyId: req.user.apiKeyId,
                userId: req.user.userId,
                requestMethod: req.method,
                requestPath: req.originalUrl.split("?")[0],
                statusCode: res.statusCode,
                durationMs: Date.now() - startTime,
                ip: req.ip || "",
              }).catch(() => {});
            });
          }
          return next();
        }
      } catch (error) {
        return sendUnauthorized(res, "API Key 无效");
      }
    }

    if (!token) {
      if (required) return sendUnauthorized(res);
      req.user = null;
      return next();
    }

    try {
      const secret = process.env.JWT_SECRET || "verify-system-secret";
      const decoded = jwt.verify(token, secret);

      if (decoded.type === "customer") {
        return sendForbidden(res, "家长端账号无权访问管理接口");
      }

      const [rows] = await pool.query(
        `
          SELECT id, username, real_name, role, store_id, status
          FROM users
          WHERE id = ?
          LIMIT 1
        `,
        [Number(decoded.userId || 0)],
      );

      const user = rows[0];
      if (!user || Number(user.status) !== 1) {
        return sendUnauthorized(res, "账号已被禁用");
      }

      req.user = {
        userId: Number(user.id),
        username: user.username,
        realName: user.real_name,
        role: Number(user.role),
        storeId: Number(user.store_id || 0),
        status: Number(user.status || 1),
        permissions: await getUserPermissionCodes(user.id, user.role)
      };

      return next();
    } catch (error) {
      return sendUnauthorized(res);
    }
  };
}

function requireRole(roles = []) {
  return (req, res, next) => {
    if (!req.user) {
      return sendUnauthorized(res);
    }

    if (!Array.isArray(roles) || roles.length === 0) {
      return next();
    }

    if (!roles.includes(req.user.role)) {
      return sendForbidden(res);
    }

    return next();
  };
}

function adminOnly(req, res, next) {
  return requireRole([ROLE_ADMIN])(req, res, next);
}

function adminOrManager(req, res, next) {
  return requireRole([ROLE_ADMIN, ROLE_OWNER, ROLE_MANAGER])(req, res, next);
}

function requireUserPermission(permissionCode) {
  return (req, res, next) => {
    if (hasPermission(req.user, permissionCode)) return next();
    return sendForbidden(res);
  };
}

function requireAnyUserPermission(permissionCodes = []) {
  return (req, res, next) => {
    const codes = Array.isArray(permissionCodes) ? permissionCodes : [permissionCodes];
    if (codes.some(code => hasPermission(req.user, code))) return next();
    return sendForbidden(res);
  };
}

function buildStoreScope(user, alias = "") {
  const isField = typeof alias === "string" && alias.includes(".");
  const prefix = !isField && alias ? `${alias}.` : "";

  if (!user) {
    return {
      sql: "1 = 0",
      params: []
    };
  }

  if (user.role === ROLE_ADMIN) {
    return {
      sql: "1 = 1",
      params: []
    };
  }

  return {
    sql: `${isField ? alias : `${prefix}store_id`} = ?`,
    params: [Number(user.storeId || 0)]
  };
}

function canManageUser(currentUser, targetUser = {}) {
  if (!currentUser) return false;

  if (currentUser.role === ROLE_ADMIN) {
    return true;
  }

  if (currentUser.role === ROLE_OWNER) {
    return (
      Number(targetUser.role) !== ROLE_ADMIN &&
      Number(targetUser.storeId) === Number(currentUser.storeId)
    );
  }

  if (currentUser.role === ROLE_MANAGER) {
    return (
      Number(targetUser.role) === ROLE_STAFF &&
      Number(targetUser.storeId) === Number(currentUser.storeId)
    );
  }

  return false;
}

module.exports = {
  ROLE_ADMIN,
  ROLE_OWNER,
  ROLE_MANAGER,
  ROLE_STAFF,
  auth,
  requireRole,
  adminOnly,
  adminOrManager,
  requireUserPermission,
  requireAnyUserPermission,
  buildStoreScope,
  canManageUser
};
