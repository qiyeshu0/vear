const { pool } = require("../config/db");
const {
  ROLE_ADMIN,
  ROLE_OWNER,
  ROLE_MANAGER,
  ROLE_STAFF
} = require("../config/constants");

const ALL_PERMISSION = "*:*:*";

const PERMISSION_GROUPS = [
  {
    module: "dashboard",
    groupName: "首页看板",
    permissions: [
      { code: "dashboard:view", name: "首页查看" },
      { code: "dashboard:notification", name: "首页通知处理" }
    ]
  },
  {
    module: "customer",
    groupName: "客户档案",
    permissions: [
      { code: "customer:view", name: "客户查看" },
      { code: "customer:create", name: "新增客户" },
      { code: "customer:update", name: "编辑客户" },
      { code: "customer:delete", name: "删除客户" },
      { code: "customer:status", name: "启停客户" },
      { code: "customer:card:open", name: "客户开卡" },
      { code: "customer:card:renew", name: "客户续卡" },
      { code: "customer:activity-card", name: "活动卡管理" },
      { code: "customer:attachment", name: "附件管理" },
      { code: "customer:phone", name: "手机号管理" },
      { code: "customer:follow", name: "跟进记录" },
      { code: "customer:visit", name: "复查记录" },
      { code: "customer:glasses", name: "配镜记录" },
      { code: "customer:refund", name: "客户退费" }
    ]
  },
  {
    module: "verify",
    groupName: "核销管理",
    permissions: [
      { code: "verify:view", name: "核销登记查看" },
      { code: "verify:create", name: "创建核销" },
      { code: "record:view", name: "核销记录查看" },
      { code: "record:export", name: "核销记录导出" },
      { code: "record:revoke:request", name: "发起撤销申请" },
      { code: "record:revoke:approve", name: "审核撤销申请" },
      { code: "record:revoke", name: "直接撤销核销" }
    ]
  },
  {
    module: "visit",
    groupName: "来访记录",
    permissions: [
      { code: "visit:view", name: "来访记录查看" },
      { code: "visit:create", name: "登记客户来访" },
      { code: "visit:update", name: "编辑来访信息" },
      { code: "visit:complete", name: "更新服务状态" },
      { code: "visit:cancel", name: "取消来访记录" },
      { code: "visit:export", name: "导出来访台账" }
    ]
  },
  {
    module: "store",
    groupName: "门店管理",
    permissions: [
      { code: "store:view", name: "门店查看" },
      { code: "store:create", name: "新增门店" },
      { code: "store:update", name: "编辑门店" },
      { code: "store:delete", name: "删除门店" }
    ]
  },
  {
    module: "user",
    groupName: "用户与审核",
    permissions: [
      { code: "user:view", name: "用户查看" },
      { code: "user:create", name: "新增用户" },
      { code: "user:update", name: "编辑用户" },
      { code: "user:delete", name: "删除用户" },
      { code: "user:status", name: "启停用户" },
      { code: "user:password", name: "重置密码" },
      { code: "user:permission", name: "分配权限" },
      { code: "user:registration:view", name: "注册申请查看" },
      { code: "user:registration:audit", name: "注册申请审核" }
    ]
  },
  {
    module: "log",
    groupName: "操作日志",
    permissions: [{ code: "log:view", name: "操作日志查看" }]
  },
  {
    module: "training",
    groupName: "训练项目",
    permissions: [
      { code: "training:view", name: "训练项目查看" },
      { code: "training:create", name: "新增训练项目" },
      { code: "training:update", name: "编辑训练项目" },
      { code: "training:status", name: "启停训练项目" },
      { code: "training:delete", name: "删除训练项目" }
    ]
  },
  {
    module: "card-template",
    groupName: "卡项管理",
    permissions: [
      { code: "card-template:view", name: "卡项查看" },
      { code: "card-template:create", name: "新增卡项" },
      { code: "card-template:update", name: "编辑卡项" },
      { code: "card-template:status", name: "启停卡项" },
      { code: "card-template:delete", name: "删除卡项" }
    ]
  },
  {
    module: "system",
    groupName: "系统设置",
    permissions: [
      { code: "system:view", name: "系统设置查看" },
      { code: "system:update", name: "修改系统设置" }
    ]
  },
  {
    module: "system-update",
    groupName: "系统版本与更新",
    permissions: [
      { code: "system-update:view", name: "版本信息查看" },
      { code: "system-update:check", name: "检查更新" },
      { code: "system-update:download", name: "下载更新" },
      { code: "system-update:apply", name: "安装更新" },
      { code: "system-update:restart", name: "更新后重启" },
      { code: "system-update:rollback", name: "更新回滚" },
      { code: "system-update:config", name: "更新源配置" }
    ]
  },
  {
    module: "sms",
    groupName: "短信中心",
    permissions: [
      { code: "sms:view", name: "短信查看" },
      { code: "sms:send", name: "发送短信" },
      { code: "sms:batch-send", name: "批量发送短信" },
      { code: "sms:template", name: "短信模板管理" },
      { code: "sms:config", name: "短信配置查看" },
      { code: "sms:export", name: "短信记录导出" }
    ]
  },
  {
    module: "data-center",
    groupName: "数据中心",
    permissions: [
      { code: "data-center:view", name: "数据中心查看" },
      { code: "data-center:backup", name: "手动/立即备份" },
      { code: "data-center:auto-backup", name: "自动备份配置" },
      { code: "data-center:restore", name: "备份恢复" },
      { code: "data-center:download", name: "备份下载" },
      { code: "data-center:delete", name: "备份删除" },
      { code: "data-center:attachment", name: "附件体检/导入" },
      { code: "data-center:import", name: "附件导入（兼容旧权限）" }
    ]
  },
  {
    module: "api-key",
    groupName: "API Key",
    permissions: [
      { code: "api-key:view", name: "API Key 查看" },
      { code: "api-key:create", name: "创建 API Key" },
      { code: "api-key:update", name: "编辑 API Key" },
      { code: "api-key:status", name: "启停 API Key" },
      { code: "api-key:rotate", name: "轮换 API Key" },
      { code: "api-key:delete", name: "删除 API Key" },
      { code: "api-key:logs", name: "API Key 日志" }
    ]
  },
  {
    module: "tool",
    groupName: "开发工具",
    permissions: [
      { code: "tool:api-test", name: "接口测试" }
    ]
  },
  {
    module: "report",
    groupName: "报表导出",
    permissions: [
      { code: "report:customer", name: "客户报表导出" },
      { code: "report:record", name: "核销报表导出" },
      { code: "report:summary", name: "汇总报表导出" }
    ]
  }
];

const ALL_PERMISSION_CODES = PERMISSION_GROUPS.flatMap(group =>
  group.permissions.map(item => item.code)
);

const TEMPLATE_DEFINITIONS = [
  {
    code: "store-owner",
    name: "门店老板模板",
    description: "适合门店老板，拥有本门店经营、客户、核销、员工和报表权限",
    role: ROLE_OWNER,
    permissions: [
      "dashboard:view", "dashboard:notification",
      "customer:view", "customer:create", "customer:update", "customer:status", "customer:card:open", "customer:card:renew", "customer:activity-card", "customer:attachment", "customer:phone", "customer:follow", "customer:visit", "customer:glasses", "customer:refund",
      "verify:view", "verify:create", "record:view", "record:export", "record:revoke:request",
      "visit:view", "visit:create", "visit:update", "visit:complete", "visit:cancel", "visit:export",
      "store:view",
      "user:view", "user:create", "user:update", "user:status", "user:password", "user:permission", "user:registration:view", "user:registration:audit",
      "log:view",
      "sms:view", "sms:send", "sms:batch-send", "sms:template", "sms:config", "sms:export",
      "report:customer", "report:record", "report:summary"
    ]
  },
  {
    code: "store-manager",
    name: "门店店长模板",
    description: "适合店长管理门店日常经营和店员",
    role: ROLE_MANAGER,
    permissions: [
      "dashboard:view", "dashboard:notification",
      "customer:view", "customer:create", "customer:update", "customer:status", "customer:card:open", "customer:card:renew", "customer:activity-card", "customer:attachment", "customer:phone", "customer:follow", "customer:visit", "customer:glasses",
      "verify:view", "verify:create", "record:view", "record:export", "record:revoke:request",
      "visit:view", "visit:create", "visit:update", "visit:complete", "visit:cancel", "visit:export",
      "store:view",
      "user:view", "user:create", "user:update", "user:status", "user:password",
      "log:view",
      "sms:view", "sms:send", "sms:batch-send",
      "report:customer", "report:record"
    ]
  },
  {
    code: "store-staff",
    name: "门店店员模板",
    description: "适合前台核销和基础客户查看",
    role: ROLE_STAFF,
    permissions: [
      "dashboard:view", "dashboard:notification",
      "customer:view", "customer:create", "customer:update", "customer:phone", "customer:follow", "customer:visit", "customer:glasses",
      "verify:view", "verify:create", "record:view", "record:revoke:request",
      "visit:view", "visit:create", "visit:update", "visit:complete",
      "sms:view", "sms:send"
    ]
  },
  {
    code: "readonly",
    name: "只读模板",
    description: "只允许查看基础数据",
    role: null,
    permissions: [
      "dashboard:view", "customer:view", "record:view", "visit:view", "store:view", "log:view"
    ]
  },
  {
    code: "operation-config",
    name: "运营配置模板",
    description: "适合维护训练项目、卡项和系统设置",
    role: null,
    permissions: [
      "dashboard:view",
      "training:view", "training:create", "training:update", "training:status", "training:delete",
      "card-template:view", "card-template:create", "card-template:update", "card-template:status", "card-template:delete",
      "system:view", "system:update",
      "customer:view"
    ]
  },
  {
    code: "data-admin",
    name: "数据管理员模板",
    description: "适合备份、恢复、导入和审计",
    role: null,
    permissions: [
      "dashboard:view", "data-center:view", "data-center:backup", "data-center:auto-backup", "data-center:restore", "data-center:download", "data-center:delete", "data-center:attachment", "data-center:import", "log:view", "report:summary"
    ]
  }
];

function normalizePermissionCodes(codes = []) {
  const allow = new Set(ALL_PERMISSION_CODES);
  return Array.from(
    new Set(
      (Array.isArray(codes) ? codes : [])
        .map(code => String(code || "").trim())
        .filter(code => allow.has(code))
    )
  );
}

let permissionTablesReady = false;
let permissionTablesPromise = null;
let defaultUserPermissionsReady = false;
let defaultUserPermissionsPromise = null;

async function ensurePermissionTables(options = {}) {
  const force = options === true || options?.force === true;

  if (!force && permissionTablesReady) return;
  if (!force && permissionTablesPromise) return permissionTablesPromise;

  permissionTablesPromise = (async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`permissions\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`code\` varchar(100) NOT NULL COMMENT '权限编码',
      \`name\` varchar(100) NOT NULL COMMENT '权限名称',
      \`module\` varchar(50) NOT NULL COMMENT '所属模块',
      \`group_name\` varchar(50) NOT NULL COMMENT '分组名称',
      \`sort_order\` int NOT NULL DEFAULT 0 COMMENT '排序',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_permission_code\` (\`code\`),
      KEY \`idx_permission_module\` (\`module\`),
      KEY \`idx_permission_status\` (\`status\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统权限点表'
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`permission_templates\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`code\` varchar(80) DEFAULT NULL COMMENT '模板编码',
      \`name\` varchar(100) NOT NULL COMMENT '模板名称',
      \`description\` varchar(255) DEFAULT NULL COMMENT '模板说明',
      \`role\` tinyint DEFAULT NULL COMMENT '建议角色',
      \`permissions\` json NOT NULL COMMENT '权限编码JSON数组',
      \`is_system\` tinyint NOT NULL DEFAULT 0 COMMENT '是否系统内置',
      \`sort_order\` int NOT NULL DEFAULT 0 COMMENT '排序',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_permission_template_code\` (\`code\`),
      KEY \`idx_permission_template_status\` (\`status\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='权限模板表'
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`user_permissions\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`user_id\` bigint unsigned NOT NULL COMMENT '用户ID',
      \`permission_code\` varchar(100) NOT NULL COMMENT '权限编码',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_user_permission\` (\`user_id\`, \`permission_code\`),
      KEY \`idx_user_permissions_user\` (\`user_id\`),
      KEY \`idx_user_permissions_code\` (\`permission_code\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户权限表'
  `);

  const permissionRows = [];
  let sort = 1;
  for (const group of PERMISSION_GROUPS) {
    for (const permission of group.permissions) {
      permissionRows.push([
        permission.code,
        permission.name,
        group.module,
        group.groupName,
        sort++
      ]);
    }
  }

  if (permissionRows.length) {
    const placeholders = permissionRows.map(() => "(?, ?, ?, ?, ?, 1)").join(", ");
    await pool.execute(
      `INSERT INTO permissions (code, name, module, group_name, sort_order, status)
       VALUES ${placeholders}
       ON DUPLICATE KEY UPDATE name = VALUES(name), module = VALUES(module), group_name = VALUES(group_name), sort_order = VALUES(sort_order), status = 1`,
      permissionRows.flat()
    );
  }

  const templateRows = [];
  let templateSort = 1;
  for (const template of TEMPLATE_DEFINITIONS) {
    templateRows.push([
      template.code,
      template.name,
      template.description,
      template.role,
      JSON.stringify(normalizePermissionCodes(template.permissions)),
      templateSort++
    ]);
  }

  if (templateRows.length) {
    const placeholders = templateRows
      .map(() => "(?, ?, ?, ?, CAST(? AS JSON), 1, ?, 1)")
      .join(", ");
    await pool.execute(
      `INSERT INTO permission_templates (code, name, description, role, permissions, is_system, sort_order, status)
       VALUES ${placeholders}
       ON DUPLICATE KEY UPDATE name = VALUES(name), description = VALUES(description), role = VALUES(role), permissions = VALUES(permissions), is_system = 1, sort_order = VALUES(sort_order), status = 1`,
      templateRows.flat()
    );
  }

    permissionTablesReady = true;
  })();

  try {
    return await permissionTablesPromise;
  } finally {
    permissionTablesPromise = null;
  }
}

async function getUserPermissionCodes(userId, role) {
  if (Number(role) === ROLE_ADMIN) return [ALL_PERMISSION];
  await ensurePermissionTables();
  const [rows] = await pool.query(
    "SELECT permission_code FROM user_permissions WHERE user_id = ? ORDER BY permission_code ASC",
    [Number(userId)]
  );
  return rows.map(row => row.permission_code);
}

async function setUserPermissionCodes(userId, codes = []) {
  await ensurePermissionTables();
  const normalized = normalizePermissionCodes(codes);
  await pool.execute("DELETE FROM user_permissions WHERE user_id = ?", [Number(userId)]);
  for (const code of normalized) {
    await pool.execute(
      "INSERT IGNORE INTO user_permissions (user_id, permission_code) VALUES (?, ?)",
      [Number(userId), code]
    );
  }
  return normalized;
}

function hasPermission(user, permissionCode) {
  if (!user) return false;
  if (Number(user.role) === ROLE_ADMIN) return true;
  const permissions = Array.isArray(user.permissions) ? user.permissions : [];
  return permissions.includes(ALL_PERMISSION) || permissions.includes(permissionCode);
}

function requirePermission(permissionCode) {
  return (req, res, next) => {
    if (hasPermission(req.user, permissionCode)) return next();
    return res.status(403).json({ code: 403, message: "无权限访问", data: null });
  };
}

async function listPermissionGroups() {
  await ensurePermissionTables();
  const [rows] = await pool.query(
    `SELECT code, name, module, group_name AS groupName, sort_order AS sortOrder
     FROM permissions WHERE status = 1 ORDER BY sort_order ASC, id ASC`
  );
  const map = new Map();
  for (const row of rows) {
    if (!map.has(row.groupName)) {
      map.set(row.groupName, { module: row.module, groupName: row.groupName, permissions: [] });
    }
    map.get(row.groupName).permissions.push({ code: row.code, name: row.name, module: row.module });
  }
  return Array.from(map.values());
}

async function listPermissionTemplates() {
  await ensurePermissionTables();
  const [rows] = await pool.query(
    `SELECT id, code, name, description, role, permissions, is_system AS isSystem, sort_order AS sortOrder, status
     FROM permission_templates WHERE status = 1 ORDER BY sort_order ASC, id ASC`
  );
  return rows.map(row => ({
    id: Number(row.id),
    code: row.code || "",
    name: row.name,
    description: row.description || "",
    role: row.role == null ? null : Number(row.role),
    permissions: normalizePermissionCodes(typeof row.permissions === "string" ? JSON.parse(row.permissions || "[]") : row.permissions || []),
    isSystem: Number(row.isSystem || 0) === 1,
    status: Number(row.status || 0)
  }));
}

function defaultPermissionsForRole(role) {
  const template = TEMPLATE_DEFINITIONS.find(item => Number(item.role) === Number(role));
  return normalizePermissionCodes(template?.permissions || ["dashboard:view"]);
}

async function ensureDefaultUserPermissions(options = {}) {
  const force = options === true || options?.force === true;

  if (!force && defaultUserPermissionsReady) return;
  if (!force && defaultUserPermissionsPromise) return defaultUserPermissionsPromise;

  defaultUserPermissionsPromise = (async () => {
    await ensurePermissionTables();
    const [users] = await pool.query("SELECT id, role FROM users WHERE role <> ?", [ROLE_ADMIN]);
    for (const user of users) {
      const [[countRow]] = await pool.query(
        "SELECT COUNT(*) AS total FROM user_permissions WHERE user_id = ?",
        [user.id]
      );
      if (Number(countRow.total || 0) === 0) {
        await setUserPermissionCodes(user.id, defaultPermissionsForRole(user.role));
      }
    }
    defaultUserPermissionsReady = true;
  })();

  try {
    return await defaultUserPermissionsPromise;
  } finally {
    defaultUserPermissionsPromise = null;
  }
}

module.exports = {
  ALL_PERMISSION,
  PERMISSION_GROUPS,
  TEMPLATE_DEFINITIONS,
  ALL_PERMISSION_CODES,
  ensurePermissionTables,
  normalizePermissionCodes,
  getUserPermissionCodes,
  setUserPermissionCodes,
  hasPermission,
  requirePermission,
  listPermissionGroups,
  listPermissionTemplates,
  defaultPermissionsForRole,
  ensureDefaultUserPermissions
};
