const crypto = require("crypto");
const { pool } = require("../config/db");

const API_KEY_PREFIX = "vvk";
const DEFAULT_SCOPES = ["*"];
const API_KEY_BLOCKED_PREFIXES = [
  "/api/install",
  "/api/auth",
  "/api/users",
  "/api/permissions",
  "/api/logs",
  "/api/api-keys",
  "/api/system-settings",
  "/api/runtime-config",
  "/api/system-update",
  "/api/tools/data-center",
  "/api/sms",
];
const API_KEY_SCOPE_OPTIONS = [
  { value: "*", label: "全部业务接口", group: "全部", description: "开放全部业务接口，但不包含账号、权限、配置、备份、系统更新、短信和 API Key 管理。" },
  { value: "GET:/api/dashboard", label: "首页数据（只读）", group: "数据读取", description: "读取首页概览、通知和天气。" },
  { value: "GET:/api/customers", label: "客户档案（只读）", group: "客户", description: "查询客户列表、详情、卡项和客户记录。" },
  { value: "POST,PUT,PATCH:/api/customers", label: "客户档案（写入）", group: "客户", description: "新增、修改、启停、开卡、续卡及客户业务操作。" },
  { value: "GET,POST:/api/verify", label: "核销业务", group: "核销", description: "读取可核销客户并提交核销。" },
  { value: "GET:/api/visits", label: "来访记录（只读）", group: "来访", description: "读取来访名单、汇总和导出记录。" },
  { value: "POST,PUT:/api/visits", label: "来访记录（登记）", group: "来访", description: "登记、修改或移除来访记录。" },
  { value: "GET:/api/records", label: "核销记录（只读）", group: "核销", description: "查询核销记录和详情。" },
  { value: "POST,PATCH:/api/records", label: "核销记录（操作）", group: "核销", description: "提交撤销申请及处理记录操作。" },
  { value: "GET:/api/training-projects", label: "训练项目（只读）", group: "基础资料", description: "读取训练项目。" },
  { value: "GET:/api/card-templates", label: "卡项模板（只读）", group: "基础资料", description: "读取卡项模板。" },
  { value: "GET:/api/stores", label: "门店资料（只读）", group: "基础资料", description: "读取当前账号有权访问的门店。" },
  { value: "GET:/api/reports", label: "报表导出（只读）", group: "报表", description: "导出当前账号数据范围内的报表。" },
  { value: "GET:/api/tools/openapi", label: "OpenAPI 文档", group: "开发工具", description: "读取 OpenAPI JSON。" },
];

let ensureTablePromise = null;
let ensureLogTablePromise = null;

const CREATE_API_KEYS_TABLE_SQL = `
  CREATE TABLE IF NOT EXISTS \`external_api_keys\` (
    \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    \`name\` varchar(100) NOT NULL COMMENT '密钥名称',
    \`key_prefix\` varchar(20) NOT NULL COMMENT '密钥前缀',
    \`key_hash\` varchar(128) NOT NULL COMMENT '密钥哈希',
    \`user_id\` bigint unsigned NOT NULL COMMENT '绑定用户ID',
    \`scopes\` text DEFAULT NULL COMMENT '权限范围(JSON数组)',
    \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
    \`expires_at\` datetime DEFAULT NULL COMMENT '过期时间',
    \`last_used_at\` datetime DEFAULT NULL COMMENT '最后使用时间',
    \`last_used_ip\` varchar(64) DEFAULT NULL COMMENT '最后使用IP',
    \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
    \`created_by\` bigint unsigned DEFAULT NULL COMMENT '创建人ID',
    \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (\`id\`),
    UNIQUE KEY \`uk_external_api_key_hash\` (\`key_hash\`),
    KEY \`idx_external_api_key_user_id\` (\`user_id\`),
    KEY \`idx_external_api_key_status\` (\`status\`),
    KEY \`idx_external_api_key_expires_at\` (\`expires_at\`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='外部系统API密钥表'
`;

const CREATE_API_KEY_LOGS_TABLE_SQL = `
  CREATE TABLE IF NOT EXISTS \`external_api_key_logs\` (
    \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    \`api_key_id\` bigint unsigned NOT NULL COMMENT 'API Key ID',
    \`user_id\` bigint unsigned DEFAULT NULL COMMENT '绑定用户ID',
    \`request_method\` varchar(10) NOT NULL COMMENT '请求方法',
    \`request_path\` varchar(255) NOT NULL COMMENT '请求路径',
    \`status_code\` int NOT NULL DEFAULT 200 COMMENT '响应状态码',
    \`duration_ms\` int NOT NULL DEFAULT 0 COMMENT '耗时毫秒',
    \`ip\` varchar(64) DEFAULT NULL COMMENT '请求IP',
    \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (\`id\`),
    KEY \`idx_external_api_key_logs_key_id\` (\`api_key_id\`),
    KEY \`idx_external_api_key_logs_user_id\` (\`user_id\`),
    KEY \`idx_external_api_key_logs_created_at\` (\`created_at\`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='外部系统API密钥调用日志表'
`;

function hashApiKey(rawKey = "") {
  return crypto.createHash("sha256").update(String(rawKey)).digest("hex");
}

function generateRawApiKey() {
  const body = crypto.randomBytes(24).toString("hex");
  return `${API_KEY_PREFIX}_${body}`;
}

function getKeyPrefix(rawKey = "") {
  return String(rawKey).slice(0, 12);
}

function normalizeScopes(scopes) {
  if (!scopes) return [...DEFAULT_SCOPES];

  if (Array.isArray(scopes)) {
    const list = scopes
      .map((item) => String(item || "").trim())
      .filter(Boolean);
    const unique = Array.from(new Set(list));
    if (unique.includes("*")) return ["*"];
    return unique.length ? unique : [...DEFAULT_SCOPES];
  }

  if (typeof scopes === "string") {
    try {
      const parsed = JSON.parse(scopes);
      return normalizeScopes(parsed);
    } catch (error) {
      return normalizeScopes(
        scopes
          .split(/[\n,]/)
          .map((item) => item.trim())
          .filter(Boolean),
      );
    }
  }

  return [...DEFAULT_SCOPES];
}

function normalizeExplicitScopes(scopes) {
  let values = scopes;
  if (typeof scopes === "string") {
    try {
      values = JSON.parse(scopes);
    } catch (error) {
      values = scopes.split(/[\n;]/);
    }
  }
  if (!Array.isArray(values)) return [];
  const list = Array.from(new Set(values.map(item => String(item || "").trim()).filter(Boolean)));
  if (list.includes("*")) return ["*"];
  return list;
}

function isValidScope(scope) {
  if (scope === "*") return true;
  const match = String(scope || "").match(/^([A-Z]+(?:,[A-Z]+)*:)?(\/api\/[A-Za-z0-9_./{}-]+)$/);
  if (!match) return false;
  if (!match[1]) return true;
  const allowedMethods = new Set(["GET", "POST", "PUT", "PATCH", "DELETE"]);
  return match[1].slice(0, -1).split(",").every(method => allowedMethods.has(method));
}

function isApiKeyPathBlocked(requestPath = "") {
  const path = String(requestPath || "").replace(/\/+$/, "") || "/";
  return API_KEY_BLOCKED_PREFIXES.some(prefix => path === prefix || path.startsWith(`${prefix}/`));
}

function pathMatchesScope(requestPath, scopePath) {
  const path = String(requestPath || "").replace(/\/+$/, "") || "/";
  const allowed = String(scopePath || "").replace(/\/+$/, "") || "/";
  return path === allowed || path.startsWith(`${allowed}/`);
}

function serializeScopes(scopes) {
  return JSON.stringify(normalizeScopes(scopes));
}

async function ensureApiKeyTable() {
  if (!ensureTablePromise) {
    ensureTablePromise = pool.query(CREATE_API_KEYS_TABLE_SQL).catch((error) => {
      ensureTablePromise = null;
      throw error;
    });
  }

  await ensureTablePromise;
}

async function ensureApiKeyLogTable() {
  if (!ensureLogTablePromise) {
    ensureLogTablePromise = pool.query(CREATE_API_KEY_LOGS_TABLE_SQL).catch((error) => {
      ensureLogTablePromise = null;
      throw error;
    });
  }

  await ensureLogTablePromise;
}

async function recordApiKeyUsageLog(payload = {}) {
  await ensureApiKeyLogTable();

  await pool.execute(
    `
      INSERT INTO external_api_key_logs
      (api_key_id, user_id, request_method, request_path, status_code, duration_ms, ip)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `,
    [
      Number(payload.apiKeyId || 0),
      payload.userId == null ? null : Number(payload.userId),
      String(payload.requestMethod || "GET").slice(0, 10),
      String(payload.requestPath || "").slice(0, 255),
      Number(payload.statusCode || 200),
      Number(payload.durationMs || 0),
      String(payload.ip || "").slice(0, 64) || null,
    ],
  );
}

/**
 * 检查 API Key 的 scope 是否允许当前请求。
 *
 * Scope 格式支持：
 *   "*"                — 所有权限
 *   "/api/customers"   — 该路径下所有方法（向后兼容）
 *   "GET:/api/customers"     — 仅 GET
 *   "POST:/api/customers"    — 仅 POST
 *   "GET,POST:/api/customers" — 多个方法
 *
 * @param {string[]} scopes — API Key 的权限范围
 * @param {string} requestPath — 请求路径
 * @param {string} requestMethod — 请求方法 (GET/POST/PUT/DELETE)
 */
function isScopeAllowed(scopes = DEFAULT_SCOPES, requestPath = "", requestMethod = "GET") {
  if (isApiKeyPathBlocked(requestPath)) return false;
  const normalizedScopes = normalizeScopes(scopes);

  if (normalizedScopes.includes("*")) {
    return true;
  }

  const method = String(requestMethod || "GET").toUpperCase();

  return normalizedScopes.some((scope) => {
    // 格式: "METHOD:/path" 或 "/path"（向后兼容）
    const colonIdx = scope.indexOf(":");
    if (colonIdx > 0 && colonIdx < scope.length - 1) {
      const methodsPart = scope.slice(0, colonIdx); // e.g. "GET,POST"
      const pathPart = scope.slice(colonIdx + 1);   // e.g. "/api/customers"
      const allowedMethods = methodsPart.split(",").map((m) => m.trim().toUpperCase());
      return allowedMethods.includes(method) && pathMatchesScope(requestPath, pathPart);
    }

    // 无 method 前缀 → 所有方法
    return pathMatchesScope(requestPath, scope);
  });
}

module.exports = {
  API_KEY_PREFIX,
  DEFAULT_SCOPES,
  API_KEY_BLOCKED_PREFIXES,
  API_KEY_SCOPE_OPTIONS,
  CREATE_API_KEYS_TABLE_SQL,
  CREATE_API_KEY_LOGS_TABLE_SQL,
  ensureApiKeyTable,
  ensureApiKeyLogTable,
  hashApiKey,
  generateRawApiKey,
  getKeyPrefix,
  normalizeScopes,
  normalizeExplicitScopes,
  isValidScope,
  isApiKeyPathBlocked,
  serializeScopes,
  isScopeAllowed,
  recordApiKeyUsageLog,
};
