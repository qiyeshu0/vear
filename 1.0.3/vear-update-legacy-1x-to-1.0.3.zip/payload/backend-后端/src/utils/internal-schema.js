async function ensureSystemSeedHistoryTable(connection) {
  await connection.query(`
    CREATE TABLE IF NOT EXISTS system_seed_history (
      seed_key varchar(100) NOT NULL,
      status varchar(20) NOT NULL DEFAULT 'running',
      details_json json DEFAULT NULL,
      applied_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (seed_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统一次性基础数据任务'
  `);
}

async function ensureSystemUpdateTables(connection) {
  await connection.query(`
    CREATE TABLE IF NOT EXISTS system_update_history (
      id bigint unsigned NOT NULL AUTO_INCREMENT,
      from_version varchar(40) NOT NULL,
      to_version varchar(40) NOT NULL,
      status varchar(30) NOT NULL,
      update_type varchar(30) DEFAULT 'feature',
      changed_files int NOT NULL DEFAULT 0,
      deleted_files int NOT NULL DEFAULT 0,
      backup_path varchar(500) DEFAULT NULL,
      package_sha256 varchar(64) DEFAULT NULL,
      operator_id bigint unsigned DEFAULT NULL,
      operator_name varchar(100) DEFAULT NULL,
      message text DEFAULT NULL,
      details_json json DEFAULT NULL,
      started_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      completed_at datetime DEFAULT NULL,
      created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_system_update_status (status),
      KEY idx_system_update_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统在线更新记录'
  `);
  await connection.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      id varchar(120) NOT NULL,
      version varchar(40) NOT NULL,
      checksum varchar(64) DEFAULT NULL,
      applied_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_schema_migration_version (version)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据库迁移记录'
  `);
}

async function ensureInternalSystemTables(connection) {
  await ensureSystemSeedHistoryTable(connection);
  await ensureSystemUpdateTables(connection);
}

module.exports = {
  ensureSystemSeedHistoryTable,
  ensureSystemUpdateTables,
  ensureInternalSystemTables,
};
