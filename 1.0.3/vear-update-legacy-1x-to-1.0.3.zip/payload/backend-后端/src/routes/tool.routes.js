const express = require("express");
const { auth, requireAnyUserPermission } = require("../middleware/auth");
const controller = require("../controllers/tool.controller");

const router = express.Router();

router.get("/openapi", controller.getOpenApiSpec);
router.get("/meta", auth(), requireAnyUserPermission(["tool:api-test", "tool:meta"]), controller.getToolMeta);

module.exports = router;
