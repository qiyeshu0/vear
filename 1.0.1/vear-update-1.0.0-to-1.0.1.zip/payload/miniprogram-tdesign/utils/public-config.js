/**
 * 小程序公开配置中心
 *
 * 原则：
 * 1. 小程序只保留 apiBase 这种“启动前必须知道”的地址。
 * 2. 系统标题、首页显示规则、订阅消息模板 ID 都从后端 /api/wx/config 获取。
 * 3. 通知模板使用业务场景字典，不再写死 subscribeTmplId / glassesSubscribeTmplId 两个字段。
 */
var config = require('./config');

var STORAGE_KEY = 'wx_public_config';
var localCfg = config.getConfig() || {};

var NOTIFY_SCENES = {
  VERIFY_SUCCESS: 'verify_success',
  GLASSES_STATUS: 'glasses_status',
  CARD_LOW_TIMES: 'card_low_times',
  CARD_EXPIRE_SOON: 'card_expire_soon',
  FOLLOWUP: 'followup',
  GLASSES_DELIVERED_FOLLOWUP: 'glasses_delivered_followup'
};

var DEFAULT_PUBLIC_CONFIG = {
  system: {
    name: '训练助手',
    subtitle: '视界记录本'
  },
  features: {
    // 这里的含义是“员工入口隐藏后可通过连续点击 6 次唤起”，不是直接暴露入口。
    enableStaffHiddenEntry: localCfg.enableStaffHiddenEntry !== false,
    showGlassesProgress: true,
    showTrainingCard: true
  },
  home: {
    glassesKeepDaysAfterDelivered: 15,
    recentVerifyLimit: 5,
    glassesLimit: 2
  },
  notificationTemplates: {
    verify_success: localCfg.subscribeTmplId || '',
    glasses_status: localCfg.glassesSubscribeTmplId || '',
    card_low_times: '',
    card_expire_soon: '',
    followup: '',
    glasses_delivered_followup: ''
  },
  // 兼容旧字段，后续页面全部改完后可以删除。
  subscribeTmplId: localCfg.subscribeTmplId || '',
  glassesSubscribeTmplId: localCfg.glassesSubscribeTmplId || ''
};

var currentConfig = mergeConfig(DEFAULT_PUBLIC_CONFIG, readCache());

function clone(obj) {
  return JSON.parse(JSON.stringify(obj || {}));
}

function boolValue(value, fallback) {
  if (value === undefined || value === null || value === '') return !!fallback;
  return value === true || value === 1 || String(value) === '1' || String(value).toLowerCase() === 'true';
}

function intValue(value, fallback) {
  var n = Number(value);
  if (!isFinite(n) || n < 0) return Number(fallback || 0);
  return Math.floor(n);
}

function uniq(arr) {
  var result = [];
  (arr || []).forEach(function(item) {
    if (item && result.indexOf(item) === -1) result.push(item);
  });
  return result;
}

function readCache() {
  try {
    return wx.getStorageSync(STORAGE_KEY) || {};
  } catch (e) {
    return {};
  }
}

function writeCache(value) {
  try {
    wx.setStorageSync(STORAGE_KEY, value || {});
  } catch (e) {}
}

function normalizeServerConfig(data) {
  data = data || {};
  var templates = Object.assign(
    {},
    data.notificationTemplates || {},
    {
      verify_success: (data.notificationTemplates && data.notificationTemplates.verify_success) || data.subscribeTmplId || '',
      glasses_status: (data.notificationTemplates && data.notificationTemplates.glasses_status) || data.glassesSubscribeTmplId || ''
    }
  );

  return {
    system: {
      name: (data.system && data.system.name) || data.title || '',
      subtitle: (data.system && data.system.subtitle) || data.subtitle || ''
    },
    features: {
      enableStaffHiddenEntry: data.features ? data.features.enableStaffHiddenEntry : data.enableStaffHiddenEntry,
      showGlassesProgress: data.features ? data.features.showGlassesProgress : data.showGlassesProgress,
      showTrainingCard: data.features ? data.features.showTrainingCard : data.showTrainingCard
    },
    home: {
      glassesKeepDaysAfterDelivered: data.home ? data.home.glassesKeepDaysAfterDelivered : data.homeGlassesKeepDays,
      recentVerifyLimit: data.home ? data.home.recentVerifyLimit : data.homeRecentVerifyLimit,
      glassesLimit: data.home ? data.home.glassesLimit : data.homeGlassesLimit
    },
    notificationTemplates: templates,
    subscribeTmplId: data.subscribeTmplId || templates.verify_success || '',
    glassesSubscribeTmplId: data.glassesSubscribeTmplId || templates.glasses_status || ''
  };
}

function mergeConfig(base, incoming) {
  base = clone(base || DEFAULT_PUBLIC_CONFIG);
  incoming = normalizeServerConfig(incoming || {});

  var next = {
    system: {
      name: incoming.system.name || base.system.name || DEFAULT_PUBLIC_CONFIG.system.name,
      subtitle: incoming.system.subtitle || base.system.subtitle || DEFAULT_PUBLIC_CONFIG.system.subtitle
    },
    features: {
      enableStaffHiddenEntry: boolValue(incoming.features.enableStaffHiddenEntry, base.features.enableStaffHiddenEntry),
      showGlassesProgress: boolValue(incoming.features.showGlassesProgress, base.features.showGlassesProgress),
      showTrainingCard: boolValue(incoming.features.showTrainingCard, base.features.showTrainingCard)
    },
    home: {
      glassesKeepDaysAfterDelivered: intValue(incoming.home.glassesKeepDaysAfterDelivered, base.home.glassesKeepDaysAfterDelivered),
      recentVerifyLimit: intValue(incoming.home.recentVerifyLimit, base.home.recentVerifyLimit),
      glassesLimit: intValue(incoming.home.glassesLimit, base.home.glassesLimit)
    },
    notificationTemplates: Object.assign({}, base.notificationTemplates || {}, incoming.notificationTemplates || {})
  };

  next.subscribeTmplId = incoming.subscribeTmplId || next.notificationTemplates.verify_success || '';
  next.glassesSubscribeTmplId = incoming.glassesSubscribeTmplId || next.notificationTemplates.glasses_status || '';
  next.notificationTemplates.verify_success = next.notificationTemplates.verify_success || next.subscribeTmplId || '';
  next.notificationTemplates.glasses_status = next.notificationTemplates.glasses_status || next.glassesSubscribeTmplId || '';
  return next;
}

function getPublicConfig() {
  return clone(currentConfig);
}

function setPublicConfig(next) {
  currentConfig = mergeConfig(currentConfig, next || {});
  writeCache(currentConfig);
  return getPublicConfig();
}

function getNotificationTemplate(scene) {
  var cfg = currentConfig || DEFAULT_PUBLIC_CONFIG;
  return (cfg.notificationTemplates && cfg.notificationTemplates[scene]) || '';
}

function getNotificationTemplates(scenes) {
  scenes = scenes || [];
  return uniq(scenes.map(function(scene) { return getNotificationTemplate(scene); }));
}

function applyToGlobalData(app, cfg) {
  if (!app || !app.globalData) return cfg || getPublicConfig();
  cfg = cfg || getPublicConfig();
  app.globalData.publicConfig = cfg;
  app.globalData.notificationTemplates = cfg.notificationTemplates || {};
  app.globalData.systemTitle = cfg.system && cfg.system.name || DEFAULT_PUBLIC_CONFIG.system.name;
  app.globalData.systemSubtitle = cfg.system && cfg.system.subtitle || DEFAULT_PUBLIC_CONFIG.system.subtitle;
  app.globalData.features = cfg.features || {};
  app.globalData.homeConfig = cfg.home || {};
  app.globalData.enableStaffHiddenEntry = cfg.features ? cfg.features.enableStaffHiddenEntry : true;
  app.globalData.subscribeTmplId = cfg.subscribeTmplId || getNotificationTemplate(NOTIFY_SCENES.VERIFY_SUCCESS);
  app.globalData.glassesSubscribeTmplId = cfg.glassesSubscribeTmplId || getNotificationTemplate(NOTIFY_SCENES.GLASSES_STATUS);
  return cfg;
}

function refreshPublicConfig(callback) {
  var apiBase = (localCfg && localCfg.apiBase) || '';
  try {
    var app = getApp();
    if (app && app.globalData && app.globalData.apiBase) apiBase = app.globalData.apiBase;
  } catch (e) {}

  if (!apiBase) {
    if (typeof callback === 'function') callback(null);
    return;
  }

  wx.request({
    url: apiBase + '/config',
    method: 'GET',
    timeout: 5000,
    success: function(res) {
      var body = res.data || {};
      var data = body.data || body || {};
      if (res.statusCode === 200 && body.success !== false) {
        var cfg = setPublicConfig(data);
        try { applyToGlobalData(getApp(), cfg); } catch (e) {}
        if (typeof callback === 'function') callback(cfg);
      } else if (typeof callback === 'function') {
        callback(null);
      }
    },
    fail: function() {
      if (typeof callback === 'function') callback(null);
    }
  });
}

module.exports = {
  STORAGE_KEY: STORAGE_KEY,
  NOTIFY_SCENES: NOTIFY_SCENES,
  DEFAULT_PUBLIC_CONFIG: DEFAULT_PUBLIC_CONFIG,
  getPublicConfig: getPublicConfig,
  setPublicConfig: setPublicConfig,
  refreshPublicConfig: refreshPublicConfig,
  applyToGlobalData: applyToGlobalData,
  getNotificationTemplate: getNotificationTemplate,
  getNotificationTemplates: getNotificationTemplates
};
