function messageFromError(err, fallback) {
  if (!err) return fallback || '操作失败，请重试';
  if (typeof err === 'string') return err;
  if (err.message) return err.message;
  if (err.data && err.data.message) return err.data.message;
  if (err.errMsg) return err.errMsg;
  return fallback || '操作失败，请重试';
}

function showError(err, fallback) {
  var msg = messageFromError(err, fallback);
  if (msg && msg.length > 18) {
    wx.showModal({ title: '提示', content: msg, showCancel: false });
  } else {
    wx.showToast({ title: msg || '操作失败', icon: 'none' });
  }
}

function logError(tag, err) {
  try { console.error('[小程序错误][' + tag + ']', err); } catch (e) {}
}

module.exports = {
  messageFromError: messageFromError,
  showError: showError,
  logError: logError
};
