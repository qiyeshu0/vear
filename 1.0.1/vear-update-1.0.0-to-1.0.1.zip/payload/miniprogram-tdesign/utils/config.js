/**
 * 小程序环境配置
 *
 * 发布前请确认：
 * 1. env 改为 'prod'
 * 2. prod.apiBase 改为正式 HTTPS 域名
 * 3. 微信公众平台配置 request/uploadFile/downloadFile 合法域名
 * 4. 后端 .env 关闭 WX_LOGIN_MOCK，并配置真实 WX_APPID/WX_APPSECRET
 */
var ENV = 'prod';

var CONFIG = {
  dev: {
    apiBase: 'https://vear.llqxs.cn/api/wx',
    enableStaffHiddenEntry: true,
    // 订阅模板ID从后端 /api/wx/config 动态获取；这里仅保留本地兜底，默认不写死。
    subscribeTmplId: '',
    glassesSubscribeTmplId: ''
  },
  prod: {
    apiBase: 'https://vear.llqxs.cn/api/wx',
    enableStaffHiddenEntry: true,
    // 订阅模板ID从后端 /api/wx/config 动态获取；后台修改后小程序无需重新发版。
    subscribeTmplId: '',
    glassesSubscribeTmplId: ''
  }
};

function getConfig() {
  return CONFIG[ENV] || CONFIG.dev;
}

function getEnv() {
  return ENV;
}

function isProd() {
  return ENV === 'prod';
}

module.exports = {
  env: ENV,
  getEnv: getEnv,
  getConfig: getConfig,
  isProd: isProd
};
