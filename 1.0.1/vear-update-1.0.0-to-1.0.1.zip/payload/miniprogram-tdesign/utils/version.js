module.exports = {
  version: '1.0.0',
  compatibleSystem: '1.0.x',
  channel: '正式版'
};
