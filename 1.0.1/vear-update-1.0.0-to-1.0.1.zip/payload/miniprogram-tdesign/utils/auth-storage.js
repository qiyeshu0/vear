/**
 * 小程序登录态隔离工具
 * - 家长端使用 parentAccessToken / parentCustomerInfo
 * - 员工端使用 staffAccessToken / staffUserInfo
 * - 兼容读取旧版 accessToken/customerInfo/userInfo，避免老用户升级后被强制异常串号
 */
function getLoginMode() {
  return wx.getStorageSync('loginMode') || '';
}

function getParentToken() {
  return wx.getStorageSync('parentAccessToken') || (getLoginMode() === 'parent' ? wx.getStorageSync('accessToken') : '') || '';
}

function setParentSession(token, customer) {
  wx.setStorageSync('parentAccessToken', token || '');
  if (customer) wx.setStorageSync('parentCustomerInfo', customer);
  wx.setStorageSync('loginMode', 'parent');
}

function clearParentSession() {
  wx.removeStorageSync('parentAccessToken');
  wx.removeStorageSync('parentCustomerInfo');
  if (getLoginMode() === 'parent') {
    wx.removeStorageSync('accessToken');
    wx.removeStorageSync('customerInfo');
    wx.removeStorageSync('loginMode');
  }
}

function getParentCustomer() {
  return wx.getStorageSync('parentCustomerInfo') || (getLoginMode() === 'parent' ? wx.getStorageSync('customerInfo') : null) || null;
}

function getStaffToken() {
  return wx.getStorageSync('staffAccessToken') || (getLoginMode() === 'staff' ? wx.getStorageSync('accessToken') : '') || '';
}

function setStaffSession(token, user) {
  wx.setStorageSync('staffAccessToken', token || '');
  if (user) wx.setStorageSync('staffUserInfo', user);
  wx.setStorageSync('loginMode', 'staff');
}

function clearStaffSession() {
  wx.removeStorageSync('staffAccessToken');
  wx.removeStorageSync('staffUserInfo');
  if (getLoginMode() === 'staff') {
    wx.removeStorageSync('accessToken');
    wx.removeStorageSync('userInfo');
    wx.removeStorageSync('loginMode');
  }
}

function getStaffUser() {
  return wx.getStorageSync('staffUserInfo') || (getLoginMode() === 'staff' ? wx.getStorageSync('userInfo') : null) || null;
}


function getStaffPermissions() {
  var user = getStaffUser() || {};
  return Array.isArray(user.permissions) ? user.permissions : [];
}

function hasStaffPermission(code) {
  var user = getStaffUser() || {};
  if (Number(user.role) === 1) return true;
  var permissions = getStaffPermissions();
  return permissions.indexOf('*:*:*') >= 0 || permissions.indexOf(code) >= 0;
}

function hasAnyStaffPermission(codes) {
  if (!Array.isArray(codes)) return false;
  for (var i = 0; i < codes.length; i++) {
    if (hasStaffPermission(codes[i])) return true;
  }
  return false;
}

function clearLegacyMixedSession() {
  wx.removeStorageSync('accessToken');
  wx.removeStorageSync('customerInfo');
  wx.removeStorageSync('userInfo');
  wx.removeStorageSync('parent_token');
}

module.exports = {
  getLoginMode: getLoginMode,
  getParentToken: getParentToken,
  setParentSession: setParentSession,
  clearParentSession: clearParentSession,
  getParentCustomer: getParentCustomer,
  getStaffToken: getStaffToken,
  setStaffSession: setStaffSession,
  clearStaffSession: clearStaffSession,
  getStaffUser: getStaffUser,
  getStaffPermissions: getStaffPermissions,
  hasStaffPermission: hasStaffPermission,
  hasAnyStaffPermission: hasAnyStaffPermission,
  clearLegacyMixedSession: clearLegacyMixedSession
};
