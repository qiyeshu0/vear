Component({
  properties: {
    title: { type: String, value: '管理端' },
    subtitle: { type: String, value: '视界记录本' },
    home: { type: Boolean, value: false }
  },
  data: {
    statusBarHeight: 24,
    navHeight: 48,
    navTotalHeight: 72,
    canBack: false
  },
  lifetimes: {
    attached: function() {
      var statusBarHeight = 24;
      var navHeight = 48;
      try {
        var sys = wx.getSystemInfoSync ? wx.getSystemInfoSync() : {};
        statusBarHeight = sys.statusBarHeight || statusBarHeight;
        if (wx.getMenuButtonBoundingClientRect) {
          var rect = wx.getMenuButtonBoundingClientRect();
          if (rect && rect.top && rect.height) {
            navHeight = (rect.top - statusBarHeight) * 2 + rect.height;
          }
        }
      } catch (e) {}
      var pages = getCurrentPages ? getCurrentPages() : [];
      this.setData({
        statusBarHeight: statusBarHeight,
        navHeight: navHeight,
        navTotalHeight: statusBarHeight + navHeight,
        canBack: pages.length > 1 && !this.properties.home
      });
    }
  },
  methods: {
    goBack: function() {
      var pages = getCurrentPages ? getCurrentPages() : [];
      if (pages.length > 1) {
        wx.navigateBack({ delta: 1 });
        return;
      }
      wx.reLaunch({ url: '/pages/staff/home/home' });
    }
  }
});
