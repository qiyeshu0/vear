var api = require('../../utils/api');
var authStorage = require('../../utils/auth-storage');
var publicConfig = require('../../utils/public-config');
var app = getApp();

Page({
  data: {
    phone: '',
    username: '',
    password: '',
    loading: false,
    isStaff: false,
    _emptyTapCount: 0,
    brandName: '视界记录本',
    brandSubtitle: '训练进度 · 核销记录 · 视力档案',
    staffEntryEnabled: !!(app.globalData && app.globalData.enableStaffHiddenEntry)
  },

  onLoad: function() {
    var that = this;
    this.applyPublicConfig();
    if (app.refreshPublicConfig) {
      app.refreshPublicConfig(function() {
        that.applyPublicConfig();
        that.setData({ staffEntryEnabled: !!(app.globalData && app.globalData.enableStaffHiddenEntry) });
      });
    }
    var mode = wx.getStorageSync('loginMode') || '';
    if (mode === 'staff' && authStorage.getStaffToken()) {
      wx.reLaunch({ url: '/pages/staff/home/home' });
      return;
    }
    if (mode !== 'staff' && authStorage.getParentToken()) {
      wx.reLaunch({ url: '/pages/home/home' });
    }
  },

  applyPublicConfig: function() {
    var cfg = (app.globalData && app.globalData.publicConfig) || publicConfig.getPublicConfig();
    var name = cfg.system && cfg.system.name || '训练助手';
    var subtitle = cfg.system && cfg.system.subtitle || '视界记录本';
    this.setData({
      brandName: subtitle || name,
      brandSubtitle: name === subtitle ? '训练进度 · 核销记录 · 视力档案' : name + ' · 训练进度 · 核销记录'
    });
  },

  onInput: function(e) { this.setData({ phone: e.detail.value, _emptyTapCount: 0 }); },
  onUserInput: function(e) { this.setData({ username: e.detail.value }); },
  onPwdInput: function(e) { this.setData({ password: e.detail.value }); },

  // 家长登录
  doBind: async function() {
    var phone = this.data.phone;

    // 空手机号 → 计数，6次切管理模式
    if (!phone || phone.length === 0) {
      var count = (this.data._emptyTapCount || 0) + 1;
      this.setData({ _emptyTapCount: count });
      if (count >= 6 && app.globalData && app.globalData.enableStaffHiddenEntry) {
        this.showStaffLogin();
        return;
      }
      wx.showToast({ title: '请输入手机号', icon: 'none' });
      return;
    }

    if (!(app.globalData && app.globalData.enableStaffHiddenEntry) && !this.data.isStaff && (!phone || phone.length === 0)) {
      wx.showToast({ title: '请输入手机号', icon: 'none' });
      return;
    }

    if (phone.length !== 11) {
      wx.showToast({ title: '请输入 11 位手机号', icon: 'none' });
      return;
    }

    this.setData({ loading: true });
    try {
      var code = '';
      try {
        var loginRes = await new Promise(function(resolve, reject) {
          wx.login({ success: resolve, fail: reject });
        });
        code = loginRes.code;
      } catch (e) {
        wx.showToast({ title: '微信登录失败，请重试', icon: 'none' });
        this.setData({ loading: false });
        return;
      }

      var result = await api.bindPhone(code, phone);
      this.saveLogin(result);
      wx.showToast({ title: '登录成功', icon: 'success' });
      setTimeout(function() { wx.reLaunch({ url: '/pages/home/home' }); }, 600);
    } catch (err) {
      // request.js 已处理
    } finally {
      this.setData({ loading: false });
    }
  },

  // 管理员登录
  doStaffLogin: async function() {
    var username = this.data.username.trim();
    var password = this.data.password.trim();

    if (!username || !password) {
      wx.showToast({ title: '请输入用户名和密码', icon: 'none' });
      return;
    }

    this.setData({ loading: true });
    try {
      var result = await api.staffLogin(username, password);
      authStorage.setStaffSession(result.accessToken, Object.assign({}, result.user || {}, { permissions: result.permissions || [] }));
      authStorage.clearLegacyMixedSession();
      app.globalData.token = result.accessToken;
      app.globalData.isLogin = true;
      wx.showToast({ title: '登录成功', icon: 'success' });
      setTimeout(function() { wx.reLaunch({ url: '/pages/staff/home/home' }); }, 600);
    } catch (err) {
      // request.js 已处理
    } finally {
      this.setData({ loading: false });
    }
  },

  showStaffLogin: function() {
    if (!(app.globalData && app.globalData.enableStaffHiddenEntry)) {
      wx.showToast({ title: '管理入口未开放', icon: 'none' });
      return;
    }
    this.setData({ isStaff: true, _emptyTapCount: 0 });
  },

  switchParent: function() {
    this.setData({ isStaff: false, username: '', password: '', _emptyTapCount: 0 });
  },

  saveLogin: function(result) {
    authStorage.setParentSession(result.accessToken, result.customer);
    authStorage.clearLegacyMixedSession();
    if (result.accounts && result.accounts.length) {
      wx.setStorageSync('wx_accounts', result.accounts);
    } else if (result.customer) {
      wx.setStorageSync('wx_accounts', [result.customer]);
    }
    wx.setStorageSync('wx_bound', true);
    app.globalData.token = result.accessToken;
    app.globalData.isLogin = true;
    app.globalData.customerInfo = result.customer;
  }
});
