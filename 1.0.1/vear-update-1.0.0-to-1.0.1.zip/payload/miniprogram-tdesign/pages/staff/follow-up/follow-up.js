function pad2(n) { n = Number(n) || 0; return n < 10 ? '0' + n : '' + n; }
var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');
function nowText(){var d=new Date();return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate())+' '+pad2(d.getHours())+':'+pad2(d.getMinutes());}
Page({
  data:{ id:0, recordTime:'', result:'已回访', content:'', remark:'', submitting:false },
  onLoad:function(o){ this.setData({ id:Number(o.id)||0, recordTime: nowText() }); },
  onInput:function(e){ var d={}; d[e.currentTarget.dataset.key]=e.detail.value; this.setData(d); },
  submit: async function(){
    if(!this.data.id) return wx.showToast({title:'参数错误',icon:'none'});
    if(!this.data.result.trim()) return wx.showToast({title:'请填写回访结果',icon:'none'});
    if(!this.data.content.trim()) return wx.showToast({title:'请填写回访内容',icon:'none'});
    this.setData({submitting:true});
    try{ await api.createFollowUp(this.data.id,{recordTime:this.data.recordTime,result:this.data.result,content:this.data.content,remark:this.data.remark}); wx.showToast({title:'已保存',icon:'success'}); setTimeout(function(){wx.navigateBack();},700); }
    catch(e){ console.error('[新增回访失败]',e); errorUtil.modal('新增回访失败', e, '新增回访失败，请检查填写内容'); }
    finally{ this.setData({submitting:false}); }
  }
});
