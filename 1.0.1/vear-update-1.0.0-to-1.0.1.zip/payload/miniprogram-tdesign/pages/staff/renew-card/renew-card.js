function pad2(n) { n = Number(n) || 0; return n < 10 ? '0' + n : '' + n; }
var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');

function today() { var d = new Date(); return d.getFullYear() + '-' + pad2(d.getMonth()+1) + '-' + pad2(d.getDate()); }
function addDays(dateStr, days) { var d = new Date(dateStr || today()); d.setDate(d.getDate() + days); return d.getFullYear() + '-' + pad2(d.getMonth()+1) + '-' + pad2(d.getDate()); }
function isFormalActiveCard(card) { return card && !card.isPromotion && Number(card.status) === 1; }
function cardLabel(card) {
  if (!card) return '请选择续卡卡项';
  return (card.cardName || card.trainingProject || '训练卡') + '｜剩' + (card.remainingTimes || 0) + '次｜到期' + (card.expireDate || '—');
}
function decorateCards(cards) {
  return (cards || []).filter(isFormalActiveCard).map(function(card) {
    card._label = cardLabel(card);
    return card;
  });
}

Page({
  data: {
    id: 0,
    currentExpire: '', currentTotal: '', currentUsed: '',
    cardList: [], selectedCardIndex: -1, selectedCard: null, selectedCardLabel: '加载中...',
    addTimes: '', newExpireDate: '', remark: '', submitting: false, loading: false, isExpired: false, expiredClass: ''
  },

  onLoad: function(options) {
    var exp = options.expire || '';
    var total = options.total || '';
    var used = options.used || '';
    var isExpired = exp && new Date(exp) < new Date();
    var baseDate = exp && exp > today() ? exp : today();
    this.setData({
      id: parseInt(options.id) || 0,
      currentExpire: exp, currentTotal: total, currentUsed: used, isExpired: isExpired, expiredClass: isExpired ? 'text-danger' : '',
      newExpireDate: addDays(baseDate, 90)
    });
    this.loadCards();
  },

  loadCards: async function() {
    if (!this.data.id) return;
    this.setData({ loading: true });
    try {
      var detail = await api.getCustomerDetail(this.data.id);
      var cards = decorateCards(detail.customerCards || []);
      var currentId = detail.currentCardId || (detail.currentCard && detail.currentCard.id);
      var idx = cards.findIndex(function(card) { return Number(card.id) === Number(currentId); });
      if (idx < 0 && cards.length) idx = 0;
      var selected = idx >= 0 ? cards[idx] : null;
      var exp = selected ? (selected.expireDate || '') : (detail.expireDate || this.data.currentExpire || '');
      var isExpired = exp && new Date(exp) < new Date();
      var baseDate = exp && exp > today() ? exp : today();
      this.setData({
        cardList: cards,
        selectedCardIndex: idx,
        selectedCard: selected,
        selectedCardLabel: selected ? selected._label : '暂无可续卡的有效训练卡',
        currentExpire: exp,
        currentTotal: selected ? selected.totalTimes : (detail.totalTimes || this.data.currentTotal),
        currentUsed: selected ? selected.usedTimes : (detail.usedTimes || this.data.currentUsed),
        isExpired: isExpired,
        expiredClass: isExpired ? 'text-danger' : '',
        newExpireDate: addDays(baseDate, 90),
        loading: false
      });
    } catch(e) {
      this.setData({ loading: false, selectedCardLabel: '卡项加载失败，请返回重试' });
      errorUtil.toast(e, '续卡卡项加载失败');
    }
  },

  onCardChange: function(e) {
    var idx = parseInt(e.detail.value);
    var card = this.data.cardList[idx];
    if (!card) return;
    var exp = card.expireDate || '';
    var isExpired = exp && new Date(exp) < new Date();
    var baseDate = exp && exp > today() ? exp : today();
    this.setData({
      selectedCardIndex: idx,
      selectedCard: card,
      selectedCardLabel: card._label,
      currentExpire: exp,
      currentTotal: card.totalTimes || 0,
      currentUsed: card.usedTimes || 0,
      isExpired: isExpired,
      expiredClass: isExpired ? 'text-danger' : '',
      newExpireDate: addDays(baseDate, 90)
    });
  },

  onInput: function(e) { var d = {}; d[e.currentTarget.dataset.key] = e.detail.value; this.setData(d); },
  onDateChange: function(e) { var d = {}; d[e.currentTarget.dataset.key] = e.detail.value; this.setData(d); },

  doSubmit: async function() {
    var data = this.data;
    if (!data.selectedCard || !data.selectedCard.id) { wx.showToast({ title:'请选择续卡卡项', icon:'none' }); return; }
    if (!data.addTimes || parseInt(data.addTimes) <= 0) { wx.showToast({ title:'请输入增加次数', icon:'none' }); return; }
    if (!data.newExpireDate) { wx.showToast({ title:'请选择到期日期', icon:'none' }); return; }
    this.setData({ submitting: true });
    try {
      await api.renewCard(data.id, {
        cardId: data.selectedCard.id,
        customerCardId: data.selectedCard.id,
        addTimes: parseInt(data.addTimes), newExpireDate: data.newExpireDate, remark: data.remark || ''
      });
      wx.showToast({ title: '续卡成功', icon: 'success' });
      setTimeout(function() { wx.navigateBack(); }, 800);
    } catch(e) { console.error('[续卡失败]', e); errorUtil.modal('续卡失败', e, '续卡失败，请检查卡项状态、增加次数或到期日期'); } finally { this.setData({ submitting: false }); }
  },
});
