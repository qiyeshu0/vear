var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');

function decorateVerifyOption(item) {
  item = item || {};
  item._remark = item._remark || '';
  item._timesClass = Number(item.remainingTimes || 0) <= 3 ? 'tag-red' : 'tag-green';
  item._projectText = item.trainingProject || '未开卡';
  item._remainingText = '剩' + (item.remainingTimes || 0) + '次';
  item._expireText = '至' + (item.expireDate || '—');
  return item;
}

Page({
  data: { keyword: '', list: [], loading: false, loadError: '', _timer: 0 },

  onShow: function() { this.search(''); },

  onSearch: function(e) {
    var v = e.detail.value;
    this.setData({ keyword: v });
    clearTimeout(this.data._timer);
    var that = this;
    this.data._timer = setTimeout(function() { that.search(v); }, 400);
  },

  onRemarkInput: function(e) {
    var id = e.currentTarget.dataset.id;
    var val = e.detail.value;
    var list = this.data.list;
    var item = list.find(function(x) { return x.id == id; });
    if (item) item._remark = val;
    this.setData({ list: list });
  },

  search: async function(kw) {
    this.setData({ loading: true, loadError: '' });
    try {
      var r = await api.getVerifyOptions(kw, 1);
      var list = (r && r.list || []).map(decorateVerifyOption);
      this.setData({ list: list });
    } catch(e) { console.error('[可核销客户加载失败]', e); this.setData({ loadError: '可核销客户加载失败，请重试' }); } finally { this.setData({ loading: false }); }
  },

  doVerify: function(e) {
    var id = e.currentTarget.dataset.id;
    var name = e.currentTarget.dataset.name;
    var idx = parseInt(e.currentTarget.dataset.idx);
    var item = this.data.list[idx] || {};
    var remark = item._remark || '';
    var cards = item.activeCards || [];
    var that = this;

    function confirmVerify(card) {
      var content = '确认为「' + name + '」核销 1 次吗？';
      if (card) content += '\n卡项：' + (card.cardName || card.trainingProject || '未命名卡项');
      if (remark) content += '\n备注：' + remark;
      wx.showModal({
        title: '确认核销',
        content: content,
        success: async function(res) {
          if (!res.confirm) return;
          try {
            await api.doVerify(id, remark, card && card.id);
            wx.showToast({ title: '核销成功', icon: 'success' });
            that.search(that.data.keyword);
          } catch(err) { console.error('[核销失败]', err); errorUtil.modal('核销失败', err, '核销失败，请检查客户卡次数、有效期或权限'); }
        }
      });
    }

    if (cards.length > 1) {
      wx.showActionSheet({
        itemList: cards.map(function(card) {
          return (card.cardName || card.trainingProject || '未命名卡项') + '（剩' + (card.remainingTimes || 0) + '次）';
        }),
        success: function(res) {
          confirmVerify(cards[res.tapIndex]);
        }
      });
      return;
    }

    confirmVerify(cards[0] || item.currentCard || null);
  },

  goPage: function(e) {
    var p = e.currentTarget.dataset.page;
    wx.reLaunch({ url: '/pages/' + p + '/' + p.split('/').pop() });
  },
});
