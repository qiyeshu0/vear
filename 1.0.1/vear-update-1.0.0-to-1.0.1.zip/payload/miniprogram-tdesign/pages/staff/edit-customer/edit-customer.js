var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');

Page({
  data: {
    id: 0, childName: '', parentName: '', parentPhone: '', gender: '', birthday: '',
    tags: '', remark: '', genders: ['男', '女'], genderLabel: '', submitting: false
  },

  onLoad: function(options) {
    var id = parseInt(options.id) || 0;
    if (!id) { wx.showToast({ title: '参数错误', icon: 'none' }); return; }
    this.setData({ id: id });
    this.loadCustomer(id);
  },

  loadCustomer: async function(id) {
    try {
      var r = await api.getCustomerDetail(id);
      this.setData({
        childName: r.childName || '', parentName: r.parentName || '',
        parentPhone: r.parentPhone || '', gender: r.gender || '',
        genderLabel: r.gender === 1 ? '男' : r.gender === 2 ? '女' : '',
        birthday: r.birthday || '', tags: (r.tags || []).join(','),
        remark: r.remark || ''
      });
    } catch(e) { errorUtil.toast(e, '客户资料加载失败'); }
  },

  onInput: function(e) { var d = {}; d[e.currentTarget.dataset.key] = e.detail.value; this.setData(d); },
  onDate: function(e) { var d = {}; d[e.currentTarget.dataset.key] = e.detail.value; this.setData(d); },
  onPicker: function(e) {
    var idx = e.detail.value;
    this.setData({ gender: idx === 0 ? 1 : 2, genderLabel: idx === 0 ? '男' : '女' });
  },

  doSubmit: async function() {
    var d = this.data;
    if (!d.childName || !d.parentPhone) { wx.showToast({ title: '姓名和电话必填', icon: 'none' }); return; }
    if (d.parentPhone && !/^1[3-9]\d{9}$/.test(d.parentPhone)) { wx.showToast({ title: '手机号格式不正确', icon: 'none' }); return; }
    this.setData({ submitting: true });
    try {
      await api.updateCustomer(d.id, {
        childName: d.childName, parentName: d.parentName, parentPhone: d.parentPhone,
        gender: d.gender || null, birthday: d.birthday || null,
        tags: (d.tags || '').split(/[,，]/).map(function(s) { return s.trim(); }).filter(Boolean),
        remark: d.remark || ''
      });
      wx.showToast({ title: '保存成功', icon: 'success' });
      setTimeout(function() { wx.navigateBack(); }, 800);
    } catch(e) { console.error('[保存客户失败]', e); errorUtil.modal('保存客户失败', e, '保存客户失败，请检查填写内容'); } finally { this.setData({ submitting: false }); }
  },
});
