/**
 * 员工端错误信息提取
 * 目标：不要只显示“操作失败”，而是把后端返回的失败原因展示给门店员工。
 */
function stringifyFallback(err) {
  if (!err) return '';
  if (typeof err === 'string') return err;
  if (err.message) return err.message;
  try { return JSON.stringify(err); } catch (e) { return ''; }
}

function pickMessage(obj) {
  if (!obj) return '';
  if (typeof obj === 'string') return obj;
  var candidates = [obj.message, obj.msg, obj.error, obj.errorMessage, obj.detail, obj.reason];
  if (obj.data) {
    candidates.push(obj.data.message, obj.data.msg, obj.data.error, obj.data.errorMessage, obj.data.detail, obj.data.reason);
  }
  if (obj.response) {
    candidates.push(obj.response.message, obj.response.msg, obj.response.error);
  }
  for (var i = 0; i < candidates.length; i++) {
    if (candidates[i]) return String(candidates[i]);
  }
  return '';
}

function getErrorMessage(err, fallback) {
  var msg = pickMessage(err) || stringifyFallback(err) || fallback || '操作失败，请稍后重试';
  msg = String(msg || '').trim();
  if (!msg || msg === '{}' || msg === '[]') msg = fallback || '操作失败，请稍后重试';
  return msg;
}

function toast(err, fallback) {
  wx.showToast({ title: getErrorMessage(err, fallback), icon: 'none', duration: 2500 });
}

function modal(title, err, fallback) {
  wx.showModal({
    title: title || '操作失败',
    content: getErrorMessage(err, fallback),
    showCancel: false,
    confirmText: '知道了'
  });
}

module.exports = {
  getErrorMessage: getErrorMessage,
  toast: toast,
  modal: modal
};
