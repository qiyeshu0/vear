var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');

Page({
  data: { list: [] },

  onShow: function() { this.load(); },

  load: async function() {
    try { var r = await api.getPendingRevokes(); this.setData({ list: r || [] }); } catch(e) { console.error('[审批列表加载失败]', e); wx.showToast({ title: '审批列表加载失败', icon: 'none' }); }
  },

  doApprove: function(e) {
    var id = e.currentTarget.dataset.id;
    var approved = e.currentTarget.dataset.approved === 'true';
    var that = this;
    var title = approved ? '同意撤回' : '拒绝撤回';
    wx.showModal({
      title: title, content: '确定' + title + '吗？',
      success: async function(res) {
        if (!res.confirm) return;
        try {
          await api.approveRevoke(id, approved, '');
          wx.showToast({ title: approved ? '已撤回' : '已拒绝', icon: 'success' });
          that.load();
        } catch(err) { console.error('[审批操作失败]', err); errorUtil.modal('审批操作失败', err, '审批操作失败，请检查权限或申请状态'); }
      }
    });
  },

  goPage: function(e) { var p = e.currentTarget.dataset.page; wx.reLaunch({ url: '/pages/' + p + '/' + p.split('/').pop() }); },
});
