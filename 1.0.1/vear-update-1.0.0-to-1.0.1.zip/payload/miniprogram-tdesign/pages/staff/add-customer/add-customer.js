function pad2(n) { n = Number(n) || 0; return n < 10 ? '0' + n : '' + n; }
var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');
var req = require('../utils/admin-request');

function today() { var d = new Date(); return d.getFullYear() + '-' + pad2(d.getMonth()+1) + '-' + pad2(d.getDate()); }
function addDays(dateStr, days) { var d = new Date(dateStr); d.setDate(d.getDate() + days); return d.getFullYear() + '-' + pad2(d.getMonth()+1) + '-' + pad2(d.getDate()); }

Page({
  data: {
    mode: 'account', childName: '', parentPhone: '', gender: '', genderLabel: '',
    birthday: '', storeList: [], selectedStore: '', selectedStoreId: 0, remark: '',
    templateList: [], selectedTemplate: null, priceOptions: [], selectedProject: '', cardName: '', totalTimes: '', salePrice: '', expireDate: '',
    genders: ['男', '女'], modeAccountClass: 'seg-active', modeCardClass: '', submitText: '创建客户档案', salePriceLabel: '请选择', selectedTemplateName: '请选择', submitting: false
  },

  onLoad: function() {
    this.setData({ expireDate: addDays(today(), 90) });
    this.loadOptions();
  },

  loadOptions: async function() {
    try { var s = await api.getStoreOptions(); this.setData({ storeList: s || [] }); } catch(e) { console.error('[门店选项加载失败]', e); }
    try { var t = await api.getCardTemplates(); this.setData({ templateList: (t || []).filter(function(x){ return !x.isPromotion; }) }); } catch(e) { console.error('[卡项模板加载失败]', e); errorUtil.toast(e, '卡项模板加载失败'); }
  },

  switchMode: function(e) { var mode = e.currentTarget.dataset.mode; this.setData({ mode: mode, modeAccountClass: mode === 'account' ? 'seg-active' : '', modeCardClass: mode === 'card' ? 'seg-active' : '', submitText: mode === 'card' ? '创建客户并开卡' : '创建客户档案' }); },

  onInput: function(e) { var d = {}; d[e.currentTarget.dataset.key] = e.detail.value; this.setData(d); },
  onDate: function(e) { var d = {}; d[e.currentTarget.dataset.key] = e.detail.value; this.setData(d); },
  onPicker: function(e) {
    var idx = e.detail.value;
    this.setData({ gender: idx === 0 ? 1 : 2, genderLabel: idx === 0 ? '男' : '女' });
  },
  onStoreChange: function(e) {
    var item = this.data.storeList[e.detail.value];
    this.setData({ selectedStore: item.storeName, selectedStoreId: item.id });
  },
  onTemplateChange: function(e) {
    var item = this.data.templateList[e.detail.value];
    var priceOptions = item && item.priceOptions || [];
    this.setData({
      selectedTemplate: item || null,
      selectedProject: item ? item.trainingProject : '',
      cardName: item ? item.cardName : '',
      totalTimes: item ? String(item.defaultTimes || '') : '',
      priceOptions: priceOptions,
      salePrice: priceOptions.length ? String(priceOptions[0]) : this.data.salePrice,
      salePriceLabel: priceOptions.length ? '¥' + String(priceOptions[0]) : '请选择',
      selectedTemplateName: item ? item.cardName : '请选择'
    });
  },
  onPriceChange: function(e) {
    var price = this.data.priceOptions[parseInt(e.detail.value)];
    this.setData({ salePrice: price != null ? String(price) : '', salePriceLabel: price != null ? '¥' + String(price) : '请选择' });
  },

  doSubmit: async function() {
    var d = this.data;
    if (!d.childName || !d.parentPhone) { wx.showToast({ title: '请填写姓名和电话', icon: 'none' }); return; }
    if (!/^1[3-9]\d{9}$/.test(d.parentPhone)) { wx.showToast({ title: '手机号格式不正确', icon: 'none' }); return; }
    if (d.mode === 'card') {
      if (!d.selectedTemplate || !d.selectedTemplate.id) { wx.showToast({ title: '请选择卡项模板', icon: 'none' }); return; }
      if (!d.totalTimes || parseInt(d.totalTimes) <= 0) { wx.showToast({ title: '请填写总次数', icon: 'none' }); return; }
      if (!d.expireDate) { wx.showToast({ title: '请选择到期日期', icon: 'none' }); return; }
    }
    this.setData({ submitting: true });
    try {
      var data = {
        childName: d.childName, parentPhone: d.parentPhone,
        gender: d.gender || null, birthday: d.birthday || null,
        storeId: d.selectedStoreId || null, remark: d.remark || ''
      };
      if (d.mode === 'card') {
        data.customerMode = 'account_and_card';
        data.cardTemplateId = d.selectedTemplate.id;
        data.trainingProject = d.selectedProject;
        data.cardName = d.cardName || d.selectedProject;
        data.totalTimes = parseInt(d.totalTimes);
        data.salePrice = d.salePrice === '' ? null : Number(d.salePrice);
        data.openCardDate = today();
        data.expireDate = d.expireDate;
      } else {
        data.customerMode = 'account_only';
      }
      var r = await req.request({ url: '/api/customers', method: 'POST', data: data });
      wx.showToast({ title: '创建成功', icon: 'success' });
      setTimeout(function() { wx.navigateBack(); }, 800);
    } catch(e) { console.error('[创建客户失败]', e); errorUtil.modal('创建客户失败', e, '创建客户失败，请检查手机号是否已存在或信息是否完整'); } finally { this.setData({ submitting: false }); }
  },
});
