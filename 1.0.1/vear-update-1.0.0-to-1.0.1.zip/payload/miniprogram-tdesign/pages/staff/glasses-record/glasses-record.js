function pad2(n) { n = Number(n) || 0; return n < 10 ? '0' + n : '' + n; }
var api = require('../utils/admin-api');
var errorUtil = require('../utils/error');
function nowText(){var d=new Date();return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate())+' '+pad2(d.getHours())+':'+pad2(d.getMinutes());}

var GLASSES_STATUS_OPTIONS = [
  { value: 1, label: '已下单' },
  { value: 2, label: '定制中' },
  { value: 3, label: '制作中' },
  { value: 4, label: '待取镜' },
  { value: 5, label: '已交付' },
  { value: 6, label: '异常处理中' },
  { value: 7, label: '已取消' }
];

Page({
  data:{id:0,recordTime:'',deliveryStatus:1,statusIndex:0,deliveryStatusOptions:GLASSES_STATUS_OPTIONS,deliveryStatusLabel:'已下单',pd:'',sphereOd:'',cylinderOd:'',axisOd:'',sphereOs:'',cylinderOs:'',axisOs:'',lensBrand:'',lensType:'',frameInfo:'',remark:'',submitting:false},
  onLoad:function(o){this.setData({id:Number(o.id)||0,recordTime:nowText()});},
  onInput:function(e){var d={};d[e.currentTarget.dataset.key]=e.detail.value;this.setData(d);},
  onStatus:function(e){
    var index=Number(e.detail.value)||0;
    var opt=GLASSES_STATUS_OPTIONS[index]||GLASSES_STATUS_OPTIONS[0];
    this.setData({statusIndex:index,deliveryStatus:opt.value,deliveryStatusLabel:opt.label});
  },
  submit:async function(){
    var has=this.data.pd||this.data.sphereOd||this.data.cylinderOd||this.data.axisOd||this.data.sphereOs||this.data.cylinderOs||this.data.axisOs;
    if(!has) return wx.showToast({title:'请至少填写一项参数',icon:'none'});
    this.setData({submitting:true});
    var payload = {
      recordTime:this.data.recordTime,
      deliveryStatus:this.data.deliveryStatus,
      pd:this.data.pd,
      sphereOd:this.data.sphereOd,
      cylinderOd:this.data.cylinderOd,
      axisOd:this.data.axisOd,
      sphereOs:this.data.sphereOs,
      cylinderOs:this.data.cylinderOs,
      axisOs:this.data.axisOs,
      lensBrand:this.data.lensBrand,
      lensType:this.data.lensType,
      frameInfo:this.data.frameInfo,
      remark:this.data.remark
    };
    try{ await api.createGlassesRecord(this.data.id,payload); wx.showToast({title:'已保存',icon:'success'}); setTimeout(function(){wx.navigateBack();},700); }
    catch(e){console.error('[新增配镜记录失败]',e); errorUtil.modal('新增配镜失败', e, '新增配镜失败，请检查验光参数');} finally{this.setData({submitting:false});}
  }
});
