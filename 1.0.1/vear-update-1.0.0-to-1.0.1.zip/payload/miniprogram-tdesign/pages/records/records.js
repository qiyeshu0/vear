const api = require('../../utils/api');
const publicConfig = require('../../utils/public-config');

function pad2(n) { n = Number(n) || 0; return n < 10 ? '0' + n : '' + n; }

var GLASSES_STATUS_LABELS = { 1: '已下单', 2: '定制中', 3: '制作中', 4: '待取镜', 5: '已交付', 6: '异常处理中', 7: '已取消' };
var GLASSES_FLOW = [1, 2, 3, 4, 5];

function decorateGlassesRecord(item) {
  item = item || {};
  var parts = [];
  if (item.lensBrand) parts.push(item.lensBrand);
  if (item.lensType) parts.push(item.lensType);
  item._lensLabel = parts.join(' / ');
  var status = Number(item.deliveryStatus || 1);
  item._deliveryText = item.deliveryStatusLabel || GLASSES_STATUS_LABELS[status] || '已下单';
  item._deliveryClass = status === 5 ? 'tag-green' : (status === 6 || status === 7 ? 'tag-red' : 'tag-orange');
  item._flowSteps = GLASSES_FLOW.map(function(value) {
    return {
      value: value,
      label: GLASSES_STATUS_LABELS[value],
      cls: status >= value && status <= 5 ? 'done' : '',
      dotCls: status === value ? 'current' : (status > value && status <= 5 ? 'done' : '')
    };
  });
  if (status === 6 || status === 7) {
    item._flowExtra = GLASSES_STATUS_LABELS[status];
  } else {
    item._flowExtra = '';
  }
  return item;
}

function decorateVerifyRecord(item) {
  item = item || {};
  item._tagText = item.trainingProject === '退卡' ? '⚠ 退卡' : (item.cardName || item.trainingProject || '核销');
  item._tagClass = item.trainingProject === '退卡' ? 'tag-red' : (item.cardName ? 'tag-orange' : 'tag-blue');
  return item;
}

function makeTabState(activeTab) {
  return {
    showVerify: activeTab === 'verify',
    showChecks: activeTab === 'checks',
    showGlasses: activeTab === 'glasses',
    showRenewals: activeTab === 'renewals',
    tabVerifyClass: activeTab === 'verify' ? 'tab-active' : '',
    tabChecksClass: activeTab === 'checks' ? 'tab-active' : '',
    tabGlassesClass: activeTab === 'glasses' ? 'tab-active' : '',
    tabRenewalsClass: activeTab === 'renewals' ? 'tab-active' : ''
  };
}

Page({
  data: {
    navSubtitle: '视界记录本',
    activeTab: 'verify',
    showVerify: true, showChecks: false, showGlasses: false, showRenewals: false,
    tabVerifyClass: 'tab-active', tabChecksClass: '', tabGlassesClass: '', tabRenewalsClass: '',
    loadError: '', loadingMore: false,
    // verify
    list: [], pageNum: 1, hasMore: false,
    // checks
    checkList: [], checkPage: 1, checkHasMore: false,
    // glasses
    glassesList: [], glassesPage: 1, glassesHasMore: false,
    // renewals
    renewalList: [], renewalPage: 1, renewalHasMore: false
  },

  onLoad(options) {
    // 支持从其他页面跳转时指定 tab
    if (options && options.tab) {
      var tab = options.tab;
      this.setData(Object.assign({ activeTab: tab }, makeTabState(tab)));
      if (tab === 'checks') this.loadCheckRecords(1);
      if (tab === 'glasses') this.loadGlassesRecords(1);
      if (tab === 'renewals') this.loadRenewalRecords(1);
    }
  },

  onShow() {
    this.applyPublicConfig();
    if (this.data.list.length === 0 && this.data.activeTab === 'verify') {
      this.loadVerifyRecords(1);
    }
  },

  onReachBottom() {
    if (this.data.loadingMore) return;
    var tab = this.data.activeTab;
    if (tab === 'verify' && this.data.hasMore) this.loadVerifyRecords(this.data.pageNum + 1);
    if (tab === 'checks' && this.data.checkHasMore) this.loadCheckRecords(this.data.checkPage + 1);
    if (tab === 'glasses' && this.data.glassesHasMore) this.loadGlassesRecords(this.data.glassesPage + 1);
    if (tab === 'renewals' && this.data.renewalHasMore) this.loadRenewalRecords(this.data.renewalPage + 1);
  },

  applyPublicConfig: function() {
    var cfg = publicConfig.getPublicConfig();
    this.setData({ navSubtitle: (cfg.system && cfg.system.subtitle) || '视界记录本' });
  },

  switchTab(e) {
    var tab = e.currentTarget.dataset.tab;
    var sr=require('../../utils/subscribe-helper'); sr.silentRenew(false, null, '记录-切换' + tab);
    this.setData(Object.assign({ activeTab: tab }, makeTabState(tab)));
    if (tab === 'checks' && this.data.checkList.length === 0) this.loadCheckRecords(1);
    if (tab === 'glasses' && this.data.glassesList.length === 0) this.loadGlassesRecords(1);
    if (tab === 'renewals' && this.data.renewalList.length === 0) this.loadRenewalRecords(1);
  },

  // 格式化时间：后端返回 "2026-06-10 19:19:00" 或 ISO格式 → 取 HH:mm
  formatTime(dt) {
    if (!dt) return '';
    var d = new Date(dt);
    if (isNaN(d.getTime())) {
      // 无法解析，尝试直接取 HH:mm
      var t = String(dt);
      var m = t.match(/(\d{2}:\d{2})/);
      return m ? m[1] : '';
    }
    var h = pad2(d.getHours());
    var min = pad2(d.getMinutes());
    return h + ':' + min;
  },

  retry: function() {
    var tab = this.data.activeTab;
    if (tab === 'verify') this.loadVerifyRecords(1);
    if (tab === 'checks') this.loadCheckRecords(1);
    if (tab === 'glasses') this.loadGlassesRecords(1);
    if (tab === 'renewals') this.loadRenewalRecords(1);
  },

  // ─── 核销记录 ───
  async loadVerifyRecords(pageNum) {
    if (pageNum > 1 && this.data.loadingMore) return;
    this.setData({ loadError: '', loadingMore: pageNum > 1 });
    try {
      var result = await api.getVerifyRecords(pageNum, 15);
      var rows = (result.list || []).map(function(item) {
        item._time = this.formatTime(item.verifyTime);
        return decorateVerifyRecord(item);
      }.bind(this));
      var list = pageNum === 1 ? rows : this.data.list.concat(rows);
      this.setData({ list: list, pageNum: pageNum, hasMore: result.list && result.list.length >= 15 });
    } catch (err) { console.error('[核销记录加载失败]', err); this.setData({ loadError: '核销记录加载失败，请重试' }); wx.showToast({ title: '核销记录加载失败', icon: 'none' }); }
    finally { if (pageNum > 1) this.setData({ loadingMore: false }); }
  },

  // ─── 检查记录 ───
  async loadCheckRecords(page) {
    if (page > 1 && this.data.loadingMore) return;
    this.setData({ loadError: '', loadingMore: page > 1 });
    try {
      var result = await api.getVisitChecks(page, 15);
      var checkList = page === 1 ? (result.list || []) : this.data.checkList.concat(result.list || []);
      this.setData({ checkList: checkList, checkPage: page, checkHasMore: result.list && result.list.length >= 15 });
    } catch (err) { console.error('[检查记录加载失败]', err); this.setData({ loadError: '检查记录加载失败，请重试' }); wx.showToast({ title: '检查记录加载失败', icon: 'none' }); }
    finally { if (page > 1) this.setData({ loadingMore: false }); }
  },

  // ─── 配镜记录 ───
  async loadGlassesRecords(page) {
    if (page > 1 && this.data.loadingMore) return;
    this.setData({ loadError: '', loadingMore: page > 1 });
    try {
      var result = await api.getGlassesRecords(page, 15);
      var rows = (result.list || []).map(decorateGlassesRecord);
      var glassesList = page === 1 ? rows : this.data.glassesList.concat(rows);
      this.setData({ glassesList: glassesList, glassesPage: page, glassesHasMore: result.list && result.list.length >= 15 });
    } catch (err) { console.error('[配镜记录加载失败]', err); this.setData({ loadError: '配镜记录加载失败，请重试' }); wx.showToast({ title: '配镜记录加载失败', icon: 'none' }); }
    finally { if (page > 1) this.setData({ loadingMore: false }); }
  },

  // ─── 续卡记录 ───
  async loadRenewalRecords(page) {
    if (page > 1 && this.data.loadingMore) return;
    this.setData({ loadError: '', loadingMore: page > 1 });
    try {
      var result = await api.getRenewals(page, 15);
      var renewalList = page === 1 ? (result.list || []) : this.data.renewalList.concat(result.list || []);
      this.setData({ renewalList: renewalList, renewalPage: page, renewalHasMore: result.list && result.list.length >= 15 });
    } catch (err) { console.error('[续卡记录加载失败]', err); this.setData({ loadError: '续卡记录加载失败，请重试' }); wx.showToast({ title: '续卡记录加载失败', icon: 'none' }); }
    finally { if (page > 1) this.setData({ loadingMore: false }); }
  },

  goPage(e) {
    var page = e.currentTarget.dataset.page;
    var sr=require('../../utils/subscribe-helper'); sr.silentRenew(false, null, '记录-跳转' + page);
    wx.reLaunch({ url: '/pages/' + page + '/' + page });
  },

  renewCurrentPage() { var sr=require('../../utils/subscribe-helper'); sr.silentRenew(false, null, '记录-当前标签'); }
});
