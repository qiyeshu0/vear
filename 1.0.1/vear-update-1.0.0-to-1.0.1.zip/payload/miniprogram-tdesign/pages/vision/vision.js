var api = require('../../utils/api');
var publicConfig = require('../../utils/public-config');

// 视力值最大高度 200rpx, 以 1.5 为满分
var MAX_VISION = 1.5;
var MAX_BAR_H = 200;

function visionToHeight(v) {
  if (v == null) return 0;
  return Math.max(8, Math.min(MAX_BAR_H, (v / MAX_VISION) * MAX_BAR_H));
}

Page({
  data: {
    navSubtitle: '视界记录本',
    list: [],
    latest: null,
    trend: null,
    trendLabel: '',
    loading: false,
    loadError: ''
  },

  onShow: function() {
    this.applyPublicConfig();
    this.loadData();
  },

  applyPublicConfig: function() {
    var cfg = publicConfig.getPublicConfig();
    this.setData({ navSubtitle: (cfg.system && cfg.system.subtitle) || '视界记录本' });
  },

  loadData: async function() {
    this.setData({ loading: true, loadError: '' });
    try {
      var result = await api.getVisionReport();
      var list = result.list || [];
      // 预处理：计算柱子高度 + 短日期
      list.forEach(function(item) {
        item._nakedOdH = visionToHeight(item.nakedOd);
        item._nakedOsH = visionToHeight(item.nakedOs);
        item._correctedOdH = visionToHeight(item.correctedOd);
        item._correctedOsH = visionToHeight(item.correctedOs);
        item._shortDate = (item.date || '').slice(5); // "01-15"
      });

      var trendMap = { up: '📈 视力提升中', down: '📉 需持续关注', stable: '➡️ 视力稳定' };
      this.setData({
        list: list,
        latest: result.latest,
        trend: result.trend,
        trendLabel: trendMap[result.trend] || ''
      });
    } catch (err) { console.error('[视力数据加载失败]', err); this.setData({ loadError: '视力数据加载失败，请检查网络后重试' }); wx.showToast({ title: '视力数据加载失败', icon: 'none' }); }
    finally { this.setData({ loading: false }); }
  },

  retry: function() { this.loadData(); },

  goPage: function(e) {
    var page = e.currentTarget.dataset.page;
    var sr=require('../../utils/subscribe-helper'); sr.silentRenew(false, null, '视力-跳转' + page);
    wx.reLaunch({ url: '/pages/' + page + '/' + page });
  },

  renewCurrentPage: function() { var sr=require('../../utils/subscribe-helper'); sr.silentRenew(false, null, '视力-当前标签'); }
});
