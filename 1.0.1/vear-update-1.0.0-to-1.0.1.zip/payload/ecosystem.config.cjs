module.exports = {
  apps: [
    {
      name: "vision-verify-system",
      cwd: "./backend-后端",
      script: "src/app.js",
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      watch: false,
      restart_delay: 3000,
      kill_timeout: 5000,
      max_memory_restart: "512M",
      env: {
        NODE_ENV: "production",
        PORT: 3000
      }
    }
  ]
};
