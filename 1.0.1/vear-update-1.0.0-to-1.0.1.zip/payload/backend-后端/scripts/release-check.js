#!/usr/bin/env node
require('dotenv').config();
const mysql = require('mysql2/promise');

const REQUIRED_TABLES = [
  'stores', 'users', 'customers', 'customer_cards', 'customer_renewals',
  'customer_card_usage_logs', 'refund_records', 'verify_records', 'revoke_requests',
  'operation_logs', 'system_settings'
];

const REQUIRED_COLUMNS = {
  customers: ['id', 'store_id', 'has_card', 'status', 'total_times', 'used_times', 'expire_date'],
  customer_cards: ['id', 'customer_id', 'card_name_snapshot', 'is_promotion', 'total_times', 'used_times', 'remaining_times', 'status'],
  customer_renewals: ['id', 'customer_id', 'customer_card_id', 'add_times', 'after_total_times', 'after_expire_date'],
  customer_card_usage_logs: ['id', 'customer_card_id', 'customer_id', 'verify_record_id', 'quantity', 'before_used_times', 'after_used_times'],
  refund_records: ['id', 'customer_id', 'customer_card_id', 'refund_amount', 'reason'],
  verify_records: ['id', 'verify_no', 'customer_id', 'customer_card_id', 'store_id', 'revoked', 'revoked_at', 'revoke_reason'],
  users: ['id', 'username', 'password_hash', 'role', 'status', 'store_id']
};

function ok(msg) { console.log('✅ ' + msg); }
function warn(msg) { console.log('⚠️  ' + msg); }
function fail(msg) { console.log('❌ ' + msg); }

function getConfig() {
  return {
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'verification_system',
    charset: 'utf8mb4',
    dateStrings: true,
    connectTimeout: Number(process.env.DB_CONNECT_TIMEOUT || 5000)
  };
}

async function tableExists(conn, table) {
  const [rows] = await conn.query(
    'SELECT COUNT(*) AS c FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?',
    [table]
  );
  return Number(rows[0].c) > 0;
}

async function getColumns(conn, table) {
  const [rows] = await conn.query(
    'SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?',
    [table]
  );
  return new Set(rows.map(r => r.COLUMN_NAME));
}

async function count(conn, sql, args = []) {
  const [rows] = await conn.query(sql, args);
  return Number(rows[0] && (rows[0].c || rows[0].count) || 0);
}

async function main() {
  const config = getConfig();
  const problems = [];
  const warnings = [];

  console.log('发布前环境检查：' + config.host + ':' + config.port + '/' + config.database);
  const conn = await mysql.createConnection(config);
  ok('数据库连接成功');

  for (const table of REQUIRED_TABLES) {
    if (await tableExists(conn, table)) ok('数据表存在：' + table);
    else { problems.push('缺少数据表：' + table); fail('缺少数据表：' + table); }
  }

  for (const [table, columns] of Object.entries(REQUIRED_COLUMNS)) {
    if (!(await tableExists(conn, table))) continue;
    const existing = await getColumns(conn, table);
    for (const column of columns) {
      if (!existing.has(column)) { problems.push(`缺少字段：${table}.${column}`); fail(`缺少字段：${table}.${column}`); }
    }
  }

  const adminCount = await count(conn, 'SELECT COUNT(*) AS c FROM users WHERE role = 1 AND status = 1');
  if (adminCount > 0) ok('可用超级管理员账号：' + adminCount + ' 个');
  else { problems.push('没有启用状态的超级管理员账号'); fail('没有启用状态的超级管理员账号'); }

  const storeCount = await count(conn, 'SELECT COUNT(*) AS c FROM stores WHERE status = 1');
  if (storeCount > 0) ok('可用门店：' + storeCount + ' 个');
  else { warnings.push('没有启用状态的门店，业务账号可能无法建档/核销'); warn('没有启用状态的门店'); }

  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) { problems.push('JWT_SECRET 未配置或长度不足'); fail('JWT_SECRET 未配置或长度不足'); }
  else ok('JWT_SECRET 已配置');

  if (String(process.env.WX_LOGIN_MOCK || '0') === '1') warnings.push('WX_LOGIN_MOCK=1，正式上线前小程序登录仍是模拟模式');
  if (!process.env.WX_APPID || !(process.env.WX_APPSECRET || process.env.WX_APP_SECRET)) warnings.push('微信 WX_APPID/WX_APPSECRET 未完整配置，小程序正式登录/订阅消息会失败');

  const smsMock = String(process.env.SMS_MOCK || '0') === '1';
  if (smsMock) warnings.push('SMS_MOCK=1，短信当前为模拟发送；正式上线如需真发请改为 0 并配置服务商密钥');
  if (!smsMock) {
    const missSms = [];
    if (!process.env.SMS_PROVIDER) missSms.push('SMS_PROVIDER');
    if (!process.env.SMS_SIGN_NAME) missSms.push('SMS_SIGN_NAME');
    if (!(process.env.ALIYUN_SMS_ACCESS_KEY_ID || process.env.SMS_ACCESS_KEY_ID)) missSms.push('SMS_ACCESS_KEY_ID');
    if (!(process.env.ALIYUN_SMS_ACCESS_KEY_SECRET || process.env.SMS_ACCESS_KEY_SECRET)) missSms.push('SMS_ACCESS_KEY_SECRET');
    if (missSms.length) warnings.push('短信真实发送配置不完整：' + missSms.join(', '));
  }

  warnings.forEach(warn);
  await conn.end();

  console.log('\n检查结果：' + (problems.length ? '不通过' : '通过') + `，错误 ${problems.length} 项，警告 ${warnings.length} 项`);
  if (problems.length) process.exit(1);
}

main().catch(err => {
  console.error('❌ 发布前检查异常：', err.message || err);
  process.exit(1);
});
