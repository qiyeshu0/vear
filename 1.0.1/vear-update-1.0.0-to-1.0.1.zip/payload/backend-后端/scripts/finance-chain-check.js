#!/usr/bin/env node
require('dotenv').config();
const mysql = require('mysql2/promise');

function log(icon, msg) { console.log(icon + ' ' + msg); }
function sample(rows) { return rows.slice(0, 5).map(r => JSON.stringify(r)).join('\n'); }

async function queryCheck(conn, title, sql, level = 'error') {
  const [rows] = await conn.query(sql);
  if (!rows.length) {
    log('✅', title);
    return { title, ok: true, count: 0, level };
  }
  log(level === 'warn' ? '⚠️ ' : '❌', `${title}：发现 ${rows.length} 条`);
  console.log(sample(rows));
  return { title, ok: false, count: rows.length, level };
}

async function main() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'verification_system',
    charset: 'utf8mb4',
    dateStrings: true,
    connectTimeout: Number(process.env.DB_CONNECT_TIMEOUT || 5000)
  });

  console.log('资金/次数主链数据体检（只读，不改数据）');
  const results = [];
  results.push(await queryCheck(conn, '卡项次数不能为负/已用不能超过总次数', `
    SELECT id, customer_id, total_times, used_times, remaining_times, status
    FROM customer_cards
    WHERE total_times < 0 OR used_times < 0 OR used_times > total_times OR remaining_times < 0
    LIMIT 50
  `));
  results.push(await queryCheck(conn, '核销记录必须绑定可追溯卡项（正式卡或已关联使用日志的活动卡）', `
    SELECT vr.id, vr.verify_no, vr.customer_id, vr.customer_card_id, vr.training_project, vr.created_at
    FROM verify_records vr
    LEFT JOIN customer_cards cc ON cc.id = vr.customer_card_id
    LEFT JOIN customer_card_usage_logs cul
      ON cul.verify_record_id = vr.id
     AND cul.customer_card_id = vr.customer_card_id
     AND cul.action_type = 'consume'
    WHERE COALESCE(vr.revoked,0) = 0
      AND vr.training_project <> '退卡'
      AND (
        vr.customer_card_id IS NULL
        OR cc.id IS NULL
        OR (COALESCE(cc.is_promotion,0) = 1 AND cul.id IS NULL)
      )
    LIMIT 50
  `, 'warn'));
  results.push(await queryCheck(conn, '活动卡使用日志必须绑定核销记录，确保撤回能恢复多次核销', `
    SELECT id, customer_id, customer_card_id, quantity, verify_record_id, created_at
    FROM customer_card_usage_logs
    WHERE action_type = 'consume' AND (verify_record_id IS NULL OR verify_record_id = 0)
    LIMIT 50
  `, 'warn'));
  results.push(await queryCheck(conn, '退款记录必须绑定退卡卡项', `
    SELECT id, customer_id, customer_card_id, refund_amount, reason, created_at
    FROM refund_records
    WHERE customer_card_id IS NULL OR customer_card_id = 0
    LIMIT 50
  `, 'warn'));
  results.push(await queryCheck(conn, '续卡记录必须绑定续卡卡项', `
    SELECT id, customer_id, customer_card_id, add_times, created_at
    FROM customer_renewals
    WHERE customer_card_id IS NULL OR customer_card_id = 0
    LIMIT 50
  `, 'warn'));
  results.push(await queryCheck(conn, '停用客户不应仍存在启用正式卡', `
    SELECT c.id AS customer_id, c.child_name, c.status, cc.id AS card_id, cc.status AS card_status
    FROM customers c
    JOIN customer_cards cc ON cc.customer_id = c.id AND cc.status = 1 AND COALESCE(cc.is_promotion,0) = 0
    WHERE c.status = 0
    LIMIT 50
  `, 'warn'));
  results.push(await queryCheck(conn, '门店隔离数据完整性：客户/核销/卡项门店链路不能断', `
    SELECT vr.id, vr.verify_no, vr.customer_id, vr.store_id, c.store_id AS customer_store_id
    FROM verify_records vr
    LEFT JOIN customers c ON c.id = vr.customer_id
    WHERE c.id IS NULL OR vr.store_id <> c.store_id
    LIMIT 50
  `));

  await conn.end();
  const errors = results.filter(r => !r.ok && r.level === 'error');
  const warnings = results.filter(r => !r.ok && r.level === 'warn');
  console.log(`\n体检结果：错误 ${errors.length} 项，警告 ${warnings.length} 项`);
  if (errors.length) process.exit(1);
}

main().catch(err => {
  console.error('❌ 资金/次数主链体检异常：', err.message || err);
  process.exit(1);
});
