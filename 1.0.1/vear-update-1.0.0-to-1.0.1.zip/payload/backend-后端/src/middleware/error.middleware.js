function notFoundHandler(req, res, next) {
  res.status(404).json({
    code: 404,
    success: false,
    message: `接口不存在：${req.method} ${req.originalUrl}`,
    data: null
  });
}

function errorHandler(err, req, res, next) {
  const statusCode = Number(err.statusCode || err.status || 500);
  const message =
    err.message || (statusCode >= 500 ? "服务器内部错误" : "请求处理失败");

  if (process.env.NODE_ENV !== "production") {
    console.error("[API ERROR]", {
      method: req.method,
      url: req.originalUrl,
      statusCode,
      message,
      stack: err.stack
    });
  }

  res.status(statusCode).json({
    code: statusCode,
    success: false,
    message,
    data: process.env.NODE_ENV === "production"
      ? null
      : {
          stack: err.stack || null
        }
  });
}

function asyncHandler(fn) {
  return function wrappedAsyncHandler(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

function createHttpError(statusCode, message, extra = {}) {
  const error = new Error(message);
  error.statusCode = statusCode;
  Object.assign(error, extra);
  return error;
}

module.exports = {
  notFoundHandler,
  errorHandler,
  asyncHandler,
  createHttpError
};
