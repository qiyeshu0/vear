/**
 * 微信服务 — code2session、获取手机号、access_token 管理
 */
const https = require("https");
const { getWechatRuntimeConfig } = require("../utils/runtime-config");

// access_token 缓存（2小时有效期）
let cachedToken = null;
let tokenExpireAt = 0;

async function getConfig() {
  return getWechatRuntimeConfig();
}

function httpsGet(url) {
  return new Promise((resolve, reject) => {
    https
      .get(url, (res) => {
        let body = "";
        res.on("data", (chunk) => (body += chunk));
        res.on("end", () => {
          try {
            resolve(JSON.parse(body));
          } catch (e) {
            reject(new Error("微信API返回解析失败: " + body.substring(0, 200)));
          }
        });
      })
      .on("error", reject);
  });
}

function httpsPost(url, data) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(data);
    const urlObj = new URL(url);
    const options = {
      hostname: urlObj.hostname,
      path: urlObj.pathname + urlObj.search,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(postData),
      },
    };
    const req = https.request(options, (res) => {
      let body = "";
      res.on("data", (chunk) => (body += chunk));
      res.on("end", () => {
        try {
          resolve(JSON.parse(body));
        } catch (e) {
          reject(new Error("微信API返回解析失败"));
        }
      });
    });
    req.on("error", reject);
    req.write(postData);
    req.end();
  });
}

/**
 * 获取 access_token（自动缓存）
 */
async function getAccessToken() {
  const now = Date.now();
  if (cachedToken && now < tokenExpireAt - 300000) {
    return cachedToken;
  }

  const { appId, appSecret } = await getConfig();
  if (!appId || !appSecret) {
    throw new Error("微信 AppID/AppSecret 未配置，请在 .env 中设置 WX_APPID 和 WX_APPSECRET");
  }

  const result = await httpsGet(
    `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${appId}&secret=${appSecret}`
  );

  if (result.errcode) {
    throw new Error(`获取 access_token 失败: [${result.errcode}] ${result.errmsg}`);
  }

  cachedToken = result.access_token;
  tokenExpireAt = now + (result.expires_in || 7200) * 1000;
  console.log("[微信] access_token 已刷新");
  return cachedToken;
}

/**
 * 用小程序 code 换 openid + session_key
 */
async function code2session(code) {
  const { appId, appSecret, mockLogin, mockOpenid } = await getConfig();
  if (mockLogin) {
    return {
      openid: mockOpenid,
      sessionKey: "mock-session-key",
      unionid: null,
      mocked: true,
    };
  }

  if (!appId || !appSecret) {
    throw new Error("微信 AppID/AppSecret 未配置；本地开发可临时设置 WX_LOGIN_MOCK=1，正式上线必须配置 WX_APPID 和 WX_APPSECRET");
  }

  const result = await httpsGet(
    `https://api.weixin.qq.com/sns/jscode2session?appid=${appId}&secret=${appSecret}&js_code=${code}&grant_type=authorization_code`
  );

  if (result.errcode) {
    throw new Error(`code2session 失败: [${result.errcode}] ${result.errmsg}`);
  }

  return {
    openid: result.openid,
    sessionKey: result.session_key,
    unionid: result.unionid || null,
  };
}

/**
 * 用 phoneCode 获取用户手机号
 * phoneCode 来自 <button open-type="getPhoneNumber"> 的回调
 */
async function getPhoneNumber(phoneCode) {
  const accessToken = await getAccessToken();
  const result = await httpsPost(
    `https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token=${accessToken}`,
    { code: phoneCode }
  );

  if (result.errcode !== 0) {
    throw new Error(`获取手机号失败: [${result.errcode}] ${result.errmsg}`);
  }

  return result.phone_info?.phoneNumber || "";
}

/**
 * 发送微信订阅消息
 * @param {string} openid - 用户 openid
 * @param {string} templateId - 模板 ID
 * @param {object} data - 模板数据 { thing1: { value: '...' }, ... }
 * @param {string} page - 点击跳转的小程序页面
 */
async function sendSubscribeMessage(openid, templateId, data, page = "pages/home/home") {
  if (!openid || !templateId) {
    throw new Error("openid 和 templateId 不能为空");
  }

  const accessToken = await getAccessToken();
  const result = await httpsPost(
    `https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token=${accessToken}`,
    {
      touser: openid,
      template_id: templateId,
      page: page,
      miniprogram_state: process.env.NODE_ENV === "production" ? "formal" : "developer",
      lang: "zh_CN",
      data: data,
    }
  );

  if (result.errcode !== 0) {
    throw new Error(`订阅消息发送失败: [${result.errcode}] ${result.errmsg}`);
  }

  return true;
}

function clearWechatCache() {
  cachedToken = null;
  tokenExpireAt = 0;
}

module.exports = {
  clearWechatCache,
  getAccessToken,
  code2session,
  getPhoneNumber,
  sendSubscribeMessage,
};
