const { pool, getDbConfig } = require("../config/db");
const { createTables } = require("../install/schema");
const { formatDateYmd } = require("../utils/date");

const VISIT_STATUS = Object.freeze({
  ARRIVED: 0,
  SERVING: 1,
  COMPLETED: 2,
  CANCELLED: 3,
});

const VISIT_TYPES = Object.freeze([
  { value: "training", label: "训练", verificationRequired: true },
  { value: "check", label: "检查", verificationRequired: false },
  { value: "review", label: "复查", verificationRequired: false },
  { value: "pickup", label: "取镜", verificationRequired: false },
  { value: "consultation", label: "咨询", verificationRequired: false },
  { value: "after_sales", label: "售后", verificationRequired: false },
  { value: "other", label: "其他", verificationRequired: false },
]);

let schemaPromise = null;
let schemaSignature = "";

function ensureVisitSchema() {
  const nextSignature = JSON.stringify(getDbConfig());
  if (!schemaPromise || schemaSignature !== nextSignature) {
    schemaSignature = nextSignature;
    schemaPromise = createTables(pool).catch((error) => {
      schemaPromise = null;
      schemaSignature = "";
      throw error;
    });
  }
  return schemaPromise;
}

function pad(value, length = 2) {
  return String(value).padStart(length, "0");
}

function formatDateTime(value = new Date()) {
  if (typeof value === "string") {
    const normalized = value.trim().replace("T", " ");
    if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/.test(normalized)) {
      return normalized.slice(0, 19);
    }
  }
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return formatDateTime(new Date());
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function generateVisitNo(prefix = "LF") {
  const now = new Date();
  return `${prefix}${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}${pad(now.getMilliseconds(), 3)}${Math.floor(Math.random() * 90000) + 10000}`;
}

async function insertVisitWithRetry(connection, payload, maxRetries = 3) {
  let lastError = null;
  for (let attempt = 0; attempt < maxRetries; attempt += 1) {
    const visitNo = generateVisitNo(payload.source === "verify_backfill" ? "LFB" : "LF");
    try {
      const [result] = await connection.execute(
        `
          INSERT INTO customer_visits
          (visit_no, customer_id, store_id, customer_name, customer_phone, visit_date,
           arrived_at, started_at, completed_at, visit_type, status,
           verification_required, source, training_project, service_user_id,
           service_user_name, reception_user_id, reception_user_name, remark,
           created_by, updated_by)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [
          visitNo,
          payload.customerId,
          payload.storeId,
          payload.customerName,
          payload.customerPhone || null,
          payload.visitDate,
          payload.arrivedAt,
          payload.startedAt || null,
          payload.completedAt || null,
          payload.visitType || "training",
          payload.status ?? VISIT_STATUS.ARRIVED,
          payload.verificationRequired === false ? 0 : 1,
          payload.source || "manual",
          payload.trainingProject || null,
          payload.serviceUserId || null,
          payload.serviceUserName || null,
          payload.receptionUserId || null,
          payload.receptionUserName || null,
          payload.remark || null,
          payload.createdBy || null,
          payload.updatedBy || payload.createdBy || null,
        ],
      );
      return { visitId: Number(result.insertId), visitNo, created: true };
    } catch (error) {
      lastError = error;
      if (error?.code === "ER_DUP_ENTRY" || Number(error?.errno) === 1062) continue;
      throw error;
    }
  }
  throw lastError || new Error("生成来访单号失败，请稍后重试");
}

async function syncVisitFromVerification(connection, payload = {}) {
  const verifyRecordId = Number(payload.verifyRecordId || 0);
  const customerId = Number(payload.customerId || 0);
  const storeId = Number(payload.storeId || 0);
  if (!verifyRecordId || !customerId || !storeId) {
    throw new Error("核销关联来访参数不完整");
  }

  const [[existingLink]] = await connection.query(
    "SELECT visit_id FROM customer_visit_verifications WHERE verify_record_id = ? LIMIT 1",
    [verifyRecordId],
  );
  if (existingLink) {
    return { visitId: Number(existingLink.visit_id), created: false, linked: false };
  }

  const verifyTime = formatDateTime(payload.verifyTime || new Date());
  const visitDate = formatDateYmd(verifyTime);
  const requestedVisitId = Number(payload.visitId || 0);
  let visit = null;

  if (requestedVisitId) {
    const [[row]] = await connection.query(
      `
        SELECT id, status, source
        FROM customer_visits
        WHERE id = ? AND customer_id = ? AND store_id = ? AND status <> ?
        LIMIT 1 FOR UPDATE
      `,
      [requestedVisitId, customerId, storeId, VISIT_STATUS.CANCELLED],
    );
    if (!row) throw new Error("指定来访记录不存在、已取消或与当前客户不匹配");
    visit = row;
  } else {
    const [[row]] = await connection.query(
      `
        SELECT id, status, source
        FROM customer_visits
        WHERE customer_id = ?
          AND store_id = ?
          AND visit_date = ?
          AND status IN (?, ?)
          AND verification_required = 1
        ORDER BY
          CASE WHEN COALESCE(training_project, '') = ? THEN 0 ELSE 1 END,
          CASE WHEN status = ? THEN 0 ELSE 1 END,
          arrived_at DESC,
          id DESC
        LIMIT 1 FOR UPDATE
      `,
      [
        customerId,
        storeId,
        visitDate,
        VISIT_STATUS.ARRIVED,
        VISIT_STATUS.SERVING,
        String(payload.trainingProject || ""),
        VISIT_STATUS.SERVING,
      ],
    );
    visit = row || null;
  }

  let created = false;
  let visitId = Number(visit?.id || 0);
  if (!visitId) {
    const inserted = await insertVisitWithRetry(connection, {
      customerId,
      storeId,
      customerName: String(payload.customerName || "客户"),
      customerPhone: String(payload.customerPhone || ""),
      visitDate,
      arrivedAt: verifyTime,
      startedAt: verifyTime,
      completedAt: verifyTime,
      visitType: "training",
      status: VISIT_STATUS.COMPLETED,
      verificationRequired: true,
      source: payload.source || "verify",
      trainingProject: String(payload.trainingProject || ""),
      serviceUserId: Number(payload.operatorId || 0) || null,
      serviceUserName: String(payload.operatorName || ""),
      receptionUserId: Number(payload.operatorId || 0) || null,
      receptionUserName: String(payload.operatorName || ""),
      remark: payload.remark || null,
      createdBy: Number(payload.operatorId || 0) || null,
    });
    visitId = inserted.visitId;
    created = true;
  } else {
    await connection.execute(
      `
        UPDATE customer_visits
        SET status = ?,
            started_at = COALESCE(started_at, ?),
            completed_at = COALESCE(completed_at, ?),
            training_project = COALESCE(NULLIF(training_project, ''), ?),
            service_user_id = COALESCE(service_user_id, ?),
            service_user_name = COALESCE(NULLIF(service_user_name, ''), ?),
            updated_by = ?
        WHERE id = ?
      `,
      [
        VISIT_STATUS.COMPLETED,
        verifyTime,
        verifyTime,
        payload.trainingProject || null,
        Number(payload.operatorId || 0) || null,
        payload.operatorName || null,
        Number(payload.operatorId || 0) || null,
        visitId,
      ],
    );
  }

  const [linkResult] = await connection.execute(
    `
      INSERT IGNORE INTO customer_visit_verifications
      (visit_id, verify_record_id, linked_by, linked_at)
      VALUES (?, ?, ?, ?)
    `,
    [visitId, verifyRecordId, Number(payload.operatorId || 0) || null, verifyTime],
  );

  return {
    visitId,
    created,
    linked: Number(linkResult.affectedRows || 0) === 1,
  };
}

async function backfillVisitsFromVerifications() {
  await ensureVisitSchema();
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [rows] = await connection.query(
      `
        SELECT
          vr.id, vr.customer_id, vr.store_id, vr.child_name, vr.training_project,
          vr.verify_date, vr.verify_time, vr.operator_id, vr.operator_name,
          c.parent_phone
        FROM verify_records vr
        LEFT JOIN customers c ON c.id = vr.customer_id
        LEFT JOIN customer_visit_verifications cvv ON cvv.verify_record_id = vr.id
        WHERE cvv.id IS NULL
          AND COALESCE(vr.training_project, '') <> '退卡'
          AND vr.verify_no NOT LIKE 'TK%'
        ORDER BY vr.verify_time ASC, vr.id ASC
      `,
    );

    const groupVisits = new Map();
    let created = 0;
    let linked = 0;

    for (const row of rows) {
      const visitDate = formatDateYmd(row.verify_date || row.verify_time);
      const key = `${row.customer_id}:${row.store_id}:${visitDate}`;
      let visitId = groupVisits.get(key);

      if (!visitId) {
        const [[existing]] = await connection.query(
          `
            SELECT id FROM customer_visits
            WHERE customer_id = ? AND store_id = ? AND visit_date = ?
              AND source = 'verify_backfill'
            ORDER BY id ASC LIMIT 1 FOR UPDATE
          `,
          [row.customer_id, row.store_id, visitDate],
        );
        visitId = Number(existing?.id || 0);
      }

      if (!visitId) {
        const verifyTime = formatDateTime(row.verify_time);
        const inserted = await insertVisitWithRetry(connection, {
          customerId: Number(row.customer_id),
          storeId: Number(row.store_id),
          customerName: row.child_name || "客户",
          customerPhone: row.parent_phone || "",
          visitDate,
          arrivedAt: verifyTime,
          startedAt: verifyTime,
          completedAt: verifyTime,
          visitType: "training",
          status: VISIT_STATUS.COMPLETED,
          verificationRequired: true,
          source: "verify_backfill",
          trainingProject: row.training_project || "",
          serviceUserId: Number(row.operator_id || 0) || null,
          serviceUserName: row.operator_name || "",
          receptionUserId: Number(row.operator_id || 0) || null,
          receptionUserName: row.operator_name || "",
          createdBy: Number(row.operator_id || 0) || null,
        });
        visitId = inserted.visitId;
        created += 1;
      }

      groupVisits.set(key, visitId);
      const [result] = await connection.execute(
        `INSERT IGNORE INTO customer_visit_verifications (visit_id, verify_record_id, linked_by, linked_at)
         VALUES (?, ?, ?, ?)`,
        [visitId, Number(row.id), Number(row.operator_id || 0) || null, formatDateTime(row.verify_time)],
      );
      linked += Number(result.affectedRows || 0);
    }

    await connection.commit();
    return { scanned: rows.length, created, linked };
  } catch (error) {
    await connection.rollback().catch(() => {});
    throw error;
  } finally {
    connection.release();
  }
}

module.exports = {
  VISIT_STATUS,
  VISIT_TYPES,
  ensureVisitSchema,
  formatDateTime,
  insertVisitWithRetry,
  syncVisitFromVerification,
  backfillVisitsFromVerifications,
};
