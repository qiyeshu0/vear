/**
 * 消息通知服务
 * 可插拔架构：支持控制台输出 / 短信 / 微信模板消息
 * 基于数据库队列，无外部中间件依赖
 */

const { pool } = require("../config/db");
const { createTables } = require("../install/schema");
const wechatService = require("./wechat.service");
const { getWechatRuntimeConfig } = require("../utils/runtime-config");

// ─── Provider 接口（可替换实现）─────────────────────────

/**
 * 控制台 Provider（开发/测试用）
 */
function createConsoleProvider() {
  return {
    name: "console",
    async send(item) {
      console.log(`[通知-${item.target_type}] → ${item.target_address}`);
      console.log(`  标题: ${item.title}`);
      console.log(`  内容: ${item.content}`);
      return { success: true };
    },
  };
}

/**
 * 短信 Provider 骨架（接入阿里云/腾讯云短信时实现）
 */
function createSmsProvider(config = {}) {
  return {
    name: "sms",
    async send(item) {
      // TODO: 接入阿里云 SMS SDK
      // const Client = require('@alicloud/dysmsapi20170525');
      // const client = new Client({ accessKeyId: config.accessKeyId, accessKeySecret: config.accessKeySecret });
      // await client.sendSms({ PhoneNumbers: item.target_address, SignName: config.signName, TemplateCode: item.template_id, TemplateParam: JSON.stringify(item.template_data || {}) });
      console.log(`[SMS] → ${item.target_address}: ${item.content}`);
      return { success: true };
    },
  };
}

/**
 * 微信模板消息 Provider 骨架
 */
function createWxTemplateProvider(config = {}) {
  return {
    name: "wx_template",
    async send(item) {
      // TODO: 接入微信模板消息 API
      // const accessToken = await getWxAccessToken(config.appId, config.appSecret);
      // await axios.post(`https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=${accessToken}`, {...});
      console.log(`[微信模板消息] → ${item.target_address}: ${item.title}`);
      return { success: true };
    },
  };
}

// ─── 通知引擎 ───────────────────────────────────────────

let schemaReady = false;

async function ensureSchema() {
  if (schemaReady) return;
  await createTables(pool);
  schemaReady = true;
}

/**
 * 入队一条通知
 */
async function enqueue(payload = {}) {
  await ensureSchema();
  const [result] = await pool.execute(
    `INSERT INTO notification_queue
     (biz_type, biz_id, target_type, target_address, title, content, template_id, template_data, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)`,
    [
      String(payload.bizType || "").slice(0, 50),
      payload.bizId == null ? null : Number(payload.bizId),
      String(payload.targetType || "sms").slice(0, 20),
      String(payload.targetAddress || "").slice(0, 100),
      String(payload.title || "").slice(0, 200),
      String(payload.content || "").slice(0, 1000),
      payload.templateId == null ? null : String(payload.templateId).slice(0, 100),
      payload.templateData ? JSON.stringify(payload.templateData) : null,
    ],
  );
  return result.insertId;
}

/**
 * 批量入队
 */
async function enqueueBatch(items = []) {
  const ids = [];
  for (const item of items) {
    const id = await enqueue(item);
    ids.push(id);
  }
  return ids;
}

/**
 * 发送待处理的队列消息
 * @param {object} provider - 发送渠道实例
 * @param {number} limit - 每次最多发送数
 */
async function processQueue(provider, limit = 20) {
  await ensureSchema();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [rows] = await connection.query(
      `SELECT id, biz_type, biz_id, target_type, target_address, title, content, template_id, template_data
       FROM notification_queue
       WHERE status = 0 AND target_type = ?
       ORDER BY id ASC LIMIT ? FOR UPDATE`,
      [provider.name, limit],
    );

    if (!rows.length) {
      await connection.commit();
      return { processed: 0 };
    }

    let successCount = 0;
    let failCount = 0;

    for (const row of rows) {
      try {
        const result = await provider.send({
          target_type: row.target_type,
          target_address: row.target_address,
          title: row.title,
          content: row.content,
          template_id: row.template_id,
          template_data: row.template_data ? JSON.parse(row.template_data) : {},
        });

        if (result && result.success !== false) {
          await connection.execute(
            `UPDATE notification_queue SET status = 1, sent_at = NOW() WHERE id = ?`,
            [row.id],
          );
          successCount += 1;
        } else {
          await connection.execute(
            `UPDATE notification_queue SET status = 2, error_msg = ? WHERE id = ?`,
            [String(result?.error || "发送失败").slice(0, 500), row.id],
          );
          failCount += 1;
        }
      } catch (error) {
        await connection.execute(
          `UPDATE notification_queue SET status = 2, error_msg = ? WHERE id = ?`,
          [String(error.message || "未知错误").slice(0, 500), row.id],
        );
        failCount += 1;
      }
    }

    await connection.commit();
    return { processed: rows.length, success: successCount, fail: failCount };
  } catch (error) {
    await connection.rollback().catch(() => {});
    throw error;
  } finally {
    connection.release();
  }
}

/**
 * 获取通知统计
 */
async function getQueueStats() {
  await ensureSchema();
  const [[row]] = await pool.query(
    `SELECT
       COUNT(*) AS total,
       SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) AS pending,
       SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) AS sent,
       SUM(CASE WHEN status = 2 THEN 1 ELSE 0 END) AS failed
     FROM notification_queue`,
  );
  return {
    total: Number(row?.total || 0),
    pending: Number(row?.pending || 0),
    sent: Number(row?.sent || 0),
    failed: Number(row?.failed || 0),
  };
}

// ─── 业务事件快捷方法 ───────────────────────────────────

/**
 * 客户次数不足通知
 */
async function notifyLowTimes(customer) {
  return enqueue({
    bizType: "low_times",
    bizId: customer.id,
    targetType: "sms",
    targetAddress: customer.parentPhone,
    title: "训练次数不足提醒",
    content: `【视光门店】${customer.childName}的${customer.trainingProject}训练剩余${customer.remainingTimes}次，请及时续卡。`,
  });
}

/**
 * 即将到期通知
 */
async function notifyExpireSoon(customer, daysLeft) {
  return enqueue({
    bizType: "expire_soon",
    bizId: customer.id,
    targetType: "sms",
    targetAddress: customer.parentPhone,
    title: "训练卡即将到期提醒",
    content: `【视光门店】${customer.childName}的训练卡将于${daysLeft}天后(${customer.expireDate})到期，请及时续卡。`,
  });
}

/**
 * 核销成功通知
 */
async function notifyVerifySuccess(customer, verifyNo) {
  return enqueue({
    bizType: "verify_success",
    bizId: customer.id,
    targetType: "sms",
    targetAddress: customer.parentPhone,
    title: "核销成功通知",
    content: `【视光门店】${customer.childName}已完成本次训练核销(${verifyNo})，剩余${customer.remainingTimes}次。`,
  });
}

/**
 * 配镜到货通知
 */
async function notifyGlassesReady(customer) {
  return enqueue({
    bizType: "glasses_ready",
    bizId: customer.id,
    targetType: "sms",
    targetAddress: customer.parentPhone,
    title: "配镜到货通知",
    content: `【视光门店】${customer.childName}的眼镜已到货，请到店取镜。`,
  });
}

// ─── 微信订阅消息 ──────────────────────────────────────

function formatWxTemplateTime(value) {
  if (!value) {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    const dd = String(now.getDate()).padStart(2, "0");
    const hh = String(now.getHours()).padStart(2, "0");
    const mi = String(now.getMinutes()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd} ${hh}:${mi}`;
  }

  const raw = String(value).trim();
  if (/^\d{1,2}:\d{2}$/.test(raw)) {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    const dd = String(now.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd} ${raw.padStart(5, "0")}`;
  }

  return raw.slice(0, 20);
}

function explainWxSubscribeError(error) {
  const message = String(error?.message || error || "");
  if (message.includes("[43101]")) {
    return `${message}。用户没有可用的订阅授权，需在小程序首页重新点击“开启”授权。`;
  }
  if (message.includes("[47003]") || message.includes("data format")) {
    return `${message}。请核对微信后台模板字段是否与代码中的 thing2/character_string1/time3/thing4/thing5 一致。`;
  }
  return message || "未知错误";
}

async function getCustomerOpenids(customerId) {
  if (!customerId) return [];
  const [openidRows] = await pool.query(
    `
      SELECT wx_openid FROM wx_user_bindings WHERE customer_id = ?
      UNION
      SELECT wx_openid FROM customers WHERE id = ? AND wx_openid IS NOT NULL
    `,
    [customerId, customerId],
  );
  return openidRows
    .map((row) => String(row.wx_openid || "").trim())
    .filter(Boolean);
}

/**
 * 通过微信订阅消息通知核销成功
 * 需要客户已授权（有 wx_openid）
 */
async function notifyVerifySuccessWx(customer, verifyNo, verifyTime) {
  try {
    if (!customer.id) return false;

    await ensureSchema();

    const openids = await getCustomerOpenids(customer.id);

    if (!openids.length) {
      console.log(`[微信订阅] 客户 ${customer.id} 未绑定 openid，跳过`);
      return false;
    }

    const { subscribeTemplateId } = await getWechatRuntimeConfig();
    const templateId = subscribeTemplateId || process.env.WX_SUBSCRIBE_TEMPLATE_ID || "";
    if (!templateId) {
      console.log("[微信订阅] 未配置 WX_SUBSCRIBE_TEMPLATE_ID，跳过");
      return false;
    }

    let successCount = 0;
    for (const openid of openids) {
      try {
        await wechatService.sendSubscribeMessage(openid, templateId, {
          thing2: { value: (customer.childName || "孩子").slice(0, 20) },
          character_string1: { value: String(verifyNo).slice(0, 32) },
          time3: { value: formatWxTemplateTime(verifyTime) },
          thing4: { value: ("剩余 " + (customer.remainingTimes || 0) + " 次").slice(0, 20) },
          thing5: { value: (customer.trainingProject || "视功能训练").slice(0, 20) },
        });
        successCount += 1;
      } catch (error) {
        console.error("[微信订阅] 单个接收人发送失败:", explainWxSubscribeError(error));
      }
    }
    console.log(`[微信订阅] 核销通知已发送 ${successCount}/${openids.length} → ${customer.childName}`);
    return successCount > 0;
  } catch (e) {
    console.error("[微信订阅] 发送失败:", explainWxSubscribeError(e));
    return false;
  }
}

/**
 * 通过微信订阅消息通知配镜进度变化
 * 推荐单独配置 WX_GLASSES_TEMPLATE_ID；未配置时临时复用 WX_SUBSCRIBE_TEMPLATE_ID。
 */
async function notifyGlassesStatusWx(customer, glassesRecord = {}, statusLabel = "", changeTime) {
  try {
    if (!customer.id) return false;

    await ensureSchema();

    const openids = await getCustomerOpenids(customer.id);
    if (!openids.length) {
      console.log(`[微信订阅] 客户 ${customer.id} 未绑定 openid，跳过配镜进度通知`);
      return false;
    }

    const { subscribeTemplateId, glassesTemplateId } = await getWechatRuntimeConfig();
    const templateId = glassesTemplateId || process.env.WX_GLASSES_TEMPLATE_ID || subscribeTemplateId || process.env.WX_SUBSCRIBE_TEMPLATE_ID || "";
    if (!templateId) {
      console.log("[微信订阅] 未配置配镜进度模板ID，跳过");
      return false;
    }

    const lensText = [glassesRecord.lensBrand || glassesRecord.lens_brand, glassesRecord.lensType || glassesRecord.lens_type]
      .map((item) => String(item || "").trim())
      .filter(Boolean)
      .join("/");
    const recordNo = String(glassesRecord.id || glassesRecord.recordId || "").trim() || `G${customer.id}`;
    const remark = statusLabel === "待取镜"
      ? "眼镜已到店，可联系门店取镜"
      : statusLabel === "已交付"
        ? "眼镜已交付，注意适应情况"
        : `当前进度：${statusLabel || "已更新"}`;

    let successCount = 0;
    for (const openid of openids) {
      try {
        await wechatService.sendSubscribeMessage(openid, templateId, {
          thing2: { value: (customer.childName || customer.child_name || "孩子").slice(0, 20) },
          character_string1: { value: recordNo.slice(0, 32) },
          time3: { value: formatWxTemplateTime(changeTime) },
          thing4: { value: (statusLabel || "进度已更新").slice(0, 20) },
          thing5: { value: (lensText || remark).slice(0, 20) },
        }, "pages/home/home");
        successCount += 1;
      } catch (error) {
        console.error("[微信订阅] 配镜进度单个接收人发送失败:", explainWxSubscribeError(error));
      }
    }
    console.log(`[微信订阅] 配镜进度通知已发送 ${successCount}/${openids.length} → ${customer.childName || customer.child_name || customer.id}`);
    return successCount > 0;
  } catch (e) {
    console.error("[微信订阅] 配镜进度发送失败:", explainWxSubscribeError(e));
    return false;
  }
}

module.exports = {
  createConsoleProvider,
  createSmsProvider,
  createWxTemplateProvider,
  enqueue,
  enqueueBatch,
  processQueue,
  getQueueStats,
  notifyLowTimes,
  notifyExpireSoon,
  notifyVerifySuccess,
  notifyGlassesReady,
  notifyVerifySuccessWx,
  notifyGlassesStatusWx,
};
