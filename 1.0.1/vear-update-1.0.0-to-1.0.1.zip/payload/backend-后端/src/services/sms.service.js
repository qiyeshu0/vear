const crypto = require("crypto");
const Core = require("@alicloud/pop-core");
const { pool } = require("../config/db");

let schemaPromise = null;

const SMS_VARIABLE_DEFINITIONS = [
  { key: "childName", token: "${childName}", label: "孩子姓名", example: "小明", source: "客户档案", description: "客户档案中的孩子姓名" },
  { key: "parentName", token: "${parentName}", label: "家长姓名", example: "张女士", source: "客户档案", description: "客户档案中的家长姓名" },
  { key: "parentPhone", token: "${parentPhone}", label: "家长手机号", example: "13800000000", source: "客户档案", description: "客户档案中的主手机号" },
  { key: "storeName", token: "${storeName}", label: "门店名称", example: "视光中心", source: "门店", description: "客户所属门店名称" },
  { key: "trainingProject", token: "${trainingProject}", label: "训练项目", example: "视觉训练", source: "客户卡项", description: "客户当前训练/活动项目" },
  { key: "totalTimes", token: "${totalTimes}", label: "总次数", example: "20", source: "客户卡项", description: "客户卡项总次数" },
  { key: "usedTimes", token: "${usedTimes}", label: "已用次数", example: "12", source: "客户卡项", description: "客户卡项已核销次数" },
  { key: "remainingTimes", token: "${remainingTimes}", label: "剩余次数", example: "8", source: "客户卡项", description: "客户卡项剩余可用次数" },
  { key: "expireDate", token: "${expireDate}", label: "到期日期", example: "2026-08-01", source: "客户卡项", description: "客户卡项到期日期" },
  { key: "lastVerifyDate", token: "${lastVerifyDate}", label: "最近核销日期", example: "2026-07-07", source: "核销记录", description: "最近一次有效核销日期" },
  { key: "customText", token: "${customText}", label: "自定义文字", example: "请提前预约", source: "发送时填写", description: "发送前在额外变量中手动填写" }
];

const SMS_PROVIDERS = [
  { value: "aliyun", label: "阿里云短信", enabled: true, description: "已接入，支持真实发送" },
  { value: "tencent", label: "腾讯云短信（预留）", enabled: false, description: "接口预留，需后续接入 SDK 后启用" }
];

const DEFAULT_SMS_TEMPLATES = [
  { name: "回访提醒", type: "follow_up", content: "您好，${childName}近期训练情况建议到店复查，如需预约可联系门店。", variables: ["childName"] },
  { name: "到期提醒", type: "expire_remind", content: "${childName}的训练卡将于${expireDate}到期，请及时到店复查或续卡。", variables: ["childName", "expireDate"] },
  { name: "次数不足提醒", type: "low_times", content: "${childName}当前训练剩余${remainingTimes}次，请合理安排到店时间。", variables: ["childName", "remainingTimes"] },
  { name: "长期未到店提醒", type: "inactive_remind", content: "${childName}已有一段时间未到店训练，建议及时复查视力情况。", variables: ["childName"] },
  { name: "复查预约提醒", type: "follow_up", content: "您好，${childName}建议近期到${storeName}进行视力复查，${customText}。", variables: ["childName", "storeName", "customText"] },
  { name: "预约到店提醒", type: "service", content: "您好，${childName}已预约到${storeName}服务，请按约定时间到店；如需调整请提前联系门店。", variables: ["childName", "storeName"] },
  { name: "核销后关怀", type: "follow_up", content: "${childName}本次${trainingProject}已完成，建议按计划坚持训练，如有不适请及时联系${storeName}。", variables: ["childName", "trainingProject", "storeName"] },
  { name: "续卡沟通提醒", type: "expire_remind", content: "${childName}当前训练卡剩余${remainingTimes}次，将于${expireDate}到期，可到${storeName}咨询续卡方案。", variables: ["childName", "remainingTimes", "expireDate", "storeName"] },
  { name: "训练计划提醒", type: "service", content: "您好，${childName}的${trainingProject}建议保持规律到店，当前剩余${remainingTimes}次，请合理安排训练时间。", variables: ["childName", "trainingProject", "remainingTimes"] },
  { name: "停训唤醒提醒", type: "inactive_remind", content: "您好，${childName}最近一次到店为${lastVerifyDate}，建议尽快恢复训练或到店复查。", variables: ["childName", "lastVerifyDate"] },
  { name: "生日/节日关怀", type: "service", content: "${parentName}您好，${storeName}祝${childName}${customText}，愿孩子视界清晰、健康成长。", variables: ["parentName", "storeName", "childName", "customText"] },
  { name: "配镜取镜提醒", type: "service", content: "您好，${childName}的配镜服务已完成，请您方便时到${storeName}取镜，${customText}。", variables: ["childName", "storeName", "customText"] },
  { name: "资料完善提醒", type: "service", content: "${parentName}您好，为便于后续服务，请协助完善${childName}的客户档案信息，感谢配合。", variables: ["parentName", "childName"] },
  { name: "营销活动通知", type: "marketing", content: "${parentName}您好，${storeName}近期有活动：${customText}。如不便接收可联系门店取消通知。", variables: ["parentName", "storeName", "customText"] }
];

function nowNo() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function createTaskNo() {
  return `SMS${nowNo()}${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}

function normalizePhone(phone) {
  return String(phone || "").replace(/\D/g, "").trim();
}

function maskPhone(phone) {
  const p = normalizePhone(phone);
  if (p.length < 7) return p;
  return `${p.slice(0, 3)}****${p.slice(-4)}`;
}

function isValidPhone(phone) {
  return /^1[3-9]\d{9}$/.test(normalizePhone(phone));
}

function sanitizeText(text, max = 500) {
  return String(text || "").trim().slice(0, max);
}

function safeJsonParse(value, fallback = {}) {
  if (!value) return fallback;
  if (typeof value === "object") return value;
  try { return JSON.parse(value); } catch { return fallback; }
}

function replaceTemplate(content, vars = {}) {
  return String(content || "").replace(/\$\{([a-zA-Z0-9_]+)\}/g, (_, key) => {
    const value = vars[key];
    return value == null ? "" : String(value);
  });
}

async function ensureSmsSchema() {
  if (schemaPromise) return schemaPromise;
  schemaPromise = (async () => {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS sms_templates (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        template_name varchar(100) NOT NULL,
        template_type varchar(50) NOT NULL DEFAULT 'service',
        provider varchar(30) NOT NULL DEFAULT 'aliyun',
        provider_template_id varchar(100) DEFAULT NULL,
        sign_name varchar(100) DEFAULT NULL,
        content varchar(500) NOT NULL,
        variables json DEFAULT NULL,
        status tinyint NOT NULL DEFAULT 1,
        remark varchar(500) DEFAULT NULL,
        created_by bigint unsigned DEFAULT NULL,
        created_by_name varchar(50) DEFAULT NULL,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_sms_templates_type (template_type),
        KEY idx_sms_templates_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短信模板表'
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS sms_tasks (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        task_no varchar(50) NOT NULL,
        task_name varchar(100) DEFAULT NULL,
        template_id bigint unsigned DEFAULT NULL,
        sms_type varchar(50) NOT NULL DEFAULT 'service',
        send_type varchar(30) NOT NULL DEFAULT 'manual',
        target_type varchar(30) NOT NULL DEFAULT 'selected',
        total_count int NOT NULL DEFAULT 0,
        success_count int NOT NULL DEFAULT 0,
        fail_count int NOT NULL DEFAULT 0,
        status tinyint NOT NULL DEFAULT 0 COMMENT '0待发送 1发送中 2完成 3部分失败 4失败',
        operator_id bigint unsigned DEFAULT NULL,
        operator_name varchar(50) DEFAULT NULL,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_sms_tasks_no (task_no),
        KEY idx_sms_tasks_created (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短信发送任务表'
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS sms_records (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        task_id bigint unsigned DEFAULT NULL,
        template_id bigint unsigned DEFAULT NULL,
        customer_id bigint unsigned DEFAULT NULL,
        child_name varchar(100) DEFAULT NULL,
        parent_phone varchar(30) NOT NULL,
        masked_phone varchar(30) DEFAULT NULL,
        sms_type varchar(50) NOT NULL DEFAULT 'service',
        provider varchar(30) NOT NULL DEFAULT 'aliyun',
        sign_name varchar(100) DEFAULT NULL,
        provider_template_id varchar(100) DEFAULT NULL,
        provider_request_id varchar(100) DEFAULT NULL,
        content varchar(600) NOT NULL,
        template_params json DEFAULT NULL,
        send_status tinyint NOT NULL DEFAULT 0 COMMENT '0待发送 1成功 2失败',
        fail_reason varchar(500) DEFAULT NULL,
        operator_id bigint unsigned DEFAULT NULL,
        operator_name varchar(50) DEFAULT NULL,
        sent_at datetime DEFAULT NULL,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_sms_records_customer (customer_id),
        KEY idx_sms_records_task (task_id),
        KEY idx_sms_records_created (created_at),
        KEY idx_sms_records_status (send_status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短信发送记录表'
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS customer_sms_preferences (
        customer_id bigint unsigned NOT NULL,
        allow_service_sms tinyint NOT NULL DEFAULT 1,
        allow_marketing_sms tinyint NOT NULL DEFAULT 0,
        unsubscribed tinyint NOT NULL DEFAULT 0,
        remark varchar(500) DEFAULT NULL,
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (customer_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客户短信授权设置表'
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS sms_config (
        id tinyint unsigned NOT NULL DEFAULT 1,
        provider varchar(30) NOT NULL DEFAULT 'aliyun',
        sign_name varchar(100) DEFAULT NULL,
        mock tinyint NOT NULL DEFAULT 0,
        aliyun_access_key_id varchar(120) DEFAULT NULL,
        aliyun_access_key_secret varchar(255) DEFAULT NULL,
        aliyun_endpoint varchar(255) DEFAULT NULL,
        updated_by bigint unsigned DEFAULT NULL,
        updated_by_name varchar(50) DEFAULT NULL,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短信服务商配置表'
    `);

    const envConfig = getConfigFromEnv();
    await pool.query(
      `INSERT IGNORE INTO sms_config (id, provider, sign_name, mock, aliyun_access_key_id, aliyun_access_key_secret, aliyun_endpoint)
       VALUES (1, ?, ?, ?, ?, ?, ?)`,
      [envConfig.provider, envConfig.signName || null, envConfig.mock ? 1 : 0, envConfig.aliyunAccessKeyId || null, envConfig.aliyunAccessKeySecret || null, envConfig.aliyunEndpoint || null]
    );

    for (const template of DEFAULT_SMS_TEMPLATES) {
      const [[existing]] = await pool.query(
        "SELECT id FROM sms_templates WHERE template_name = ? AND remark = '系统内置模板' LIMIT 1",
        [template.name]
      );
      if (!existing) {
        await pool.execute(
          `INSERT INTO sms_templates (template_name, template_type, provider, content, variables, status, remark)
           VALUES (?, ?, 'aliyun', ?, ?, 1, '系统内置模板')`,
          [template.name, template.type, template.content, JSON.stringify(template.variables)]
        );
      }
    }
  })().catch((error) => {
    schemaPromise = null;
    throw error;
  });
  return schemaPromise;
}

function getConfigFromEnv() {
  return {
    provider: process.env.SMS_PROVIDER || "aliyun",
    aliyunAccessKeyId: process.env.ALIYUN_SMS_ACCESS_KEY_ID || process.env.SMS_ACCESS_KEY_ID || "",
    aliyunAccessKeySecret: process.env.ALIYUN_SMS_ACCESS_KEY_SECRET || process.env.SMS_ACCESS_KEY_SECRET || "",
    aliyunEndpoint: process.env.ALIYUN_SMS_ENDPOINT || "https://dysmsapi.aliyuncs.com",
    signName: process.env.SMS_SIGN_NAME || "",
    mock: String(process.env.SMS_MOCK || "0") === "1",
  };
}

function maskSecret(value) {
  const text = String(value || "");
  if (!text) return "";
  if (text.length <= 6) return "******";
  return `${text.slice(0, 3)}******${text.slice(-3)}`;
}

function normalizeProvider(provider) {
  const value = String(provider || "aliyun").trim();
  return SMS_PROVIDERS.some(item => item.value === value) ? value : "aliyun";
}

async function getSmsConfig(options = {}) {
  await ensureSmsSchema();
  const envConfig = getConfigFromEnv();
  const [[row]] = await pool.query("SELECT * FROM sms_config WHERE id = 1 LIMIT 1");
  const config = {
    provider: normalizeProvider(row?.provider || envConfig.provider),
    signName: row?.sign_name || envConfig.signName || "",
    mock: row ? Number(row.mock || 0) === 1 : envConfig.mock,
    aliyunAccessKeyId: row?.aliyun_access_key_id || envConfig.aliyunAccessKeyId || "",
    aliyunAccessKeySecret: row?.aliyun_access_key_secret || envConfig.aliyunAccessKeySecret || "",
    aliyunEndpoint: row?.aliyun_endpoint || envConfig.aliyunEndpoint || "https://dysmsapi.aliyuncs.com",
    updatedAt: row?.updated_at || null,
    updatedByName: row?.updated_by_name || "",
  };
  if (options.maskSecret) {
    return {
      ...config,
      aliyunAccessKeySecret: config.aliyunAccessKeySecret ? "******" : "",
      aliyunAccessKeySecretMasked: maskSecret(config.aliyunAccessKeySecret),
      aliyunAccessKeyConfigured: Boolean(config.aliyunAccessKeyId && config.aliyunAccessKeySecret),
      providers: getProviderOptions(config.provider),
      variables: SMS_VARIABLE_DEFINITIONS,
    };
  }
  return config;
}

async function saveSmsConfig(input = {}, operator = {}) {
  await ensureSmsSchema();
  const current = await getSmsConfig();
  const provider = normalizeProvider(input.provider || current.provider);
  const selectedProvider = SMS_PROVIDERS.find(item => item.value === provider);
  if (!selectedProvider || selectedProvider.enabled === false) {
    const error = new Error(`暂不支持启用短信服务商：${provider}`);
    error.statusCode = 400;
    throw error;
  }
  const signName = sanitizeText(input.signName ?? current.signName, 100) || null;
  const mock = input.mock === true || input.mock === 1 || input.mock === "1" ? 1 : 0;
  const aliyunAccessKeyId = sanitizeText(input.aliyunAccessKeyId ?? current.aliyunAccessKeyId, 120) || null;
  const rawSecret = input.aliyunAccessKeySecret;
  const aliyunAccessKeySecret = rawSecret == null || rawSecret === "" || rawSecret === "******"
    ? (current.aliyunAccessKeySecret || null)
    : String(rawSecret).trim().slice(0, 255);
  const aliyunEndpoint = sanitizeText(input.aliyunEndpoint ?? current.aliyunEndpoint, 255) || "https://dysmsapi.aliyuncs.com";

  if (!mock) {
    if (provider === "aliyun") {
      if (!signName) {
        const error = new Error("短信签名不能为空");
        error.statusCode = 400;
        throw error;
      }
      if (!aliyunAccessKeyId || !aliyunAccessKeySecret) {
        const error = new Error("启用真实短信发送前，请先完整配置阿里云 AccessKey");
        error.statusCode = 400;
        throw error;
      }
    }
  }
  await pool.execute(
    `INSERT INTO sms_config (id, provider, sign_name, mock, aliyun_access_key_id, aliyun_access_key_secret, aliyun_endpoint, updated_by, updated_by_name)
     VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE provider=VALUES(provider), sign_name=VALUES(sign_name), mock=VALUES(mock), aliyun_access_key_id=VALUES(aliyun_access_key_id), aliyun_access_key_secret=VALUES(aliyun_access_key_secret), aliyun_endpoint=VALUES(aliyun_endpoint), updated_by=VALUES(updated_by), updated_by_name=VALUES(updated_by_name)`,
    [provider, signName, mock, aliyunAccessKeyId, aliyunAccessKeySecret, aliyunEndpoint, operator.userId || null, operator.realName || operator.username || ""]
  );
  return getSmsConfig({ maskSecret: true });
}

function getProviderOptions(currentProvider) {
  const current = normalizeProvider(currentProvider || process.env.SMS_PROVIDER || "aliyun");
  return SMS_PROVIDERS.map(item => ({ ...item, current: item.value === current }));
}

function buildTemplateParams(vars = {}) {
  const params = {};
  Object.entries(vars || {}).forEach(([key, value]) => {
    if (value != null && value !== "") params[key] = String(value);
  });
  return params;
}

async function sendByAliyun(payload, config) {
  config = config || await getSmsConfig();
  if (config.mock) {
    return { ok: true, requestId: `MOCK_${Date.now()}`, raw: { mock: true } };
  }
  if (!config.aliyunAccessKeyId || !config.aliyunAccessKeySecret) {
    return { ok: false, message: "阿里云短信 AccessKey 未配置" };
  }
  if (!payload.signName) return { ok: false, message: "短信签名未配置" };
  if (!payload.templateCode) return { ok: false, message: "服务商模板ID未配置" };

  const client = new Core({
    accessKeyId: config.aliyunAccessKeyId,
    accessKeySecret: config.aliyunAccessKeySecret,
    endpoint: config.aliyunEndpoint,
    apiVersion: "2017-05-25",
  });

  try {
    const result = await client.request("SendSms", {
      PhoneNumbers: payload.phone,
      SignName: payload.signName,
      TemplateCode: payload.templateCode,
      TemplateParam: JSON.stringify(payload.params || {}),
    }, { method: "POST" });
    const ok = result && result.Code === "OK";
    return { ok, requestId: result?.RequestId || "", message: ok ? "发送成功" : (result?.Message || result?.Code || "发送失败"), raw: result };
  } catch (error) {
    return { ok: false, message: error.message || "短信发送异常", raw: error };
  }
}

async function sendSms(payload) {
  const config = await getSmsConfig();
  const provider = payload.provider || config.provider || "aliyun";
  if (provider !== "aliyun") return { ok: false, message: `暂不支持短信服务商：${provider}` };
  return sendByAliyun(payload, config);
}

module.exports = {
  SMS_VARIABLE_DEFINITIONS,
  getProviderOptions,
  ensureSmsSchema,
  createTaskNo,
  normalizePhone,
  maskPhone,
  isValidPhone,
  sanitizeText,
  safeJsonParse,
  replaceTemplate,
  buildTemplateParams,
  getConfigFromEnv,
  getSmsConfig,
  saveSmsConfig,
  sendSms,
};
