/**
 * 客户业务服务层
 * 所有客户相关的数据库操作和业务逻辑集中在此
 * Controller 只负责 HTTP 参数提取和响应
 */

const { pool } = require("../config/db");
const { ROLE_ADMIN, CUSTOMER_STATUS } = require("../config/constants");
const { formatDateYmd, parseDateYmd, compareDateYmd } = require("../utils/date");
const { toCamelCase } = require("../utils/case");
const { toInt, normalizePage } = require("../utils/pagination");
const { buildStoreScope } = require("../utils/store-scope");
const { createTables } = require("../install/schema");
const {
  getCustomerCardsMap,
  getActiveCustomerCards,
  createCustomerCardRecord,
  syncCustomerCardSnapshot,
} = require("../utils/customer-card");

const CUSTOMER_MODE_ACCOUNT_ONLY = "account_only";
const CUSTOMER_MODE_ACCOUNT_AND_CARD = "account_and_card";

// ─── helpers ──────────────────────────────────────────────


const GLASSES_FLOW_STATUS = {
  ORDERED: 1,
  CUSTOMIZING: 2,
  PRODUCING: 3,
  READY: 4,
  DELIVERED: 5,
  EXCEPTION: 6,
  CANCELED: 7,
};

const GLASSES_FLOW_STATUS_LABELS = {
  1: "已下单",
  2: "定制中",
  3: "制作中",
  4: "待取镜",
  5: "已交付",
  6: "异常处理中",
  7: "已取消",
};

const GLASSES_FLOW_STATUS_OPTIONS = Object.keys(GLASSES_FLOW_STATUS_LABELS).map((key) => ({
  value: Number(key),
  label: GLASSES_FLOW_STATUS_LABELS[key],
}));

function normalizeGlassesStatus(value, fallback = GLASSES_FLOW_STATUS.ORDERED) {
  const status = toInt(value, fallback);
  return GLASSES_FLOW_STATUS_LABELS[status] ? status : fallback;
}

function getGlassesStatusLabel(value) {
  return GLASSES_FLOW_STATUS_LABELS[normalizeGlassesStatus(value)] || GLASSES_FLOW_STATUS_LABELS[GLASSES_FLOW_STATUS.ORDERED];
}

function isGlassesTerminalStatus(value) {
  const status = normalizeGlassesStatus(value);
  return status === GLASSES_FLOW_STATUS.DELIVERED || status === GLASSES_FLOW_STATUS.CANCELED;
}

function parseTags(input) {
  if (Array.isArray(input)) {
    return [...new Set(input.map((item) => String(item).trim()).filter(Boolean))];
  }
  if (typeof input === "string") {
    return [...new Set(input.split(/[,，|]/).map((item) => item.trim()).filter(Boolean))];
  }
  return [];
}

function isValidPhone(phone) {
  return /^1[3-9]\d{9}$/.test(String(phone || ""));
}

function tagsToDbString(tags) {
  return parseTags(tags).join(",");
}

function dbStringToTags(value) {
  if (!value) return [];
  return String(value).split(",").map((item) => item.trim()).filter(Boolean);
}

function buildCustomerNo() {
  const now = new Date();
  const year = now.getFullYear();
  const month = `${now.getMonth() + 1}`.padStart(2, "0");
  const day = `${now.getDate()}`.padStart(2, "0");
  const random = `${Math.floor(Math.random() * 90000) + 10000}`;
  return `CUS${year}${month}${day}${random}`;
}

function normalizeCustomerMode(value, fallback = CUSTOMER_MODE_ACCOUNT_AND_CARD) {
  const text = String(value || "").trim();
  if (text === CUSTOMER_MODE_ACCOUNT_ONLY) return CUSTOMER_MODE_ACCOUNT_ONLY;
  if (text === CUSTOMER_MODE_ACCOUNT_AND_CARD) return CUSTOMER_MODE_ACCOUNT_AND_CARD;
  return fallback;
}

function hasCustomerCard(row) {
  return Number(row?.has_card || 0) === 1;
}

function normalizeOptionalText(value, maxLength = 32) {
  const text = String(value ?? "").trim();
  return text ? text.slice(0, maxLength) : null;
}

function normalizeRemarkText(value, maxLength = 500) {
  const text = String(value ?? "").trim();
  return text ? text.slice(0, maxLength) : null;
}

function normalizeSalePrice(value) {
  if (value === "" || value == null) return null;
  const num = Number(value);
  if (!Number.isFinite(num) || num < 0) return null;
  return Math.round(num * 100) / 100;
}

// ─── DB helpers ───────────────────────────────────────────

let schemaReadyPromise = null;
let schemaReadySignature = "";

function ensureCustomerSchema(config) {
  const nextSignature = JSON.stringify(config || {});
  if (!schemaReadyPromise || schemaReadySignature !== nextSignature) {
    schemaReadySignature = nextSignature;
    schemaReadyPromise = createTables(pool).catch((error) => {
      schemaReadyPromise = null;
      schemaReadySignature = "";
      throw error;
    });
  }
  return schemaReadyPromise;
}

// ─── builders ─────────────────────────────────────────────

function buildEyeProfilePayload(payload = {}) {
  return {
    nakedVisionOd: normalizeOptionalText(payload.nakedVisionOd),
    nakedVisionOs: normalizeOptionalText(payload.nakedVisionOs),
    correctedVisionOd: normalizeOptionalText(payload.correctedVisionOd),
    correctedVisionOs: normalizeOptionalText(payload.correctedVisionOs),
    pd: normalizeOptionalText(payload.pd),
    oldSphereOd: normalizeOptionalText(payload.oldSphereOd),
    oldCylinderOd: normalizeOptionalText(payload.oldCylinderOd),
    oldAxisOd: normalizeOptionalText(payload.oldAxisOd),
    oldSphereOs: normalizeOptionalText(payload.oldSphereOs),
    oldCylinderOs: normalizeOptionalText(payload.oldCylinderOs),
    oldAxisOs: normalizeOptionalText(payload.oldAxisOs),
  };
}

function buildVisitCheckPayload(payload = {}) {
  return {
    checkResult: String(payload.checkResult || "").trim(),
    suggestion: String(payload.suggestion || "").trim(),
    remark: String(payload.remark || "").trim(),
    ...buildEyeProfilePayload(payload),
    // exam fields
    examSphereOd: normalizeOptionalText(payload.examSphereOd),
    examCylinderOd: normalizeOptionalText(payload.examCylinderOd),
    examAxisOd: normalizeOptionalText(payload.examAxisOd),
    examSphereOs: normalizeOptionalText(payload.examSphereOs),
    examCylinderOs: normalizeOptionalText(payload.examCylinderOs),
    examAxisOs: normalizeOptionalText(payload.examAxisOs),
    recommendedSphereOd: normalizeOptionalText(payload.recommendedSphereOd),
    recommendedCylinderOd: normalizeOptionalText(payload.recommendedCylinderOd),
    recommendedAxisOd: normalizeOptionalText(payload.recommendedAxisOd),
    recommendedSphereOs: normalizeOptionalText(payload.recommendedSphereOs),
    recommendedCylinderOs: normalizeOptionalText(payload.recommendedCylinderOs),
    recommendedAxisOs: normalizeOptionalText(payload.recommendedAxisOs),
  };
}

function buildGlassesRecordPayload(payload = {}) {
  return {
    recordTime: String(payload.recordTime || "").trim(),
    sourceCheckId: payload.sourceCheckId == null || payload.sourceCheckId === "" ? null : toInt(payload.sourceCheckId, 0),
    deliveryStatus: normalizeGlassesStatus(payload.deliveryStatus, GLASSES_FLOW_STATUS.ORDERED),
    pd: normalizeOptionalText(payload.pd),
    sphereOd: normalizeOptionalText(payload.sphereOd),
    cylinderOd: normalizeOptionalText(payload.cylinderOd),
    axisOd: normalizeOptionalText(payload.axisOd),
    sphereOs: normalizeOptionalText(payload.sphereOs),
    cylinderOs: normalizeOptionalText(payload.cylinderOs),
    axisOs: normalizeOptionalText(payload.axisOs),
    lensBrand: normalizeOptionalText(payload.lensBrand, 100),
    lensType: normalizeOptionalText(payload.lensType, 100),
    frameInfo: normalizeOptionalText(payload.frameInfo, 255),
    remark: normalizeRemarkText(payload.remark),
  };
}

// ─── formatters ───────────────────────────────────────────

function formatCustomer(row) {
  if (!row) return null;
  const hasCard = hasCustomerCard(row);
  return {
    id: Number(row.id),
    customerNo: row.customer_no || "",
    childName: row.child_name || "",
    gender: row.gender == null ? null : Number(row.gender),
    birthday: row.birthday || null,
    parentName: row.parent_name || "",
    parentPhone: row.parent_phone || "",
    storeId: Number(row.store_id || 0),
    storeName: row.store_name || "",
    hasCard,
    customerMode: hasCard ? CUSTOMER_MODE_ACCOUNT_AND_CARD : CUSTOMER_MODE_ACCOUNT_ONLY,
    customerStage: hasCard ? "carded" : "account_only",
    currentCardId: row.current_card_id == null ? null : Number(row.current_card_id || 0),
    currentCardName: row.current_card_name || "",
    currentCardSalePrice: row.current_card_sale_price == null ? null : Number(row.current_card_sale_price),
    trainingProject: row.training_project || "",
    totalTimes: Number(row.total_times || 0),
    usedTimes: Number(row.used_times || 0),
    remainingTimes: !hasCard ? 0 : row.remaining_times == null ? Number(row.total_times || 0) - Number(row.used_times || 0) : Number(row.remaining_times || 0),
    openCardDate: hasCard ? row.open_card_date || null : null,
    expireDate: hasCard ? row.expire_date || null : null,
    status: Number(row.status || 0),
    remark: row.remark || "",
    tags: dbStringToTags(row.tags),
    tagsText: row.tags || "",
    createdBy: row.created_by == null ? null : Number(row.created_by),
    updatedBy: row.updated_by == null ? null : Number(row.updated_by),
    createdAt: row.created_at || null,
    updatedAt: row.updated_at || null,
    eyeProfile: {
      nakedVisionOd: row.naked_vision_od || "",
      nakedVisionOs: row.naked_vision_os || "",
      correctedVisionOd: row.corrected_vision_od || "",
      correctedVisionOs: row.corrected_vision_os || "",
      pd: row.pd || "",
      oldSphereOd: row.old_sphere_od || "",
      oldCylinderOd: row.old_cylinder_od || "",
      oldAxisOd: row.old_axis_od || "",
      oldSphereOs: row.old_sphere_os || "",
      oldCylinderOs: row.old_cylinder_os || "",
      oldAxisOs: row.old_axis_os || "",
    },
    customerCards: [],
  };
}

function formatAttachment(row) {
  if (!row) return null;
  return {
    id: Number(row.id), customerId: Number(row.customer_id),
    fileName: row.file_name, filePath: row.file_path, fileUrl: row.file_path,
    fileExt: row.file_ext || "", fileSize: Number(row.file_size || 0),
    mimeType: row.mime_type || "", uploadedBy: row.uploaded_by == null ? null : Number(row.uploaded_by),
    createdAt: row.created_at || null,
  };
}

function formatFollowUpRecord(row) {
  if (!row) return null;
  return {
    id: Number(row.id), customerId: Number(row.customer_id || 0),
    recordTime: row.record_time || null, result: row.result || "", content: row.content || "",
    operatorId: Number(row.operator_id || 0), operatorName: row.operator_name || "",
    remark: row.remark || "", createdAt: row.created_at || null,
  };
}

function formatVisitCheckRecord(row) {
  if (!row) return null;
  return {
    id: Number(row.id), customerId: Number(row.customer_id || 0),
    checkTime: row.check_time || null, checkResult: row.check_result || "",
    suggestion: row.suggestion || "",
    nakedVisionOd: row.naked_vision_od || "", nakedVisionOs: row.naked_vision_os || "",
    correctedVisionOd: row.corrected_vision_od || "", correctedVisionOs: row.corrected_vision_os || "",
    pd: row.pd || "",
    examSphereOd: row.exam_sphere_od || "", examCylinderOd: row.exam_cylinder_od || "", examAxisOd: row.exam_axis_od || "",
    examSphereOs: row.exam_sphere_os || "", examCylinderOs: row.exam_cylinder_os || "", examAxisOs: row.exam_axis_os || "",
    recommendedSphereOd: row.recommended_sphere_od || "", recommendedCylinderOd: row.recommended_cylinder_od || "", recommendedAxisOd: row.recommended_axis_od || "",
    recommendedSphereOs: row.recommended_sphere_os || "", recommendedCylinderOs: row.recommended_cylinder_os || "", recommendedAxisOs: row.recommended_axis_os || "",
    operatorId: Number(row.operator_id || 0), operatorName: row.operator_name || "",
    remark: row.remark || "", createdAt: row.created_at || null,
  };
}

function formatGlassesRecord(row) {
  if (!row) return null;
  return {
    id: Number(row.id), customerId: Number(row.customer_id || 0),
    sourceCheckId: row.source_check_id == null ? null : Number(row.source_check_id || 0),
    recordTime: row.record_time || null, deliveryStatus: normalizeGlassesStatus(row.delivery_status), deliveryStatusLabel: getGlassesStatusLabel(row.delivery_status),
    pd: row.pd || "",
    sphereOd: row.sphere_od || "", cylinderOd: row.cylinder_od || "", axisOd: row.axis_od || "",
    sphereOs: row.sphere_os || "", cylinderOs: row.cylinder_os || "", axisOs: row.axis_os || "",
    lensBrand: row.lens_brand || "", lensType: row.lens_type || "", frameInfo: row.frame_info || "",
    operatorId: Number(row.operator_id || 0), operatorName: row.operator_name || "",
    remark: row.remark || "", createdAt: row.created_at || null,
  };
}

function buildCurrentGlassesSummary(eyeProfile = {}, glassesRecord = null) {
  if (glassesRecord) {
    return {
      source: "glasses_record",
      label: glassesRecord.deliveryStatus === GLASSES_FLOW_STATUS.DELIVERED ? "当前佩戴镜参数" : "最近一次配镜参数",
      recordTime: glassesRecord.recordTime || null,
      deliveryStatus: glassesRecord.deliveryStatus,
      deliveryStatusLabel: glassesRecord.deliveryStatusLabel || getGlassesStatusLabel(glassesRecord.deliveryStatus),
      lensBrand: glassesRecord.lensBrand || "", lensType: glassesRecord.lensType || "",
      frameInfo: glassesRecord.frameInfo || "",
      pd: glassesRecord.pd || "",
      sphereOd: glassesRecord.sphereOd || "", cylinderOd: glassesRecord.cylinderOd || "", axisOd: glassesRecord.axisOd || "",
      sphereOs: glassesRecord.sphereOs || "", cylinderOs: glassesRecord.cylinderOs || "", axisOs: glassesRecord.axisOs || "",
      remark: glassesRecord.remark || "",
    };
  }
  const hasBase = eyeProfile?.pd || eyeProfile?.oldSphereOd || eyeProfile?.oldCylinderOd || eyeProfile?.oldAxisOd || eyeProfile?.oldSphereOs || eyeProfile?.oldCylinderOs || eyeProfile?.oldAxisOs;
  if (!hasBase) return null;
  return {
    source: "eye_profile", label: "建档原镜参考", recordTime: null, deliveryStatus: null,
    lensBrand: "", lensType: "", frameInfo: "",
    pd: eyeProfile?.pd || "",
    sphereOd: eyeProfile?.oldSphereOd || "", cylinderOd: eyeProfile?.oldCylinderOd || "", axisOd: eyeProfile?.oldAxisOd || "",
    sphereOs: eyeProfile?.oldSphereOs || "", cylinderOs: eyeProfile?.oldCylinderOs || "", axisOs: eyeProfile?.oldAxisOs || "",
    remark: "",
  };
}

function formatTimelineEvent(event = {}) {
  return {
    id: String(event.id || ""), type: String(event.type || ""),
    title: String(event.title || ""), description: String(event.description || ""),
    operatorName: event.operatorName || "", createdAt: event.createdAt || null,
    status: event.status == null ? null : Number(event.status), meta: event.meta || {},
  };
}

// ─── core CRUD ────────────────────────────────────────────

async function getCustomerById(customerId, user) {
  const scope = buildStoreScope(user, "c.store_id");
  const [rows] = await pool.query(
    `SELECT c.id, c.customer_no, c.child_name, c.gender, c.birthday, c.parent_name, c.parent_phone,
      c.store_id, c.has_card, s.store_name, c.training_project, c.total_times, c.used_times,
      c.remaining_times, c.open_card_date, c.expire_date, c.status, c.remark, c.tags,
      c.created_by, c.updated_by, c.created_at, c.updated_at,
      ep.naked_vision_od, ep.naked_vision_os, ep.corrected_vision_od, ep.corrected_vision_os,
      ep.pd, ep.old_sphere_od, ep.old_cylinder_od, ep.old_axis_od,
      ep.old_sphere_os, ep.old_cylinder_os, ep.old_axis_os
    FROM customers c
    LEFT JOIN stores s ON s.id = c.store_id
    LEFT JOIN customer_eye_profiles ep ON ep.customer_id = c.id
    WHERE c.id = ? AND ${scope.sql} LIMIT 1`,
    [customerId, ...scope.params],
  );
  return rows[0] || null;
}

async function upsertCustomerEyeProfile(connection, customerId, payload = {}) {
  const ep = buildEyeProfilePayload(payload);
  const values = [customerId, ep.nakedVisionOd, ep.nakedVisionOs, ep.correctedVisionOd, ep.correctedVisionOs, ep.pd, ep.oldSphereOd, ep.oldCylinderOd, ep.oldAxisOd, ep.oldSphereOs, ep.oldCylinderOs, ep.oldAxisOs];
  const hasAny = values.slice(1).some((v) => v != null);
  if (!hasAny) {
    await connection.execute("DELETE FROM customer_eye_profiles WHERE customer_id = ?", [customerId]);
    return;
  }
  await connection.execute(
    `INSERT INTO customer_eye_profiles (customer_id, naked_vision_od, naked_vision_os, corrected_vision_od, corrected_vision_os, pd, old_sphere_od, old_cylinder_od, old_axis_od, old_sphere_os, old_cylinder_os, old_axis_os)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE naked_vision_od=VALUES(naked_vision_od), naked_vision_os=VALUES(naked_vision_os),
       corrected_vision_od=VALUES(corrected_vision_od), corrected_vision_os=VALUES(corrected_vision_os),
       pd=VALUES(pd), old_sphere_od=VALUES(old_sphere_od), old_cylinder_od=VALUES(old_cylinder_od), old_axis_od=VALUES(old_axis_od),
       old_sphere_os=VALUES(old_sphere_os), old_cylinder_os=VALUES(old_cylinder_os), old_axis_os=VALUES(old_axis_os)`,
    values,
  );
}

async function resolveCardPayload(connection, payload = {}, options = {}) {
  const cardTemplateId = toInt(payload.cardTemplateId ?? payload.card_template_id, 0);
  let template = null;
  if (cardTemplateId) {
    const [rows] = await connection.query("SELECT * FROM card_templates WHERE id = ? LIMIT 1", [cardTemplateId]);
    template = rows[0] || null;
  }
  if (options.requireTemplate && !template) return { error: "请选择卡项模板", errorCode: "MISSING_CARD_TEMPLATE" };
  if (template && Number(template.status || 0) !== 1) return { error: "所选卡项模板已停用", errorCode: "CARD_TEMPLATE_DISABLED" };
  if (options.requirePromotion && template && Number(template.is_promotion || 0) !== 1) return { error: "所选模板不是活动卡模板", errorCode: "CARD_TEMPLATE_NOT_PROMOTION" };
  const cardName = String(payload.cardName || template?.card_name || "").trim();
  const trainingProject = String(payload.trainingProject || template?.training_project || "").trim();
  const totalTimes = toInt(payload.totalTimes, template ? Number(template.default_times || 0) : 0);
  const salePrice = normalizeSalePrice(payload.salePrice);
  return { cardTemplateId: template ? Number(template.id) : null, cardName, trainingProject, totalTimes, salePrice, template };
}

// ─── list helpers ─────────────────────────────────────────

function buildListWhere(user, filters = {}) {
  const { keyword, status, storeId, tag, customerMode, startExpireDate, endExpireDate } = filters;
  const where = [];
  const params = [];
  const scope = buildStoreScope(user, "c.store_id");
  where.push(scope.sql);
  params.push(...scope.params);
  if (Number(user.role) === ROLE_ADMIN && storeId > 0) {
    where.push("c.store_id = ?");
    params.push(storeId);
  }
  if (keyword) {
    where.push("(c.customer_no LIKE ? OR c.child_name LIKE ? OR c.parent_name LIKE ? OR c.parent_phone LIKE ? OR c.training_project LIKE ?)");
    params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
  }
  if (status === 0 || status === 1) { where.push("c.status = ?"); params.push(status); }
  if (tag) { where.push("c.tags LIKE ?"); params.push(`%${tag}%`); }
  if (customerMode === CUSTOMER_MODE_ACCOUNT_ONLY) { where.push("c.has_card = 0"); }
  else if (customerMode === CUSTOMER_MODE_ACCOUNT_AND_CARD) { where.push("c.has_card = 1"); }
  if (startExpireDate) { where.push("c.has_card = 1"); where.push("c.expire_date >= ?"); params.push(startExpireDate); }
  if (endExpireDate) { where.push("c.has_card = 1"); where.push("c.expire_date <= ?"); params.push(endExpireDate); }
  return { whereSql: where.length ? `WHERE ${where.join(" AND ")}` : "", params };
}

async function getCustomerList(user, query = {}) {
  await ensureCustomerSchema();
  const { pageNum, pageSize, offset } = normalizePage(query);
  const filters = {
    keyword: String(query.keyword || "").trim(),
    status: query.status === "" || query.status == null ? null : toInt(query.status, -1),
    storeId: toInt(query.storeId, 0),
    tag: String(query.tag || "").trim(),
    customerMode: normalizeCustomerMode(query.customerMode, ""),
    startExpireDate: String(query.startExpireDate || "").trim(),
    endExpireDate: String(query.endExpireDate || "").trim(),
  };
  const { whereSql, params } = buildListWhere(user, filters);
  const countSql = `SELECT COUNT(*) AS total FROM customers c ${whereSql}`;
  const listSql = `SELECT c.id, c.customer_no, c.child_name, c.gender, c.birthday, c.parent_name, c.parent_phone,
    c.store_id, c.has_card, s.store_name, c.training_project, c.total_times, c.used_times, c.remaining_times,
    c.open_card_date, c.expire_date, c.status, c.remark, c.tags, c.created_by, c.updated_by, c.created_at, c.updated_at
    FROM customers c LEFT JOIN stores s ON s.id = c.store_id ${whereSql} ORDER BY c.id DESC LIMIT ? OFFSET ?`;
  const [[countRow]] = await pool.query(countSql, params);
  const [rows] = await pool.query(listSql, [...params, pageSize, offset]);
  const cardMap = await getCustomerCardsMap(pool, rows.map((item) => item.id), { activeOnly: true });
  const list = rows.map((row) => {
    const customer = formatCustomer(row);
    const cards = cardMap.get(Number(row.id || 0)) || [];
    customer.customerCards = cards;
    const mainCard = cards.find((item) => !item.isPromotion) || null;
    if (mainCard) {
      customer.currentCardId = mainCard.id;
      customer.currentCardName = mainCard.cardName;
      customer.currentCardSalePrice = mainCard.salePrice;
    }
    return customer;
  });
  return { list, total: Number(countRow.total || 0), pageNum, pageSize };
}

async function getCustomerDetail(user, id) {
  await ensureCustomerSchema();
  const customer = await getCustomerById(id, user);
  if (!customer) return null;

  const [attachments] = await pool.query("SELECT id, customer_id, file_name, file_path, file_ext, file_size, mime_type, uploaded_by, created_at FROM customer_attachments WHERE customer_id = ? ORDER BY id DESC", [id]);
  const [renewals] = await pool.query("SELECT id, customer_id, before_total_times, before_used_times, before_expire_date, add_times, after_total_times, after_expire_date, operator_id, operator_name, remark, created_at FROM customer_renewals WHERE customer_id = ? ORDER BY id DESC", [id]);
  const [verifyRecords] = await pool.query("SELECT id, verify_no, verify_date, verify_time, customer_card_id, card_name, card_sale_price, revoked, revoked_at, revoked_by, revoked_by_name, revoke_reason, operator_id, operator_name, remark, created_at FROM verify_records WHERE customer_id = ? ORDER BY verify_time DESC, id DESC", [id]);
  const [followUpRecords] = await pool.query("SELECT id, customer_id, record_time, result, content, operator_id, operator_name, remark, created_at FROM customer_follow_ups WHERE customer_id = ? ORDER BY record_time DESC, id DESC", [id]);
  const [visitCheckRecords] = await pool.query("SELECT id, customer_id, check_time, check_result, naked_vision_od, naked_vision_os, corrected_vision_od, corrected_vision_os, pd, exam_sphere_od, exam_cylinder_od, exam_axis_od, exam_sphere_os, exam_cylinder_os, exam_axis_os, recommended_sphere_od, recommended_cylinder_od, recommended_axis_od, recommended_sphere_os, recommended_cylinder_os, recommended_axis_os, suggestion, operator_id, operator_name, remark, created_at FROM customer_visit_checks WHERE customer_id = ? ORDER BY check_time DESC, id DESC", [id]);
  const [glassesRecords] = await pool.query("SELECT id, customer_id, record_time, source_check_id, delivery_status, pd, sphere_od, cylinder_od, axis_od, sphere_os, cylinder_os, axis_os, lens_brand, lens_type, frame_info, operator_id, operator_name, remark, created_at FROM customer_glasses_records WHERE customer_id = ? ORDER BY record_time DESC, id DESC", [id]);
  const [statusLogs] = await pool.query("SELECT id, action, content, operator_name, created_at FROM operation_logs WHERE module = 'customer' AND biz_type = 'customer' AND action = 'update_status' AND biz_id = ? ORDER BY created_at DESC, id DESC", [id]);
  const [activityCardUsageLogs] = await pool.query("SELECT l.id, l.customer_card_id, l.customer_id, l.action_type, l.quantity, l.before_used_times, l.after_used_times, l.remark, l.operator_id, l.operator_name, l.created_at, cc.card_name_snapshot, cc.sale_price FROM customer_card_usage_logs l INNER JOIN customer_cards cc ON cc.id = l.customer_card_id WHERE l.customer_id = ? ORDER BY l.created_at DESC, l.id DESC", [id]);

  const customerCardsMap = await getCustomerCardsMap(pool, [id]);
  const customerCards = customerCardsMap.get(id) || [];

  const formattedRenewals = renewals.map((item) => ({
    id: Number(item.id), customerId: Number(item.customer_id),
    beforeTotalTimes: Number(item.before_total_times || 0), beforeUsedTimes: Number(item.before_used_times || 0),
    beforeExpireDate: item.before_expire_date, addTimes: Number(item.add_times || 0),
    afterTotalTimes: Number(item.after_total_times || 0), afterExpireDate: item.after_expire_date,
    operatorId: Number(item.operator_id || 0), operatorName: item.operator_name || "",
    remark: item.remark || "", createdAt: item.created_at,
  }));

  const formattedVerifyRecords = verifyRecords.map((item) => ({
    id: Number(item.id), verifyNo: item.verify_no || "", verifyDate: item.verify_date, verifyTime: item.verify_time,
    customerCardId: Number(item.customer_card_id || 0) || null, cardName: item.card_name || "",
    cardSalePrice: item.card_sale_price == null ? null : Number(item.card_sale_price),
    revoked: Number(item.revoked || 0) === 1, revokedAt: item.revoked_at || null,
    revokedBy: Number(item.revoked_by || 0), revokedByName: item.revoked_by_name || "",
    revokeReason: item.revoke_reason || "", operatorId: Number(item.operator_id || 0),
    operatorName: item.operator_name || "", remark: item.remark || "", createdAt: item.created_at,
  }));

  const formattedFollowUpRecords = followUpRecords.map(formatFollowUpRecord);
  const formattedVisitCheckRecords = visitCheckRecords.map(formatVisitCheckRecord);
  const formattedGlassesRecords = glassesRecords.map(formatGlassesRecord);
  const formattedActivityCardUsageLogs = activityCardUsageLogs.map((item) => ({
    id: Number(item.id), customerCardId: Number(item.customer_card_id || 0),
    customerId: Number(item.customer_id || 0), actionType: item.action_type || "consume",
    quantity: Number(item.quantity || 1), beforeUsedTimes: Number(item.before_used_times || 0),
    afterUsedTimes: Number(item.after_used_times || 0), remark: item.remark || "",
    operatorId: Number(item.operator_id || 0), operatorName: item.operator_name || "",
    cardName: item.card_name_snapshot || "", salePrice: item.sale_price == null ? null : Number(item.sale_price),
    createdAt: item.created_at,
  }));

  const latestDeliveredGlassesRecord = formattedGlassesRecords.find((item) => item.deliveryStatus === GLASSES_FLOW_STATUS.DELIVERED) || formattedGlassesRecords[0] || null;
  const currentGlasses = buildCurrentGlassesSummary(formatCustomer(customer).eyeProfile, latestDeliveredGlassesRecord);

  const timeline = [
    formatTimelineEvent({ id: `account-${customer.id}`, type: "account_open", title: "客户开户", description: "已创建客户档案", createdAt: customer.created_at, status: customer.status, meta: { hasCard: hasCustomerCard(customer) } }),
    ...(customerCards.length ? customerCards.map((item) => formatTimelineEvent({ id: `open-${item.id}`, type: "open_card", title: "客户开卡", description: `${item.cardName}，${item.totalTimes} 次${item.salePrice != null ? `，成交价 ¥${item.salePrice}` : ""}`, createdAt: item.openCardDate || item.createdAt, status: customer.status, meta: { cardName: item.cardName, totalTimes: item.totalTimes, expireDate: item.expireDate, trainingProject: item.trainingProject || "", salePrice: item.salePrice } })) : hasCustomerCard(customer) ? [formatTimelineEvent({ id: `open-${customer.id}`, type: "open_card", title: "客户开卡", description: `开卡建档，项目：${customer.training_project}，总次数：${customer.total_times}，到期日：${customer.expire_date}`, createdAt: customer.open_card_date || customer.created_at, status: customer.status, meta: { totalTimes: Number(customer.total_times || 0), expireDate: customer.expire_date, trainingProject: customer.training_project || "" } })] : []),
    ...formattedRenewals.map((item) => formatTimelineEvent({ id: `renew-${item.id}`, type: "renew", title: "客户续卡", description: `增加 ${item.addTimes} 次，到期日调整为 ${item.afterExpireDate}`, operatorName: item.operatorName, createdAt: item.createdAt, meta: { addTimes: item.addTimes, beforeExpireDate: item.beforeExpireDate, afterExpireDate: item.afterExpireDate } })),
    ...formattedVerifyRecords.map((item) => formatTimelineEvent({ id: `verify-${item.id}`, type: "verify", title: item.revoked ? "核销记录" : "核销完成", description: `核销单号：${item.verifyNo}`, operatorName: item.operatorName, createdAt: item.verifyTime || item.createdAt, meta: { verifyNo: item.verifyNo, verifyDate: item.verifyDate, remark: item.remark || "", revoked: item.revoked, revokedAt: item.revokedAt, revokeReason: item.revokeReason || "" } })),
    ...formattedVerifyRecords.filter((item) => item.revoked && item.revokedAt).map((item) => formatTimelineEvent({ id: `verify-revoke-${item.id}`, type: "verify_revoke", title: "撤回核销", description: `撤回核销单号：${item.verifyNo}${item.revokeReason ? `，原因：${item.revokeReason}` : ""}`, operatorName: item.revokedByName || item.operatorName, createdAt: item.revokedAt || item.createdAt, meta: { verifyNo: item.verifyNo, revokeReason: item.revokeReason || "" } })),
    ...formattedFollowUpRecords.map((item) => formatTimelineEvent({ id: `follow-up-${item.id}`, type: "follow_up", title: "客户回访", description: `${item.result}${item.content ? `：${item.content}` : ""}`, operatorName: item.operatorName, createdAt: item.recordTime || item.createdAt, meta: { result: item.result, content: item.content, remark: item.remark || "" } })),
    ...formattedVisitCheckRecords.map((item) => formatTimelineEvent({ id: `visit-check-${item.id}`, type: "visit_check", title: "到店检查", description: item.checkResult || "已记录到店检查", operatorName: item.operatorName, createdAt: item.checkTime || item.createdAt, meta: { checkResult: item.checkResult, suggestion: item.suggestion || "", remark: item.remark || "" } })),
    ...formattedGlassesRecords.map((item) => formatTimelineEvent({ id: `glasses-${item.id}`, type: "glasses_record", title: item.deliveryStatus === GLASSES_FLOW_STATUS.DELIVERED ? "配镜交付" : `配镜进度：${item.deliveryStatusLabel || getGlassesStatusLabel(item.deliveryStatus)}`, description: [item.lensBrand || item.lensType ? `镜片：${[item.lensBrand, item.lensType].filter(Boolean).join(" / ")}` : "", item.frameInfo ? `镜架：${item.frameInfo}` : ""].filter(Boolean).join("，") || "已记录配镜参数", operatorName: item.operatorName, createdAt: item.recordTime || item.createdAt, meta: { deliveryStatus: item.deliveryStatus, deliveryStatusLabel: item.deliveryStatusLabel || getGlassesStatusLabel(item.deliveryStatus), pd: item.pd || "", remark: item.remark || "" } })),
    ...statusLogs.map((item) => formatTimelineEvent({ id: `status-${item.id}`, type: "status_change", title: "状态变更", description: item.content || "客户状态已变更", operatorName: item.operator_name || "", createdAt: item.created_at })),
  ].sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

  const formattedCustomer = formatCustomer(customer);
  formattedCustomer.customerCards = customerCards;
  const currentMainCard = customerCards.find((item) => !item.isPromotion) || null;
  if (currentMainCard) {
    formattedCustomer.currentCardId = currentMainCard.id;
    formattedCustomer.currentCardName = currentMainCard.cardName;
    formattedCustomer.currentCardSalePrice = currentMainCard.salePrice;
  }

  return {
    ...formattedCustomer, attachments: attachments.map(formatAttachment),
    currentCard: currentMainCard, customerCards,
    activityCardUsageLogs: formattedActivityCardUsageLogs,
    renewals: formattedRenewals, verifyRecords: formattedVerifyRecords,
    followUpRecords: formattedFollowUpRecords, visitCheckRecords: formattedVisitCheckRecords,
    glassesRecords: formattedGlassesRecords, currentGlasses, timeline,
  };
}

// ─── options / stats / tags ───────────────────────────────

async function getCustomerOptions(user, keyword, status, customerMode) {
  await ensureCustomerSchema();
  const scope = buildStoreScope(user, "c.store_id");
  const where = [scope.sql];
  const params = [...scope.params];
  if (status === 0 || status === 1) { where.push("c.status = ?"); params.push(status); }
  if (keyword) { where.push("(c.child_name LIKE ? OR c.parent_phone LIKE ? OR c.training_project LIKE ?)"); params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`); }
  if (customerMode === CUSTOMER_MODE_ACCOUNT_ONLY) { where.push("c.has_card = 0"); }
  else if (customerMode === CUSTOMER_MODE_ACCOUNT_AND_CARD) { where.push("c.has_card = 1"); }
  const [rows] = await pool.query(
    `SELECT c.id, c.customer_no, c.child_name, c.parent_name, c.parent_phone, c.store_id, c.has_card,
      s.store_name, c.training_project, c.total_times, c.used_times, c.remaining_times, c.expire_date, c.status, c.tags
    FROM customers c LEFT JOIN stores s ON s.id = c.store_id
    WHERE ${where.join(" AND ")} ORDER BY c.child_name ASC, c.id DESC LIMIT 300`,
    params,
  );
  return rows.map((row) => ({
    id: Number(row.id), customerNo: row.customer_no, childName: row.child_name,
    parentName: row.parent_name || "", parentPhone: row.parent_phone,
    storeId: Number(row.store_id || 0), storeName: row.store_name || "",
    hasCard: Number(row.has_card || 0) === 1,
    customerMode: Number(row.has_card || 0) === 1 ? CUSTOMER_MODE_ACCOUNT_AND_CARD : CUSTOMER_MODE_ACCOUNT_ONLY,
    trainingProject: row.training_project, totalTimes: Number(row.total_times || 0),
    usedTimes: Number(row.used_times || 0),
    remainingTimes: Number(row.has_card || 0) !== 1 ? 0 : row.remaining_times == null ? Number(row.total_times || 0) - Number(row.used_times || 0) : Number(row.remaining_times || 0),
    expireDate: Number(row.has_card || 0) === 1 ? row.expire_date : null,
    status: Number(row.status || 0), tags: dbStringToTags(row.tags),
  }));
}

async function getCustomerTags(user) {
  await ensureCustomerSchema();
  const scope = buildStoreScope(user, "c.store_id");
  const [rows] = await pool.query("SELECT c.tags FROM customers c WHERE c.tags IS NOT NULL AND c.tags <> '' AND " + scope.sql, scope.params);
  const tagMap = {};
  for (const row of rows) {
    for (const tag of dbStringToTags(row.tags)) { tagMap[tag] = (tagMap[tag] || 0) + 1; }
  }
  return Object.entries(tagMap).map(([tag, count]) => ({ tag, count })).sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag, "zh-CN"));
}

module.exports = {
  // helpers
  GLASSES_FLOW_STATUS, GLASSES_FLOW_STATUS_LABELS, GLASSES_FLOW_STATUS_OPTIONS, normalizeGlassesStatus, getGlassesStatusLabel, isGlassesTerminalStatus,
  parseTags, isValidPhone, tagsToDbString, dbStringToTags, buildCustomerNo,
  normalizeCustomerMode, hasCustomerCard, normalizeOptionalText, normalizeRemarkText, normalizeSalePrice,
  // builders
  buildEyeProfilePayload, buildVisitCheckPayload, buildGlassesRecordPayload, buildCurrentGlassesSummary,
  // formatters
  formatCustomer, formatAttachment, formatFollowUpRecord, formatVisitCheckRecord, formatGlassesRecord, formatTimelineEvent,
  // DB
  ensureCustomerSchema, getCustomerById, upsertCustomerEyeProfile, resolveCardPayload,
  // CRUD
  getCustomerList, getCustomerDetail, getCustomerOptions, getCustomerTags,
  CUSTOMER_MODE_ACCOUNT_ONLY, CUSTOMER_MODE_ACCOUNT_AND_CARD,
};
