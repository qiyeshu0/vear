const ExcelJS = require("exceljs");
const { pool } = require("../config/db");
const { ROLE_ADMIN } = require("../config/constants");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { buildStoreScope } = require("../middleware/auth");
const { writeOperationLog } = require("../utils/operation-log");
const { createTables } = require("../install/schema");
const { syncCustomerCardSnapshot } = require("../utils/customer-card");
const { toInt } = require("../utils/pagination");

let recordSchemaPromise = null;

function ensureRecordSchema() {
  if (!recordSchemaPromise) {
    recordSchemaPromise = createTables(pool).catch((error) => {
      recordSchemaPromise = null;
      throw error;
    });
  }

  return recordSchemaPromise;
}


function normalizePagination(query = {}) {
  const pageNum = Math.max(toInt(query.pageNum, 1), 1);
  const pageSize = Math.min(Math.max(toInt(query.pageSize, 10), 1), 200);
  const offset = (pageNum - 1) * pageSize;

  return {
    pageNum,
    pageSize,
    offset,
  };
}

function buildDateRangeConditions(
  startDate,
  endDate,
  fieldName = "vr.verify_date",
) {
  const conditions = [];
  const params = [];

  if (startDate) {
    conditions.push(`${fieldName} >= ?`);
    params.push(startDate);
  }

  if (endDate) {
    conditions.push(`${fieldName} <= ?`);
    params.push(endDate);
  }

  return {
    conditions,
    params,
  };
}

function formatRecord(row) {
  if (!row) return null;

  return {
    id: Number(row.id),
    verifyNo: row.verify_no,
    customerId: Number(row.customer_id),
    customerCardId:
      row.customer_card_id == null ? null : Number(row.customer_card_id),
    storeId: Number(row.store_id),
    storeName: row.store_name || "",
    childName: row.child_name,
    parentPhone: row.parent_phone || "",
    trainingProject: row.training_project,
    cardName: row.card_name || "",
    cardSalePrice:
      row.card_sale_price == null ? null : Number(row.card_sale_price),
    verifyDate: row.verify_date,
    verifyTime: row.verify_time,
    operatorId: row.operator_id ? Number(row.operator_id) : null,
    operatorName: row.operator_name || "",
    remark: row.remark || "",
    revoked: Number(row.revoked || 0) === 1,
    revokedAt: row.revoked_at || null,
    revokedBy: row.revoked_by == null ? null : Number(row.revoked_by),
    revokedByName: row.revoked_by_name || "",
    revokeReason: row.revoke_reason || "",
    createdAt: row.created_at,
  };
}

function buildRecordFilter(req) {
  const scope = buildStoreScope(req.user, "vr.store_id");
  const where = [scope.sql];
  const params = [...scope.params];

  const startDate = String(req.query.startDate || "").trim();
  const endDate = String(req.query.endDate || "").trim();
  const childName = String(req.query.childName || "").trim();
  const keyword = String(req.query.keyword || "").trim();
  const operatorName = String(req.query.operatorName || "").trim();
  const verifyNo = String(req.query.verifyNo || "").trim();
  const storeId = toInt(req.query.storeId, 0);
  const recordStatus = String(req.query.recordStatus || "").trim();

  const { conditions: dateConditions, params: dateParams } =
    buildDateRangeConditions(startDate, endDate, "vr.verify_date");
  where.push(...dateConditions);
  params.push(...dateParams);

  if (childName) {
    where.push("vr.child_name LIKE ?");
    params.push(`%${childName}%`);
  }

  if (operatorName) {
    where.push("vr.operator_name LIKE ?");
    params.push(`%${operatorName}%`);
  }

  if (verifyNo) {
    where.push("vr.verify_no LIKE ?");
    params.push(`%${verifyNo}%`);
  }

  if (keyword) {
    where.push(
      "(vr.child_name LIKE ? OR vr.training_project LIKE ? OR vr.operator_name LIKE ? OR vr.verify_no LIKE ? OR c.parent_phone LIKE ?)",
    );
    params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
  }

  if (Number(req.user.role) === ROLE_ADMIN && storeId > 0) {
    where.push("vr.store_id = ?");
    params.push(storeId);
  }

  if (recordStatus === "active") {
    where.push("vr.revoked = 0");
  } else if (recordStatus === "revoked") {
    where.push("vr.revoked = 1");
  }

  return {
    whereSql: where.length ? `WHERE ${where.join(" AND ")}` : "",
    params,
    query: {
      startDate,
      endDate,
      childName,
      keyword,
      operatorName,
      verifyNo,
      storeId,
      recordStatus,
    },
  };
}

async function getRecordList(req, res, next) {
  try {
    await ensureRecordSchema();
    const { pageNum, pageSize, offset } = normalizePagination(req.query);
    const { whereSql, params } = buildRecordFilter(req);

    const countSql = `
      SELECT COUNT(*) AS total
      FROM verify_records vr
      LEFT JOIN customers c ON c.id = vr.customer_id
      ${whereSql}
    `;

    const listSql = `
      SELECT
        vr.id,
        vr.verify_no,
        vr.customer_id,
        vr.customer_card_id,
        vr.store_id,
        s.store_name,
        vr.child_name,
        c.parent_phone,
        vr.training_project,
        vr.card_name,
        vr.card_sale_price,
        vr.verify_date,
        vr.verify_time,
        vr.operator_id,
        vr.operator_name,
        vr.remark,
        vr.revoked,
        vr.revoked_at,
        vr.revoked_by,
        vr.revoked_by_name,
        vr.revoke_reason,
        vr.created_at
      FROM verify_records vr
      LEFT JOIN stores s ON s.id = vr.store_id
      LEFT JOIN customers c ON c.id = vr.customer_id
      ${whereSql}
      ORDER BY vr.verify_time DESC, vr.id DESC
      LIMIT ? OFFSET ?
    `;

    const [[countRow]] = await pool.query(countSql, params);
    const [rows] = await pool.query(listSql, [...params, pageSize, offset]);

    return sendPage(
      res,
      rows.map(formatRecord),
      Number(countRow.total || 0),
      pageNum,
      pageSize,
    );
  } catch (error) {
    next(error);
  }
}

async function getRecordDetail(req, res, next) {
  try {
    await ensureRecordSchema();
    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "核销记录ID无效", 400);
    }

    const scope = buildStoreScope(req.user, "vr.store_id");
    const [rows] = await pool.query(
      `
        SELECT
          vr.id,
          vr.verify_no,
          vr.customer_id,
          vr.customer_card_id,
          vr.store_id,
          s.store_name,
          vr.child_name,
          c.parent_phone,
          vr.training_project,
          vr.card_name,
          vr.card_sale_price,
          vr.verify_date,
          vr.verify_time,
          vr.operator_id,
          vr.operator_name,
          vr.remark,
          vr.revoked,
          vr.revoked_at,
          vr.revoked_by,
          vr.revoked_by_name,
          vr.revoke_reason,
          vr.created_at,
          c.parent_name,
          c.parent_phone,
          c.total_times,
          c.used_times,
          c.remaining_times,
          c.open_card_date,
          c.expire_date,
          c.tags,
          c.status AS customer_status
        FROM verify_records vr
        LEFT JOIN stores s ON s.id = vr.store_id
        LEFT JOIN customers c ON c.id = vr.customer_id
        WHERE vr.id = ?
          AND ${scope.sql}
        LIMIT 1
      `,
      [id, ...scope.params],
    );

    if (!rows.length) {
      return sendFail(res, "核销记录不存在", 404);
    }

    const row = rows[0];
    return sendSuccess(
      res,
      {
        ...formatRecord(row),
        customer: {
          id: row.customer_id ? Number(row.customer_id) : null,
          parentName: row.parent_name || "",
          parentPhone: row.parent_phone || "",
          totalTimes: row.total_times != null ? Number(row.total_times) : null,
          usedTimes: row.used_times != null ? Number(row.used_times) : null,
          remainingTimes:
            row.remaining_times != null ? Number(row.remaining_times) : null,
          openCardDate: row.open_card_date || null,
          expireDate: row.expire_date || null,
          tags: row.tags || "",
          status:
            row.customer_status != null ? Number(row.customer_status) : null,
        },
      },
      "查询核销记录成功",
    );
  } catch (error) {
    next(error);
  }
}

async function exportRecordList(req, res, next) {
  try {
    await ensureRecordSchema();
    const { whereSql, params, query } = buildRecordFilter(req);

    const [rows] = await pool.query(
      `
        SELECT
          vr.id,
          vr.verify_no,
          vr.customer_id,
          vr.customer_card_id,
          vr.store_id,
          s.store_name,
          vr.child_name,
          vr.training_project,
          vr.card_name,
          vr.card_sale_price,
          vr.verify_date,
          vr.verify_time,
          vr.operator_id,
          vr.operator_name,
          vr.remark,
          vr.revoked,
          vr.revoked_at,
          vr.revoked_by_name,
          vr.revoke_reason,
          vr.created_at
        FROM verify_records vr
        LEFT JOIN stores s ON s.id = vr.store_id
        LEFT JOIN customers c ON c.id = vr.customer_id
        ${whereSql}
        ORDER BY vr.verify_time DESC, vr.id DESC
      `,
      params,
    );

    const workbook = new ExcelJS.Workbook();
    workbook.creator = "vision-verify-system";
    workbook.created = new Date();
    workbook.modified = new Date();

    const worksheet = workbook.addWorksheet("核销记录");

    worksheet.columns = [
      { header: "序号", key: "index", width: 10 },
      { header: "核销单号", key: "verifyNo", width: 24 },
      { header: "孩子姓名", key: "childName", width: 16 },
      { header: "联系电话", key: "parentPhone", width: 18 },
      { header: "训练项目", key: "trainingProject", width: 22 },
      { header: "核销日期", key: "verifyDate", width: 14 },
      { header: "核销时间", key: "verifyTime", width: 22 },
      { header: "操作人", key: "operatorName", width: 16 },
      { header: "所属门店", key: "storeName", width: 20 },
      { header: "状态", key: "recordStatus", width: 14 },
      { header: "撤回信息", key: "revokeInfo", width: 32 },
      { header: "备注", key: "remark", width: 40 },
    ];

    worksheet.getRow(1).font = {
      bold: true,
    };
    worksheet.getRow(1).alignment = {
      vertical: "middle",
      horizontal: "center",
    };
    worksheet.getRow(1).fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFE8F0FE" },
    };
    worksheet.views = [{ state: "frozen", ySplit: 1 }];

    rows.forEach((row, index) => {
      worksheet.addRow({
        index: index + 1,
        verifyNo: row.verify_no,
        childName: row.child_name,
        parentPhone: row.parent_phone || "",
        trainingProject: row.training_project,
        verifyDate: row.verify_date,
        verifyTime: row.verify_time,
        operatorName: row.operator_name,
        storeName: row.store_name || "",
        recordStatus: Number(row.revoked || 0) === 1 ? "已撤回" : "正常",
        revokeInfo:
          Number(row.revoked || 0) === 1
            ? `${row.revoked_by_name || "-"} ${row.revoked_at || ""} ${row.revoke_reason || ""}`.trim()
            : "",
        remark: row.remark || "",
      });
    });

    worksheet.eachRow((row, rowNumber) => {
      row.alignment = {
        vertical: "middle",
        horizontal: rowNumber === 1 ? "center" : "left",
        wrapText: true,
      };
      row.height = 22;
    });

    await writeOperationLog(req, {
      module: "record",
      action: "export",
      bizType: "verify_record",
      content: `导出核销记录，共 ${rows.length} 条`,
      bizNo: JSON.stringify(query),
    });

    const now = new Date();
    const filename = `核销记录_${now.getFullYear()}${`${now.getMonth() + 1}`.padStart(
      2,
      "0",
    )}${`${now.getDate()}`.padStart(2, "0")}_${`${now.getHours()}`.padStart(
      2,
      "0",
    )}${`${now.getMinutes()}`.padStart(2, "0")}${`${now.getSeconds()}`.padStart(
      2,
      "0",
    )}.xlsx`;

    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`,
    );

    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    next(error);
  }
}

async function revokeRecord(req, res, next) {
  await ensureRecordSchema();
  const connection = await pool.getConnection();

  try {
    const id = toInt(req.params.id, 0);
    const reason = String(req.body.reason || "").trim();

    if (!id) {
      connection.release();
      return sendFail(res, "核销记录ID无效", 400);
    }

    await connection.beginTransaction();

    const scope = buildStoreScope(req.user, "vr.store_id");
    const [rows] = await connection.query(
      `
        SELECT
          vr.id,
          vr.verify_no,
          vr.customer_id,
          vr.customer_card_id,
          vr.store_id,
          vr.child_name,
          vr.training_project,
          vr.card_name,
          vr.verify_time,
          vr.revoked,
          c.used_times
        FROM verify_records vr
        INNER JOIN customers c ON c.id = vr.customer_id
        WHERE vr.id = ?
          AND ${scope.sql}
        LIMIT 1
        FOR UPDATE
      `,
      [id, ...scope.params],
    );

    const record = rows[0];

    if (!record) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "核销记录不存在", 404);
    }

    if (Number(record.revoked || 0) === 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该核销记录已经撤回过，不能重复撤回", 400, {
        errorCode: "RECORD_ALREADY_REVOKED",
      });
    }

    let customerUpdateResult;
    if (record.customer_card_id) {
      const [[usageLog]] = await connection.query(
        `
          SELECT quantity
          FROM customer_card_usage_logs
          WHERE verify_record_id = ?
            AND customer_card_id = ?
          LIMIT 1
          FOR UPDATE
        `,
        [Number(record.id || 0), Number(record.customer_card_id || 0)],
      );
      const revokeQuantity = Math.max(1, Math.trunc(Number(usageLog?.quantity || 1)));

      const [cardUpdateResult] = await connection.execute(
        `
          UPDATE customer_cards
          SET used_times = used_times - ?,
              updated_by = ?
          WHERE id = ?
            AND used_times >= ?
        `,
        [
          revokeQuantity,
          Number(req.user.userId || 0),
          Number(record.customer_card_id || 0),
          revokeQuantity,
        ],
      );
      customerUpdateResult = cardUpdateResult;
      await syncCustomerCardSnapshot(
        connection,
        Number(record.customer_id || 0),
        Number(req.user.userId || 0),
      );
    } else {
      const [legacyCustomerUpdateResult] = await connection.execute(
        `
          UPDATE customers
          SET used_times = used_times - 1,
              updated_by = ?
          WHERE id = ?
            AND used_times > 0
        `,
        [Number(req.user.userId || 0), Number(record.customer_id || 0)],
      );
      customerUpdateResult = legacyCustomerUpdateResult;
    }

    if (Number(customerUpdateResult.affectedRows || 0) !== 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "客户次数状态异常，无法撤回本次核销", 409, {
        errorCode: "CUSTOMER_TIMES_INVALID",
      });
    }

    const [recordUpdateResult] = await connection.execute(
      `
        UPDATE verify_records
        SET revoked = 1,
            revoked_at = NOW(),
            revoked_by = ?,
            revoked_by_name = ?,
            revoke_reason = ?
        WHERE id = ?
          AND revoked = 0
      `,
      [
        Number(req.user.userId || 0),
        String(req.user.realName || ""),
        reason || null,
        id,
      ],
    );

    if (Number(recordUpdateResult.affectedRows || 0) !== 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该核销记录已经撤回过，不能重复撤回", 400, {
        errorCode: "RECORD_ALREADY_REVOKED",
      });
    }

    await writeOperationLog(connection, {
      operatorId: req.user.userId,
      operatorName: req.user.realName,
      operatorRole: req.user.role,
      storeId: Number(record.store_id || 0),
      module: "record",
      action: "revoke",
      bizType: "verify_record",
      bizId: Number(record.id || 0),
      bizNo: record.verify_no,
      content: `撤回核销：客户【${record.child_name}】项目【${record.training_project}】${record.card_name ? `卡项【${record.card_name}】` : ""}单号【${record.verify_no}】${reason ? `，原因：${reason}` : ""}`,
      ip: req.ip || "",
      userAgent: String(req.headers["user-agent"] || "").slice(0, 500),
    });

    await connection.commit();
    connection.release();

    return sendSuccess(
      res,
      {
        id: Number(record.id || 0),
        verifyNo: record.verify_no,
        revoked: true,
      },
      "撤回核销成功",
    );
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore rollback error
    }
    connection.release();
    next(error);
  }
}

module.exports = {
  getRecordList,
  getRecordDetail,
  exportRecordList,
  revokeRecord,
};
