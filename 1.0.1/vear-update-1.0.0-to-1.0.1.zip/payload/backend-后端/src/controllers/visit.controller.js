const ExcelJS = require("exceljs");
const { pool } = require("../config/db");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { normalizePage, toInt } = require("../utils/pagination");
const { buildStoreScope } = require("../utils/store-scope");
const { formatDateYmd, parseDateYmd } = require("../utils/date");
const { toCamelCase } = require("../utils/case");
const { writeOperationLog } = require("../utils/operation-log");
const {
  VISIT_STATUS,
  VISIT_TYPES,
  ensureVisitSchema,
  formatDateTime,
  insertVisitWithRetry,
} = require("../services/visit.service");

const VISIT_STATUS_OPTIONS = [
  { value: VISIT_STATUS.ARRIVED, label: "已到店" },
  { value: VISIT_STATUS.SERVING, label: "服务中" },
  { value: VISIT_STATUS.COMPLETED, label: "已完成" },
  { value: VISIT_STATUS.CANCELLED, label: "已取消" },
];

const VERIFICATION_STATUS_OPTIONS = [
  { value: "none", label: "无需核销" },
  { value: "pending", label: "待核销" },
  { value: "verified", label: "已核销" },
  { value: "revoked", label: "核销已撤销" },
];

function today() {
  return formatDateYmd(new Date());
}

function cleanText(value, maxLength = 500) {
  return String(value || "").trim().slice(0, maxLength);
}

function normalizeVisitType(value) {
  const normalized = String(value || "training").trim();
  return VISIT_TYPES.some((item) => item.value === normalized)
    ? normalized
    : "training";
}

function defaultVerificationRequired(visitType) {
  return Boolean(
    VISIT_TYPES.find((item) => item.value === visitType)?.verificationRequired,
  );
}

function normalizeBoolean(value, fallback = false) {
  if (value === true || value === 1 || value === "1" || value === "true") return true;
  if (value === false || value === 0 || value === "0" || value === "false") return false;
  return fallback;
}

function buildVisitBaseQuery(req, options = {}) {
  const scope = buildStoreScope(req.user, "cv.store_id");
  const where = [scope.sql];
  const params = [...scope.params];
  const keyword = cleanText(req.query.keyword, 100);
  const requestedStoreId = toInt(req.query.storeId, 0);
  const customerId = toInt(req.query.customerId, 0);
  const serviceUserId = toInt(req.query.serviceUserId, 0);
  const visitType = String(req.query.visitType || "").trim();
  const status = String(req.query.status ?? "").trim();
  const hasDateFilter = Boolean(req.query.startDate || req.query.endDate);
  const useDefaultToday = options.defaultToday !== false && !hasDateFilter;
  const startDate = parseDateYmd(String(req.query.startDate || "")) || (useDefaultToday ? today() : "");
  const endDate = parseDateYmd(String(req.query.endDate || "")) || (useDefaultToday ? today() : "");

  if (requestedStoreId) {
    where.push("cv.store_id = ?");
    params.push(requestedStoreId);
  }
  if (customerId) {
    where.push("cv.customer_id = ?");
    params.push(customerId);
  }
  if (serviceUserId) {
    where.push("cv.service_user_id = ?");
    params.push(serviceUserId);
  }
  if (VISIT_TYPES.some((item) => item.value === visitType)) {
    where.push("cv.visit_type = ?");
    params.push(visitType);
  }
  if (!status && String(req.query.includeCancelled || "") !== "1") {
    where.push("cv.status <> ?");
    params.push(VISIT_STATUS.CANCELLED);
  }
  if (["0", "1", "2", "3"].includes(status)) {
    where.push("cv.status = ?");
    params.push(Number(status));
  }
  if (startDate) {
    where.push("cv.visit_date >= ?");
    params.push(startDate);
  }
  if (endDate) {
    where.push("cv.visit_date <= ?");
    params.push(endDate);
  }
  if (keyword) {
    const like = `%${keyword}%`;
    where.push(`(
      cv.visit_no LIKE ? OR cv.customer_name LIKE ? OR cv.customer_phone LIKE ?
      OR cv.training_project LIKE ? OR cv.service_user_name LIKE ?
    )`);
    params.push(like, like, like, like, like);
  }

  const baseSql = `
    SELECT
      cv.id,
      cv.visit_no,
      cv.customer_id,
      cv.store_id,
      s.store_name,
      cv.customer_name,
      cv.customer_phone,
      cv.visit_date,
      cv.arrived_at,
      cv.started_at,
      cv.completed_at,
      cv.cancelled_at,
      cv.visit_type,
      cv.status,
      cv.verification_required,
      cv.source,
      cv.training_project,
      cv.service_user_id,
      cv.service_user_name,
      cv.reception_user_id,
      cv.reception_user_name,
      cv.remark,
      cv.cancel_reason,
      cv.created_at,
      cv.updated_at,
      c.status AS customer_status,
      (SELECT COUNT(*)
       FROM customer_visit_verifications cvv
       WHERE cvv.visit_id = cv.id) AS linked_verification_count,
      (SELECT COUNT(*)
       FROM customer_visit_verifications cvv
       INNER JOIN verify_records vr ON vr.id = cvv.verify_record_id
       WHERE cvv.visit_id = cv.id AND COALESCE(vr.revoked, 0) = 0) AS valid_verification_count,
      (SELECT COUNT(*)
       FROM customer_visit_verifications cvv
       INNER JOIN verify_records vr ON vr.id = cvv.verify_record_id
       WHERE cvv.visit_id = cv.id AND COALESCE(vr.revoked, 0) = 1) AS revoked_verification_count,
      (SELECT GROUP_CONCAT(vr.verify_no ORDER BY vr.verify_time ASC SEPARATOR '|||')
       FROM customer_visit_verifications cvv
       INNER JOIN verify_records vr ON vr.id = cvv.verify_record_id
       WHERE cvv.visit_id = cv.id AND COALESCE(vr.revoked, 0) = 0) AS verify_nos,
      (SELECT GROUP_CONCAT(
         CONCAT(
           COALESCE(NULLIF(vr.training_project, ''), NULLIF(vr.card_name, ''), '核销'),
           CASE
             WHEN NULLIF(TRIM(COALESCE(vr.remark, '')), '') IS NOT NULL
             THEN CONCAT('（', TRIM(vr.remark), '）')
             ELSE ''
           END
         )
         ORDER BY vr.verify_time ASC SEPARATOR '|||'
       )
       FROM customer_visit_verifications cvv
       INNER JOIN verify_records vr ON vr.id = cvv.verify_record_id
       WHERE cvv.visit_id = cv.id AND COALESCE(vr.revoked, 0) = 0) AS verify_descriptions,
      (SELECT MAX(vr.verify_time)
       FROM customer_visit_verifications cvv
       INNER JOIN verify_records vr ON vr.id = cvv.verify_record_id
       WHERE cvv.visit_id = cv.id AND COALESCE(vr.revoked, 0) = 0) AS last_verify_time
    FROM customer_visits cv
    LEFT JOIN stores s ON s.id = cv.store_id
    LEFT JOIN customers c ON c.id = cv.customer_id
    WHERE ${where.join(" AND ")}
  `;

  const verificationStatus = String(req.query.verificationStatus || "").trim();
  const outerWhere = [];
  if (verificationStatus === "none") {
    outerWhere.push("visit_rows.verification_required = 0");
  } else if (verificationStatus === "unverified") {
    outerWhere.push("visit_rows.valid_verification_count = 0");
  } else if (verificationStatus === "verified") {
    outerWhere.push("visit_rows.valid_verification_count > 0");
  } else if (verificationStatus === "pending") {
    outerWhere.push("visit_rows.verification_required = 1 AND visit_rows.linked_verification_count = 0");
  } else if (verificationStatus === "revoked") {
    outerWhere.push("visit_rows.verification_required = 1 AND visit_rows.linked_verification_count > 0 AND visit_rows.valid_verification_count = 0");
  }

  return {
    baseSql,
    params,
    outerSql: outerWhere.length ? `WHERE ${outerWhere.join(" AND ")}` : "",
    range: { startDate, endDate },
  };
}

function formatVisitRow(row) {
  const formatted = toCamelCase(row);
  const linkedCount = Number(formatted.linkedVerificationCount || 0);
  const validCount = Number(formatted.validVerificationCount || 0);
  let verificationStatus = "none";
  if (Number(formatted.verificationRequired || 0) === 1) {
    verificationStatus = validCount > 0 ? "verified" : linkedCount > 0 ? "revoked" : "pending";
  }
  return {
    ...formatted,
    id: Number(formatted.id || 0),
    customerId: Number(formatted.customerId || 0),
    storeId: Number(formatted.storeId || 0),
    status: Number(formatted.status || 0),
    customerStatus: Number(formatted.customerStatus ?? 0),
    serviceUserId: formatted.serviceUserId == null ? null : Number(formatted.serviceUserId || 0),
    verificationRequired: Number(formatted.verificationRequired || 0) === 1,
    linkedVerificationCount: linkedCount,
    validVerificationCount: validCount,
    revokedVerificationCount: Number(formatted.revokedVerificationCount || 0),
    verifyNos: formatted.verifyNos ? String(formatted.verifyNos).split("|||").filter(Boolean) : [],
    verifyDescriptions: formatted.verifyDescriptions
      ? String(formatted.verifyDescriptions).split("|||").filter(Boolean)
      : [],
    verificationStatus,
  };
}

async function fetchVisitRows(req, options = {}) {
  const query = buildVisitBaseQuery(req, options);
  const orderSql = "ORDER BY visit_rows.arrived_at DESC, visit_rows.id DESC";
  const [rows] = await pool.query(
    `SELECT * FROM (${query.baseSql}) visit_rows ${query.outerSql} ${orderSql}`,
    query.params,
  );
  return { rows: rows.map(formatVisitRow), query };
}

async function getVisitList(req, res, next) {
  try {
    await ensureVisitSchema();
    const { pageNum, pageSize, offset } = normalizePage(req.query);
    const query = buildVisitBaseQuery(req);
    const [[countRow]] = await pool.query(
      `SELECT COUNT(*) AS total FROM (${query.baseSql}) visit_rows ${query.outerSql}`,
      query.params,
    );
    const [rows] = await pool.query(
      `SELECT * FROM (${query.baseSql}) visit_rows ${query.outerSql}
       ORDER BY visit_rows.arrived_at DESC, visit_rows.id DESC LIMIT ? OFFSET ?`,
      [...query.params, pageSize, offset],
    );
    const [[summary]] = await pool.query(
      `
        SELECT
          COUNT(*) AS total_visits,
          COUNT(DISTINCT customer_id) AS unique_customers,
          SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) AS arrived_count,
          SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) AS serving_count,
          SUM(CASE WHEN status = 2 THEN 1 ELSE 0 END) AS completed_count,
          SUM(CASE WHEN status = 3 THEN 1 ELSE 0 END) AS cancelled_count,
          SUM(CASE WHEN verification_required = 1 AND linked_verification_count = 0 THEN 1 ELSE 0 END) AS pending_verification_count,
          SUM(CASE WHEN valid_verification_count > 0 THEN 1 ELSE 0 END) AS verified_count
        FROM (${query.baseSql}) visit_rows ${query.outerSql}
      `,
      query.params,
    );
    return sendPage(
      res,
      rows.map(formatVisitRow),
      Number(countRow.total || 0),
      pageNum,
      pageSize,
      { summary: toCamelCase(summary || {}), range: query.range },
    );
  } catch (error) {
    next(error);
  }
}

async function getVisitSummary(req, res, next) {
  try {
    await ensureVisitSchema();
    const query = buildVisitBaseQuery(req);
    const [[row]] = await pool.query(
      `
        SELECT
          COUNT(*) AS total_visits,
          COUNT(DISTINCT customer_id) AS unique_customers,
          SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) AS arrived_count,
          SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) AS serving_count,
          SUM(CASE WHEN status = 2 THEN 1 ELSE 0 END) AS completed_count,
          SUM(CASE WHEN status = 3 THEN 1 ELSE 0 END) AS cancelled_count,
          SUM(CASE WHEN verification_required = 1 AND linked_verification_count = 0 THEN 1 ELSE 0 END) AS pending_verification_count,
          SUM(CASE WHEN valid_verification_count > 0 THEN 1 ELSE 0 END) AS verified_count
        FROM (${query.baseSql}) visit_rows ${query.outerSql}
      `,
      query.params,
    );
    return sendSuccess(res, { ...toCamelCase(row || {}), range: query.range }, "获取来访汇总成功");
  } catch (error) {
    next(error);
  }
}

async function getVisitMeta(req, res, next) {
  try {
    await ensureVisitSchema();
    const scope = buildStoreScope(req.user, "u.store_id");
    const [staff] = await pool.query(
      `SELECT u.id, u.real_name, u.store_id, s.store_name
       FROM users u LEFT JOIN stores s ON s.id = u.store_id
       WHERE u.status = 1 AND ${scope.sql}
       ORDER BY u.store_id ASC, u.real_name ASC`,
      scope.params,
    );
    return sendSuccess(res, {
      visitTypes: VISIT_TYPES,
      visitStatuses: VISIT_STATUS_OPTIONS,
      verificationStatuses: VERIFICATION_STATUS_OPTIONS,
      staff: toCamelCase(staff),
    }, "获取来访配置成功");
  } catch (error) {
    next(error);
  }
}

async function getVisitCustomerOptions(req, res, next) {
  try {
    await ensureVisitSchema();
    const keyword = cleanText(req.query.keyword, 100);
    const scope = buildStoreScope(req.user, "c.store_id");
    const where = [scope.sql];
    const params = [...scope.params];
    if (keyword) {
      const like = `%${keyword}%`;
      where.push("(c.child_name LIKE ? OR c.parent_name LIKE ? OR c.parent_phone LIKE ? OR c.customer_no LIKE ?)");
      params.push(like, like, like, like);
    }
    const [rows] = await pool.query(
      `
        SELECT c.id, c.customer_no, c.child_name, c.parent_name, c.parent_phone,
               c.store_id, c.status, c.has_card, c.training_project,
               c.remaining_times, s.store_name
        FROM customers c
        LEFT JOIN stores s ON s.id = c.store_id
        WHERE ${where.join(" AND ")}
        ORDER BY c.status DESC, c.updated_at DESC, c.id DESC
        LIMIT 80
      `,
      params,
    );
    return sendSuccess(res, toCamelCase(rows), "获取来访客户选项成功");
  } catch (error) {
    next(error);
  }
}

async function resolveServiceUser(connection, serviceUserId, storeId, fallbackUser) {
  const requestedId = Number(serviceUserId || 0);
  const fallbackId = Number(fallbackUser?.userId || 0);
  const fallbackStoreId = Number(fallbackUser?.storeId || 0);
  const normalizedId = requestedId || (fallbackStoreId === Number(storeId || 0) ? fallbackId : 0);
  if (!normalizedId) return { id: null, name: "" };
  const [[staff]] = await connection.query(
    "SELECT id, real_name, store_id, status FROM users WHERE id = ? LIMIT 1",
    [normalizedId],
  );
  if (!staff || Number(staff.status) !== 1 || Number(staff.store_id || 0) !== Number(storeId || 0)) {
    return null;
  }
  return { id: Number(staff.id), name: staff.real_name || "" };
}

async function createVisit(req, res, next) {
  await ensureVisitSchema();
  const connection = await pool.getConnection();
  try {
    const customerId = toInt(req.body.customerId, 0);
    if (!customerId) {
      connection.release();
      return sendFail(res, "请选择到店客户", 400);
    }
    await connection.beginTransaction();
    const scope = buildStoreScope(req.user, "c.store_id");
    const [[customer]] = await connection.query(
      `SELECT c.id, c.customer_no, c.child_name, c.parent_phone, c.store_id,
              c.status, c.training_project
       FROM customers c
       WHERE c.id = ? AND ${scope.sql}
       LIMIT 1 FOR UPDATE`,
      [customerId, ...scope.params],
    );
    if (!customer) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "客户不存在或无权限登记", 404);
    }

    const visitType = normalizeVisitType(req.body.visitType);
    if (Number(customer.status) !== 1 && !["consultation", "other"].includes(visitType)) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户已停用，仅可登记咨询或其他来访；继续服务前请先启用客户", 400);
    }

    const arrivedAt = formatDateTime(req.body.arrivedAt || new Date());
    const visitDate = formatDateYmd(arrivedAt);
    const serviceUser = await resolveServiceUser(
      connection,
      req.body.serviceUserId,
      customer.store_id,
      req.user,
    );
    if (!serviceUser) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "服务员工不存在、已停用或不属于客户所在门店", 400);
    }

    const verificationRequired = normalizeBoolean(
      req.body.verificationRequired,
      defaultVerificationRequired(visitType),
    );
    const inserted = await insertVisitWithRetry(connection, {
      customerId: Number(customer.id),
      storeId: Number(customer.store_id),
      customerName: customer.child_name || "客户",
      customerPhone: customer.parent_phone || "",
      visitDate,
      arrivedAt,
      visitType,
      status: VISIT_STATUS.ARRIVED,
      verificationRequired,
      source: "manual",
      trainingProject: cleanText(req.body.trainingProject || customer.training_project, 100),
      serviceUserId: serviceUser.id,
      serviceUserName: serviceUser.name,
      receptionUserId: req.user.userId,
      receptionUserName: req.user.realName,
      remark: cleanText(req.body.remark, 500),
      createdBy: req.user.userId,
    });

    await writeOperationLog(connection, {
      operatorId: req.user.userId,
      operatorName: req.user.realName,
      operatorRole: req.user.role,
      storeId: Number(customer.store_id),
      module: "visit",
      action: "create",
      bizType: "customer_visit",
      bizId: inserted.visitId,
      bizNo: inserted.visitNo,
      content: `登记来访：客户【${customer.child_name}】，类型【${VISIT_TYPES.find((item) => item.value === visitType)?.label || visitType}】`,
      ip: req.ip || "",
      userAgent: String(req.headers["user-agent"] || "").slice(0, 500),
    });
    await connection.commit();
    connection.release();
    return sendSuccess(res, { id: inserted.visitId, visitNo: inserted.visitNo }, "来访登记成功");
  } catch (error) {
    await connection.rollback().catch(() => {});
    connection.release();
    next(error);
  }
}

async function updateVisit(req, res, next) {
  await ensureVisitSchema();
  const connection = await pool.getConnection();
  try {
    const id = toInt(req.params.id, 0);
    await connection.beginTransaction();
    const scope = buildStoreScope(req.user, "cv.store_id");
    const [[visit]] = await connection.query(
      `SELECT cv.* FROM customer_visits cv WHERE cv.id = ? AND ${scope.sql} LIMIT 1 FOR UPDATE`,
      [id, ...scope.params],
    );
    if (!visit) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "来访记录不存在或无权限操作", 404);
    }
    if (Number(visit.status) === VISIT_STATUS.CANCELLED) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "已取消的来访记录不能再编辑", 400);
    }

    const visitType = normalizeVisitType(req.body.visitType || visit.visit_type);
    const serviceUser = await resolveServiceUser(
      connection,
      req.body.serviceUserId || visit.service_user_id,
      visit.store_id,
      req.user,
    );
    if (!serviceUser) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "服务员工不存在、已停用或不属于当前门店", 400);
    }
    const verificationRequired = normalizeBoolean(
      req.body.verificationRequired,
      Number(visit.verification_required) === 1,
    );
    await connection.execute(
      `UPDATE customer_visits
       SET visit_type = ?, verification_required = ?, training_project = ?,
           service_user_id = ?, service_user_name = ?, remark = ?, updated_by = ?
       WHERE id = ?`,
      [
        visitType,
        verificationRequired ? 1 : 0,
        cleanText(req.body.trainingProject ?? visit.training_project, 100) || null,
        serviceUser.id,
        serviceUser.name,
        cleanText(req.body.remark ?? visit.remark, 500) || null,
        req.user.userId,
        id,
      ],
    );
    await writeOperationLog(connection, {
      operatorId: req.user.userId,
      operatorName: req.user.realName,
      operatorRole: req.user.role,
      storeId: Number(visit.store_id),
      module: "visit",
      action: "update",
      bizType: "customer_visit",
      bizId: id,
      bizNo: visit.visit_no,
      content: `更新来访信息：客户【${visit.customer_name}】`,
      ip: req.ip || "",
      userAgent: String(req.headers["user-agent"] || "").slice(0, 500),
    });
    await connection.commit();
    connection.release();
    return sendSuccess(res, null, "来访信息已更新");
  } catch (error) {
    await connection.rollback().catch(() => {});
    connection.release();
    next(error);
  }
}

async function changeVisitStatus(req, res, next, targetStatus) {
  await ensureVisitSchema();
  const connection = await pool.getConnection();
  try {
    const id = toInt(req.params.id, 0);
    const reason = cleanText(req.body.reason || req.body.remark, 255);
    await connection.beginTransaction();
    const scope = buildStoreScope(req.user, "cv.store_id");
    const [[visit]] = await connection.query(
      `SELECT cv.* FROM customer_visits cv WHERE cv.id = ? AND ${scope.sql} LIMIT 1 FOR UPDATE`,
      [id, ...scope.params],
    );
    if (!visit) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "来访记录不存在或无权限操作", 404);
    }

    const currentStatus = Number(visit.status);
    const allowed = targetStatus === VISIT_STATUS.SERVING
      ? currentStatus === VISIT_STATUS.ARRIVED
      : [VISIT_STATUS.ARRIVED, VISIT_STATUS.SERVING].includes(currentStatus);
    if (!allowed) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "当前来访状态不能执行此操作，请刷新后重试", 409);
    }
    if (targetStatus === VISIT_STATUS.CANCELLED && !reason) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "取消来访必须填写原因", 400);
    }

    const fields = ["status = ?", "updated_by = ?"];
    const params = [targetStatus, req.user.userId];
    if (targetStatus === VISIT_STATUS.SERVING) fields.push("started_at = COALESCE(started_at, NOW())");
    if (targetStatus === VISIT_STATUS.COMPLETED) {
      fields.push("started_at = COALESCE(started_at, arrived_at)");
      fields.push("completed_at = NOW()");
    }
    if (targetStatus === VISIT_STATUS.CANCELLED) {
      fields.push("cancelled_at = NOW()");
      fields.push("cancel_reason = ?");
      params.push(reason);
    }
    params.push(id, currentStatus);
    const [result] = await connection.execute(
      `UPDATE customer_visits SET ${fields.join(", ")} WHERE id = ? AND status = ?`,
      params,
    );
    if (Number(result.affectedRows || 0) !== 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "来访状态已变化，请刷新后重试", 409);
    }

    const statusLabel = VISIT_STATUS_OPTIONS.find((item) => item.value === targetStatus)?.label || "状态更新";
    await writeOperationLog(connection, {
      operatorId: req.user.userId,
      operatorName: req.user.realName,
      operatorRole: req.user.role,
      storeId: Number(visit.store_id),
      module: "visit",
      action: targetStatus === VISIT_STATUS.CANCELLED ? "cancel" : "status",
      bizType: "customer_visit",
      bizId: id,
      bizNo: visit.visit_no,
      content: `${statusLabel}：客户【${visit.customer_name}】${reason ? `，原因：${reason}` : ""}`,
      ip: req.ip || "",
      userAgent: String(req.headers["user-agent"] || "").slice(0, 500),
    });
    await connection.commit();
    connection.release();
    return sendSuccess(res, { id, status: targetStatus }, `来访状态已更新为${statusLabel}`);
  } catch (error) {
    await connection.rollback().catch(() => {});
    connection.release();
    next(error);
  }
}

function startVisit(req, res, next) {
  return changeVisitStatus(req, res, next, VISIT_STATUS.SERVING);
}

function completeVisit(req, res, next) {
  return changeVisitStatus(req, res, next, VISIT_STATUS.COMPLETED);
}

function cancelVisit(req, res, next) {
  return changeVisitStatus(req, res, next, VISIT_STATUS.CANCELLED);
}

async function getVisitDetail(req, res, next) {
  try {
    await ensureVisitSchema();
    const id = toInt(req.params.id, 0);
    const scope = buildStoreScope(req.user, "cv.store_id");
    const [rows] = await pool.query(
      `SELECT cv.*, s.store_name, c.status AS customer_status
       FROM customer_visits cv
       LEFT JOIN stores s ON s.id = cv.store_id
       LEFT JOIN customers c ON c.id = cv.customer_id
       WHERE cv.id = ? AND ${scope.sql} LIMIT 1`,
      [id, ...scope.params],
    );
    if (!rows.length) return sendFail(res, "来访记录不存在或无权查看", 404);
    const [verifications] = await pool.query(
      `SELECT vr.id, vr.verify_no, vr.training_project, vr.card_name, vr.verify_time,
              vr.operator_name, vr.remark, vr.revoked, vr.revoked_at, vr.revoke_reason
       FROM customer_visit_verifications cvv
       INNER JOIN verify_records vr ON vr.id = cvv.verify_record_id
       WHERE cvv.visit_id = ? ORDER BY vr.verify_time ASC, vr.id ASC`,
      [id],
    );
    return sendSuccess(res, {
      ...formatVisitRow({
        ...rows[0],
        linked_verification_count: verifications.length,
        valid_verification_count: verifications.filter((item) => Number(item.revoked || 0) === 0).length,
        revoked_verification_count: verifications.filter((item) => Number(item.revoked || 0) === 1).length,
        verify_nos: verifications.filter((item) => Number(item.revoked || 0) === 0).map((item) => item.verify_no).join("|||"),
        verify_descriptions: verifications
          .filter((item) => Number(item.revoked || 0) === 0)
          .map((item) => {
            const name = item.training_project || item.card_name || "核销";
            const remark = String(item.remark || "").trim();
            return remark ? `${name}（${remark}）` : name;
          })
          .join("|||"),
      }),
      verifications: toCamelCase(verifications),
    }, "获取来访详情成功");
  } catch (error) {
    next(error);
  }
}

async function exportVisitList(req, res, next) {
  try {
    await ensureVisitSchema();
    const { rows } = await fetchVisitRows(req, { defaultToday: true });
    const workbook = new ExcelJS.Workbook();
    workbook.creator = "vision-verify-system";
    const sheet = workbook.addWorksheet("来访台账");
    sheet.columns = [
      { header: "序号", key: "index", width: 8 },
      { header: "来访单号", key: "visitNo", width: 26 },
      { header: "到店时间", key: "arrivedAt", width: 21 },
      { header: "客户姓名", key: "customerName", width: 14 },
      { header: "联系电话", key: "customerPhone", width: 16 },
      { header: "门店", key: "storeName", width: 18 },
      { header: "记录", key: "recordText", width: 32 },
      { header: "核销单号", key: "verifyNos", width: 32 },
      { header: "备注", key: "remark", width: 36 },
    ];
    rows.forEach((item, index) => {
      sheet.addRow({
        index: index + 1,
        visitNo: item.visitNo,
        arrivedAt: item.arrivedAt,
        customerName: item.customerName,
        customerPhone: item.customerPhone,
        storeName: item.storeName,
        recordText: item.verificationStatus === "verified"
          ? item.verifyDescriptions.join("、") || "核销"
          : "保健",
        verifyNos: item.verifyNos.join("、"),
        remark: item.cancelReason || item.remark,
      });
    });
    sheet.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
    sheet.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF2563EB" } };
    sheet.views = [{ state: "frozen", ySplit: 1 }];
    sheet.eachRow((row) => {
      row.alignment = { vertical: "middle", wrapText: true };
      row.height = 22;
    });
    await writeOperationLog(req, {
      module: "visit",
      action: "export",
      bizType: "customer_visit",
      content: `导出来访台账，共 ${rows.length} 条`,
    });
    const filename = `来访台账_${today().replace(/-/g, "")}.xlsx`;
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getVisitList,
  getVisitSummary,
  getVisitMeta,
  getVisitCustomerOptions,
  createVisit,
  updateVisit,
  startVisit,
  completeVisit,
  cancelVisit,
  getVisitDetail,
  exportVisitList,
};
