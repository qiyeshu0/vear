const { pool } = require("../config/db");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { ROLE_ADMIN } = require("../config/constants");
const { toInt } = require("../utils/pagination");


function normalizePagination(query = {}) {
  const pageNum = Math.max(toInt(query.pageNum, 1), 1);
  const pageSize = Math.min(Math.max(toInt(query.pageSize, 10), 1), 100);
  const offset = (pageNum - 1) * pageSize;

  return {
    pageNum,
    pageSize,
    offset
  };
}

function canAccessStore(currentUser, storeId) {
  if (!currentUser) return false;
  if (Number(currentUser.role) === ROLE_ADMIN) return true;
  return Number(currentUser.storeId || 0) === Number(storeId || 0);
}

function formatStore(row) {
  if (!row) return null;

  return {
    id: Number(row.id),
    storeName: row.store_name,
    storeCode: row.store_code,
    contactName: row.contact_name || "",
    contactPhone: row.contact_phone || "",
    address: row.address || "",
    status: Number(row.status),
    remark: row.remark || "",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    customerCount:
      row.customer_count !== undefined ? Number(row.customer_count || 0) : undefined,
    userCount: row.user_count !== undefined ? Number(row.user_count || 0) : undefined
  };
}

async function writeStoreLog(req, action, content, bizId = null, bizNo = null) {
  if (!req.user) return;

  await pool.execute(
    `
      INSERT INTO operation_logs
      (operator_id, operator_name, operator_role, store_id, module, action, biz_type, biz_id, biz_no, content, ip, user_agent)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
    [
      req.user.userId,
      req.user.realName,
      req.user.role,
      null,
      "store",
      action,
      "store",
      bizId,
      bizNo,
      content,
      req.ip || "",
      (req.headers["user-agent"] || "").slice(0, 500)
    ]
  );
}

async function getStoreOptions(req, res, next) {
  try {
    const includeDisabled = String(req.query.includeDisabled || "") === "1";
    const params = [];
    const where = [];

    if (!includeDisabled) {
      where.push("s.status = 1");
    }

    if (Number(req.user?.role) !== ROLE_ADMIN) {
      where.push("s.id = ?");
      params.push(Number(req.user?.storeId || 0));
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const [rows] = await pool.query(
      `
        SELECT
          s.id,
          s.store_name,
          s.store_code,
          s.status
        FROM stores s
        ${whereSql}
        ORDER BY s.id ASC
      `,
      params
    );

    return sendSuccess(
      res,
      rows.map(item => ({
        id: Number(item.id),
        storeName: item.store_name,
        storeCode: item.store_code,
        status: Number(item.status)
      })),
      "查询成功"
    );
  } catch (error) {
    next(error);
  }
}

async function listStores(req, res, next) {
  try {
    if (Number(req.user?.role) !== ROLE_ADMIN) {
      return sendFail(res, "仅超级管理员可查看全部门店列表", 403);
    }

    const { pageNum, pageSize, offset } = normalizePagination(req.query);
    const keyword = String(req.query.keyword || "").trim();
    const status =
      req.query.status === undefined || req.query.status === ""
        ? null
        : toInt(req.query.status, 1);

    const where = [];
    const params = [];

    if (keyword) {
      where.push(
        "(s.store_name LIKE ? OR s.store_code LIKE ? OR s.contact_name LIKE ? OR s.contact_phone LIKE ?)"
      );
      params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
    }

    if (status !== null && (status === 0 || status === 1)) {
      where.push("s.status = ?");
      params.push(status);
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const countSql = `
      SELECT COUNT(*) AS total
      FROM stores s
      ${whereSql}
    `;

    const listSql = `
      SELECT
        s.id,
        s.store_name,
        s.store_code,
        s.contact_name,
        s.contact_phone,
        s.address,
        s.status,
        s.remark,
        s.created_at,
        s.updated_at,
        COUNT(DISTINCT u.id) AS user_count,
        COUNT(DISTINCT c.id) AS customer_count
      FROM stores s
      LEFT JOIN users u ON u.store_id = s.id
      LEFT JOIN customers c ON c.store_id = s.id
      ${whereSql}
      GROUP BY
        s.id,
        s.store_name,
        s.store_code,
        s.contact_name,
        s.contact_phone,
        s.address,
        s.status,
        s.remark,
        s.created_at,
        s.updated_at
      ORDER BY s.id DESC
      LIMIT ? OFFSET ?
    `;

    const [[countRow]] = await pool.query(countSql, params);
    const [rows] = await pool.query(listSql, [...params, pageSize, offset]);

    return sendPage(
      res,
      rows.map(formatStore),
      Number(countRow.total || 0),
      pageNum,
      pageSize
    );
  } catch (error) {
    next(error);
  }
}

async function getStoreDetail(req, res, next) {
  try {
    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "门店ID无效", 400);
    }

    const [rows] = await pool.query(
      `
        SELECT
          s.id,
          s.store_name,
          s.store_code,
          s.contact_name,
          s.contact_phone,
          s.address,
          s.status,
          s.remark,
          s.created_at,
          s.updated_at,
          COUNT(DISTINCT u.id) AS user_count,
          COUNT(DISTINCT c.id) AS customer_count
        FROM stores s
        LEFT JOIN users u ON u.store_id = s.id
        LEFT JOIN customers c ON c.store_id = s.id
        WHERE s.id = ?
        GROUP BY
          s.id,
          s.store_name,
          s.store_code,
          s.contact_name,
          s.contact_phone,
          s.address,
          s.status,
          s.remark,
          s.created_at,
          s.updated_at
        LIMIT 1
      `,
      [id]
    );

    if (!rows.length) {
      return sendFail(res, "门店不存在", 404);
    }

    if (!canAccessStore(req.user, rows[0].id)) {
      return sendFail(res, "无权限查看该门店", 403);
    }

    return sendSuccess(res, formatStore(rows[0]), "查询成功");
  } catch (error) {
    next(error);
  }
}

async function createStore(req, res, next) {
  try {
    if (Number(req.user?.role) !== ROLE_ADMIN) {
      return sendFail(res, "仅超级管理员可新增门店", 403);
    }

    const storeName = String(req.body.storeName || "").trim();
    const storeCode = String(req.body.storeCode || "").trim();
    const contactName = String(req.body.contactName || "").trim();
    const contactPhone = String(req.body.contactPhone || "").trim();
    const address = String(req.body.address || "").trim();
    const remark = String(req.body.remark || "").trim();
    const status = req.body.status === undefined ? 1 : toInt(req.body.status, 1);

    if (!storeName) {
      return sendFail(res, "请输入门店名称", 400);
    }

    if (!storeCode) {
      return sendFail(res, "请输入门店编码", 400);
    }

    if (![0, 1].includes(status)) {
      return sendFail(res, "门店状态无效", 400);
    }

    const [existsRows] = await pool.query(
      `
        SELECT id, store_name, store_code
        FROM stores
        WHERE store_name = ? OR store_code = ?
        LIMIT 1
      `,
      [storeName, storeCode]
    );

    if (existsRows.length) {
      const hit = existsRows[0];
      if (hit.store_name === storeName) {
        return sendFail(res, "门店名称已存在", 400);
      }
      if (hit.store_code === storeCode) {
        return sendFail(res, "门店编码已存在", 400);
      }
    }

    const [result] = await pool.execute(
      `
        INSERT INTO stores
        (store_name, store_code, contact_name, contact_phone, address, status, remark)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `,
      [storeName, storeCode, contactName || null, contactPhone || null, address || null, status, remark || null]
    );

    await writeStoreLog(
      req,
      "create",
      `新增门店：${storeName}（编码：${storeCode}）`,
      result.insertId,
      storeCode
    );

    const [rows] = await pool.query(
      `
        SELECT
          id,
          store_name,
          store_code,
          contact_name,
          contact_phone,
          address,
          status,
          remark,
          created_at,
          updated_at
        FROM stores
        WHERE id = ?
        LIMIT 1
      `,
      [result.insertId]
    );

    return sendSuccess(res, formatStore(rows[0]), "新增门店成功");
  } catch (error) {
    next(error);
  }
}

async function updateStore(req, res, next) {
  try {
    if (Number(req.user?.role) !== ROLE_ADMIN) {
      return sendFail(res, "仅超级管理员可修改门店", 403);
    }

    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "门店ID无效", 400);
    }

    const storeName = String(req.body.storeName || "").trim();
    const storeCode = String(req.body.storeCode || "").trim();
    const contactName = String(req.body.contactName || "").trim();
    const contactPhone = String(req.body.contactPhone || "").trim();
    const address = String(req.body.address || "").trim();
    const remark = String(req.body.remark || "").trim();
    const status = req.body.status === undefined ? 1 : toInt(req.body.status, 1);

    if (!storeName) {
      return sendFail(res, "请输入门店名称", 400);
    }

    if (!storeCode) {
      return sendFail(res, "请输入门店编码", 400);
    }

    if (![0, 1].includes(status)) {
      return sendFail(res, "门店状态无效", 400);
    }

    const [storeRows] = await pool.query(
      `
        SELECT id, store_name, store_code
        FROM stores
        WHERE id = ?
        LIMIT 1
      `,
      [id]
    );

    if (!storeRows.length) {
      return sendFail(res, "门店不存在", 404);
    }

    const [existsRows] = await pool.query(
      `
        SELECT id, store_name, store_code
        FROM stores
        WHERE (store_name = ? OR store_code = ?)
          AND id <> ?
        LIMIT 1
      `,
      [storeName, storeCode, id]
    );

    if (existsRows.length) {
      const hit = existsRows[0];
      if (hit.store_name === storeName) {
        return sendFail(res, "门店名称已存在", 400);
      }
      if (hit.store_code === storeCode) {
        return sendFail(res, "门店编码已存在", 400);
      }
    }

    await pool.execute(
      `
        UPDATE stores
        SET
          store_name = ?,
          store_code = ?,
          contact_name = ?,
          contact_phone = ?,
          address = ?,
          status = ?,
          remark = ?
        WHERE id = ?
      `,
      [storeName, storeCode, contactName || null, contactPhone || null, address || null, status, remark || null, id]
    );

    await writeStoreLog(
      req,
      "update",
      `编辑门店：${storeName}（编码：${storeCode}）`,
      id,
      storeCode
    );

    const [rows] = await pool.query(
      `
        SELECT
          id,
          store_name,
          store_code,
          contact_name,
          contact_phone,
          address,
          status,
          remark,
          created_at,
          updated_at
        FROM stores
        WHERE id = ?
        LIMIT 1
      `,
      [id]
    );

    return sendSuccess(res, formatStore(rows[0]), "修改门店成功");
  } catch (error) {
    next(error);
  }
}

async function deleteStore(req, res, next) {
  try {
    if (Number(req.user?.role) !== ROLE_ADMIN) {
      return sendFail(res, "仅超级管理员可删除门店", 403);
    }

    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "门店ID无效", 400);
    }

    const [storeRows] = await pool.query(
      `
        SELECT id, store_name, store_code
        FROM stores
        WHERE id = ?
        LIMIT 1
      `,
      [id]
    );

    if (!storeRows.length) {
      return sendFail(res, "门店不存在", 404);
    }

    const store = storeRows[0];

    const [[userCountRow]] = await pool.query(
      "SELECT COUNT(*) AS total FROM users WHERE store_id = ?",
      [id]
    );
    const [[customerCountRow]] = await pool.query(
      "SELECT COUNT(*) AS total FROM customers WHERE store_id = ?",
      [id]
    );
    const [[verifyCountRow]] = await pool.query(
      "SELECT COUNT(*) AS total FROM verify_records WHERE store_id = ?",
      [id]
    );

    if (Number(userCountRow.total || 0) > 0) {
      return sendFail(res, "该门店下存在用户数据，无法删除", 400);
    }

    if (Number(customerCountRow.total || 0) > 0) {
      return sendFail(res, "该门店下存在客户数据，无法删除", 400);
    }

    if (Number(verifyCountRow.total || 0) > 0) {
      return sendFail(res, "该门店下存在核销记录，无法删除", 400);
    }

    await pool.execute("DELETE FROM stores WHERE id = ?", [id]);

    await writeStoreLog(
      req,
      "delete",
      `删除门店：${store.store_name}（编码：${store.store_code}）`,
      id,
      store.store_code
    );

    return sendSuccess(res, null, "删除门店成功");
  } catch (error) {
    next(error);
  }
}

module.exports = {
  listStores,
  getStoreDetail,
  createStore,
  updateStore,
  deleteStore,
  getStoreOptions
};
