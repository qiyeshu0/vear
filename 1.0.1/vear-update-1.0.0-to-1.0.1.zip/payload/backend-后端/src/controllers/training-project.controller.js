const { pool } = require("../config/db");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { ROLE_ADMIN } = require("../config/constants");
const { writeOperationLog } = require("../utils/operation-log");
const { toInt } = require("../utils/pagination");


function formatProject(row) {
  if (!row) return null;
  return {
    id: Number(row.id),
    projectName: row.project_name,
    status: Number(row.status),
    remark: row.remark || "",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

async function ensureTrainingProjectTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`training_projects\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`project_name\` varchar(100) NOT NULL COMMENT '项目名称',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`created_by\` bigint unsigned DEFAULT NULL COMMENT '创建人ID',
      \`updated_by\` bigint unsigned DEFAULT NULL COMMENT '更新人ID',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_project_name\` (\`project_name\`),
      KEY \`idx_project_status\` (\`status\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='训练项目表'
  `);
}

async function getProjectOptions(req, res, next) {
  try {
    await ensureTrainingProjectTable();
    const includeDisabled = String(req.query.includeDisabled || "") === "1";
    const where = includeDisabled ? "" : "WHERE status = 1";
    const [rows] = await pool.query(
      `SELECT id, project_name, status FROM training_projects ${where} ORDER BY project_name ASC`,
    );
    return sendSuccess(
      res,
      rows.map((row) => ({
        id: Number(row.id),
        projectName: row.project_name,
        status: Number(row.status),
      })),
      "查询成功",
    );
  } catch (error) {
    next(error);
  }
}

async function getProjectList(req, res, next) {
  try {
    await ensureTrainingProjectTable();
    const pageNum = Math.max(toInt(req.query.pageNum, 1), 1);
    const pageSize = Math.min(Math.max(toInt(req.query.pageSize, 10), 1), 100);
    const offset = (pageNum - 1) * pageSize;

    const keyword = String(req.query.keyword || "").trim();
    const statusRaw = req.query.status;
    const status = statusRaw === "" || statusRaw == null ? null : toInt(statusRaw, -1);

    const where = [];
    const params = [];

    if (keyword) {
      where.push("project_name LIKE ?");
      params.push(`%${keyword}%`);
    }

    if (status !== null && status !== -1) {
      where.push("status = ?");
      params.push(status);
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const [rows] = await pool.query(
      `
        SELECT *
        FROM training_projects
        ${whereSql}
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?
      `,
      [...params, pageSize, offset],
    );

    const [[countRow]] = await pool.query(
      `SELECT COUNT(*) AS total FROM training_projects ${whereSql}`,
      params,
    );

    return sendPage(
      res,
      rows.map(formatProject),
      Number(countRow.total || 0),
      pageNum,
      pageSize,
    );
  } catch (error) {
    next(error);
  }
}

async function createProject(req, res, next) {
  try {
    await ensureTrainingProjectTable();

    const projectName = String(req.body.projectName || "").trim();
    const remark = String(req.body.remark || "").trim();

    if (!projectName) {
      return sendFail(res, "请输入项目名称", 400);
    }

    const [exists] = await pool.execute(
      "SELECT id FROM training_projects WHERE project_name = ? LIMIT 1",
      [projectName],
    );
    if (exists.length) {
      return sendFail(res, "项目名称已存在", 400);
    }

    const [result] = await pool.execute(
      `
        INSERT INTO training_projects
        (project_name, status, remark, created_by, updated_by)
        VALUES (?, 1, ?, ?, ?)
      `,
      [projectName, remark || null, req.user.userId, req.user.userId],
    );

    await writeOperationLog(req, {
      module: "system",
      action: "create",
      bizType: "training_project",
      bizId: result.insertId,
      bizNo: projectName,
      content: `新增训练项目：${projectName}`,
    });

    return sendSuccess(res, { id: result.insertId }, "新增成功");
  } catch (error) {
    next(error);
  }
}

async function updateProject(req, res, next) {
  try {
    await ensureTrainingProjectTable();

    const id = toInt(req.params.id, 0);
    if (!id) return sendFail(res, "项目ID无效", 400);

    const projectName = String(req.body.projectName || "").trim();
    const remark = String(req.body.remark || "").trim();

    if (!projectName) {
      return sendFail(res, "请输入项目名称", 400);
    }

    const [exists] = await pool.execute(
      "SELECT id FROM training_projects WHERE project_name = ? AND id <> ? LIMIT 1",
      [projectName, id],
    );
    if (exists.length) {
      return sendFail(res, "项目名称已存在", 400);
    }

    await pool.execute(
      `UPDATE training_projects SET project_name = ?, remark = ?, updated_by = ? WHERE id = ?`,
      [projectName, remark || null, req.user.userId, id],
    );

    await writeOperationLog(req, {
      module: "system",
      action: "update",
      bizType: "training_project",
      bizId: id,
      bizNo: projectName,
      content: `编辑训练项目：${projectName}`,
    });

    return sendSuccess(res, null, "更新成功");
  } catch (error) {
    next(error);
  }
}

async function updateProjectStatus(req, res, next) {
  try {
    await ensureTrainingProjectTable();

    const id = toInt(req.params.id, 0);
    const status = toInt(req.body.status, -1);
    if (!id) return sendFail(res, "项目ID无效", 400);
    if (![0, 1].includes(status)) return sendFail(res, "状态值无效", 400);

    const [rows] = await pool.execute(
      "SELECT project_name FROM training_projects WHERE id = ? LIMIT 1",
      [id],
    );
    if (!rows.length) return sendFail(res, "项目不存在", 404);

    await pool.execute(
      "UPDATE training_projects SET status = ?, updated_by = ? WHERE id = ?",
      [status, req.user.userId, id],
    );

    await writeOperationLog(req, {
      module: "system",
      action: "update_status",
      bizType: "training_project",
      bizId: id,
      bizNo: rows[0].project_name,
      content: `${status === 1 ? "启用" : "停用"}训练项目：${rows[0].project_name}`,
    });

    return sendSuccess(res, null, "更新状态成功");
  } catch (error) {
    next(error);
  }
}

async function deleteProject(req, res, next) {
  try {
    await ensureTrainingProjectTable();

    const id = toInt(req.params.id, 0);
    if (!id) return sendFail(res, "项目ID无效", 400);

    const [rows] = await pool.execute(
      "SELECT project_name FROM training_projects WHERE id = ? LIMIT 1",
      [id],
    );
    const project = rows[0];
    if (!project) return sendFail(res, "项目不存在", 404);

    const [[usageRow]] = await pool.query(
      `
        SELECT
          (SELECT COUNT(*) FROM customers WHERE training_project = ?) AS customer_count,
          (SELECT COUNT(*) FROM customer_cards WHERE training_project = ?) AS card_count,
          (SELECT COUNT(*) FROM card_templates WHERE training_project = ?) AS template_count,
          (SELECT COUNT(*) FROM verify_records WHERE training_project = ?) AS record_count
      `,
      [project.project_name, project.project_name, project.project_name, project.project_name],
    );

    const usageTotal =
      Number(usageRow.customer_count || 0) +
      Number(usageRow.card_count || 0) +
      Number(usageRow.template_count || 0) +
      Number(usageRow.record_count || 0);

    if (usageTotal > 0) {
      return sendFail(
        res,
        "已有客户、卡项或核销记录使用该项目，不能删除；如不再使用请改为停用",
        400,
      );
    }

    await pool.execute("DELETE FROM training_projects WHERE id = ?", [id]);

    await writeOperationLog(req, {
      module: "system",
      action: "delete",
      bizType: "training_project",
      bizId: id,
      bizNo: project.project_name,
      content: `删除训练项目：${project.project_name}`,
    });

    return sendSuccess(res, null, "删除成功");
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getProjectOptions,
  getProjectList,
  createProject,
  updateProject,
  updateProjectStatus,
  deleteProject,
};
