const bcrypt = require("bcryptjs");
const { pool } = require("../config/db");
const { toInt, normalizePage } = require("../utils/pagination");
const {
  ROLE_ADMIN,
  ROLE_OWNER,
  ROLE_MANAGER,
  ROLE_STAFF,
  ROLE_MAP,
} = require("../config/constants");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { writeOperationLog } = require("../utils/operation-log");
const {
  ALL_PERMISSION,
  getUserPermissionCodes,
  setUserPermissionCodes,
  normalizePermissionCodes,
  defaultPermissionsForRole,
  hasPermission
} = require("../utils/permission");


function buildUserItem(row) {
  if (!row) return null;

  return {
    id: Number(row.id),
    username: row.username,
    realName: row.real_name,
    role: Number(row.role),
    roleLabel: ROLE_MAP[Number(row.role)] || "未知角色",
    storeId: row.store_id ? Number(row.store_id) : null,
    storeName: row.store_name || null,
    status: Number(row.status),
    lastLoginAt: row.last_login_at || null,
    lastLoginIp: row.last_login_ip || null,
    remark: row.remark || "",
    permissionCount: row.permission_count == null ? undefined : Number(row.permission_count || 0),
    permissions: row.permissions ? normalizePermissionCodes(Array.isArray(row.permissions) ? row.permissions : JSON.parse(row.permissions || "[]")) : undefined,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

async function ensureRegistrationTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`user_registrations\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`username\` varchar(50) NOT NULL COMMENT '登录账号',
      \`password_hash\` varchar(255) NOT NULL COMMENT '密码哈希',
      \`real_name\` varchar(50) NOT NULL COMMENT '真实姓名',
      \`phone\` varchar(20) DEFAULT NULL COMMENT '联系电话',
      \`store_id\` bigint unsigned DEFAULT NULL COMMENT '所属门店ID',
      \`role\` tinyint DEFAULT NULL COMMENT '分配角色',
      \`status\` tinyint NOT NULL DEFAULT 0 COMMENT '状态：0待审核 1通过 2拒绝',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`review_note\` varchar(255) DEFAULT NULL COMMENT '审核意见',
      \`reviewed_by\` bigint unsigned DEFAULT NULL COMMENT '审核人ID',
      \`reviewed_at\` datetime DEFAULT NULL COMMENT '审核时间',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_reg_username\` (\`username\`),
      KEY \`idx_reg_status\` (\`status\`),
      KEY \`idx_reg_store_id\` (\`store_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户注册申请表'
  `);
}

function buildRegistrationItem(row) {
  if (!row) return null;
  return {
    id: Number(row.id),
    username: row.username,
    realName: row.real_name,
    phone: row.phone || "",
    storeId: row.store_id ? Number(row.store_id) : null,
    storeName: row.store_name || null,
    role: row.role == null ? null : Number(row.role),
    status: Number(row.status),
    remark: row.remark || "",
    reviewNote: row.review_note || "",
    reviewedBy: row.reviewed_by ? Number(row.reviewed_by) : null,
    reviewedAt: row.reviewed_at || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function canManageTarget(currentUser, targetUser) {
  if (!currentUser || !targetUser) return false;

  if (Number(currentUser.role) === ROLE_ADMIN) {
    return true;
  }

  if (Number(currentUser.role) === ROLE_OWNER) {
    return (
      Number(targetUser.role) !== ROLE_ADMIN &&
      Number(targetUser.store_id || 0) === Number(currentUser.storeId || 0)
    );
  }

  if (Number(currentUser.role) === ROLE_MANAGER) {
    return (
      Number(targetUser.role) === ROLE_STAFF &&
      Number(targetUser.store_id || 0) === Number(currentUser.storeId || 0)
    );
  }

  return false;
}

function normalizeRole(role) {
  const roleNum = toInt(role, 0);
  if ([ROLE_ADMIN, ROLE_OWNER, ROLE_MANAGER, ROLE_STAFF].includes(roleNum)) {
    return roleNum;
  }
  return 0;
}

function canAssignUserPermissions(currentUser) {
  return (
    hasPermission(currentUser, ALL_PERMISSION) ||
    hasPermission(currentUser, "user:permission")
  );
}

async function getProfile(req, res, next) {
  try {
    const userId = Number(req.user.userId);

    const [rows] = await pool.execute(
      `
        SELECT
          u.id,
          u.username,
          u.real_name,
          u.role,
          u.store_id,
          u.status,
          u.last_login_at,
          u.last_login_ip,
          u.remark,
          u.created_at,
          u.updated_at,
          s.store_name
        FROM users u
        LEFT JOIN stores s ON s.id = u.store_id
        WHERE u.id = ?
        LIMIT 1
      `,
      [userId],
    );

    const user = rows[0];
    if (!user) {
      return sendFail(res, "用户不存在", 404);
    }

    return sendSuccess(res, buildUserItem(user), "获取个人信息成功");
  } catch (error) {
    next(error);
  }
}

async function updateProfile(req, res, next) {
  try {
    const userId = Number(req.user.userId);
    const realName = String(req.body.realName || "").trim();
    const remark = String(req.body.remark || "").trim();

    if (!realName) {
      return sendFail(res, "真实姓名不能为空", 400);
    }

    await pool.execute(
      `
        UPDATE users
        SET real_name = ?, remark = ?
        WHERE id = ?
      `,
      [realName, remark, userId],
    );

    await writeOperationLog(req, {
      module: "user",
      action: "update",
      bizType: "user",
      bizId: userId,
      bizNo: req.user.username,
      content: `更新个人资料：${req.user.username}`,
    });

    const [rows] = await pool.execute(
      `
        SELECT
          u.id,
          u.username,
          u.real_name,
          u.role,
          u.store_id,
          u.status,
          u.last_login_at,
          u.last_login_ip,
          u.remark,
          u.created_at,
          u.updated_at,
          s.store_name
        FROM users u
        LEFT JOIN stores s ON s.id = u.store_id
        WHERE u.id = ?
        LIMIT 1
      `,
      [userId],
    );

    return sendSuccess(res, buildUserItem(rows[0]), "更新个人信息成功");
  } catch (error) {
    next(error);
  }
}

async function updateMyPassword(req, res, next) {
  try {
    const userId = Number(req.user.userId);
    const oldPassword = String(req.body.oldPassword || "").trim();
    const newPassword = String(req.body.newPassword || "").trim();

    if (!oldPassword || !newPassword) {
      return sendFail(res, "请输入原密码和新密码", 400);
    }

    if (newPassword.length < 6) {
      return sendFail(res, "新密码长度不能少于6位", 400);
    }

    const [rows] = await pool.execute(
      `
        SELECT id, username, password_hash
        FROM users
        WHERE id = ?
        LIMIT 1
      `,
      [userId],
    );

    const user = rows[0];
    if (!user) {
      return sendFail(res, "用户不存在", 404);
    }

    const matched = await bcrypt.compare(oldPassword, user.password_hash);
    if (!matched) {
      return sendFail(res, "原密码不正确", 400);
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);

    await pool.execute(
      `
        UPDATE users
        SET password_hash = ?
        WHERE id = ?
      `,
      [passwordHash, userId],
    );

    await pool.execute("DELETE FROM user_sessions WHERE user_id = ?", [userId]);

    await writeOperationLog(req, {
      module: "user",
      action: "update_password",
      bizType: "user",
      bizId: userId,
      bizNo: req.user.username,
      content: `修改个人密码：${req.user.username}`,
    });

    return sendSuccess(res, null, "密码修改成功，请重新登录");
  } catch (error) {
    next(error);
  }
}

async function getUserList(req, res, next) {
  try {
    const { pageNum, pageSize, offset } = normalizePage(req.query);

    const keyword = String(req.query.keyword || "").trim();
    const role = normalizeRole(req.query.role);
    const status =
      req.query.status === "" || req.query.status == null
        ? null
        : toInt(req.query.status, -1);
    const storeId = toInt(req.query.storeId, 0);

    const where = [];
    const params = [];

    if (Number(req.user.role) === ROLE_OWNER) {
      where.push("u.store_id = ?");
      params.push(Number(req.user.storeId));
      where.push("u.role <> ?");
      params.push(ROLE_ADMIN);
    } else if (Number(req.user.role) === ROLE_MANAGER) {
      where.push("u.store_id = ?");
      params.push(Number(req.user.storeId));
      where.push("u.role = ?");
      params.push(ROLE_STAFF);
    }

    if (keyword) {
      where.push("(u.username LIKE ? OR u.real_name LIKE ?)");
      params.push(`%${keyword}%`, `%${keyword}%`);
    }

    if (role > 0) {
      where.push("u.role = ?");
      params.push(role);
    }

    if (status === 0 || status === 1) {
      where.push("u.status = ?");
      params.push(status);
    }

    if (Number(req.user.role) === ROLE_ADMIN && storeId > 0) {
      where.push("u.store_id = ?");
      params.push(storeId);
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const countSql = `
      SELECT COUNT(*) AS total
      FROM users u
      ${whereSql}
    `;

    const listSql = `
      SELECT
        u.id,
        u.username,
        u.real_name,
        u.role,
        u.store_id,
        u.status,
        u.last_login_at,
        u.last_login_ip,
        u.remark,
        u.created_at,
        u.updated_at,
        s.store_name,
        (SELECT COUNT(*) FROM user_permissions up WHERE up.user_id = u.id) AS permission_count
      FROM users u
      LEFT JOIN stores s ON s.id = u.store_id
      ${whereSql}
      ORDER BY u.id DESC
      LIMIT ? OFFSET ?
    `;

    const [[countRow]] = await pool.query(countSql, params);
    const [rows] = await pool.query(listSql, [...params, pageSize, offset]);

    const list = rows.map(buildUserItem);

    return sendPage(res, list, Number(countRow.total || 0), pageNum, pageSize);
  } catch (error) {
    next(error);
  }
}

async function getUserDetail(req, res, next) {
  try {
    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "用户ID无效", 400);
    }

    const [rows] = await pool.execute(
      `
        SELECT
          u.id,
          u.username,
          u.real_name,
          u.role,
          u.store_id,
          u.status,
          u.last_login_at,
          u.last_login_ip,
          u.remark,
          u.created_at,
          u.updated_at,
          s.store_name
        FROM users u
        LEFT JOIN stores s ON s.id = u.store_id
        WHERE u.id = ?
        LIMIT 1
      `,
      [id],
    );

    const user = rows[0];
    if (!user) {
      return sendFail(res, "用户不存在", 404);
    }

    if (
      !canManageTarget(req.user, user) &&
      Number(req.user.role) !== ROLE_ADMIN
    ) {
      return sendFail(res, "无权限查看该用户", 403);
    }

    return sendSuccess(
      res,
      {
        ...buildUserItem(user),
        permissions: await getUserPermissionCodes(user.id, user.role)
      },
      "查询成功"
    );
  } catch (error) {
    next(error);
  }
}

async function createUser(req, res, next) {
  try {
    const username = String(req.body.username || "").trim();
    const realName = String(req.body.realName || "").trim();
    const password = String(req.body.password || "").trim();
    const role = normalizeRole(req.body.role);
    const status = req.body.status == null ? 1 : toInt(req.body.status, 1);
    const remark = String(req.body.remark || "").trim();
    let storeId = req.body.storeId == null ? null : toInt(req.body.storeId, 0);

    if (!username || !realName || !password) {
      return sendFail(res, "账号、姓名、密码不能为空", 400);
    }

    if (password.length < 6) {
      return sendFail(res, "密码长度不能少于6位", 400);
    }

    if (!role) {
      return sendFail(res, "角色无效", 400);
    }

    if (Number(req.user.role) === ROLE_OWNER) {
      if ([ROLE_ADMIN, ROLE_OWNER].includes(role)) {
        return sendFail(res, "门店老板不能创建超级管理员或门店老板账号", 403);
      }
      storeId = Number(req.user.storeId);
    } else if (Number(req.user.role) === ROLE_MANAGER) {
      if (role !== ROLE_STAFF) {
        return sendFail(res, "店长只能创建店员账号", 403);
      }
      storeId = Number(req.user.storeId);
    }

    if (role !== ROLE_ADMIN && !storeId) {
      return sendFail(res, "非管理员账号必须指定所属门店", 400);
    }

    if (role === ROLE_ADMIN) {
      storeId = null;
    }

    const [existsRows] = await pool.execute(
      "SELECT id FROM users WHERE username = ? LIMIT 1",
      [username],
    );

    if (existsRows.length) {
      return sendFail(res, "登录账号已存在", 400);
    }

    if (storeId) {
      const [storeRows] = await pool.execute(
        "SELECT id, store_name FROM stores WHERE id = ? LIMIT 1",
        [storeId],
      );
      if (!storeRows.length) {
        return sendFail(res, "所属门店不存在", 400);
      }
    }

    const passwordHash = await bcrypt.hash(password, 10);

    if (role !== ROLE_ADMIN && Array.isArray(req.body.permissions) && !canAssignUserPermissions(req.user)) {
      return sendFail(res, "无权限分配用户权限", 403);
    }

    const [result] = await pool.execute(
      `
        INSERT INTO users
        (username, password_hash, real_name, role, store_id, status, remark)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `,
      [
        username,
        passwordHash,
        realName,
        role,
        storeId,
        status === 0 ? 0 : 1,
        remark,
      ],
    );

    if (role !== ROLE_ADMIN) {
      const requestedPermissions = Array.isArray(req.body.permissions)
        ? req.body.permissions
        : defaultPermissionsForRole(role);
      const finalPermissions = hasPermission(req.user, ALL_PERMISSION)
        ? requestedPermissions
        : normalizePermissionCodes(requestedPermissions).filter(code => hasPermission(req.user, code));
      await setUserPermissionCodes(result.insertId, finalPermissions);
    }

    await writeOperationLog(req, {
      module: "user",
      action: "create",
      bizType: "user",
      bizId: result.insertId,
      bizNo: username,
      content: `创建用户：${username}`,
    });

    const [rows] = await pool.execute(
      `
        SELECT
          u.id,
          u.username,
          u.real_name,
          u.role,
          u.store_id,
          u.status,
          u.last_login_at,
          u.last_login_ip,
          u.remark,
          u.created_at,
          u.updated_at,
          s.store_name
        FROM users u
        LEFT JOIN stores s ON s.id = u.store_id
        WHERE u.id = ?
        LIMIT 1
      `,
      [result.insertId],
    );

    return sendSuccess(res, buildUserItem(rows[0]), "创建用户成功");
  } catch (error) {
    next(error);
  }
}

async function updateUser(req, res, next) {
  try {
    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "用户ID无效", 400);
    }

    const [targetRows] = await pool.execute(
      "SELECT id, username, role, store_id FROM users WHERE id = ? LIMIT 1",
      [id],
    );

    const targetUser = targetRows[0];
    if (!targetUser) {
      return sendFail(res, "用户不存在", 404);
    }

    if (!canManageTarget(req.user, targetUser)) {
      return sendFail(res, "无权限修改该用户", 403);
    }

    const username = String(req.body.username || "").trim();
    const realName = String(req.body.realName || "").trim();
    const remark = String(req.body.remark || "").trim();
    const status = req.body.status == null ? null : toInt(req.body.status, 1);
    let role =
      req.body.role == null
        ? Number(targetUser.role)
        : normalizeRole(req.body.role);
    let storeId =
      req.body.storeId == null
        ? targetUser.store_id
          ? Number(targetUser.store_id)
          : null
        : toInt(req.body.storeId, 0);

    if (!username || !realName) {
      return sendFail(res, "账号和姓名不能为空", 400);
    }

    if (Number(req.user.role) === ROLE_OWNER) {
      if ([ROLE_ADMIN, ROLE_OWNER].includes(role)) {
        return sendFail(res, "门店老板不能设置超级管理员或门店老板角色", 403);
      }
      storeId = Number(req.user.storeId);
    } else if (Number(req.user.role) === ROLE_MANAGER) {
      role = ROLE_STAFF;
      storeId = Number(req.user.storeId);
    }

    if (role !== ROLE_ADMIN && !storeId) {
      return sendFail(res, "非管理员账号必须指定所属门店", 400);
    }

    if (role === ROLE_ADMIN) {
      storeId = null;
    }

    const [duplicateRows] = await pool.execute(
      "SELECT id FROM users WHERE username = ? AND id <> ? LIMIT 1",
      [username, id],
    );

    if (duplicateRows.length) {
      return sendFail(res, "登录账号已存在", 400);
    }

    if (role !== ROLE_ADMIN && Array.isArray(req.body.permissions) && !canAssignUserPermissions(req.user)) {
      return sendFail(res, "无权限分配用户权限", 403);
    }

    await pool.execute(
      `
        UPDATE users
        SET
          username = ?,
          real_name = ?,
          role = ?,
          store_id = ?,
          status = ?,
          remark = ?
        WHERE id = ?
      `,
      [
        username,
        realName,
        role,
        storeId,
        status == null ? 1 : status === 0 ? 0 : 1,
        remark,
        id,
      ],
    );

    if (role === ROLE_ADMIN) {
      await setUserPermissionCodes(id, []);
    } else if (Array.isArray(req.body.permissions)) {
      const requestedPermissions = req.body.permissions;
      const finalPermissions = hasPermission(req.user, ALL_PERMISSION)
        ? requestedPermissions
        : normalizePermissionCodes(requestedPermissions).filter(code => hasPermission(req.user, code));
      await setUserPermissionCodes(id, finalPermissions);
    }

    await writeOperationLog(req, {
      module: "user",
      action: "update",
      bizType: "user",
      bizId: id,
      bizNo: username,
      content: `修改用户：${username}`,
    });

    const [rows] = await pool.execute(
      `
        SELECT
          u.id,
          u.username,
          u.real_name,
          u.role,
          u.store_id,
          u.status,
          u.last_login_at,
          u.last_login_ip,
          u.remark,
          u.created_at,
          u.updated_at,
          s.store_name
        FROM users u
        LEFT JOIN stores s ON s.id = u.store_id
        WHERE u.id = ?
        LIMIT 1
      `,
      [id],
    );

    return sendSuccess(res, buildUserItem(rows[0]), "更新用户成功");
  } catch (error) {
    next(error);
  }
}

async function updateUserStatus(req, res, next) {
  try {
    const id = toInt(req.params.id, 0);
    const status = toInt(req.body.status, -1);

    if (!id) {
      return sendFail(res, "用户ID无效", 400);
    }

    if (![0, 1].includes(status)) {
      return sendFail(res, "状态值无效", 400);
    }

    const [rows] = await pool.execute(
      "SELECT id, username, role, store_id FROM users WHERE id = ? LIMIT 1",
      [id],
    );

    const targetUser = rows[0];
    if (!targetUser) {
      return sendFail(res, "用户不存在", 404);
    }

    if (!canManageTarget(req.user, targetUser)) {
      return sendFail(res, "无权限修改该用户状态", 403);
    }

    if (Number(req.user.userId) === id && status === 0) {
      return sendFail(res, "不能禁用自己的账号", 400);
    }

    await pool.execute("UPDATE users SET status = ? WHERE id = ?", [
      status,
      id,
    ]);

    if (status === 0) {
      await pool.execute("DELETE FROM user_sessions WHERE user_id = ?", [id]);
    }

    await writeOperationLog(req, {
      module: "user",
      action: "update_status",
      bizType: "user",
      bizId: id,
      bizNo: targetUser.username,
      content: `${status === 1 ? "启用" : "禁用"}用户：${targetUser.username}`,
    });

    return sendSuccess(res, null, "更新状态成功");
  } catch (error) {
    next(error);
  }
}

async function deleteUser(req, res, next) {
  try {
    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "用户ID无效", 400);
    }

    if (Number(req.user.userId) === id) {
      return sendFail(res, "不能删除自己的账号", 400);
    }

    const [rows] = await pool.execute(
      "SELECT id, username, role, store_id FROM users WHERE id = ? LIMIT 1",
      [id],
    );

    const targetUser = rows[0];
    if (!targetUser) {
      return sendFail(res, "用户不存在", 404);
    }

    if (!canManageTarget(req.user, targetUser)) {
      return sendFail(res, "无权限删除该用户", 403);
    }

    await pool.execute("DELETE FROM user_sessions WHERE user_id = ?", [id]);
    await pool.execute("DELETE FROM user_permissions WHERE user_id = ?", [id]);
    await pool.execute("DELETE FROM users WHERE id = ?", [id]);

    await writeOperationLog(req, {
      module: "user",
      action: "delete",
      bizType: "user",
      bizId: id,
      bizNo: targetUser.username,
      content: `删除用户：${targetUser.username}`,
    });

    return sendSuccess(res, null, "删除用户成功");
  } catch (error) {
    next(error);
  }
}

async function resetUserPassword(req, res, next) {
  try {
    const id = toInt(req.params.id, 0);
    const newPassword = String(req.body.newPassword || "").trim();

    if (!id) {
      return sendFail(res, "用户ID无效", 400);
    }

    if (!newPassword || newPassword.length < 6) {
      return sendFail(res, "新密码长度不能少于6位", 400);
    }

    const [rows] = await pool.execute(
      "SELECT id, username, role, store_id FROM users WHERE id = ? LIMIT 1",
      [id],
    );

    const targetUser = rows[0];
    if (!targetUser) {
      return sendFail(res, "用户不存在", 404);
    }

    if (!canManageTarget(req.user, targetUser)) {
      return sendFail(res, "无权限重置该用户密码", 403);
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);

    await pool.execute("UPDATE users SET password_hash = ? WHERE id = ?", [
      passwordHash,
      id,
    ]);

    await pool.execute("DELETE FROM user_sessions WHERE user_id = ?", [id]);

    await writeOperationLog(req, {
      module: "user",
      action: "reset_password",
      bizType: "user",
      bizId: id,
      bizNo: targetUser.username,
      content: `重置用户密码：${targetUser.username}`,
    });

    return sendSuccess(res, null, "重置密码成功");
  } catch (error) {
    next(error);
  }
}

async function getRegistrationList(req, res, next) {
  try {
    await ensureRegistrationTable();
    const pageNum = Math.max(toInt(req.query.pageNum, 1), 1);
    const pageSize = Math.max(toInt(req.query.pageSize, 10), 1);
    const offset = (pageNum - 1) * pageSize;

    const keyword = String(req.query.keyword || "").trim();
    const statusRaw = req.query.status;
    const status =
      statusRaw === "" || statusRaw == null ? null : toInt(statusRaw, -1);

    const where = [];
    const params = [];

    if (keyword) {
      where.push(
        "(r.username LIKE ? OR r.real_name LIKE ? OR r.phone LIKE ?)"
      );
      params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
    }

    if (status !== null && status !== -1) {
      where.push("r.status = ?");
      params.push(status);
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const [rows] = await pool.query(
      `
        SELECT
          r.*,
          s.store_name
        FROM user_registrations r
        LEFT JOIN stores s ON s.id = r.store_id
        ${whereSql}
        ORDER BY r.status ASC, r.created_at DESC
        LIMIT ? OFFSET ?
      `,
      [...params, pageSize, offset]
    );

    const [[countRow]] = await pool.query(
      `
        SELECT COUNT(*) AS total
        FROM user_registrations r
        ${whereSql}
      `,
      params
    );

    return sendPage(
      res,
      rows.map(buildRegistrationItem),
      Number(countRow.total || 0),
      pageNum,
      pageSize
    );
  } catch (error) {
    next(error);
  }
}

async function approveRegistration(req, res, next) {
  try {
    await ensureRegistrationTable();
    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "申请ID无效", 400);
    }

    const role = toInt(req.body.role, 0);
    let storeId =
      req.body.storeId == null || req.body.storeId === ""
        ? null
        : toInt(req.body.storeId, 0);
    const remark = String(req.body.remark || "").trim();

    if (![ROLE_ADMIN, ROLE_OWNER, ROLE_MANAGER, ROLE_STAFF].includes(role)) {
      return sendFail(res, "角色无效", 400);
    }

    if (role === ROLE_ADMIN) {
      storeId = null;
    }

    if (role !== ROLE_ADMIN && !storeId) {
      return sendFail(res, "请选择所属门店", 400);
    }

    if (storeId) {
      const [storeRows] = await pool.execute(
        "SELECT id FROM stores WHERE id = ? LIMIT 1",
        [storeId]
      );
      if (!storeRows.length) {
        return sendFail(res, "所属门店不存在", 400);
      }
    }

    const [rows] = await pool.execute(
      "SELECT * FROM user_registrations WHERE id = ? LIMIT 1",
      [id]
    );
    const reg = rows[0];
    if (!reg) {
      return sendFail(res, "注册申请不存在", 404);
    }

    if (Number(reg.status) === 1) {
      return sendFail(res, "该申请已通过", 400);
    }

    const [existsUser] = await pool.execute(
      "SELECT id FROM users WHERE username = ? LIMIT 1",
      [reg.username]
    );
    if (existsUser.length) {
      return sendFail(res, "账号已存在，请勿重复审批", 400);
    }

    let userRemark = remark || reg.remark || "";
    if (reg.phone) {
      const phoneMark = `注册电话:${reg.phone}`;
      if (!userRemark.includes(phoneMark)) {
        userRemark = userRemark ? `${userRemark}；${phoneMark}` : phoneMark;
      }
    }

    const [result] = await pool.execute(
      `
        INSERT INTO users
        (username, password_hash, real_name, role, store_id, status, remark)
        VALUES (?, ?, ?, ?, ?, 1, ?)
      `,
      [
        reg.username,
        reg.password_hash,
        reg.real_name,
        role,
        storeId,
        userRemark || null
      ]
    );

    if (role !== ROLE_ADMIN) {
      if (Array.isArray(req.body.permissions) && !canAssignUserPermissions(req.user)) {
        return sendFail(res, "无权限分配用户权限", 403);
      }
      await setUserPermissionCodes(
        result.insertId,
        Array.isArray(req.body.permissions) ? req.body.permissions : defaultPermissionsForRole(role)
      );
    }

    await pool.execute(
      `
        UPDATE user_registrations
        SET status = 1,
            role = ?,
            store_id = ?,
            reviewed_by = ?,
            reviewed_at = NOW(),
            review_note = ?
        WHERE id = ?
      `,
      [role, storeId, req.user.userId, "审核通过", id]
    );

    await writeOperationLog(req, {
      module: "user",
      action: "approve_registration",
      bizType: "user_registration",
      bizId: id,
      bizNo: reg.username,
      content: `通过注册申请：${reg.username}，角色：${ROLE_MAP[role] || role}`,
    });

    return sendSuccess(
      res,
      { userId: result.insertId },
      "审核通过并创建用户成功"
    );
  } catch (error) {
    next(error);
  }
}

async function rejectRegistration(req, res, next) {
  try {
    await ensureRegistrationTable();
    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "申请ID无效", 400);
    }

    const reason = String(req.body.reason || "").trim();
    const [rows] = await pool.execute(
      "SELECT * FROM user_registrations WHERE id = ? LIMIT 1",
      [id]
    );
    const reg = rows[0];
    if (!reg) {
      return sendFail(res, "注册申请不存在", 404);
    }

    if (Number(reg.status) === 2) {
      return sendFail(res, "该申请已拒绝", 400);
    }

    await pool.execute(
      `
        UPDATE user_registrations
        SET status = 2,
            reviewed_by = ?,
            reviewed_at = NOW(),
            review_note = ?
        WHERE id = ?
      `,
      [req.user.userId, reason || "审核拒绝", id]
    );

    await writeOperationLog(req, {
      module: "user",
      action: "reject_registration",
      bizType: "user_registration",
      bizId: id,
      bizNo: reg.username,
      content: `拒绝注册申请：${reg.username}`,
    });

    return sendSuccess(res, null, "已拒绝该注册申请");
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getProfile,
  updateProfile,
  updateMyPassword,
  getUserList,
  getUserDetail,
  createUser,
  updateUser,
  updateUserStatus,
  deleteUser,
  resetUserPassword,
  getRegistrationList,
  approveRegistration,
  rejectRegistration,
};
