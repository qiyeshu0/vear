const fs = require("fs");
const path = require("path");
const { sendSuccess, sendFail } = require("../utils/response");

const PROJECT_ROOT = path.join(__dirname, "..", "..");
const WORKSPACE_ROOT = path.join(PROJECT_ROOT, "..");
const OPENAPI_CANDIDATES = [
  path.join(PROJECT_ROOT, "openapi.json"),
  path.join(WORKSPACE_ROOT, "openapi.json"),
];

function getOpenApiFile() {
  return OPENAPI_CANDIDATES.find((file) => fs.existsSync(file)) || "";
}

async function getOpenApiSpec(req, res) {
  const openapiFile = getOpenApiFile();
  if (!openapiFile) {
    return sendFail(res, "openapi.json 不存在", 404);
  }

  const content = fs.readFileSync(openapiFile, "utf8");
  res.type("application/json");
  res.send(content);
}

async function getToolMeta(req, res) {
  const openapiFile = getOpenApiFile();
  let operations = [];
  if (openapiFile) {
    try {
      const spec = JSON.parse(fs.readFileSync(openapiFile, "utf8"));
      const methods = new Set(["get", "post", "put", "patch", "delete"]);
      operations = Object.entries(spec.paths || {}).flatMap(([requestPath, pathItem]) =>
        Object.entries(pathItem || {})
          .filter(([method]) => methods.has(method.toLowerCase()))
          .map(([method, operation]) => ({
            method: method.toUpperCase(),
            path: requestPath,
            summary: operation?.summary || operation?.operationId || `${method.toUpperCase()} ${requestPath}`,
            tags: Array.isArray(operation?.tags) ? operation.tags : [],
            requiresAuth: Array.isArray(operation?.security) ? operation.security.length > 0 : true,
          })),
      );
    } catch (error) {
      operations = [];
    }
  }
  return sendSuccess(
    res,
    {
      openapiUrl: "/api/tools/openapi",
      swaggerPage: "/swagger.html",
      apiDocPage: "/API接口对接文档.html",
      pathCount: new Set(operations.map(item => item.path)).size,
      operationCount: operations.length,
      operations,
      apiBase: "/api",
    },
    "获取工具信息成功",
  );
}

module.exports = {
  getOpenApiSpec,
  getToolMeta,
};
