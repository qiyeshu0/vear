const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const { createTables } = require("../install/schema");
const { seedDefaultBusinessData } = require("../install/default-business-data");
const { resetPool } = require("../config/db");
const { sendSuccess, sendFail } = require("../utils/response");
const { ensurePermissionTables, ensureDefaultUserPermissions } = require("../utils/permission");
const { saveSettings, DEFAULT_SETTINGS } = require("../utils/system-settings");
const { ensureSmsSchema } = require("../services/sms.service");
const { ensureRuntimeConfigSchema } = require("../utils/runtime-config");

const INSTALL_LOCK_FILE = path.join(__dirname, "..", "..", ".installed");
const ENV_FILE = path.join(__dirname, "..", "..", ".env");
const DEFAULT_CORS_ORIGINS = ["http://localhost:3000", "http://localhost:5173"];
const RUNTIME_NODE_ENV = process.env.NODE_ENV || "production";
const RUNTIME_PORT = process.env.PORT || "3000";
const CORE_TABLES = ["stores", "users", "customers", "verify_records", "customer_attachments"];

function isInstalled() {
  return fs.existsSync(INSTALL_LOCK_FILE);
}

function collectRuntimeOrigins(req) {
  const host = req.headers.host;
  const requestOrigin = String(req.headers.origin || "").trim();
  const forwardedProto = String(req.headers["x-forwarded-proto"] || "")
    .split(",")[0]
    .trim();
  const protocol = forwardedProto || req.protocol || "http";
  const currentOrigin = host ? `${protocol}://${host}` : "";

  return Array.from(
    new Set([
      requestOrigin,
      currentOrigin,
      ...DEFAULT_CORS_ORIGINS
    ].filter(Boolean))
  );
}

async function createAdminUser(connection, adminData) {
  const passwordHash = await bcrypt.hash(adminData.password, 10);

  const [result] = await connection.query(
    `INSERT INTO users (username, password_hash, real_name, role, status, remark)
     VALUES (?, ?, ?, 1, 1, '系统初始化管理员')`,
    [adminData.username, passwordHash, adminData.realName]
  );

  return result.insertId;
}

async function createDefaultStore(connection) {
  const [result] = await connection.query(
    `INSERT INTO stores (store_name, store_code, contact_name, contact_phone, address, status, remark)
     VALUES ('总部', 'HQ', '系统管理员', '13800000000', '总部地址', 1, '初始化门店')`
  );

  return result.insertId;
}

async function connectMysqlServer(config) {
  const mysql = require("mysql2/promise");
  return mysql.createConnection({
    host: config.host || "127.0.0.1",
    port: Number(config.port) || 3306,
    user: config.user || "root",
    password: config.password || ""
  });
}

async function connectMysqlDatabase(config, dbName) {
  const mysql = require("mysql2/promise");
  return mysql.createConnection({
    host: config.host || "127.0.0.1",
    port: Number(config.port) || 3306,
    user: config.user || "root",
    password: config.password || "",
    database: dbName,
    charset: "utf8mb4"
  });
}

async function checkDatabaseConnection(config) {
  const connection = await connectMysqlServer(config);
  try {
    await connection.ping();
    return true;
  } finally {
    await connection.end();
  }
}

async function createDatabase(config, dbName) {
  const connection = await connectMysqlServer(config);
  try {
    await connection.query(
      `CREATE DATABASE IF NOT EXISTS \`${dbName}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci`
    );
  } finally {
    await connection.end();
  }
}

async function databaseExists(config, dbName) {
  const connection = await connectMysqlServer(config);

  try {
    const [rows] = await connection.query(
      `SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ? LIMIT 1`,
      [dbName]
    );
    return Boolean(rows[0]);
  } finally {
    await connection.end();
  }
}

async function inspectDatabaseState(config) {
  const dbName = config.database || "verification_system";
  const exists = await databaseExists(config, dbName);

  if (!exists) {
    return {
      databaseExists: false,
      canReuse: false,
      dbName,
      coreTablesPresent: false,
      tables: [],
      counts: {
        stores: 0,
        users: 0,
        customers: 0,
        attachments: 0,
        records: 0,
      },
    };
  }

  const connection = await connectMysqlDatabase(config, dbName);

  try {
    const [tableRows] = await connection.query(
      `
        SELECT TABLE_NAME
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = ?
      `,
      [dbName]
    );

    const tables = tableRows.map((row) => row.TABLE_NAME);
    const coreTablesPresent = CORE_TABLES.every((table) => tables.includes(table));
    const counts = {
      stores: 0,
      users: 0,
      customers: 0,
      attachments: 0,
      records: 0,
    };

    if (tables.includes("stores")) {
      const [[row]] = await connection.query(`SELECT COUNT(*) AS total FROM stores`);
      counts.stores = Number(row.total || 0);
    }
    if (tables.includes("users")) {
      const [[row]] = await connection.query(`SELECT COUNT(*) AS total FROM users`);
      counts.users = Number(row.total || 0);
    }
    if (tables.includes("customers")) {
      const [[row]] = await connection.query(`SELECT COUNT(*) AS total FROM customers`);
      counts.customers = Number(row.total || 0);
    }
    if (tables.includes("customer_attachments")) {
      const [[row]] = await connection.query(`SELECT COUNT(*) AS total FROM customer_attachments`);
      counts.attachments = Number(row.total || 0);
    }
    if (tables.includes("verify_records")) {
      const [[row]] = await connection.query(`SELECT COUNT(*) AS total FROM verify_records`);
      counts.records = Number(row.total || 0);
    }

    return {
      databaseExists: true,
      canReuse: coreTablesPresent,
      dbName,
      coreTablesPresent,
      tables,
      counts,
    };
  } finally {
    await connection.end();
  }
}

function pickRuntimeEnv(key, fallback = "") {
  const value = process.env[key];
  if (value == null || value === "") return fallback;
  return String(value);
}

function buildEnvContent(dbConfig, dbName, jwtSecret, runtimeOrigins) {
  return `NODE_ENV=${RUNTIME_NODE_ENV}
PORT=${RUNTIME_PORT}

# MySQL
DB_HOST=${dbConfig.host || "127.0.0.1"}
DB_PORT=${dbConfig.port || 3306}
DB_NAME=${dbName}
DB_USER=${dbConfig.user || "root"}
DB_PASSWORD=${dbConfig.password || ""}
DB_CONNECT_TIMEOUT=${pickRuntimeEnv("DB_CONNECT_TIMEOUT", "5000")}

# JWT
JWT_SECRET=${jwtSecret}
JWT_EXPIRES_IN=${pickRuntimeEnv("JWT_EXPIRES_IN", "7d")}
CONFIG_ENCRYPTION_KEY=${pickRuntimeEnv("CONFIG_ENCRYPTION_KEY", crypto.randomBytes(32).toString("hex"))}

# Upload
UPLOAD_DIR=${pickRuntimeEnv("UPLOAD_DIR", "src/uploads")}
UPLOAD_MAX_SIZE=${pickRuntimeEnv("UPLOAD_MAX_SIZE", "10485760")}

# CORS
CORS_ORIGIN=${runtimeOrigins.join(",")}

# 后台首页天气配置：默认 open-meteo 免 Key；安装后可在后台运行配置中心修改
WEATHER_ENABLED=${pickRuntimeEnv("WEATHER_ENABLED", "1")}
WEATHER_PROVIDER=amap
WEATHER_API_URL=https://restapi.amap.com/v3/weather/weatherInfo?city={adcode}&extensions=all&key={key}
WEATHER_API_KEY=${pickRuntimeEnv("WEATHER_API_KEY", "")}
WEATHER_API_KEY_HEADER=${pickRuntimeEnv("WEATHER_API_KEY_HEADER", "")}
WEATHER_LOCATION_NAME=${pickRuntimeEnv("WEATHER_LOCATION_NAME", "默认城市")}
WEATHER_CITY=${pickRuntimeEnv("WEATHER_CITY", "上海")}
WEATHER_ADCODE=${pickRuntimeEnv("WEATHER_ADCODE", "310000")}
WEATHER_LATITUDE=${pickRuntimeEnv("WEATHER_LATITUDE", "31.2304")}
WEATHER_LONGITUDE=${pickRuntimeEnv("WEATHER_LONGITUDE", "121.4737")}
WEATHER_CUSTOM_MAPPING=${pickRuntimeEnv("WEATHER_CUSTOM_MAPPING", "")}
WEATHER_REVERSE_GEOCODE_ENABLED=${pickRuntimeEnv("WEATHER_REVERSE_GEOCODE_ENABLED", "1")}
WEATHER_REVERSE_GEOCODE_URL=${pickRuntimeEnv("WEATHER_REVERSE_GEOCODE_URL", "https://api-bdc.io/data/reverse-geocode-client?latitude={lat}&longitude={lon}&localityLanguage=zh")}

# 微信小程序：安装完成后如需小程序正式登录，请填写真实 AppID/Secret
WX_LOGIN_MOCK=${pickRuntimeEnv("WX_LOGIN_MOCK", "0")}
WX_APPID=${pickRuntimeEnv("WX_APPID", "")}
WX_APPSECRET=${pickRuntimeEnv("WX_APPSECRET") || pickRuntimeEnv("WX_APP_SECRET", "")}
WX_MOCK_OPENID=${pickRuntimeEnv("WX_MOCK_OPENID", "dev-openid-local")}
WX_SUBSCRIBE_TEMPLATE_ID=${pickRuntimeEnv("WX_SUBSCRIBE_TEMPLATE_ID", "")}
WX_GLASSES_TEMPLATE_ID=${pickRuntimeEnv("WX_GLASSES_TEMPLATE_ID", "")}
WX_LOW_TIMES_TEMPLATE_ID=${pickRuntimeEnv("WX_LOW_TIMES_TEMPLATE_ID", "")}
WX_EXPIRE_SOON_TEMPLATE_ID=${pickRuntimeEnv("WX_EXPIRE_SOON_TEMPLATE_ID", "")}
WX_FOLLOWUP_TEMPLATE_ID=${pickRuntimeEnv("WX_FOLLOWUP_TEMPLATE_ID", "")}

# 小程序展示与首页规则：可在后台「系统设置 → 运行配置中心」热更新
MINIPROGRAM_TITLE=${pickRuntimeEnv("MINIPROGRAM_TITLE", "训练助手")}
MINIPROGRAM_SUBTITLE=${pickRuntimeEnv("MINIPROGRAM_SUBTITLE", "视界记录本")}
MINIPROGRAM_ENABLE_STAFF_HIDDEN_ENTRY=${pickRuntimeEnv("MINIPROGRAM_ENABLE_STAFF_HIDDEN_ENTRY", "1")}
MINIPROGRAM_SHOW_GLASSES_PROGRESS=${pickRuntimeEnv("MINIPROGRAM_SHOW_GLASSES_PROGRESS", "1")}
MINIPROGRAM_SHOW_TRAINING_CARD=${pickRuntimeEnv("MINIPROGRAM_SHOW_TRAINING_CARD", "1")}
MINIPROGRAM_HOME_GLASSES_KEEP_DAYS=${pickRuntimeEnv("MINIPROGRAM_HOME_GLASSES_KEEP_DAYS", "15")}
MINIPROGRAM_HOME_RECENT_VERIFY_LIMIT=${pickRuntimeEnv("MINIPROGRAM_HOME_RECENT_VERIFY_LIMIT", "5")}
MINIPROGRAM_HOME_GLASSES_LIMIT=${pickRuntimeEnv("MINIPROGRAM_HOME_GLASSES_LIMIT", "2")}

# SMS 短信服务：未配置真发密钥前建议保持 SMS_MOCK=1
SMS_PROVIDER=${pickRuntimeEnv("SMS_PROVIDER", "aliyun")}
SMS_MOCK=${pickRuntimeEnv("SMS_MOCK", "1")}
SMS_SIGN_NAME=${pickRuntimeEnv("SMS_SIGN_NAME", "")}
ALIYUN_SMS_ACCESS_KEY_ID=${pickRuntimeEnv("ALIYUN_SMS_ACCESS_KEY_ID") || pickRuntimeEnv("SMS_ACCESS_KEY_ID", "")}
ALIYUN_SMS_ACCESS_KEY_SECRET=${pickRuntimeEnv("ALIYUN_SMS_ACCESS_KEY_SECRET") || pickRuntimeEnv("SMS_ACCESS_KEY_SECRET", "")}
ALIYUN_SMS_ENDPOINT=${pickRuntimeEnv("ALIYUN_SMS_ENDPOINT", "https://dysmsapi.aliyuncs.com")}

# Installed at ${new Date().toISOString()}
`;
}

async function writeRuntimeConfig(dbConfig, dbName, jwtSecret, runtimeOrigins, meta = {}) {
  fs.writeFileSync(ENV_FILE, buildEnvContent(dbConfig, dbName, jwtSecret, runtimeOrigins));
  fs.writeFileSync(
    INSTALL_LOCK_FILE,
    JSON.stringify(
      {
        installedAt: new Date().toISOString(),
        origins: runtimeOrigins,
        ...meta,
      },
      null,
      2
    )
  );

  const parsedRuntimeEnv = require("dotenv").parse(fs.readFileSync(ENV_FILE));
  Object.assign(process.env, parsedRuntimeEnv);

  await resetPool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
  });
}

function pickExistingAdminUsername(rows = []) {
  const adminUser = rows.find((row) => Number(row.role) === 1);
  return adminUser?.username || rows[0]?.username || "";
}

async function ensureBaseData(connection, adminAccount) {
  const [[storeRow]] = await connection.query(`SELECT COUNT(*) AS total FROM stores`);
  const [[userRow]] = await connection.query(`SELECT COUNT(*) AS total FROM users`);

  let storeId = 0;
  let adminId = 0;
  let adminCreated = false;
  let existingAdminUsername = "";

  if (Number(storeRow.total || 0) === 0) {
    storeId = await createDefaultStore(connection);
  } else {
    const [[row]] = await connection.query(`SELECT id FROM stores ORDER BY id ASC LIMIT 1`);
    storeId = Number(row?.id || 0);
  }

  if (Number(userRow.total || 0) === 0) {
    if (!adminAccount?.username || !adminAccount?.realName || !adminAccount?.password) {
      throw new Error("当前数据库没有管理员，请填写管理员账号信息");
    }
    adminId = await createAdminUser(connection, adminAccount);
    adminCreated = true;
    existingAdminUsername = adminAccount.username;
    if (storeId) {
      await connection.query(`UPDATE users SET store_id = ? WHERE id = ?`, [storeId, adminId]);
    }
  } else {
    const [rows] = await connection.query(
      `SELECT id, username, role FROM users ORDER BY role ASC, id ASC LIMIT 20`
    );
    existingAdminUsername = pickExistingAdminUsername(rows);
  }

  return {
    storeId,
    adminId,
    adminCreated,
    adminUsername: existingAdminUsername,
  };
}

async function checkInstallStatus(req, res, next) {
  try {
    const installed = isInstalled();

    return sendSuccess(
      res,
      {
        installed,
        step: installed ? "done" : "welcome"
      },
      "获取安装状态成功"
    );
  } catch (error) {
    next(error);
  }
}

async function testDbConnection(req, res, next) {
  try {
    if (isInstalled()) {
      return sendFail(res, "系统已安装，安装检测接口已关闭", 403);
    }

    const { host, port, user, password } = req.body;

    await checkDatabaseConnection({ host, port, user, password });

    return sendSuccess(res, null, "数据库连接成功");
  } catch (error) {
    return sendFail(res, `数据库连接失败：${error.message}`, 400);
  }
}

async function inspectDb(req, res) {
  try {
    if (isInstalled()) {
      return sendFail(res, "系统已安装，安装检测接口已关闭", 403);
    }

    const dbConfig = req.body || {};
    await checkDatabaseConnection(dbConfig);
    const result = await inspectDatabaseState(dbConfig);
    const items = [
      {
        key: "databaseExists",
        label: "目标数据库",
        value: result.databaseExists,
        status: result.databaseExists ? "success" : "warning",
        remark: result.databaseExists ? "检测到目标数据库已存在" : "目标数据库不存在，初始化模式会自动创建"
      },
      {
        key: "coreTablesPresent",
        label: "核心表结构",
        value: result.coreTablesPresent,
        status: result.coreTablesPresent ? "success" : "info",
        remark: result.coreTablesPresent ? "核心业务表已存在" : "核心表尚未完整建立"
      },
      {
        key: "users",
        label: "后台用户",
        value: result.counts.users,
        status: Number(result.counts.users || 0) > 0 ? "success" : "info",
        remark: "当前数据库中的后台用户数量"
      },
      {
        key: "customers",
        label: "客户档案",
        value: result.counts.customers,
        status: Number(result.counts.customers || 0) > 0 ? "success" : "info",
        remark: "当前数据库中的客户档案数量"
      },
      {
        key: "attachments",
        label: "附件记录",
        value: result.counts.attachments,
        status: Number(result.counts.attachments || 0) > 0 ? "success" : "info",
        remark: "仅表示数据库附件记录数，文件本体可后续单独导入"
      }
    ];

    const warnings = [];
    if (!result.databaseExists) {
      warnings.push("目标数据库不存在，复用已有数据库模式不可继续。");
    }
    if (result.databaseExists && !result.coreTablesPresent) {
      warnings.push("目标数据库已存在，但缺少完整核心表结构，更适合使用初始化新系统模式。");
    }
    if (result.databaseExists && result.coreTablesPresent && result.counts.attachments > 0) {
      warnings.push("如果更换了电脑或服务器，请确认附件目录也已迁移，或后续到数据中心执行附件导入。");
    }

    return sendSuccess(
      res,
      {
        installMode: req.body?.installMode || null,
        connectionReady: true,
        databaseExists: result.databaseExists,
        tablesReady: result.coreTablesPresent,
        tableCount: result.tables.length,
        userCount: result.counts.users,
        customerCount: result.counts.customers,
        storeCount: result.counts.stores,
        attachmentCount: result.counts.attachments,
        verifyRecordCount: result.counts.records,
        canReuse: result.databaseExists && result.coreTablesPresent,
        warnings,
        items,
        summary: result,
      },
      "数据库检测成功"
    );
  } catch (error) {
    return sendFail(res, `数据库检测失败：${error.message}`, 400);
  }
}

async function doInstall(req, res) {
  try {
    if (isInstalled()) {
      return sendFail(res, "系统已安装，请勿重复安装", 400);
    }

    const { dbConfig, adminAccount, installMode } = req.body;
    if (!dbConfig) {
      return sendFail(res, "参数不完整", 400);
    }

    const mode =
      installMode === "reuse" || installMode === "reuse_existing"
        ? "reuse"
        : "init";
    const dbName = dbConfig.database || "verification_system";
    const runtimeOrigins = collectRuntimeOrigins(req);
    const jwtSecret = crypto.randomBytes(32).toString("hex");

    await checkDatabaseConnection(dbConfig);

    if (mode === "init") {
      const inspect = await inspectDatabaseState(dbConfig);
      if (
        inspect.databaseExists &&
        inspect.coreTablesPresent &&
        (inspect.counts.users > 0 || inspect.counts.customers > 0 || inspect.counts.records > 0)
      ) {
        return sendFail(res, "当前数据库已存在系统数据，请改用“复用已有数据库”模式", 400);
      }

      await createDatabase(dbConfig, dbName);
    } else {
      const exists = await databaseExists(dbConfig, dbName);
      if (!exists) {
        return sendFail(res, "目标数据库不存在，无法复用，请先创建数据库或改用初始化模式", 400);
      }
    }

    const connection = await connectMysqlDatabase(dbConfig, dbName);

    try {
      await createTables(connection);
      await connection.beginTransaction();
      let ensureResult;
      let businessDefaults;
      try {
        ensureResult = await ensureBaseData(connection, adminAccount);
        businessDefaults = await seedDefaultBusinessData(connection, {
          operatorId: ensureResult.adminId
        });
        await connection.commit();
      } catch (error) {
        await connection.rollback();
        throw error;
      }

      await writeRuntimeConfig(dbConfig, dbName, jwtSecret, runtimeOrigins, {
        installMode: mode,
        reusedDatabase: mode === "reuse",
        adminUsername: ensureResult.adminUsername,
      });

      // 安装向导也必须达到正式初始化脚本同等效果：权限、系统设置、短信中心基础数据一次性补齐。
      await ensurePermissionTables({ force: true });
      await ensureDefaultUserPermissions({ force: true });
      await saveSettings({
        systemName: pickRuntimeEnv("SEED_SYSTEM_NAME", DEFAULT_SETTINGS.system_name),
        soonExpireDays: pickRuntimeEnv("SEED_SOON_EXPIRE_DAYS", DEFAULT_SETTINGS.soon_expire_days),
        lowTimesThreshold: pickRuntimeEnv("SEED_LOW_TIMES_THRESHOLD", DEFAULT_SETTINGS.low_times_threshold),
        remark: "安装向导默认系统设置",
      });
      await ensureSmsSchema();
      await ensureRuntimeConfigSchema();

      return sendSuccess(
        res,
        {
          success: true,
          reusedDatabase: mode === "reuse",
          adminCreated: ensureResult.adminCreated,
          adminUsername: ensureResult.adminUsername,
          defaultTrainingProjects: businessDefaults.trainingProjects,
          defaultCardTemplates: businessDefaults.cardTemplates,
        },
        mode === "reuse" ? "系统已接入已有数据库" : "系统安装成功"
      );
    } finally {
      await connection.end();
    }
  } catch (error) {
    console.error("安装失败:", error);
    return sendFail(res, `安装失败：${error.message}`, 500);
  }
}

module.exports = {
  checkInstallStatus,
  testDbConnection,
  inspectDb,
  doInstall,
  isInstalled,
};
