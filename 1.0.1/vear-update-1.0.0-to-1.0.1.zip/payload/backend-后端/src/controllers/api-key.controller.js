const { pool } = require("../config/db");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { writeOperationLog } = require("../utils/operation-log");
const { toInt, normalizePage } = require("../utils/pagination");
const {
  ensureApiKeyTable,
  ensureApiKeyLogTable,
  hashApiKey,
  generateRawApiKey,
  getKeyPrefix,
  normalizeScopes,
  normalizeExplicitScopes,
  isValidScope,
  API_KEY_SCOPE_OPTIONS,
  serializeScopes,
} = require("../utils/api-key");



function formatApiKey(row) {
  if (!row) return null;

  return {
    id: Number(row.id),
    name: row.name || "",
    keyPrefix: row.key_prefix || "",
    userId: Number(row.user_id || 0),
    username: row.username || "",
    realName: row.real_name || "",
    role: Number(row.role || 0),
    roleLabel: row.role_label || "",
    userStatus: Number(row.user_status ?? 1),
    storeId: row.store_id == null ? null : Number(row.store_id),
    storeName: row.store_name || null,
    scopes: normalizeScopes(row.scopes),
    status: Number(row.status || 0),
    expiresAt: row.expires_at || null,
    lastUsedAt: row.last_used_at || null,
    lastUsedIp: row.last_used_ip || null,
    remark: row.remark || "",
    createdBy: row.created_by == null ? null : Number(row.created_by),
    createdAt: row.created_at || null,
    updatedAt: row.updated_at || null,
    callCount: Number(row.call_count || 0),
    failedCount: Number(row.failed_count || 0),
    effectiveStatus: Number(row.user_status ?? 1) !== 1
      ? "user_disabled"
      : Number(row.status || 0) !== 1
        ? "disabled"
        : row.expires_at && new Date(row.expires_at).getTime() < Date.now()
          ? "expired"
          : "active",
  };
}

function canManageApiKeyTarget(currentUser, targetUser = {}) {
  if (!currentUser) return false;
  if (Number(currentUser.role) === 1) return true;
  return Number(currentUser.storeId || 0) > 0 && Number(currentUser.storeId || 0) === Number(targetUser.store_id || 0);
}

function formatApiKeyLog(row) {
  if (!row) return null;

  return {
    id: Number(row.id),
    apiKeyId: Number(row.api_key_id || 0),
    userId: row.user_id == null ? null : Number(row.user_id),
    requestMethod: row.request_method || "GET",
    requestPath: row.request_path || "",
    statusCode: Number(row.status_code || 0),
    durationMs: Number(row.duration_ms || 0),
    ip: row.ip || "",
    createdAt: row.created_at || null,
  };
}

function parseRequestedScopes(value) {
  const scopes = normalizeExplicitScopes(value);
  if (!scopes.length) {
    const error = new Error("请至少选择一项接口权限");
    error.statusCode = 400;
    throw error;
  }
  if (scopes.length > 30 || scopes.some(scope => !isValidScope(scope))) {
    const error = new Error("接口权限范围格式不正确");
    error.statusCode = 400;
    throw error;
  }
  return scopes;
}

function parseStatus(value, fallback = 1) {
  if (value === "" || value == null) return fallback;
  const status = toInt(value, -1);
  if (![0, 1].includes(status)) {
    const error = new Error("状态值无效");
    error.statusCode = 400;
    throw error;
  }
  return status;
}

function parseExpiry(value) {
  const text = String(value || "").trim();
  if (!text) return null;
  const date = new Date(text.replace(" ", "T"));
  if (Number.isNaN(date.getTime())) {
    const error = new Error("到期时间格式不正确");
    error.statusCode = 400;
    throw error;
  }
  return text;
}

function statsScope(user, alias = "u") {
  if (Number(user?.role) === 1) return { sql: "", params: [] };
  return { sql: ` AND ${alias}.store_id = ?`, params: [Number(user?.storeId || 0)] };
}

async function getApiKeyMeta(req, res) {
  return sendSuccess(res, {
    scopes: API_KEY_SCOPE_OPTIONS,
    blockedModules: ["账号登录", "用户与权限", "系统配置", "数据备份恢复", "短信发送", "API Key 管理"],
    authHeader: "X-API-Key",
  }, "获取 API Key 配置成功");
}

async function getApiKeyStats(req, res, next) {
  try {
    await ensureApiKeyTable();
    await ensureApiKeyLogTable();

    const scope = statsScope(req.user);
    const [[summaryRow]] = await pool.query(
      `
        SELECT
          COUNT(*) AS total_keys,
          SUM(CASE WHEN k.status = 1 AND u.status = 1 AND (k.expires_at IS NULL OR k.expires_at >= NOW()) THEN 1 ELSE 0 END) AS active_keys,
          SUM(CASE WHEN k.expires_at IS NOT NULL AND k.expires_at < NOW() THEN 1 ELSE 0 END) AS expired_keys,
          SUM(CASE WHEN k.status = 0 OR u.status = 0 THEN 1 ELSE 0 END) AS disabled_keys
        FROM external_api_keys k
        INNER JOIN users u ON u.id = k.user_id
        WHERE 1 = 1 ${scope.sql}
      `,
      scope.params,
    );

    const [[callRow]] = await pool.query(
      `
        SELECT
          COUNT(*) AS total_logs,
          SUM(CASE WHEN l.created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY) THEN 1 ELSE 0 END) AS calls_24h,
          SUM(CASE WHEN l.created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY) AND l.status_code >= 400 THEN 1 ELSE 0 END) AS failed_24h
        FROM external_api_key_logs l
        INNER JOIN external_api_keys k ON k.id = l.api_key_id
        INNER JOIN users u ON u.id = k.user_id
        WHERE 1 = 1 ${scope.sql}
      `,
      scope.params,
    );

    const [topRows] = await pool.query(
      `
        SELECT
          k.id,
          k.name,
          k.key_prefix,
          COUNT(l.id) AS call_count,
          MAX(l.created_at) AS last_called_at
        FROM external_api_keys k
        INNER JOIN users u ON u.id = k.user_id
        LEFT JOIN external_api_key_logs l ON l.api_key_id = k.id
        WHERE 1 = 1 ${scope.sql}
        GROUP BY k.id, k.name, k.key_prefix
        ORDER BY call_count DESC, k.id DESC
        LIMIT 5
      `,
      scope.params,
    );

    const [trendRows] = await pool.query(
      `
        SELECT
          DATE_FORMAT(l.created_at, '%Y-%m-%d') AS stat_date,
          COUNT(*) AS call_count
        FROM external_api_key_logs l
        INNER JOIN external_api_keys k ON k.id = l.api_key_id
        INNER JOIN users u ON u.id = k.user_id
        WHERE l.created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) ${scope.sql}
        GROUP BY DATE_FORMAT(l.created_at, '%Y-%m-%d')
        ORDER BY stat_date ASC
      `,
      scope.params,
    );

    const [pathRows] = await pool.query(
      `
        SELECT
          l.request_path,
          COUNT(*) AS call_count,
          SUM(CASE WHEN l.status_code >= 400 THEN 1 ELSE 0 END) AS failed_count,
          MAX(l.created_at) AS last_called_at
        FROM external_api_key_logs l
        INNER JOIN external_api_keys k ON k.id = l.api_key_id
        INNER JOIN users u ON u.id = k.user_id
        WHERE 1 = 1 ${scope.sql}
        GROUP BY l.request_path
        ORDER BY call_count DESC, last_called_at DESC
        LIMIT 10
      `,
      scope.params,
    );

    const trendMap = new Map(trendRows.map(row => [row.stat_date, Number(row.call_count || 0)]));
    const trend = Array.from({ length: 7 }).map((_, index) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - index));
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
      return { date: key, count: trendMap.get(key) || 0 };
    });
    const calls24h = Number(callRow.calls_24h || 0);
    const failed24h = Number(callRow.failed_24h || 0);

    return sendSuccess(
      res,
      {
        totalKeys: Number(summaryRow.total_keys || 0),
        activeKeys: Number(summaryRow.active_keys || 0),
        expiredKeys: Number(summaryRow.expired_keys || 0),
        disabledKeys: Number(summaryRow.disabled_keys || 0),
        totalLogs: Number(callRow.total_logs || 0),
        callsIn24h: calls24h,
        failedCalls: failed24h,
        successRate24h: calls24h ? Number((((calls24h - failed24h) / calls24h) * 100).toFixed(1)) : 100,
        topKeys: topRows.map((row) => ({
          id: Number(row.id),
          name: row.name || "",
          keyPrefix: row.key_prefix || "",
          callCount: Number(row.call_count || 0),
          lastCalledAt: row.last_called_at || null,
        })),
        trend,
        topPaths: pathRows.map((row) => ({
          requestPath: row.request_path || "",
          callCount: Number(row.call_count || 0),
          failedCount: Number(row.failed_count || 0),
          lastCalledAt: row.last_called_at || null,
        })),
      },
      "获取 API Key 统计成功",
    );
  } catch (error) {
    next(error);
  }
}

async function getApiKeyLogs(req, res, next) {
  try {
    await ensureApiKeyTable();
    await ensureApiKeyLogTable();

    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "API Key ID 无效", 400);
    }

    const { pageNum, pageSize, offset } = normalizePage(req.query);
    const failedOnly = String(req.query.failedOnly || "").trim();
    const method = String(req.query.method || "").trim().toUpperCase();
    const keyword = String(req.query.keyword || "").trim();

    const [[existsRow]] = await pool.query(
      `SELECT k.id, k.name, u.store_id
       FROM external_api_keys k
       INNER JOIN users u ON u.id = k.user_id
       WHERE k.id = ? LIMIT 1`,
      [id],
    );

    if (!existsRow) {
      return sendFail(res, "API Key 不存在", 404);
    }

    if (!canManageApiKeyTarget(req.user, existsRow)) {
      return sendFail(res, "无权限查看该 API Key 日志", 403);
    }

    const where = ["api_key_id = ?"];
    const logParams = [id];
    if (failedOnly === "1") where.push("status_code >= 400");
    if (method) {
      where.push("request_method = ?");
      logParams.push(method);
    }
    if (keyword) {
      where.push("request_path LIKE ?");
      logParams.push(`%${keyword}%`);
    }
    const whereSql = `WHERE ${where.join(" AND ")}`;

    const [[countRow]] = await pool.query(
      `SELECT COUNT(*) AS total FROM external_api_key_logs ${whereSql}`,
      logParams,
    );
    const [rows] = await pool.query(
      `
        SELECT
          id,
          api_key_id,
          user_id,
          request_method,
          request_path,
          status_code,
          duration_ms,
          ip,
          created_at
        FROM external_api_key_logs
        ${whereSql}
        ORDER BY created_at DESC, id DESC
        LIMIT ? OFFSET ?
      `,
      [...logParams, pageSize, offset],
    );

    return sendPage(
      res,
      rows.map(formatApiKeyLog),
      Number(countRow.total || 0),
      pageNum,
      pageSize,
    );
  } catch (error) {
    next(error);
  }
}

async function getApiKeyList(req, res, next) {
  try {
    await ensureApiKeyTable();

    const { pageNum, pageSize, offset } = normalizePage(req.query);
    const keyword = String(req.query.keyword || "").trim();
    const status = String(req.query.status || "").trim();

    const where = [];
    const params = [];

    if (Number(req.user.role) !== 1) {
      where.push("u.store_id = ?");
      params.push(Number(req.user.storeId || 0));
    }

    if (keyword) {
      where.push("(k.name LIKE ? OR u.username LIKE ? OR u.real_name LIKE ?)");
      params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
    }

    if (status !== "") {
      where.push("k.status = ?");
      params.push(Number(status));
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const countSql = `
      SELECT COUNT(*) AS total
      FROM external_api_keys k
      INNER JOIN users u ON u.id = k.user_id
      ${whereSql}
    `;

    const listSql = `
      SELECT
        k.*,
        u.username,
        u.real_name,
        u.role,
        u.store_id,
        u.status AS user_status,
        s.store_name,
        COALESCE(a.call_count, 0) AS call_count,
        COALESCE(a.failed_count, 0) AS failed_count,
        CASE u.role
          WHEN 1 THEN '超级管理员'
          WHEN 2 THEN '门店店长'
          WHEN 3 THEN '门店店员'
          WHEN 4 THEN '门店老板'
          ELSE '未知角色'
        END AS role_label
      FROM external_api_keys k
      INNER JOIN users u ON u.id = k.user_id
      LEFT JOIN stores s ON s.id = u.store_id
      LEFT JOIN (
        SELECT api_key_id, COUNT(*) AS call_count, SUM(status_code >= 400) AS failed_count
        FROM external_api_key_logs
        GROUP BY api_key_id
      ) a ON a.api_key_id = k.id
      ${whereSql}
      ORDER BY k.id DESC
      LIMIT ? OFFSET ?
    `;

    const [[countRow]] = await pool.query(countSql, params);
    const [rows] = await pool.query(listSql, [...params, pageSize, offset]);

    return sendPage(
      res,
      rows.map(formatApiKey),
      Number(countRow.total || 0),
      pageNum,
      pageSize,
    );
  } catch (error) {
    next(error);
  }
}

async function createApiKey(req, res, next) {
  try {
    await ensureApiKeyTable();

    const name = String(req.body.name || "").trim();
    const userId = toInt(req.body.userId, 0);
    const remark = String(req.body.remark || "").trim();
    const expiresAt = parseExpiry(req.body.expiresAt);
    const scopes = parseRequestedScopes(req.body.scopes);
    const status = parseStatus(req.body.status, 1);

    if (!name) {
      return sendFail(res, "请输入密钥名称", 400);
    }
    if (name.length > 100 || remark.length > 255) {
      return sendFail(res, "名称不能超过 100 字，备注不能超过 255 字", 400);
    }

    if (!userId) {
      return sendFail(res, "请选择绑定用户", 400);
    }

    const [userRows] = await pool.query(
      `
        SELECT u.id, u.username, u.real_name, u.role, u.store_id, u.status, s.store_name
        FROM users u
        LEFT JOIN stores s ON s.id = u.store_id
        WHERE u.id = ?
        LIMIT 1
      `,
      [userId],
    );

    const user = userRows[0];
    if (!user) {
      return sendFail(res, "绑定用户不存在", 404);
    }

    if (!canManageApiKeyTarget(req.user, user)) {
      return sendFail(res, "无权限为该用户创建 API Key", 403);
    }

    if (Number(user.status) !== 1) {
      return sendFail(res, "绑定用户已停用，不能创建 API Key", 400);
    }

    const rawKey = generateRawApiKey();
    const [result] = await pool.execute(
      `
        INSERT INTO external_api_keys
        (name, key_prefix, key_hash, user_id, scopes, status, expires_at, remark, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        name,
        getKeyPrefix(rawKey),
        hashApiKey(rawKey),
        userId,
        serializeScopes(scopes),
        status,
        expiresAt || null,
        remark || null,
        req.user.userId,
      ],
    );

    await writeOperationLog(req, {
      module: "api_key",
      action: "create",
      bizType: "external_api_key",
      bizId: result.insertId,
      content: `创建外部API Key：${name}，绑定用户：${user.username}`,
    });

    const [rows] = await pool.query(
      `
        SELECT
          k.*,
          u.username,
          u.real_name,
          u.role,
          u.store_id,
          u.status AS user_status,
          s.store_name,
          CASE u.role
            WHEN 1 THEN '超级管理员'
            WHEN 2 THEN '门店店长'
          WHEN 3 THEN '门店店员'
          WHEN 4 THEN '门店老板'
            ELSE '未知角色'
          END AS role_label
        FROM external_api_keys k
        INNER JOIN users u ON u.id = k.user_id
        LEFT JOIN stores s ON s.id = u.store_id
        WHERE k.id = ?
        LIMIT 1
      `,
      [result.insertId],
    );

    return sendSuccess(
      res,
      {
        apiKey: rawKey,
        item: formatApiKey(rows[0]),
      },
      "API Key 创建成功",
    );
  } catch (error) {
    next(error);
  }
}

async function updateApiKey(req, res, next) {
  try {
    await ensureApiKeyTable();

    const id = toInt(req.params.id, 0);
    const name = String(req.body.name || "").trim();
    const remark = String(req.body.remark || "").trim();
    const expiresAt = parseExpiry(req.body.expiresAt);
    const scopes = parseRequestedScopes(req.body.scopes);

    if (!id) {
      return sendFail(res, "API Key ID 无效", 400);
    }

    const [existsRows] = await pool.query(
      "SELECT k.id, k.name, k.status, u.store_id FROM external_api_keys k INNER JOIN users u ON u.id = k.user_id WHERE k.id = ? LIMIT 1",
      [id],
    );

    const existing = existsRows[0];
    if (!existing) {
      return sendFail(res, "API Key 不存在", 404);
    }

    if (!canManageApiKeyTarget(req.user, existing)) {
      return sendFail(res, "无权限修改该 API Key", 403);
    }
    if (name.length > 100 || remark.length > 255) {
      return sendFail(res, "名称不能超过 100 字，备注不能超过 255 字", 400);
    }
    const status = parseStatus(req.body.status, Number(existing.status));

    await pool.execute(
      `
        UPDATE external_api_keys
        SET
          name = ?,
          scopes = ?,
          status = ?,
          expires_at = ?,
          remark = ?
        WHERE id = ?
      `,
      [
        name || existing.name,
        serializeScopes(scopes),
        status,
        expiresAt || null,
        remark || null,
        id,
      ],
    );

    await writeOperationLog(req, {
      module: "api_key",
      action: "update",
      bizType: "external_api_key",
      bizId: id,
      content: `更新外部API Key：${name || existing.name}`,
    });

    return sendSuccess(res, null, "API Key 更新成功");
  } catch (error) {
    next(error);
  }
}

async function updateApiKeyStatus(req, res, next) {
  try {
    await ensureApiKeyTable();

    const id = toInt(req.params.id, 0);
    const status = toInt(req.body.status, -1);

    if (!id) {
      return sendFail(res, "API Key ID 无效", 400);
    }

    if (![0, 1].includes(status)) {
      return sendFail(res, "状态值无效", 400);
    }

    const [existsRows] = await pool.query(
      "SELECT k.id, k.name, u.store_id FROM external_api_keys k INNER JOIN users u ON u.id = k.user_id WHERE k.id = ? LIMIT 1",
      [id],
    );
    const existing = existsRows[0];
    if (!existing) {
      return sendFail(res, "API Key 不存在", 404);
    }

    if (!canManageApiKeyTarget(req.user, existing)) {
      return sendFail(res, "无权限修改该 API Key 状态", 403);
    }

    await pool.execute(
      "UPDATE external_api_keys SET status = ? WHERE id = ?",
      [status, id],
    );

    await writeOperationLog(req, {
      module: "api_key",
      action: "update_status",
      bizType: "external_api_key",
      bizId: id,
      content: `${status === 1 ? "启用" : "停用"}外部API Key：${existing.name}`,
    });

    return sendSuccess(res, null, "API Key 状态更新成功");
  } catch (error) {
    next(error);
  }
}

async function rotateApiKey(req, res, next) {
  try {
    await ensureApiKeyTable();

    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "API Key ID 无效", 400);
    }

    const [existsRows] = await pool.query(
      "SELECT k.id, k.name, u.store_id FROM external_api_keys k INNER JOIN users u ON u.id = k.user_id WHERE k.id = ? LIMIT 1",
      [id],
    );
    const existing = existsRows[0];
    if (!existing) {
      return sendFail(res, "API Key 不存在", 404);
    }

    if (!canManageApiKeyTarget(req.user, existing)) {
      return sendFail(res, "无权限轮换该 API Key", 403);
    }

    const rawKey = generateRawApiKey();
    await pool.execute(
      `
        UPDATE external_api_keys
        SET key_prefix = ?, key_hash = ?, last_used_at = NULL, last_used_ip = NULL
        WHERE id = ?
      `,
      [getKeyPrefix(rawKey), hashApiKey(rawKey), id],
    );

    await writeOperationLog(req, {
      module: "api_key",
      action: "rotate",
      bizType: "external_api_key",
      bizId: id,
      content: `重置外部API Key：${existing.name}`,
    });

    return sendSuccess(
      res,
      { apiKey: rawKey },
      "API Key 已重新生成",
    );
  } catch (error) {
    next(error);
  }
}

async function deleteApiKey(req, res, next) {
  try {
    await ensureApiKeyTable();

    const id = toInt(req.params.id, 0);
    if (!id) {
      return sendFail(res, "API Key ID 无效", 400);
    }

    const [existsRows] = await pool.query(
      "SELECT k.id, k.name, u.store_id FROM external_api_keys k INNER JOIN users u ON u.id = k.user_id WHERE k.id = ? LIMIT 1",
      [id],
    );
    const existing = existsRows[0];
    if (!existing) {
      return sendFail(res, "API Key 不存在", 404);
    }

    if (!canManageApiKeyTarget(req.user, existing)) {
      return sendFail(res, "无权限删除该 API Key", 403);
    }

    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      await connection.execute("DELETE FROM external_api_key_logs WHERE api_key_id = ?", [id]);
      await connection.execute("DELETE FROM external_api_keys WHERE id = ?", [id]);
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }

    await writeOperationLog(req, {
      module: "api_key",
      action: "delete",
      bizType: "external_api_key",
      bizId: id,
      content: `删除外部API Key：${existing.name}`,
    });

    return sendSuccess(res, null, "API Key 删除成功");
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getApiKeyMeta,
  getApiKeyStats,
  getApiKeyList,
  getApiKeyLogs,
  createApiKey,
  updateApiKey,
  updateApiKeyStatus,
  rotateApiKey,
  deleteApiKey,
};
