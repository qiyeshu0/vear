const { pool } = require("../config/db");
const { sendSuccess, sendFail } = require("../utils/response");
const { formatDateYmd } = require("../utils/date");
const { CUSTOMER_STATUS, DEFAULT_PAGE } = require("../config/constants");
const { buildStoreScope } = require("../middleware/auth");
const { toCamelCase } = require("../utils/case");
const { writeOperationLog } = require("../utils/operation-log");
const { createTables } = require("../install/schema");
const { toInt, normalizePage } = require("../utils/pagination");
const { notifyVerifySuccess, notifyLowTimes, notifyVerifySuccessWx } = require("../services/notification.service");
const {
  getCustomerCardsMap,
  getActiveCustomerCards,
  syncCustomerCardSnapshot,
} = require("../utils/customer-card");
const { syncVisitFromVerification } = require("../services/visit.service");

let verifySchemaPromise = null;

function ensureVerifySchema() {
  if (!verifySchemaPromise) {
    verifySchemaPromise = createTables(pool).catch((error) => {
      verifySchemaPromise = null;
      throw error;
    });
  }

  return verifySchemaPromise;
}

function getTodayDate() {
  const now = new Date();
  const year = now.getFullYear();
  const month = `${now.getMonth() + 1}`.padStart(2, "0");
  const day = `${now.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatDateTime(date = new Date()) {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  const hour = `${date.getHours()}`.padStart(2, "0");
  const minute = `${date.getMinutes()}`.padStart(2, "0");
  const second = `${date.getSeconds()}`.padStart(2, "0");
  return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
}

function generateVerifyNo() {
  const now = new Date();
  const y = now.getFullYear();
  const m = `${now.getMonth() + 1}`.padStart(2, "0");
  const d = `${now.getDate()}`.padStart(2, "0");
  const h = `${now.getHours()}`.padStart(2, "0");
  const i = `${now.getMinutes()}`.padStart(2, "0");
  const s = `${now.getSeconds()}`.padStart(2, "0");
  const ms = `${now.getMilliseconds()}`.padStart(3, "0");
  const random = `${Math.floor(Math.random() * 90000) + 10000}`;
  return `HX${y}${m}${d}${h}${i}${s}${ms}${random}`;
}

async function createVerifyRecordWithRetry(
  connection,
  payload,
  maxRetries = 3,
) {
  let lastError = null;

  for (let attempt = 0; attempt < maxRetries; attempt += 1) {
    const verifyNo = generateVerifyNo();

    try {
      const [insertResult] = await connection.execute(
        `
          INSERT INTO verify_records
          (verify_no, customer_id, customer_card_id, store_id, child_name, training_project, card_name, card_sale_price, verify_date, verify_time, operator_id, operator_name, remark)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [
          verifyNo,
          payload.customerId,
          payload.customerCardId || null,
          payload.storeId,
          payload.childName,
          payload.trainingProject,
          payload.cardName || null,
          payload.cardSalePrice ?? null,
          payload.verifyDate,
          payload.verifyTime,
          payload.operatorId,
          payload.operatorName,
          payload.remark,
        ],
      );

      return {
        verifyNo,
        insertResult,
      };
    } catch (error) {
      const isDuplicateVerifyNo =
        error &&
        (error.code === "ER_DUP_ENTRY" ||
          error.errno === 1062 ||
          String(error.message || "").includes("Duplicate entry"));

      if (!isDuplicateVerifyNo) {
        throw error;
      }

      lastError = error;
    }
  }

  throw lastError || new Error("生成核销单号失败，请稍后重试");
}



async function getVerifyCustomerOptions(req, res, next) {
  try {
    await ensureVerifySchema();
    const keyword = String(req.query.keyword || "").trim();
    const scope = buildStoreScope(req.user, "c.store_id");
    const { pageNum, pageSize, offset } = normalizePage(req.query);

    const where = [
      scope.sql,
      "c.status = ?",
      "c.has_card = 1",
      "c.remaining_times > 0",
      "c.expire_date >= CURDATE()",
    ];
    const params = [...scope.params, CUSTOMER_STATUS.ENABLED];

    if (keyword) {
      where.push(
        "(c.child_name LIKE ? OR c.parent_phone LIKE ? OR c.training_project LIKE ?)",
      );
      params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
    }

    const [rows] = await pool.query(
      `
        SELECT
          c.id,
          c.child_name,
          c.parent_name,
          c.parent_phone,
          c.has_card,
          c.training_project,
          c.total_times,
          c.used_times,
          c.remaining_times,
          c.open_card_date,
          c.expire_date,
          c.store_id,
          s.store_name
        FROM customers c
        LEFT JOIN stores s ON s.id = c.store_id
        WHERE ${where.join(" AND ")}
        ORDER BY c.child_name ASC, c.id DESC
        LIMIT ? OFFSET ?
      `,
      [...params, pageSize + 1, offset],
    );

    const hasMore = rows.length > pageSize;
    const list = rows.slice(0, pageSize);

    const cardMap = await getCustomerCardsMap(pool, list.map((item) => item.id), {
      activeOnly: true,
    });

    return sendSuccess(
      res,
      {
        list: toCamelCase(list).map((item) => {
          const cards = (cardMap.get(Number(item.id || 0)) || []).filter(
            (card) => !card.isPromotion,
          );
          return {
            ...item,
            activeCards: cards,
            currentCard: cards[0] || null,
          };
        }),
        pageNum,
        pageSize,
        hasMore,
      },
      "获取可核销客户成功",
    );
  } catch (error) {
    return next(error);
  }
}

async function getTodayVerifyRecords(req, res, next) {
  try {
    await ensureVerifySchema();
    const scope = buildStoreScope(req.user, "vr.store_id");
    const today = getTodayDate();

    const [rows] = await pool.query(
      `
        SELECT
          vr.id,
          vr.verify_no,
          vr.customer_id,
          vr.store_id,
          s.store_name,
          vr.child_name,
          vr.training_project,
          vr.card_name,
          vr.card_sale_price,
          vr.verify_date,
          vr.verify_time,
          vr.operator_id,
          vr.operator_name,
          vr.remark,
          vr.created_at
        FROM verify_records vr
        LEFT JOIN stores s ON s.id = vr.store_id
        WHERE vr.verify_date = ?
          AND vr.revoked = 0
          AND ${scope.sql}
        ORDER BY vr.verify_time DESC, vr.id DESC
      `,
      [today, ...scope.params],
    );

    return sendSuccess(
      res,
      {
        date: today,
        list: toCamelCase(rows),
      },
      "获取今日核销记录成功",
    );
  } catch (error) {
    return next(error);
  }
}

async function createVerifyRecord(req, res, next) {
  await ensureVerifySchema();
  const connection = await pool.getConnection();

  try {
    const customerId = Number(req.body.customerId || req.body.customer_id || 0);
    const customerCardId = Number(
      req.body.customerCardId || req.body.customer_card_id || 0,
    );
    const remark = String(req.body.remark || "").trim();
    const visitId = Number(req.body.visitId || req.body.visit_id || 0);
    const user = req.user;

    if (!customerId) {
      connection.release();
      return sendFail(res, "请选择要核销的客户", 400, {
        errorCode: "MISSING_CUSTOMER",
      });
    }

    await connection.beginTransaction();

    const customerScope = buildStoreScope(user, "c.store_id");

    const [customerRows] = await connection.query(
      `
        SELECT
          c.id,
          c.child_name,
          c.parent_name,
          c.parent_phone,
          c.has_card,
          c.training_project,
          c.total_times,
          c.used_times,
          c.remaining_times,
          c.open_card_date,
          c.expire_date,
          c.status,
          c.store_id,
          s.store_name
        FROM customers c
        LEFT JOIN stores s ON s.id = c.store_id
        WHERE c.id = ?
          AND ${customerScope.sql}
        LIMIT 1
        FOR UPDATE
      `,
      [customerId, ...customerScope.params],
    );

    const customer = customerRows[0];

    if (!customer) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404, {
        errorCode: "CUSTOMER_NOT_FOUND",
      });
    }

    if (Number(customer.status) !== CUSTOMER_STATUS.ENABLED) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户已停用，无法核销", 400, {
        errorCode: "CUSTOMER_DISABLED",
      });
    }

    if (Number(customer.has_card || 0) !== 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户尚未开卡，无法核销", 400, {
        errorCode: "CUSTOMER_NO_CARD",
      });
    }

    const activeCards = await getActiveCustomerCards(connection, customer.id);
    const selectedCard =
      activeCards.find((item) => item.id === customerCardId) ||
      (!customerCardId && activeCards.length === 1 ? activeCards[0] : null);

    if (activeCards.length > 1 && !selectedCard) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户有多张有效卡，请先选择核销卡项", 400, {
        errorCode: "REQUIRE_CARD_SELECTION",
      });
    }

    const effectiveRemainingTimes = selectedCard
      ? selectedCard.remainingTimes
      : Number(customer.remaining_times);
    const effectiveExpireDate = selectedCard
      ? selectedCard.expireDate
      : formatDateYmd(customer.expire_date);
    const effectiveTrainingProject = selectedCard
      ? selectedCard.trainingProject
      : customer.training_project;

    if (effectiveRemainingTimes <= 0) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户剩余次数不足，无法核销", 400, {
        errorCode: "NO_REMAINING",
      });
    }

    if (!effectiveExpireDate) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "客户到期日期无效，无法核销", 400, {
        errorCode: "INVALID_EXPIRE_DATE",
      });
    }

    if (effectiveExpireDate < getTodayDate()) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户已过期，无法核销", 400, {
        errorCode: "CUSTOMER_EXPIRED",
      });
    }

    const verifyDate = getTodayDate();
    const verifyTime = formatDateTime(new Date());

    const { verifyNo, insertResult } = await createVerifyRecordWithRetry(
      connection,
      {
        customerId: customer.id,
        customerCardId: selectedCard?.id || null,
        storeId: customer.store_id,
        childName: customer.child_name,
        trainingProject: effectiveTrainingProject,
        cardName: selectedCard?.cardName || null,
        cardSalePrice: selectedCard?.salePrice ?? null,
        verifyDate,
        verifyTime,
        operatorId: user.userId,
        operatorName: user.realName,
        remark: remark || null,
      },
    );

    let updateResult;
    if (selectedCard) {
      const [cardUpdateResult] = await connection.execute(
        `
          UPDATE customer_cards
          SET used_times = used_times + 1,
              updated_by = ?
          WHERE id = ?
            AND customer_id = ?
            AND status = 1
            AND COALESCE(is_promotion, 0) = 0
            AND remaining_times > 0
        `,
        [user.userId, selectedCard.id, customer.id],
      );
      updateResult = cardUpdateResult;
      await syncCustomerCardSnapshot(connection, customer.id, user.userId);
    } else {
      const [customerUpdateResult] = await connection.execute(
        `
          UPDATE customers
          SET used_times = used_times + 1,
              updated_by = ?
          WHERE id = ?
            AND remaining_times > 0
        `,
        [user.userId, customer.id],
      );
      updateResult = customerUpdateResult;
    }

    if (Number(updateResult.affectedRows || 0) !== 1) {
      await connection.rollback();
      connection.release();
      return sendFail(
        res,
        "核销失败，客户剩余次数已变化，请刷新后重试",
        409,
        {
          errorCode: "REMAINING_CHANGED",
        },
      );
    }

    const visitSync = await syncVisitFromVerification(connection, {
      visitId,
      verifyRecordId: Number(insertResult.insertId),
      customerId: Number(customer.id),
      storeId: Number(customer.store_id),
      customerName: customer.child_name,
      customerPhone: customer.parent_phone,
      trainingProject: effectiveTrainingProject,
      verifyTime,
      operatorId: user.userId,
      operatorName: user.realName,
      remark,
      source: "verify",
    });

    await writeOperationLog(connection, {
      operatorId: user.userId,
      operatorName: user.realName,
      operatorRole: user.role,
      storeId: customer.store_id,
      module: "verify",
      action: "verify",
      bizType: "verify_record",
      bizId: insertResult.insertId,
      bizNo: verifyNo,
      content: `核销成功：客户【${customer.child_name}】项目【${effectiveTrainingProject}】${selectedCard ? `卡项【${selectedCard.cardName}】` : ""}单号【${verifyNo}】`,
      ip: req.ip || "",
      userAgent: String(req.headers["user-agent"] || "").slice(0, 500),
    });

    await connection.commit();

    const [recordRows] = await pool.query(
      `
        SELECT
          vr.id,
          vr.verify_no,
          vr.customer_id,
          vr.store_id,
          s.store_name,
          vr.child_name,
          vr.training_project,
          vr.card_name,
          vr.card_sale_price,
          vr.verify_date,
          vr.verify_time,
          vr.revoked,
          vr.revoked_at,
          vr.revoked_by_name,
          vr.revoke_reason,
          vr.operator_id,
          vr.operator_name,
          vr.remark,
          vr.created_at
        FROM verify_records vr
        LEFT JOIN stores s ON s.id = vr.store_id
        WHERE vr.id = ?
        LIMIT 1
      `,
      [insertResult.insertId],
    );

    const [customerRowsAfter] = await pool.query(
      `
        SELECT
          id,
          child_name,
          total_times,
          used_times,
          remaining_times,
          expire_date,
          store_id
        FROM customers
        WHERE id = ?
        LIMIT 1
      `,
      [customer.id],
    );

    connection.release();

    // 异步发送通知（不阻塞响应）
    const remainingAfterVerify = Number(customerRowsAfter[0]?.remaining_times ?? 0);
    const notifyCustomer = {
      id: customer.id,
      childName: customer.child_name,
      parentPhone: customer.parent_phone,
      trainingProject: effectiveTrainingProject,
      remainingTimes: remainingAfterVerify,
    };
    notifyVerifySuccess(notifyCustomer, verifyNo).catch(() => {});

    // 微信订阅消息（不需要手机号，通过 openid 推送）
    const wxNow = new Date();
    const verifyTimeStr = `${wxNow.getHours().toString().padStart(2, "0")}:${wxNow.getMinutes().toString().padStart(2, "0")}`;
    notifyVerifySuccessWx(notifyCustomer, verifyNo, verifyTimeStr).catch(() => {});

    // 剩余次数不足提醒
    if (remainingAfterVerify > 0 && remainingAfterVerify <= 5) {
      notifyLowTimes(notifyCustomer).catch(() => {});
    }

    return sendSuccess(
      res,
      {
        verifyNo,
        visitId: visitSync.visitId,
        record: toCamelCase(recordRows[0]) || null,
        customer: toCamelCase(customerRowsAfter[0]) || null,
      },
      "核销成功",
    );
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore rollback error
    }
    connection.release();
    return next(error);
  }
}

module.exports = {
  getVerifyCustomerOptions,
  getTodayVerifyRecords,
  createVerifyRecord,
};
