const { pool } = require("../config/db");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { ROLE_ADMIN } = require("../config/constants");
const { writeOperationLog } = require("../utils/operation-log");
const { createTables } = require("../install/schema");
const { toInt } = require("../utils/pagination");
const {
  formatCardTemplate,
  priceOptionsToDbString,
} = require("../utils/customer-card");

let cardTemplateSchemaPromise = null;

function ensureCardTemplateSchema() {
  if (!cardTemplateSchemaPromise) {
    cardTemplateSchemaPromise = createTables(pool).catch((error) => {
      cardTemplateSchemaPromise = null;
      throw error;
    });
  }

  return cardTemplateSchemaPromise;
}


async function getCardTemplateOptions(req, res, next) {
  try {
    await ensureCardTemplateSchema();
    const includeDisabled = String(req.query.includeDisabled || "") === "1";
    const where = includeDisabled ? "" : "WHERE status = 1";
    const [rows] = await pool.query(
      `
        SELECT *
        FROM card_templates
        ${where}
        ORDER BY card_name ASC
      `,
    );

    return sendSuccess(
      res,
      rows.map(formatCardTemplate),
      "获取卡项模板成功",
    );
  } catch (error) {
    next(error);
  }
}

async function getCardTemplateList(req, res, next) {
  try {
    await ensureCardTemplateSchema();
    const pageNum = Math.max(toInt(req.query.pageNum, 1), 1);
    const pageSize = Math.min(Math.max(toInt(req.query.pageSize, 10), 1), 100);
    const offset = (pageNum - 1) * pageSize;
    const keyword = String(req.query.keyword || "").trim();
    const statusRaw = req.query.status;
    const status = statusRaw === "" || statusRaw == null ? null : toInt(statusRaw, -1);

    const where = [];
    const params = [];

    if (keyword) {
      where.push("(card_name LIKE ? OR training_project LIKE ? OR remark LIKE ?)");
      params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
    }

    if (status !== null && status !== -1) {
      where.push("status = ?");
      params.push(status);
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const [rows] = await pool.query(
      `
        SELECT *
        FROM card_templates
        ${whereSql}
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?
      `,
      [...params, pageSize, offset],
    );

    const [[countRow]] = await pool.query(
      `SELECT COUNT(*) AS total FROM card_templates ${whereSql}`,
      params,
    );

    return sendPage(
      res,
      rows.map(formatCardTemplate),
      Number(countRow.total || 0),
      pageNum,
      pageSize,
    );
  } catch (error) {
    next(error);
  }
}

async function createCardTemplate(req, res, next) {
  try {
    await ensureCardTemplateSchema();

    const cardName = String(req.body.cardName || "").trim();
    const trainingProject = String(req.body.trainingProject || "").trim();
    const defaultTimes = toInt(req.body.defaultTimes, 0);
    const priceOptions = priceOptionsToDbString(req.body.priceOptions);
    const isPromotion = Number(req.body.isPromotion || 0) === 1 ? 1 : 0;
    const remark = String(req.body.remark || "").trim();

    if (!cardName) {
      return sendFail(res, "请输入卡项名称", 400);
    }
    if (defaultTimes <= 0) {
      return sendFail(res, "默认次数必须大于0", 400);
    }

    const [exists] = await pool.execute(
      "SELECT id FROM card_templates WHERE card_name = ? LIMIT 1",
      [cardName],
    );
    if (exists.length) {
      return sendFail(res, "卡项名称已存在", 400);
    }

    const [result] = await pool.execute(
      `
        INSERT INTO card_templates
        (card_name, training_project, default_times, price_options, is_promotion, status, remark, created_by, updated_by)
        VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)
      `,
      [
        cardName,
        trainingProject,
        defaultTimes,
        priceOptions || null,
        isPromotion,
        remark || null,
        req.user.userId,
        req.user.userId,
      ],
    );

    await writeOperationLog(req, {
      module: "system",
      action: "create",
      bizType: "card_template",
      bizId: result.insertId,
      bizNo: cardName,
      content: `新增卡项模板：${cardName}`,
    });

    return sendSuccess(res, { id: result.insertId }, "新增卡项模板成功");
  } catch (error) {
    next(error);
  }
}

async function updateCardTemplate(req, res, next) {
  try {
    await ensureCardTemplateSchema();

    const id = toInt(req.params.id, 0);
    const cardName = String(req.body.cardName || "").trim();
    const trainingProject = String(req.body.trainingProject || "").trim();
    const defaultTimes = toInt(req.body.defaultTimes, 0);
    const priceOptions = priceOptionsToDbString(req.body.priceOptions);
    const isPromotion = Number(req.body.isPromotion || 0) === 1 ? 1 : 0;
    const remark = String(req.body.remark || "").trim();

    if (!id) return sendFail(res, "卡项模板ID无效", 400);
    if (!cardName) return sendFail(res, "请输入卡项名称", 400);
    if (defaultTimes <= 0) return sendFail(res, "默认次数必须大于0", 400);

    const [exists] = await pool.execute(
      "SELECT id FROM card_templates WHERE card_name = ? AND id <> ? LIMIT 1",
      [cardName, id],
    );
    if (exists.length) {
      return sendFail(res, "卡项名称已存在", 400);
    }

    await pool.execute(
      `
        UPDATE card_templates
        SET
          card_name = ?,
          training_project = ?,
          default_times = ?,
          price_options = ?,
          is_promotion = ?,
          remark = ?,
          updated_by = ?
        WHERE id = ?
      `,
      [
        cardName,
        trainingProject,
        defaultTimes,
        priceOptions || null,
        isPromotion,
        remark || null,
        req.user.userId,
        id,
      ],
    );

    await writeOperationLog(req, {
      module: "system",
      action: "update",
      bizType: "card_template",
      bizId: id,
      bizNo: cardName,
      content: `编辑卡项模板：${cardName}`,
    });

    return sendSuccess(res, null, "更新卡项模板成功");
  } catch (error) {
    next(error);
  }
}

async function updateCardTemplateStatus(req, res, next) {
  try {
    await ensureCardTemplateSchema();

    const id = toInt(req.params.id, 0);
    const status = toInt(req.body.status, -1);
    if (!id) return sendFail(res, "卡项模板ID无效", 400);
    if (![0, 1].includes(status)) return sendFail(res, "状态值无效", 400);

    const [rows] = await pool.execute(
      "SELECT card_name FROM card_templates WHERE id = ? LIMIT 1",
      [id],
    );
    if (!rows.length) {
      return sendFail(res, "卡项模板不存在", 404);
    }

    await pool.execute(
      "UPDATE card_templates SET status = ?, updated_by = ? WHERE id = ?",
      [status, req.user.userId, id],
    );

    await writeOperationLog(req, {
      module: "system",
      action: "update_status",
      bizType: "card_template",
      bizId: id,
      bizNo: rows[0].card_name,
      content: `${status === 1 ? "启用" : "停用"}卡项模板：${rows[0].card_name}`,
    });

    return sendSuccess(res, null, "更新卡项模板状态成功");
  } catch (error) {
    next(error);
  }
}

async function deleteCardTemplate(req, res, next) {
  try {
    await ensureCardTemplateSchema();

    const id = toInt(req.params.id, 0);
    if (!id) return sendFail(res, "卡项模板ID无效", 400);

    const [rows] = await pool.execute(
      "SELECT card_name FROM card_templates WHERE id = ? LIMIT 1",
      [id],
    );
    const template = rows[0];
    if (!template) return sendFail(res, "卡项模板不存在", 404);

    const [countRows] = await pool.execute(
      "SELECT COUNT(*) AS total FROM customer_cards WHERE card_template_id = ?",
      [id],
    );
    if (Number(countRows[0].total || 0) > 0) {
      return sendFail(res, "已有客户使用该卡项模板，不能删除", 400);
    }

    await pool.execute("DELETE FROM card_templates WHERE id = ?", [id]);

    await writeOperationLog(req, {
      module: "system",
      action: "delete",
      bizType: "card_template",
      bizId: id,
      bizNo: template.card_name,
      content: `删除卡项模板：${template.card_name}`,
    });

    return sendSuccess(res, null, "删除卡项模板成功");
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getCardTemplateOptions,
  getCardTemplateList,
  createCardTemplate,
  updateCardTemplate,
  updateCardTemplateStatus,
  deleteCardTemplate,
};
