const rateLimit = require("express-rate-limit");

/**
 * 通用 API 限流：每分钟 600 次（正常使用不会触发）
 */
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 600,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    code: 429,
    success: false,
    message: "请求过于频繁，请稍后再试",
    data: null,
  },
});

/**
 * 登录接口限流：每分钟 30 次（防暴力破解）
 */
const authLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  // 登录成功、刷新成功不计入限制，避免正常使用/自动刷新把自己“锁”在登录页外。
  // 失败请求仍会计数，用来防暴力破解。
  skipSuccessfulRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    code: 429,
    success: false,
    message: "登录尝试过于频繁，请1分钟后再试",
    data: null,
  },
});

/**
 * 安装接口限流：每分钟 60 次（安装向导会频繁轮询状态）
 */
const installLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    code: 429,
    success: false,
    message: "安装请求过于频繁，请稍后再试",
    data: null,
  },
});

/**
 * 注册接口限流：每小时 5 次（防滥用注册）
 */
const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    code: 429,
    success: false,
    message: "注册请求过于频繁，请稍后再试",
    data: null,
  },
});

module.exports = {
  apiLimiter,
  authLimiter,
  installLimiter,
  registerLimiter,
};
