const ROLE_ADMIN = 1;
const ROLE_MANAGER = 2;
const ROLE_STAFF = 3;
const ROLE_OWNER = 4;

const ROLE_MAP = {
  [ROLE_ADMIN]: "超级管理员",
  [ROLE_MANAGER]: "门店店长",
  [ROLE_STAFF]: "门店店员",
  [ROLE_OWNER]: "门店老板"
};

const USER_STATUS = {
  DISABLED: 0,
  ENABLED: 1
};

const USER_STATUS_MAP = {
  [USER_STATUS.DISABLED]: "禁用",
  [USER_STATUS.ENABLED]: "启用"
};

const STORE_STATUS = {
  DISABLED: 0,
  ENABLED: 1
};

const STORE_STATUS_MAP = {
  [STORE_STATUS.DISABLED]: "停用",
  [STORE_STATUS.ENABLED]: "启用"
};

const CUSTOMER_STATUS = {
  DISABLED: 0,
  ENABLED: 1
};

const CUSTOMER_STATUS_MAP = {
  [CUSTOMER_STATUS.DISABLED]: "停用",
  [CUSTOMER_STATUS.ENABLED]: "正常"
};

const GENDER = {
  MALE: 1,
  FEMALE: 2
};

const GENDER_MAP = {
  [GENDER.MALE]: "男",
  [GENDER.FEMALE]: "女"
};

const LOG_MODULE = {
  AUTH: "auth",
  DASHBOARD: "dashboard",
  CUSTOMER: "customer",
  VERIFY: "verify",
  RECORD: "record",
  STORE: "store",
  USER: "user",
  LOG: "log"
};

const LOG_ACTION = {
  LOGIN: "login",
  LOGOUT: "logout",
  CREATE: "create",
  UPDATE: "update",
  DELETE: "delete",
  RENEW: "renew",
  VERIFY: "verify",
  EXPORT: "export",
  QUERY: "query"
};

const VERIFY_RULE = {
  DEFAULT_SOON_EXPIRE_DAYS: 15,
  LOW_REMAINING_TIMES_THRESHOLD: 3
};

const FILE_UPLOAD = {
  ALLOW_EXTENSIONS: ["jpg", "jpeg", "png", "gif", "webp", "pdf"],
  ALLOW_MIME_TYPES: [
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
    "application/pdf"
  ],
  DEFAULT_MAX_SIZE: 10 * 1024 * 1024
};

const DEFAULT_PAGE = {
  PAGE_NUM: 1,
  PAGE_SIZE: 10,
  MAX_PAGE_SIZE: 100
};

module.exports = {
  ROLE_ADMIN,
  ROLE_OWNER,
  ROLE_MANAGER,
  ROLE_STAFF,
  ROLE_MAP,
  USER_STATUS,
  USER_STATUS_MAP,
  STORE_STATUS,
  STORE_STATUS_MAP,
  CUSTOMER_STATUS,
  CUSTOMER_STATUS_MAP,
  GENDER,
  GENDER_MAP,
  LOG_MODULE,
  LOG_ACTION,
  VERIFY_RULE,
  FILE_UPLOAD,
  DEFAULT_PAGE
};
