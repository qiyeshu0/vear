const TABLE_CREATE_SQLS = [
  `
    CREATE TABLE IF NOT EXISTS \`stores\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`store_name\` varchar(100) NOT NULL COMMENT '门店名称',
      \`store_code\` varchar(50) NOT NULL COMMENT '门店编码',
      \`contact_name\` varchar(50) DEFAULT NULL COMMENT '联系人',
      \`contact_phone\` varchar(20) DEFAULT NULL COMMENT '联系电话',
      \`address\` varchar(255) DEFAULT NULL COMMENT '门店地址',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_store_code\` (\`store_code\`),
      KEY \`idx_store_status\` (\`status\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='门店表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`users\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`username\` varchar(50) NOT NULL COMMENT '登录账号',
      \`password_hash\` varchar(255) NOT NULL COMMENT '密码哈希',
      \`real_name\` varchar(50) NOT NULL COMMENT '真实姓名',
      \`role\` tinyint NOT NULL COMMENT '角色：1超级管理员 2店长 3店员',
      \`store_id\` bigint unsigned DEFAULT NULL COMMENT '所属门店ID',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0禁用',
      \`last_login_at\` datetime DEFAULT NULL COMMENT '最后登录时间',
      \`last_login_ip\` varchar(64) DEFAULT NULL COMMENT '最后登录IP',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_user_username\` (\`username\`),
      KEY \`idx_user_store_id\` (\`store_id\`),
      KEY \`idx_user_role\` (\`role\`),
      KEY \`idx_user_status\` (\`status\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表'
  `,

];

module.exports = { TABLE_CREATE_SQLS, createTables: async () => {} };
