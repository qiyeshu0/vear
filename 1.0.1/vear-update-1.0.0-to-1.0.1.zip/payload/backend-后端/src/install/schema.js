const TABLE_CREATE_SQLS = [
  `
    CREATE TABLE IF NOT EXISTS \`stores\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`store_name\` varchar(100) NOT NULL COMMENT '门店名称',
      \`store_code\` varchar(50) NOT NULL COMMENT '门店编码',
      \`contact_name\` varchar(50) DEFAULT NULL COMMENT '联系人',
      \`contact_phone\` varchar(20) DEFAULT NULL COMMENT '联系电话',
      \`address\` varchar(255) DEFAULT NULL COMMENT '门店地址',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_store_code\` (\`store_code\`),
      KEY \`idx_store_status\` (\`status\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='门店表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`users\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`username\` varchar(50) NOT NULL COMMENT '登录账号',
      \`password_hash\` varchar(255) NOT NULL COMMENT '密码哈希',
      \`real_name\` varchar(50) NOT NULL COMMENT '真实姓名',
      \`role\` tinyint NOT NULL COMMENT '角色：1超级管理员 2店长 3店员',
      \`store_id\` bigint unsigned DEFAULT NULL COMMENT '所属门店ID',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0禁用',
      \`last_login_at\` datetime DEFAULT NULL COMMENT '最后登录时间',
      \`last_login_ip\` varchar(64) DEFAULT NULL COMMENT '最后登录IP',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_user_username\` (\`username\`),
      KEY \`idx_user_store_id\` (\`store_id\`),
      KEY \`idx_user_role\` (\`role\`),
      KEY \`idx_user_status\` (\`status\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`user_registrations\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`username\` varchar(50) NOT NULL COMMENT '登录账号',
      \`password_hash\` varchar(255) NOT NULL COMMENT '密码哈希',
      \`real_name\` varchar(50) NOT NULL COMMENT '真实姓名',
      \`phone\` varchar(20) DEFAULT NULL COMMENT '联系电话',
      \`store_id\` bigint unsigned DEFAULT NULL COMMENT '所属门店ID',
      \`role\` tinyint DEFAULT NULL COMMENT '分配角色',
      \`status\` tinyint NOT NULL DEFAULT 0 COMMENT '状态：0待审核 1通过 2拒绝',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`review_note\` varchar(255) DEFAULT NULL COMMENT '审核意见',
      \`reviewed_by\` bigint unsigned DEFAULT NULL COMMENT '审核人ID',
      \`reviewed_at\` datetime DEFAULT NULL COMMENT '审核时间',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_reg_username\` (\`username\`),
      KEY \`idx_reg_status\` (\`status\`),
      KEY \`idx_reg_store_id\` (\`store_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户注册申请表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customers\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_no\` varchar(50) NOT NULL COMMENT '客户编号',
      \`child_name\` varchar(50) NOT NULL COMMENT '孩子姓名',
      \`gender\` tinyint DEFAULT NULL COMMENT '性别：1男 2女',
      \`birthday\` date DEFAULT NULL COMMENT '生日',
      \`parent_name\` varchar(50) DEFAULT NULL COMMENT '家长姓名',
      \`parent_phone\` varchar(20) NOT NULL COMMENT '家长电话',
      \`store_id\` bigint unsigned NOT NULL COMMENT '所属门店ID',
      \`training_project\` varchar(100) NOT NULL COMMENT '训练项目',
      \`total_times\` int NOT NULL DEFAULT 0 COMMENT '总次数',
      \`used_times\` int NOT NULL DEFAULT 0 COMMENT '已使用次数',
      \`remaining_times\` int GENERATED ALWAYS AS ((\`total_times\` - \`used_times\`)) STORED COMMENT '剩余次数',
      \`open_card_date\` date NOT NULL COMMENT '开卡日期',
      \`expire_date\` date DEFAULT NULL COMMENT '到期日期',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1正常 0停用',
      \`remark\` text DEFAULT NULL COMMENT '备注',
      \`tags\` varchar(500) DEFAULT NULL COMMENT '标签，逗号分隔',
      \`created_by\` bigint unsigned DEFAULT NULL COMMENT '创建人ID',
      \`updated_by\` bigint unsigned DEFAULT NULL COMMENT '更新人ID',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_customer_store_id\` (\`store_id\`),
      KEY \`idx_customer_child_name\` (\`child_name\`),
      KEY \`idx_customer_parent_phone\` (\`parent_phone\`),
      KEY \`idx_customer_status\` (\`status\`),
      KEY \`idx_customer_expire_date\` (\`expire_date\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户档案表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`wx_user_bindings\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`wx_openid\` varchar(64) NOT NULL COMMENT '微信openid',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_wx_user_binding\` (\`wx_openid\`, \`customer_id\`),
      KEY \`idx_wx_binding_openid\` (\`wx_openid\`),
      KEY \`idx_wx_binding_customer\` (\`customer_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='微信用户绑定表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_phones\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`phone\` varchar(20) NOT NULL COMMENT '手机号',
      \`relation_name\` varchar(50) DEFAULT NULL COMMENT '关系：父亲/母亲/其他',
      \`is_primary\` tinyint NOT NULL DEFAULT 0 COMMENT '是否主手机号',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_customer_phone\` (\`customer_id\`, \`phone\`),
      KEY \`idx_customer_phone_phone\` (\`phone\`),
      KEY \`idx_customer_phone_customer\` (\`customer_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户手机号绑定表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_attachments\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`file_name\` varchar(255) NOT NULL COMMENT '原始文件名',
      \`file_path\` varchar(500) NOT NULL COMMENT '存储路径',
      \`file_ext\` varchar(20) DEFAULT NULL COMMENT '文件扩展名',
      \`file_size\` bigint unsigned NOT NULL DEFAULT 0 COMMENT '文件大小(字节)',
      \`mime_type\` varchar(100) DEFAULT NULL COMMENT 'MIME类型',
      \`uploaded_by\` bigint unsigned DEFAULT NULL COMMENT '上传人ID',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '上传时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_attach_customer_id\` (\`customer_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户附件表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_eye_profiles\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`naked_vision_od\` varchar(32) DEFAULT NULL COMMENT '裸眼视力右眼OD',
      \`naked_vision_os\` varchar(32) DEFAULT NULL COMMENT '裸眼视力左眼OS',
      \`corrected_vision_od\` varchar(32) DEFAULT NULL COMMENT '戴镜视力右眼OD',
      \`corrected_vision_os\` varchar(32) DEFAULT NULL COMMENT '戴镜视力左眼OS',
      \`pd\` varchar(32) DEFAULT NULL COMMENT '瞳距PD',
      \`old_sphere_od\` varchar(32) DEFAULT NULL COMMENT '原镜球镜右眼OD',
      \`old_cylinder_od\` varchar(32) DEFAULT NULL COMMENT '原镜柱镜右眼OD',
      \`old_axis_od\` varchar(32) DEFAULT NULL COMMENT '原镜轴位右眼OD',
      \`old_sphere_os\` varchar(32) DEFAULT NULL COMMENT '原镜球镜左眼OS',
      \`old_cylinder_os\` varchar(32) DEFAULT NULL COMMENT '原镜柱镜左眼OS',
      \`old_axis_os\` varchar(32) DEFAULT NULL COMMENT '原镜轴位左眼OS',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_customer_eye_profile_customer_id\` (\`customer_id\`),
      KEY \`idx_customer_eye_profile_customer_id\` (\`customer_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户基础眼视光资料表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`training_projects\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`project_name\` varchar(100) NOT NULL COMMENT '项目名称',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`created_by\` bigint unsigned DEFAULT NULL COMMENT '创建人ID',
      \`updated_by\` bigint unsigned DEFAULT NULL COMMENT '更新人ID',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_project_name\` (\`project_name\`),
      KEY \`idx_project_status\` (\`status\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='训练项目表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`card_templates\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`card_name\` varchar(100) NOT NULL COMMENT '卡项名称',
      \`training_project\` varchar(100) NOT NULL COMMENT '适用业务分类',
      \`default_times\` int NOT NULL DEFAULT 1 COMMENT '默认次数',
      \`price_options\` varchar(255) DEFAULT NULL COMMENT '常用价格选项，逗号分隔',
      \`is_promotion\` tinyint NOT NULL DEFAULT 0 COMMENT '是否活动卡：1是 0否',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`created_by\` bigint unsigned DEFAULT NULL COMMENT '创建人ID',
      \`updated_by\` bigint unsigned DEFAULT NULL COMMENT '更新人ID',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_card_template_name\` (\`card_name\`),
      KEY \`idx_card_template_status\` (\`status\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='卡项模板表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_cards\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`card_template_id\` bigint unsigned DEFAULT NULL COMMENT '卡项模板ID',
      \`card_name_snapshot\` varchar(100) NOT NULL COMMENT '卡项名称快照',
      \`training_project\` varchar(100) DEFAULT NULL COMMENT '业务分类快照',
      \`sale_price\` decimal(10,2) DEFAULT NULL COMMENT '实际成交价',
      \`is_promotion\` tinyint NOT NULL DEFAULT 0 COMMENT '是否活动卡：1是 0否',
      \`total_times\` int NOT NULL DEFAULT 0 COMMENT '总次数',
      \`used_times\` int NOT NULL DEFAULT 0 COMMENT '已使用次数',
      \`remaining_times\` int GENERATED ALWAYS AS ((\`total_times\` - \`used_times\`)) STORED COMMENT '剩余次数',
      \`open_card_date\` date NOT NULL COMMENT '开卡日期',
      \`expire_date\` date NOT NULL COMMENT '到期日期',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1有效 0停用',
      \`remark\` varchar(500) DEFAULT NULL COMMENT '备注',
      \`created_by\` bigint unsigned DEFAULT NULL COMMENT '创建人ID',
      \`updated_by\` bigint unsigned DEFAULT NULL COMMENT '更新人ID',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_customer_cards_customer_id\` (\`customer_id\`),
      KEY \`idx_customer_cards_template_id\` (\`card_template_id\`),
      KEY \`idx_customer_cards_status\` (\`status\`),
      KEY \`idx_customer_cards_expire_date\` (\`expire_date\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户持卡记录表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_card_usage_logs\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_card_id\` bigint unsigned NOT NULL COMMENT '客户持卡记录ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`verify_record_id\` bigint unsigned DEFAULT NULL COMMENT '关联核销记录ID',
      \`action_type\` varchar(32) NOT NULL DEFAULT 'consume' COMMENT '动作类型',
      \`quantity\` int NOT NULL DEFAULT 1 COMMENT '本次变更次数',
      \`before_used_times\` int NOT NULL DEFAULT 0 COMMENT '变更前已使用次数',
      \`after_used_times\` int NOT NULL DEFAULT 0 COMMENT '变更后已使用次数',
      \`remark\` varchar(500) DEFAULT NULL COMMENT '备注',
      \`operator_id\` bigint unsigned DEFAULT NULL COMMENT '操作人ID',
      \`operator_name\` varchar(50) DEFAULT NULL COMMENT '操作人姓名',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_customer_card_usage_card_id\` (\`customer_card_id\`),
      KEY \`idx_customer_card_usage_customer_id\` (\`customer_id\`),
      KEY \`idx_customer_card_usage_verify_record_id\` (\`verify_record_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动卡使用记录表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`refund_records\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`customer_card_id\` bigint unsigned DEFAULT NULL COMMENT '客户持卡记录ID',
      \`original_times\` int NOT NULL DEFAULT 0 COMMENT '原总次数',
      \`used_times\` int NOT NULL DEFAULT 0 COMMENT '已用次数',
      \`refund_times\` int NOT NULL DEFAULT 0 COMMENT '退还次数',
      \`refund_amount\` decimal(10,2) DEFAULT NULL COMMENT '退款金额',
      \`reason\` varchar(500) DEFAULT NULL COMMENT '退卡原因',
      \`operator_id\` bigint unsigned DEFAULT NULL COMMENT '操作人ID',
      \`operator_name\` varchar(50) DEFAULT NULL COMMENT '操作人姓名',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_refund_customer_id\` (\`customer_id\`),
      KEY \`idx_refund_card_id\` (\`customer_card_id\`),
      KEY \`idx_refund_created_at\` (\`created_at\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退卡退款记录表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`verify_records\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`verify_no\` varchar(50) NOT NULL COMMENT '核销单号',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`customer_card_id\` bigint unsigned DEFAULT NULL COMMENT '客户持卡记录ID',
      \`store_id\` bigint unsigned NOT NULL COMMENT '门店ID',
      \`child_name\` varchar(50) NOT NULL COMMENT '孩子姓名',
      \`training_project\` varchar(100) NOT NULL COMMENT '训练项目',
      \`card_name\` varchar(100) DEFAULT NULL COMMENT '卡项名称快照',
      \`card_sale_price\` decimal(10,2) DEFAULT NULL COMMENT '卡成交价快照',
      \`verify_date\` date NOT NULL COMMENT '核销日期',
      \`verify_time\` datetime NOT NULL COMMENT '核销时间',
      \`operator_id\` bigint unsigned NOT NULL COMMENT '操作人ID',
      \`operator_name\` varchar(50) NOT NULL COMMENT '操作人姓名',
      \`remark\` varchar(500) DEFAULT NULL COMMENT '备注',
      \`revoked\` tinyint NOT NULL DEFAULT 0 COMMENT '是否已撤回：0否 1是',
      \`revoked_at\` datetime DEFAULT NULL COMMENT '撤回时间',
      \`revoked_by\` bigint unsigned DEFAULT NULL COMMENT '撤回人ID',
      \`revoked_by_name\` varchar(50) DEFAULT NULL COMMENT '撤回人姓名',
      \`revoke_reason\` varchar(500) DEFAULT NULL COMMENT '撤回原因',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_verify_no\` (\`verify_no\`),
      KEY \`idx_verify_customer_id\` (\`customer_id\`),
      KEY \`idx_verify_store_id\` (\`store_id\`),
      KEY \`idx_verify_date\` (\`verify_date\`),
      KEY \`idx_verify_operator_id\` (\`operator_id\`),
      KEY \`idx_verify_revoked\` (\`revoked\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='核销记录表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_visits\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`visit_no\` varchar(50) NOT NULL COMMENT '来访单号',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`store_id\` bigint unsigned NOT NULL COMMENT '到店门店ID',
      \`customer_name\` varchar(50) NOT NULL COMMENT '客户姓名快照',
      \`customer_phone\` varchar(30) DEFAULT NULL COMMENT '联系电话快照',
      \`visit_date\` date NOT NULL COMMENT '来访日期',
      \`arrived_at\` datetime NOT NULL COMMENT '到店时间',
      \`started_at\` datetime DEFAULT NULL COMMENT '开始服务时间',
      \`completed_at\` datetime DEFAULT NULL COMMENT '完成服务时间',
      \`cancelled_at\` datetime DEFAULT NULL COMMENT '取消时间',
      \`visit_type\` varchar(30) NOT NULL DEFAULT 'training' COMMENT '来访类型',
      \`status\` tinyint NOT NULL DEFAULT 0 COMMENT '状态：0已到店 1服务中 2已完成 3已取消',
      \`verification_required\` tinyint NOT NULL DEFAULT 1 COMMENT '是否需要核销：1是 0否',
      \`source\` varchar(30) NOT NULL DEFAULT 'manual' COMMENT '来源：manual/verify/verify_backfill',
      \`training_project\` varchar(100) DEFAULT NULL COMMENT '训练项目快照',
      \`service_user_id\` bigint unsigned DEFAULT NULL COMMENT '服务员工ID',
      \`service_user_name\` varchar(50) DEFAULT NULL COMMENT '服务员工姓名快照',
      \`reception_user_id\` bigint unsigned DEFAULT NULL COMMENT '登记员工ID',
      \`reception_user_name\` varchar(50) DEFAULT NULL COMMENT '登记员工姓名快照',
      \`remark\` varchar(500) DEFAULT NULL COMMENT '来访备注',
      \`cancel_reason\` varchar(255) DEFAULT NULL COMMENT '取消原因',
      \`created_by\` bigint unsigned DEFAULT NULL COMMENT '创建人ID',
      \`updated_by\` bigint unsigned DEFAULT NULL COMMENT '最后更新人ID',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_customer_visit_no\` (\`visit_no\`),
      KEY \`idx_customer_visit_date_store\` (\`visit_date\`, \`store_id\`),
      KEY \`idx_customer_visit_customer_date\` (\`customer_id\`, \`visit_date\`),
      KEY \`idx_customer_visit_status\` (\`status\`),
      KEY \`idx_customer_visit_service_user\` (\`service_user_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户每日来访台账'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_visit_verifications\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`visit_id\` bigint unsigned NOT NULL COMMENT '来访记录ID',
      \`verify_record_id\` bigint unsigned NOT NULL COMMENT '核销记录ID',
      \`linked_by\` bigint unsigned DEFAULT NULL COMMENT '关联操作人ID',
      \`linked_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '关联时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_visit_verify_record\` (\`verify_record_id\`),
      KEY \`idx_visit_verification_visit\` (\`visit_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='来访与核销关联表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_renewals\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`customer_card_id\` bigint unsigned DEFAULT NULL COMMENT '客户持卡记录ID',
      \`before_total_times\` int NOT NULL COMMENT '续卡前总次数',
      \`before_used_times\` int NOT NULL COMMENT '续卡前已用次数',
      \`before_expire_date\` date NOT NULL COMMENT '续卡前到期日',
      \`add_times\` int NOT NULL COMMENT '增加次数',
      \`after_total_times\` int NOT NULL COMMENT '续卡后总次数',
      \`after_expire_date\` date NOT NULL COMMENT '续卡后到期日',
      \`operator_id\` bigint unsigned NOT NULL COMMENT '操作人ID',
      \`operator_name\` varchar(50) NOT NULL COMMENT '操作人姓名',
      \`remark\` varchar(500) DEFAULT NULL COMMENT '备注',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_renew_customer_id\` (\`customer_id\`),
      KEY \`idx_renew_card_id\` (\`customer_card_id\`),
      KEY \`idx_renew_operator_id\` (\`operator_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户续卡记录表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_follow_ups\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`record_time\` datetime NOT NULL COMMENT '回访时间',
      \`result\` varchar(100) NOT NULL COMMENT '回访结果',
      \`content\` varchar(1000) NOT NULL COMMENT '回访内容',
      \`operator_id\` bigint unsigned NOT NULL COMMENT '操作人ID',
      \`operator_name\` varchar(50) NOT NULL COMMENT '操作人姓名',
      \`remark\` varchar(500) DEFAULT NULL COMMENT '备注',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_follow_up_customer_id\` (\`customer_id\`),
      KEY \`idx_follow_up_record_time\` (\`record_time\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户回访记录表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_visit_checks\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`check_time\` datetime NOT NULL COMMENT '到店检查时间',
      \`check_result\` varchar(1000) NOT NULL COMMENT '检查结果',
      \`naked_vision_od\` varchar(32) DEFAULT NULL COMMENT '裸眼视力右眼OD',
      \`naked_vision_os\` varchar(32) DEFAULT NULL COMMENT '裸眼视力左眼OS',
      \`corrected_vision_od\` varchar(32) DEFAULT NULL COMMENT '戴镜视力右眼OD',
      \`corrected_vision_os\` varchar(32) DEFAULT NULL COMMENT '戴镜视力左眼OS',
      \`pd\` varchar(32) DEFAULT NULL COMMENT '检查瞳距PD',
      \`exam_sphere_od\` varchar(32) DEFAULT NULL COMMENT '检查球镜右眼OD',
      \`exam_cylinder_od\` varchar(32) DEFAULT NULL COMMENT '检查柱镜右眼OD',
      \`exam_axis_od\` varchar(32) DEFAULT NULL COMMENT '检查轴位右眼OD',
      \`exam_sphere_os\` varchar(32) DEFAULT NULL COMMENT '检查球镜左眼OS',
      \`exam_cylinder_os\` varchar(32) DEFAULT NULL COMMENT '检查柱镜左眼OS',
      \`exam_axis_os\` varchar(32) DEFAULT NULL COMMENT '检查轴位左眼OS',
      \`recommended_sphere_od\` varchar(32) DEFAULT NULL COMMENT '建议球镜右眼OD',
      \`recommended_cylinder_od\` varchar(32) DEFAULT NULL COMMENT '建议柱镜右眼OD',
      \`recommended_axis_od\` varchar(32) DEFAULT NULL COMMENT '建议轴位右眼OD',
      \`recommended_sphere_os\` varchar(32) DEFAULT NULL COMMENT '建议球镜左眼OS',
      \`recommended_cylinder_os\` varchar(32) DEFAULT NULL COMMENT '建议柱镜左眼OS',
      \`recommended_axis_os\` varchar(32) DEFAULT NULL COMMENT '建议轴位左眼OS',
      \`suggestion\` varchar(1000) DEFAULT NULL COMMENT '检查建议',
      \`operator_id\` bigint unsigned NOT NULL COMMENT '操作人ID',
      \`operator_name\` varchar(50) NOT NULL COMMENT '操作人姓名',
      \`remark\` varchar(500) DEFAULT NULL COMMENT '备注',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_visit_check_customer_id\` (\`customer_id\`),
      KEY \`idx_visit_check_time\` (\`check_time\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户到店检查记录表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_glasses_records\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`record_time\` datetime NOT NULL COMMENT '配镜时间',
      \`source_check_id\` bigint unsigned DEFAULT NULL COMMENT '来源检查记录ID',
      \`delivery_status\` tinyint NOT NULL DEFAULT 1 COMMENT '配镜流程状态：1已下单 2定制中 3制作中 4待取镜 5已交付 6异常处理中 7已取消',
      \`pd\` varchar(32) DEFAULT NULL COMMENT '配镜瞳距PD',
      \`sphere_od\` varchar(32) DEFAULT NULL COMMENT '配镜球镜右眼OD',
      \`cylinder_od\` varchar(32) DEFAULT NULL COMMENT '配镜柱镜右眼OD',
      \`axis_od\` varchar(32) DEFAULT NULL COMMENT '配镜轴位右眼OD',
      \`sphere_os\` varchar(32) DEFAULT NULL COMMENT '配镜球镜左眼OS',
      \`cylinder_os\` varchar(32) DEFAULT NULL COMMENT '配镜柱镜左眼OS',
      \`axis_os\` varchar(32) DEFAULT NULL COMMENT '配镜轴位左眼OS',
      \`lens_brand\` varchar(100) DEFAULT NULL COMMENT '镜片品牌',
      \`lens_type\` varchar(100) DEFAULT NULL COMMENT '镜片类型',
      \`frame_info\` varchar(255) DEFAULT NULL COMMENT '镜架信息',
      \`remark\` varchar(500) DEFAULT NULL COMMENT '备注',
      \`operator_id\` bigint unsigned NOT NULL COMMENT '操作人ID',
      \`operator_name\` varchar(50) NOT NULL COMMENT '操作人姓名',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_customer_glasses_customer_id\` (\`customer_id\`),
      KEY \`idx_customer_glasses_record_time\` (\`record_time\`),
      KEY \`idx_customer_glasses_delivery_status\` (\`delivery_status\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户配镜记录表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`customer_glasses_status_logs\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`glasses_record_id\` bigint unsigned NOT NULL COMMENT '配镜记录ID',
      \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
      \`from_status\` tinyint DEFAULT NULL COMMENT '原状态',
      \`to_status\` tinyint NOT NULL COMMENT '新状态',
      \`remark\` varchar(500) DEFAULT NULL COMMENT '流转备注',
      \`operator_id\` bigint unsigned DEFAULT NULL COMMENT '操作人ID',
      \`operator_name\` varchar(50) DEFAULT NULL COMMENT '操作人姓名',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_glasses_status_log_record\` (\`glasses_record_id\`),
      KEY \`idx_glasses_status_log_customer\` (\`customer_id\`),
      KEY \`idx_glasses_status_log_status\` (\`to_status\`),
      KEY \`idx_glasses_status_log_created_at\` (\`created_at\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户配镜流程状态流转记录表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`operation_logs\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`operator_id\` bigint unsigned DEFAULT NULL COMMENT '操作人ID',
      \`operator_name\` varchar(50) DEFAULT NULL COMMENT '操作人姓名',
      \`operator_role\` tinyint DEFAULT NULL COMMENT '操作人角色',
      \`store_id\` bigint unsigned DEFAULT NULL COMMENT '所属门店ID',
      \`module\` varchar(50) NOT NULL COMMENT '模块',
      \`action\` varchar(50) NOT NULL COMMENT '动作',
      \`biz_type\` varchar(50) DEFAULT NULL COMMENT '业务类型',
      \`biz_id\` bigint unsigned DEFAULT NULL COMMENT '业务主键ID',
      \`biz_no\` varchar(100) DEFAULT NULL COMMENT '业务编号',
      \`content\` varchar(1000) NOT NULL COMMENT '日志内容',
      \`ip\` varchar(64) DEFAULT NULL COMMENT '操作IP',
      \`user_agent\` varchar(500) DEFAULT NULL COMMENT 'User-Agent',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (\`id\`),
      KEY \`idx_log_operator_id\` (\`operator_id\`),
      KEY \`idx_log_store_id\` (\`store_id\`),
      KEY \`idx_log_module_action\` (\`module\`, \`action\`),
      KEY \`idx_log_created_at\` (\`created_at\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表'
  `,
  `
    CREATE TABLE IF NOT EXISTS \`user_sessions\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`user_id\` bigint unsigned NOT NULL COMMENT '用户ID',
      \`refresh_token\` varchar(255) NOT NULL COMMENT '刷新令牌',
      \`expired_at\` datetime NOT NULL COMMENT '过期时间',
      \`ip\` varchar(64) DEFAULT NULL COMMENT '登录IP',
      \`user_agent\` varchar(500) DEFAULT NULL COMMENT 'User-Agent',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_refresh_token\` (\`refresh_token\`),
      KEY \`idx_session_user_id\` (\`user_id\`),
      KEY \`idx_session_expired_at\` (\`expired_at\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户会话表'
  `,
  `
  CREATE TABLE IF NOT EXISTS \`external_api_keys\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      \`name\` varchar(100) NOT NULL COMMENT '密钥名称',
      \`key_prefix\` varchar(20) NOT NULL COMMENT '密钥前缀',
      \`key_hash\` varchar(128) NOT NULL COMMENT '密钥哈希',
      \`user_id\` bigint unsigned NOT NULL COMMENT '绑定用户ID',
      \`scopes\` text DEFAULT NULL COMMENT '权限范围(JSON数组)',
      \`status\` tinyint NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
      \`expires_at\` datetime DEFAULT NULL COMMENT '过期时间',
      \`last_used_at\` datetime DEFAULT NULL COMMENT '最后使用时间',
      \`last_used_ip\` varchar(64) DEFAULT NULL COMMENT '最后使用IP',
      \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
      \`created_by\` bigint unsigned DEFAULT NULL COMMENT '创建人ID',
      \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uk_external_api_key_hash\` (\`key_hash\`),
      KEY \`idx_external_api_key_user_id\` (\`user_id\`),
      KEY \`idx_external_api_key_status\` (\`status\`),
      KEY \`idx_external_api_key_expires_at\` (\`expires_at\`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='外部系统API密钥表'
`,
  `
  CREATE TABLE IF NOT EXISTS \`external_api_key_logs\` (
    \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    \`api_key_id\` bigint unsigned NOT NULL COMMENT 'API Key ID',
    \`user_id\` bigint unsigned DEFAULT NULL COMMENT '绑定用户ID',
    \`request_method\` varchar(10) NOT NULL COMMENT '请求方法',
    \`request_path\` varchar(255) NOT NULL COMMENT '请求路径',
    \`status_code\` int NOT NULL DEFAULT 200 COMMENT '响应状态码',
    \`duration_ms\` int NOT NULL DEFAULT 0 COMMENT '耗时毫秒',
    \`ip\` varchar(64) DEFAULT NULL COMMENT '请求IP',
    \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (\`id\`),
    KEY \`idx_external_api_key_logs_key_id\` (\`api_key_id\`),
    KEY \`idx_external_api_key_logs_user_id\` (\`user_id\`),
    KEY \`idx_external_api_key_logs_created_at\` (\`created_at\`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='外部系统API密钥调用日志表'
`,
  `
    CREATE TABLE IF NOT EXISTS \`user_notification_states\` (
    \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    \`user_id\` bigint unsigned NOT NULL COMMENT '用户ID',
    \`notification_id\` varchar(100) NOT NULL COMMENT '通知唯一标识',
    \`is_read\` tinyint NOT NULL DEFAULT 0 COMMENT '是否已读',
    \`read_at\` datetime DEFAULT NULL COMMENT '已读时间',
    \`handled_at\` datetime DEFAULT NULL COMMENT '处理时间',
    \`handled_note\` varchar(255) DEFAULT NULL COMMENT '处理备注',
    \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (\`id\`),
    UNIQUE KEY \`uk_notification_user_notice\` (\`user_id\`, \`notification_id\`),
    KEY \`idx_notification_user_id\` (\`user_id\`),
    KEY \`idx_notification_is_read\` (\`is_read\`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户通知状态表'
`,
  `
  CREATE TABLE IF NOT EXISTS \`system_settings\` (
    \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    \`setting_key\` varchar(100) NOT NULL COMMENT '设置键',
    \`setting_value\` varchar(500) DEFAULT NULL COMMENT '设置值',
    \`remark\` varchar(255) DEFAULT NULL COMMENT '备注',
    \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (\`id\`),
    UNIQUE KEY \`uk_system_setting_key\` (\`setting_key\`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表'
`,
  `
  CREATE TABLE IF NOT EXISTS \`wx_reservations\` (
    \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    \`customer_id\` bigint unsigned NOT NULL COMMENT '客户ID',
    \`store_id\` bigint unsigned NOT NULL COMMENT '门店ID',
    \`reservation_date\` date NOT NULL COMMENT '预约日期',
    \`time_slot\` varchar(20) NOT NULL COMMENT '时段',
    \`training_project\` varchar(100) DEFAULT NULL COMMENT '预约项目',
    \`status\` tinyint NOT NULL DEFAULT 0 COMMENT '状态：0待确认 1已确认 2已完成 3已取消',
    \`cancel_reason\` varchar(255) DEFAULT NULL COMMENT '取消原因',
    \`remark\` varchar(500) DEFAULT NULL COMMENT '备注',
    \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (\`id\`),
    KEY \`idx_reservation_date\` (\`reservation_date\`),
    KEY \`idx_reservation_customer\` (\`customer_id\`),
    KEY \`idx_reservation_store\` (\`store_id\`),
    KEY \`idx_reservation_status\` (\`status\`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='微信小程序预约表'
`,
  `
  CREATE TABLE IF NOT EXISTS \`notification_queue\` (
    \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    \`biz_type\` varchar(50) NOT NULL COMMENT '业务类型',
    \`biz_id\` bigint unsigned DEFAULT NULL COMMENT '业务主键ID',
    \`target_type\` varchar(20) NOT NULL DEFAULT 'sms' COMMENT '目标渠道',
    \`target_address\` varchar(100) NOT NULL COMMENT '手机号或openid',
    \`title\` varchar(200) NOT NULL COMMENT '通知标题',
    \`content\` varchar(1000) NOT NULL COMMENT '通知内容',
    \`template_id\` varchar(100) DEFAULT NULL COMMENT '模板ID',
    \`template_data\` text DEFAULT NULL COMMENT '模板变量JSON',
    \`status\` tinyint NOT NULL DEFAULT 0 COMMENT '状态：0待发送 1已发送 2发送失败',
    \`error_msg\` varchar(500) DEFAULT NULL COMMENT '失败原因',
    \`sent_at\` datetime DEFAULT NULL COMMENT '发送时间',
    \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (\`id\`),
    KEY \`idx_notification_status\` (\`status\`),
    KEY \`idx_notification_biz\` (\`biz_type\`),
    KEY \`idx_notification_created\` (\`created_at\`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息通知队列表'
`
];


async function createTables(connection) {
  for (const sql of TABLE_CREATE_SQLS) {
    await connection.query(sql);
  }

  await ensureCustomerColumns(connection);
  await ensureCustomerPhoneRows(connection);
  await ensureCustomerCardColumns(connection);
  await ensureCustomerRenewalColumns(connection);
  await ensureVerifyRecordColumns(connection);
  await ensureVisitCheckColumns(connection);
  await ensureSystemSettings(connection);
}

async function hasColumn(connection, tableName, columnName) {
  const [rows] = await connection.query(
    `SHOW COLUMNS FROM \`${tableName}\` LIKE ?`,
    [columnName],
  );
  return rows.length > 0;
}

async function hasIndex(connection, tableName, indexName) {
  const [rows] = await connection.query(
    `SHOW INDEX FROM \`${tableName}\` WHERE Key_name = ?`,
    [indexName],
  );
  return rows.length > 0;
}

async function ensureCustomerColumns(connection) {
  if (!(await hasColumn(connection, "customers", "has_card"))) {
    await connection.query(`
      ALTER TABLE \`customers\`
      ADD COLUMN \`has_card\` tinyint NOT NULL DEFAULT 1 COMMENT '是否已开卡：1已开卡 0仅开户' AFTER \`store_id\`
    `);
  }

  await connection.query(`
    ALTER TABLE \`customers\`
    MODIFY COLUMN \`training_project\` varchar(100) DEFAULT NULL COMMENT '训练项目'
  `);

  await connection.query(`
    ALTER TABLE \`customers\`
    MODIFY COLUMN \`open_card_date\` date DEFAULT NULL COMMENT '开卡日期'
  `);

  await connection.query(`
    ALTER TABLE \`customers\`
    MODIFY COLUMN \`expire_date\` date DEFAULT NULL COMMENT '到期日期'
  `);

  await connection.query(`
    UPDATE \`customers\`
    SET \`has_card\` = CASE
      WHEN COALESCE(\`training_project\`, '') <> ''
        AND \`open_card_date\` IS NOT NULL
        AND \`expire_date\` IS NOT NULL
      THEN 1
      ELSE 0
    END
    WHERE \`has_card\` IS NULL
       OR \`has_card\` NOT IN (0, 1)
  `);

  if (!(await hasIndex(connection, "customers", "idx_customer_has_card"))) {
    await connection.query(`
      ALTER TABLE \`customers\`
      ADD KEY \`idx_customer_has_card\` (\`has_card\`)
    `);
  }

  if (!(await hasColumn(connection, "customers", "wx_openid"))) {
    await connection.query(`
      ALTER TABLE \`customers\`
      ADD COLUMN \`wx_openid\` varchar(64) DEFAULT NULL COMMENT '微信openid' AFTER \`parent_phone\`
    `);
  }
}

async function ensureCustomerPhoneRows(connection) {
  await connection.query(`
    INSERT IGNORE INTO \`customer_phones\` (\`customer_id\`, \`phone\`, \`is_primary\`, \`status\`)
    SELECT \`id\`, \`parent_phone\`, 1, 1
    FROM \`customers\`
    WHERE \`parent_phone\` IS NOT NULL
      AND \`parent_phone\` <> ''
  `);
}

async function ensureCustomerCardColumns(connection) {
  if (!(await hasColumn(connection, "customer_card_usage_logs", "verify_record_id"))) {
    await connection.query(`
      ALTER TABLE \`customer_card_usage_logs\`
      ADD COLUMN \`verify_record_id\` bigint unsigned DEFAULT NULL COMMENT '关联核销记录ID' AFTER \`customer_id\`
    `);
  }

  if (!(await hasIndex(connection, "customer_card_usage_logs", "idx_customer_card_usage_verify_record_id"))) {
    await connection.query(`
      ALTER TABLE \`customer_card_usage_logs\`
      ADD KEY \`idx_customer_card_usage_verify_record_id\` (\`verify_record_id\`)
    `);
  }

  if (!(await hasColumn(connection, "customer_cards", "is_promotion"))) {
    await connection.query(`
      ALTER TABLE \`customer_cards\`
      ADD COLUMN \`is_promotion\` tinyint NOT NULL DEFAULT 0 COMMENT '是否活动卡：1是 0否' AFTER \`sale_price\`
    `);
  }

  await connection.query(`
    UPDATE \`customer_cards\` cc
    LEFT JOIN \`card_templates\` ct ON ct.id = cc.card_template_id
    SET cc.\`is_promotion\` = COALESCE(ct.\`is_promotion\`, cc.\`is_promotion\`, 0)
  `);

  await connection.query(`
    ALTER TABLE \`customer_cards\`
    MODIFY COLUMN \`expire_date\` date DEFAULT NULL COMMENT '到期日期'
  `);
}

async function ensureCustomerRenewalColumns(connection) {
  if (!(await hasColumn(connection, "customer_renewals", "customer_card_id"))) {
    await connection.query(`
      ALTER TABLE \`customer_renewals\`
      ADD COLUMN \`customer_card_id\` bigint unsigned DEFAULT NULL COMMENT '客户持卡记录ID' AFTER \`customer_id\`
    `);
  }

  if (!(await hasIndex(connection, "customer_renewals", "idx_renew_card_id"))) {
    await connection.query(`
      ALTER TABLE \`customer_renewals\`
      ADD KEY \`idx_renew_card_id\` (\`customer_card_id\`)
    `);
  }
}

async function ensureVerifyRecordColumns(connection) {
  if (!(await hasColumn(connection, "verify_records", "customer_card_id"))) {
    await connection.query(`
      ALTER TABLE \`verify_records\`
      ADD COLUMN \`customer_card_id\` bigint unsigned DEFAULT NULL COMMENT '客户持卡记录ID' AFTER \`customer_id\`
    `);
  }

  if (!(await hasColumn(connection, "verify_records", "card_name"))) {
    await connection.query(`
      ALTER TABLE \`verify_records\`
      ADD COLUMN \`card_name\` varchar(100) DEFAULT NULL COMMENT '卡项名称快照' AFTER \`training_project\`
    `);
  }

  if (!(await hasColumn(connection, "verify_records", "card_sale_price"))) {
    await connection.query(`
      ALTER TABLE \`verify_records\`
      ADD COLUMN \`card_sale_price\` decimal(10,2) DEFAULT NULL COMMENT '卡成交价快照' AFTER \`card_name\`
    `);
  }

  if (!(await hasColumn(connection, "verify_records", "revoked"))) {
    await connection.query(`
      ALTER TABLE \`verify_records\`
      ADD COLUMN \`revoked\` tinyint NOT NULL DEFAULT 0 COMMENT '是否已撤回：0否 1是' AFTER \`remark\`
    `);
  }

  if (!(await hasColumn(connection, "verify_records", "revoked_at"))) {
    await connection.query(`
      ALTER TABLE \`verify_records\`
      ADD COLUMN \`revoked_at\` datetime DEFAULT NULL COMMENT '撤回时间' AFTER \`revoked\`
    `);
  }

  if (!(await hasColumn(connection, "verify_records", "revoked_by"))) {
    await connection.query(`
      ALTER TABLE \`verify_records\`
      ADD COLUMN \`revoked_by\` bigint unsigned DEFAULT NULL COMMENT '撤回人ID' AFTER \`revoked_at\`
    `);
  }

  if (!(await hasColumn(connection, "verify_records", "revoked_by_name"))) {
    await connection.query(`
      ALTER TABLE \`verify_records\`
      ADD COLUMN \`revoked_by_name\` varchar(50) DEFAULT NULL COMMENT '撤回人姓名' AFTER \`revoked_by\`
    `);
  }

  if (!(await hasColumn(connection, "verify_records", "revoke_reason"))) {
    await connection.query(`
      ALTER TABLE \`verify_records\`
      ADD COLUMN \`revoke_reason\` varchar(500) DEFAULT NULL COMMENT '撤回原因' AFTER \`revoked_by_name\`
    `);
  }

  await connection.query(`
    UPDATE \`verify_records\`
    SET \`revoked\` = 0
    WHERE \`revoked\` IS NULL
       OR \`revoked\` NOT IN (0, 1)
  `);

  if (!(await hasIndex(connection, "verify_records", "idx_verify_revoked"))) {
    await connection.query(`
      ALTER TABLE \`verify_records\`
      ADD KEY \`idx_verify_revoked\` (\`revoked\`)
    `);
  }

  if (!(await hasIndex(connection, "verify_records", "idx_verify_customer_card_id"))) {
    await connection.query(`
      ALTER TABLE \`verify_records\`
      ADD KEY \`idx_verify_customer_card_id\` (\`customer_card_id\`)
    `);
  }
}

async function ensureVisitCheckColumns(connection) {
  const visitCheckColumns = [
    ["naked_vision_od", "varchar(32) DEFAULT NULL COMMENT '裸眼视力右眼OD' AFTER `check_result`"],
    ["naked_vision_os", "varchar(32) DEFAULT NULL COMMENT '裸眼视力左眼OS' AFTER `naked_vision_od`"],
    ["corrected_vision_od", "varchar(32) DEFAULT NULL COMMENT '戴镜视力右眼OD' AFTER `naked_vision_os`"],
    ["corrected_vision_os", "varchar(32) DEFAULT NULL COMMENT '戴镜视力左眼OS' AFTER `corrected_vision_od`"],
    ["pd", "varchar(32) DEFAULT NULL COMMENT '检查瞳距PD' AFTER `corrected_vision_os`"],
    ["exam_sphere_od", "varchar(32) DEFAULT NULL COMMENT '检查球镜右眼OD' AFTER `pd`"],
    ["exam_cylinder_od", "varchar(32) DEFAULT NULL COMMENT '检查柱镜右眼OD' AFTER `exam_sphere_od`"],
    ["exam_axis_od", "varchar(32) DEFAULT NULL COMMENT '检查轴位右眼OD' AFTER `exam_cylinder_od`"],
    ["exam_sphere_os", "varchar(32) DEFAULT NULL COMMENT '检查球镜左眼OS' AFTER `exam_axis_od`"],
    ["exam_cylinder_os", "varchar(32) DEFAULT NULL COMMENT '检查柱镜左眼OS' AFTER `exam_sphere_os`"],
    ["exam_axis_os", "varchar(32) DEFAULT NULL COMMENT '检查轴位左眼OS' AFTER `exam_cylinder_os`"],
    ["recommended_sphere_od", "varchar(32) DEFAULT NULL COMMENT '建议球镜右眼OD' AFTER `exam_axis_os`"],
    ["recommended_cylinder_od", "varchar(32) DEFAULT NULL COMMENT '建议柱镜右眼OD' AFTER `recommended_sphere_od`"],
    ["recommended_axis_od", "varchar(32) DEFAULT NULL COMMENT '建议轴位右眼OD' AFTER `recommended_cylinder_od`"],
    ["recommended_sphere_os", "varchar(32) DEFAULT NULL COMMENT '建议球镜左眼OS' AFTER `recommended_axis_od`"],
    ["recommended_cylinder_os", "varchar(32) DEFAULT NULL COMMENT '建议柱镜左眼OS' AFTER `recommended_sphere_os`"],
    ["recommended_axis_os", "varchar(32) DEFAULT NULL COMMENT '建议轴位左眼OS' AFTER `recommended_cylinder_os`"],
  ];

  for (const [columnName, definition] of visitCheckColumns) {
    if (!(await hasColumn(connection, "customer_visit_checks", columnName))) {
      await connection.query(`
        ALTER TABLE \`customer_visit_checks\`
        ADD COLUMN \`${columnName}\` ${definition}
      `);
    }
  }
}

async function ensureSystemSettings(connection) {
  await connection.query(
    `
      INSERT INTO \`system_settings\` (\`setting_key\`, \`setting_value\`, \`remark\`)
      VALUES ('low_times_threshold', '5', '次数不足提醒阈值，默认小于等于5次')
      ON DUPLICATE KEY UPDATE
        \`remark\` = VALUES(\`remark\`)
    `
  );
}

module.exports = {
  TABLE_CREATE_SQLS,
  createTables
};
