const DEFAULT_TRAINING_PROJECTS = Object.freeze([
  ["近视", "近视客户的基础管理分类，可按门店实际方案修改。"],
  ["弱视", "弱视客户的基础管理分类，可按专业方案细分。"],
  ["保健", "日常视力保健、护眼和非核销来访服务。"],
  ["调节训练", "改善调节滞后、调节不足、调节灵活度下降等问题。"],
  ["调节放松训练", "用于缓解近距离用眼后的眼疲劳和调节紧张。"],
  ["调节灵敏度训练", "提升双眼调节切换速度，适合阅读后模糊、看远恢复慢人群。"],
  ["集合训练", "改善集合不足、近距离阅读串行、眼酸胀等问题。"],
  ["散开训练", "改善散开能力不足和双眼协同异常。"],
  ["融合训练", "提升双眼融合范围和稳定性，增强双眼单视能力。"],
  ["立体视训练", "提升深度感知和精细空间判断能力。"],
  ["眼动追踪训练", "提升追踪稳定性，适合阅读跳行、球类运动追踪弱等情况。"],
  ["扫视训练", "提升快速定位和换行能力，改善阅读速度与准确性。"],
  ["注视稳定训练", "改善注视不稳、注意力易飘、精细阅读困难。"],
  ["视觉追踪训练", "适合低龄儿童进行基础追踪与手眼协调训练。"],
  ["视觉定位训练", "提升空间定位、视线落点和手眼协调能力。"],
  ["视觉记忆训练", "提升视觉短时记忆、图形记忆和课堂抄写效率。"],
  ["视觉分辨训练", "提升相似图形、文字细节和方向辨别能力。"],
  ["视觉空间训练", "提升左右、上下、空间关系和结构感知能力。"],
  ["手眼协调训练", "提升视觉输入与动作输出协调，适合低龄及精细动作弱人群。"],
  ["阅读效率训练", "综合改善阅读速度、跳行、漏字、理解疲劳等问题。"],
  ["眼动训练", "以扫视、追踪、注视稳定为核心的综合眼动训练。"],
  ["近视防控训练", "结合调节、集合、用眼习惯管理，服务近视防控客户。"],
  ["综合视功能训练", "适合多项视功能指标同时需要提升的客户。"],
  ["调节集合综合训练", "同时强化调节和集合能力，适合学习负荷较大的青少年。"],
  ["弱视辅助训练", "配合弱视治疗方案进行视觉刺激和精细目力训练。"],
  ["斜视术后维护训练", "用于斜视术后双眼视功能维护和融合能力恢复。"],
  ["低龄启蒙训练", "适合学龄前儿童建立基础视觉能力和训练兴趣。"],
  ["视觉疲劳改善训练", "面向长时间近距离用眼导致的酸胀、干涩、模糊问题。"],
  ["视功能维护训练", "用于已稳定客户的定期维护和复查管理。"],
  ["离焦镜适应训练", "配合离焦类镜片佩戴后的适应和视功能维护。"],
  ["角膜塑形镜配合训练", "配合角膜塑形镜客户进行视功能和用眼习惯管理。"],
  ["青少年运动视觉训练", "提升动态追踪、反应速度和手眼协调能力。"],
  ["成人视疲劳训练", "适合办公、屏幕使用频繁的成人客户。"],
  ["家庭护眼指导", "用于家庭用眼环境、阅读姿势、户外活动和复查节奏指导。"],
  ["复查评估服务", "用于阶段性复查、数据评估和方案调整。"]
]);

const DEFAULT_CARD_TEMPLATES = Object.freeze([
  ["启蒙视觉训练体验卡", "低龄启蒙训练", 6, "398,498", 0, "适合首次体验和低龄儿童适应训练。"],
  ["儿童视觉训练月卡", "视觉追踪训练", 12, "980,1280,1680", 0, "适合低龄儿童基础追踪、注视和手眼协调训练。"],
  ["儿童视觉训练季度卡", "视觉追踪训练", 36, "2680,3280", 0, "适合低龄儿童连续训练一个季度。"],
  ["调节训练基础卡", "调节训练", 24, "1680,1980", 0, "适合调节不足、调节滞后客户。"],
  ["调节灵敏度提升卡", "调节灵敏度训练", 32, "2180,2580", 0, "适合看远看近切换慢、阅读后模糊客户。"],
  ["调节放松月卡", "调节放松训练", 12, "880,1280", 0, "适合短期视疲劳改善。"],
  ["集合训练基础卡", "集合训练", 24, "1880,2280", 0, "适合集合不足和近距离阅读疲劳客户。"],
  ["集合强化季度卡", "集合训练", 36, "2880,3280", 0, "适合需要连续强化集合能力客户。"],
  ["融合训练基础卡", "融合训练", 24, "1980,2380", 0, "适合融合范围不足或双眼协同弱客户。"],
  ["双眼视功能强化卡", "融合训练", 48, "3680,3980", 0, "综合提升融合、调节、集合能力。"],
  ["立体视提升卡", "立体视训练", 20, "1680,1980", 0, "适合立体视弱和精细空间判断弱客户。"],
  ["眼动追踪基础卡", "眼动追踪训练", 20, "1480,1880", 0, "适合追踪稳定性不足、球类追踪弱客户。"],
  ["扫视阅读提升卡", "扫视训练", 24, "1880,2280", 0, "适合阅读跳行、漏字、换行困难客户。"],
  ["注视稳定训练卡", "注视稳定训练", 20, "1380,1680", 0, "适合注视不稳、注意力易偏移客户。"],
  ["视觉定位训练卡", "视觉定位训练", 20, "1480,1880", 0, "适合空间定位和视觉落点训练。"],
  ["视觉记忆提升卡", "视觉记忆训练", 24, "1880,2280", 0, "适合抄写慢、图形记忆弱客户。"],
  ["视觉分辨训练卡", "视觉分辨训练", 20, "1480,1880", 0, "适合相似字形、方向、细节分辨训练。"],
  ["视觉空间能力卡", "视觉空间训练", 24, "1980,2380", 0, "适合空间结构感弱、左右方向感弱客户。"],
  ["手眼协调训练卡", "手眼协调训练", 20, "1280,1680", 0, "适合手眼协调、精细动作配合训练。"],
  ["阅读效率提升卡", "阅读效率训练", 32, "2180,2680", 0, "适合阅读速度慢、跳行漏字、阅读疲劳客户。"],
  ["青少年近视防控基础卡", "近视防控训练", 36, "2680,3280", 0, "适合近视防控初期管理。"],
  ["近视管理半年卡", "近视防控训练", 48, "3980,4680", 0, "适合半年连续近视防控管理。"],
  ["近视管理年度卡", "近视防控训练", 72, "5680,6880", 0, "适合年度近视防控和复查管理。"],
  ["综合视功能月卡", "综合视功能训练", 16, "1280,1680", 0, "适合多项视功能基础训练。"],
  ["综合视功能季度卡", "综合视功能训练", 48, "3280,3980", 0, "适合阶段性综合提升。"],
  ["综合视功能半年卡", "综合视功能训练", 72, "4980,5980", 0, "适合中长期综合训练。"],
  ["调节集合综合提升卡", "调节集合综合训练", 50, "3680,4280", 0, "适合调节与集合均需提升客户。"],
  ["弱视辅助训练月卡", "弱视辅助训练", 20, "1980,2380", 0, "配合弱视治疗的辅助训练。"],
  ["弱视辅助训练季度卡", "弱视辅助训练", 60, "4980,5680", 0, "适合弱视客户阶段性训练。"],
  ["斜视术后维护卡", "斜视术后维护训练", 30, "2980,3680", 0, "适合斜视术后双眼视维护。"],
  ["视觉疲劳改善卡", "视觉疲劳改善训练", 30, "1980,2380", 0, "适合学习或办公导致的视疲劳客户。"],
  ["成人视疲劳改善卡", "成人视疲劳训练", 12, "980,1280", 0, "适合成人办公屏幕用眼疲劳。"],
  ["离焦镜适应维护卡", "离焦镜适应训练", 16, "1280,1680", 0, "配合离焦镜佩戴适应和维护。"],
  ["角膜塑形镜配合训练卡", "角膜塑形镜配合训练", 20, "1680,2280", 0, "适合角膜塑形镜客户视功能管理。"],
  ["青少年运动视觉训练卡", "青少年运动视觉训练", 24, "1980,2580", 0, "适合运动追踪、反应和协调能力提升。"],
  ["视功能维护半年卡", "视功能维护训练", 40, "2980,3680", 0, "适合指标稳定后的半年维护。"],
  ["复查评估服务卡", "复查评估服务", 6, "399,599", 0, "用于阶段复查、数据评估和方案调整。"],
  ["家庭护眼指导服务卡", "家庭护眼指导", 6, "299,499", 0, "用于家庭环境和用眼习惯指导。"],
  ["新客体验活动卡", "综合视功能训练", 3, "99,199", 1, "新客户短期体验活动卡。"],
  ["暑期强化活动卡", "调节集合综合训练", 12, "899,1299", 1, "暑期集中训练活动卡。"],
  ["老客户关怀赠送卡", "视功能维护训练", 5, "0", 1, "用于老客户维护和活动赠送。"],
  ["复查优惠活动卡", "复查评估服务", 2, "0,99", 1, "用于阶段复查活动。"]
]);

async function seedDefaultBusinessData(connection, options = {}) {
  const operatorId = Number(options.operatorId || 0) || null;
  const [[projectCountRow]] = await connection.query("SELECT COUNT(*) AS total FROM training_projects");
  const [[cardCountRow]] = await connection.query("SELECT COUNT(*) AS total FROM card_templates");
  const projectCount = Number(projectCountRow.total || 0);
  const cardCount = Number(cardCountRow.total || 0);

  if (projectCount > 0 || cardCount > 0) {
    return {
      inserted: false,
      trainingProjects: 0,
      cardTemplates: 0,
      reason: "基础资料表已有数据，已保留现有内容"
    };
  }

  const projectPlaceholders = DEFAULT_TRAINING_PROJECTS.map(() => "(?, 1, ?, ?, ?)").join(",");
  const projectParams = DEFAULT_TRAINING_PROJECTS.flatMap(([name, remark]) => [name, remark, operatorId, operatorId]);
  await connection.query(
    `INSERT INTO training_projects (project_name, status, remark, created_by, updated_by) VALUES ${projectPlaceholders}`,
    projectParams
  );

  const cardPlaceholders = DEFAULT_CARD_TEMPLATES.map(() => "(?, ?, ?, ?, ?, 1, ?, ?, ?)").join(",");
  const cardParams = DEFAULT_CARD_TEMPLATES.flatMap(([name, project, times, prices, promotion, remark]) => [
    name,
    project,
    times,
    prices,
    promotion,
    remark,
    operatorId,
    operatorId
  ]);
  await connection.query(
    `INSERT INTO card_templates (card_name, training_project, default_times, price_options, is_promotion, status, remark, created_by, updated_by) VALUES ${cardPlaceholders}`,
    cardParams
  );

  return {
    inserted: true,
    trainingProjects: DEFAULT_TRAINING_PROJECTS.length,
    cardTemplates: DEFAULT_CARD_TEMPLATES.length,
    reason: "已写入可编辑、可启停、可删除的默认基础资料"
  };
}

async function ensureDefaultBusinessReleaseSeed(pool) {
  const connection = await pool.getConnection();
  try {
    await connection.query(`
      CREATE TABLE IF NOT EXISTS system_seed_history (
        seed_key varchar(100) NOT NULL,
        status varchar(20) NOT NULL DEFAULT 'running',
        details_json json DEFAULT NULL,
        applied_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (seed_key)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统一次性基础数据任务'
    `);
    await connection.beginTransaction();
    const [marker] = await connection.execute(
      "INSERT IGNORE INTO system_seed_history (seed_key, status) VALUES (?, 'running')",
      ["default-business-data-v1"]
    );
    if (Number(marker.affectedRows || 0) === 0) {
      await connection.rollback();
      return { applied: false, reason: "该版本基础资料任务已经执行" };
    }
    const result = await seedDefaultBusinessData(connection);
    await connection.execute(
      "UPDATE system_seed_history SET status='applied', details_json=?, applied_at=NOW() WHERE seed_key=?",
      [JSON.stringify(result), "default-business-data-v1"]
    );
    await connection.commit();
    return { applied: true, ...result };
  } catch (error) {
    try { await connection.rollback(); } catch {}
    throw error;
  } finally {
    connection.release();
  }
}

module.exports = {
  DEFAULT_TRAINING_PROJECTS,
  DEFAULT_CARD_TEMPLATES,
  seedDefaultBusinessData,
  ensureDefaultBusinessReleaseSeed
};
