const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const { sendSuccess, sendFail } = require("../utils/response");
const {
  listPermissionGroups,
  listPermissionTemplates,
  normalizePermissionCodes,
  ensurePermissionTables
} = require("../utils/permission");
const { pool } = require("../config/db");

const router = express.Router();
router.use(auth());

router.get("/meta", requireUserPermission("user:permission"), async (_req, res, next) => {
  try {
    const [groups, templates] = await Promise.all([
      listPermissionGroups(),
      listPermissionTemplates()
    ]);
    return sendSuccess(res, { groups, templates }, "获取权限配置成功");
  } catch (error) {
    next(error);
  }
});

router.get("/templates", requireUserPermission("user:permission"), async (_req, res, next) => {
  try {
    return sendSuccess(res, await listPermissionTemplates(), "获取权限模板成功");
  } catch (error) {
    next(error);
  }
});

router.post("/templates", requireUserPermission("user:permission"), async (req, res, next) => {
  try {
    await ensurePermissionTables();
    const name = String(req.body.name || "").trim();
    const description = String(req.body.description || "").trim();
    const permissions = normalizePermissionCodes(req.body.permissions || []);
    if (!name) return sendFail(res, "模板名称不能为空", 400);
    const [result] = await pool.execute(
      `INSERT INTO permission_templates (code, name, description, role, permissions, is_system, sort_order, status)
       VALUES (NULL, ?, ?, NULL, CAST(? AS JSON), 0, 1000, 1)`,
      [name, description || null, JSON.stringify(permissions)]
    );
    return sendSuccess(res, { id: result.insertId }, "创建权限模板成功");
  } catch (error) {
    next(error);
  }
});

router.put("/templates/:id", requireUserPermission("user:permission"), async (req, res, next) => {
  try {
    await ensurePermissionTables();
    const id = Number(req.params.id || 0);
    const name = String(req.body.name || "").trim();
    const description = String(req.body.description || "").trim();
    const permissions = normalizePermissionCodes(req.body.permissions || []);
    if (!id) return sendFail(res, "模板ID无效", 400);
    if (!name) return sendFail(res, "模板名称不能为空", 400);
    const [rows] = await pool.execute("SELECT id, is_system FROM permission_templates WHERE id = ? LIMIT 1", [id]);
    if (!rows.length) return sendFail(res, "模板不存在", 404);
    if (Number(rows[0].is_system) === 1) return sendFail(res, "系统模板不允许修改", 400);
    await pool.execute(
      "UPDATE permission_templates SET name = ?, description = ?, permissions = CAST(? AS JSON) WHERE id = ?",
      [name, description || null, JSON.stringify(permissions), id]
    );
    return sendSuccess(res, null, "更新权限模板成功");
  } catch (error) {
    next(error);
  }
});

router.delete("/templates/:id", requireUserPermission("user:permission"), async (req, res, next) => {
  try {
    await ensurePermissionTables();
    const id = Number(req.params.id || 0);
    if (!id) return sendFail(res, "模板ID无效", 400);
    const [rows] = await pool.execute("SELECT id, is_system FROM permission_templates WHERE id = ? LIMIT 1", [id]);
    if (!rows.length) return sendFail(res, "模板不存在", 404);
    if (Number(rows[0].is_system) === 1) return sendFail(res, "系统模板不允许删除", 400);
    await pool.execute("UPDATE permission_templates SET status = 0 WHERE id = ?", [id]);
    return sendSuccess(res, null, "删除权限模板成功");
  } catch (error) {
    next(error);
  }
});

module.exports = router;
