/**
 * 报表导出（Excel）
 * 使用 exceljs 生成 .xlsx 文件
 */

const express = require("express");
const ExcelJS = require("exceljs");
const { pool } = require("../config/db");
const { auth, requireUserPermission, buildStoreScope } = require("../middleware/auth");
const { sendFail } = require("../utils/response");
const { formatDateYmd } = require("../utils/date");
const { toInt } = require("../utils/pagination");
const { ROLE_ADMIN } = require("../config/constants");
const { createTables } = require("../install/schema");

const router = express.Router();

let schemaPromise = null;
function ensureSchema() {
  if (!schemaPromise) {
    schemaPromise = createTables(pool).catch((error) => {
      schemaPromise = null;
      throw error;
    });
  }
  return schemaPromise;
}

function setCommonHeaders(res, filename) {
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
}

// ═══════════════════════════════════════════════════
// 1. 客户档案导出
// ═══════════════════════════════════════════════════
router.get("/customers", auth(), requireUserPermission("report:customer"), async (req, res, next) => {
  try {
    await ensureSchema();
    const user = req.user;
    const scope = buildStoreScope(user, "c.store_id");
    const status = req.query.status === "" || req.query.status == null ? null : toInt(req.query.status, -1);
    const where = [scope.sql];
    const params = [...scope.params];
    if (status === 0 || status === 1) { where.push("c.status = ?"); params.push(status); }

    const [rows] = await pool.query(
      `SELECT c.customer_no, c.child_name, c.gender, c.birthday, c.parent_name, c.parent_phone,
        s.store_name, c.training_project, c.total_times, c.used_times, c.remaining_times,
        c.open_card_date, c.expire_date, c.status, c.tags, c.remark, c.created_at
      FROM customers c LEFT JOIN stores s ON s.id = c.store_id
      WHERE ${where.join(" AND ")} ORDER BY c.id DESC LIMIT 10000`,
      params,
    );

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("客户档案");

    sheet.columns = [
      { header: "客户编号", key: "customer_no", width: 16 },
      { header: "孩子姓名", key: "child_name", width: 12 },
      { header: "性别", key: "gender", width: 8 },
      { header: "生日", key: "birthday", width: 12 },
      { header: "家长姓名", key: "parent_name", width: 12 },
      { header: "家长电话", key: "parent_phone", width: 14 },
      { header: "门店", key: "store_name", width: 16 },
      { header: "训练项目", key: "training_project", width: 16 },
      { header: "总次数", key: "total_times", width: 10 },
      { header: "已使用", key: "used_times", width: 10 },
      { header: "剩余", key: "remaining_times", width: 10 },
      { header: "开卡日期", key: "open_card_date", width: 12 },
      { header: "到期日期", key: "expire_date", width: 12 },
      { header: "状态", key: "status", width: 8 },
      { header: "标签", key: "tags", width: 20 },
      { header: "备注", key: "remark", width: 20 },
      { header: "建档日期", key: "created_at", width: 18 },
    ];

    for (const row of rows) {
      sheet.addRow({
        ...row,
        gender: row.gender === 1 ? "男" : row.gender === 2 ? "女" : "",
        status: row.status === 1 ? "正常" : "停用",
        remaining_times: row.remaining_times ?? (Number(row.total_times || 0) - Number(row.used_times || 0)),
      });
    }

    // 表头样式
    const headerRow = sheet.getRow(1);
    headerRow.font = { bold: true };
    headerRow.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE0E0E0" } };

    const filename = `客户档案_${formatDateYmd(new Date())}.xlsx`;
    setCommonHeaders(res, filename);
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════
// 2. 核销记录导出
// ═══════════════════════════════════════════════════
router.get("/verify-records", auth(), requireUserPermission("report:record"), async (req, res, next) => {
  try {
    await ensureSchema();
    const user = req.user;
    const scope = buildStoreScope(user, "vr.store_id");
    const startDate = String(req.query.startDate || "").trim();
    const endDate = String(req.query.endDate || "").trim();

    const where = ["vr.revoked = 0", scope.sql];
    const params = [...scope.params];
    if (startDate) { where.push("vr.verify_date >= ?"); params.push(startDate); }
    if (endDate) { where.push("vr.verify_date <= ?"); params.push(endDate); }

    const [rows] = await pool.query(
      `SELECT vr.verify_no, vr.verify_date, vr.verify_time, vr.child_name, vr.training_project,
        vr.card_name, vr.card_sale_price, vr.operator_name, vr.remark, vr.created_at, s.store_name
      FROM verify_records vr LEFT JOIN stores s ON s.id = vr.store_id
      WHERE ${where.join(" AND ")} ORDER BY vr.verify_time DESC LIMIT 50000`,
      params,
    );

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("核销记录");

    sheet.columns = [
      { header: "核销单号", key: "verify_no", width: 26 },
      { header: "核销日期", key: "verify_date", width: 12 },
      { header: "核销时间", key: "verify_time", width: 20 },
      { header: "孩子姓名", key: "child_name", width: 12 },
      { header: "训练项目", key: "training_project", width: 16 },
      { header: "卡项名称", key: "card_name", width: 16 },
      { header: "成交价", key: "card_sale_price", width: 10 },
      { header: "门店", key: "store_name", width: 16 },
      { header: "操作人", key: "operator_name", width: 12 },
      { header: "备注", key: "remark", width: 20 },
      { header: "创建时间", key: "created_at", width: 20 },
    ];

    for (const row of rows) {
      sheet.addRow({
        ...row,
        card_sale_price: row.card_sale_price != null ? Number(row.card_sale_price) : "",
      });
    }

    const headerRow = sheet.getRow(1);
    headerRow.font = { bold: true };
    headerRow.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE0E0E0" } };

    const filename = `核销记录_${formatDateYmd(new Date())}.xlsx`;
    setCommonHeaders(res, filename);
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════
// 3. 数据汇总导出（统计+清单在一个文件的多sheet）
// ═══════════════════════════════════════════════════
router.get("/summary", auth(), requireUserPermission("report:summary"), async (req, res, next) => {
  try {
    await ensureSchema();
    const user = req.user;
    const scope = buildStoreScope(user, "store_id");

    const workbook = new ExcelJS.Workbook();
    workbook.creator = "视光门店核销管理系统";

    // Sheet 1: 门店统计
    if (Number(user.role) === ROLE_ADMIN) {
      const [storeRows] = await pool.query(
        `SELECT s.store_name, COUNT(DISTINCT c.id) AS customer_count, COUNT(DISTINCT vr.id) AS verify_count
         FROM stores s
         LEFT JOIN customers c ON c.store_id = s.id
         LEFT JOIN verify_records vr ON vr.store_id = s.id AND vr.revoked = 0
         GROUP BY s.id, s.store_name ORDER BY s.id`,
      );

      const sheet = workbook.addWorksheet("门店统计");
      sheet.columns = [
        { header: "门店名称", key: "store_name", width: 20 },
        { header: "客户数", key: "customer_count", width: 12 },
        { header: "核销次数", key: "verify_count", width: 12 },
      ];
      for (const row of storeRows) sheet.addRow(row);
      sheet.getRow(1).font = { bold: true };
    }

    // Sheet 2: 即将到期客户
    const [expireRows] = await pool.query(
      `SELECT c.child_name, c.parent_phone, c.training_project, c.remaining_times, c.expire_date, s.store_name
       FROM customers c LEFT JOIN stores s ON s.id = c.store_id
       WHERE c.status = 1 AND c.has_card = 1 AND c.expire_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
         AND ${scope.sql}
       ORDER BY c.expire_date ASC LIMIT 1000`,
      scope.params,
    );

    if (expireRows.length) {
      const sheet2 = workbook.addWorksheet("即将到期客户");
      sheet2.columns = [
        { header: "孩子姓名", key: "child_name", width: 12 },
        { header: "家长电话", key: "parent_phone", width: 14 },
        { header: "训练项目", key: "training_project", width: 16 },
        { header: "剩余次数", key: "remaining_times", width: 10 },
        { header: "到期日期", key: "expire_date", width: 12 },
        { header: "门店", key: "store_name", width: 16 },
      ];
      for (const row of expireRows) sheet2.addRow(row);
      sheet2.getRow(1).font = { bold: true };
    }

    const filename = `数据汇总_${formatDateYmd(new Date())}.xlsx`;
    setCommonHeaders(res, filename);
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    next(error);
  }
});

module.exports = router;
