const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const controller = require("../controllers/tool.controller");

const router = express.Router();

router.get("/openapi", controller.getOpenApiSpec);
router.get("/meta", auth(), requireUserPermission("tool:meta"), controller.getToolMeta);

module.exports = router;
