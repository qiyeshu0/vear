const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const {
  listStores,
  getStoreDetail,
  createStore,
  updateStore,
  deleteStore,
  getStoreOptions
} = require("../controllers/store.controller");

const router = express.Router();
router.use(auth());

router.get("/options", requireUserPermission("store:view"), getStoreOptions);
router.get("/", requireUserPermission("store:view"), listStores);
router.get("/:id", requireUserPermission("store:view"), getStoreDetail);
router.post("/", requireUserPermission("store:create"), createStore);
router.put("/:id", requireUserPermission("store:update"), updateStore);
router.delete("/:id", requireUserPermission("store:delete"), deleteStore);

module.exports = router;
