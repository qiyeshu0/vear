const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const controller = require("../controllers/api-key.controller");

const router = express.Router();
router.use(auth());

router.get("/meta", requireUserPermission("api-key:view"), controller.getApiKeyMeta);
router.get("/stats", requireUserPermission("api-key:view"), controller.getApiKeyStats);
router.get("/", requireUserPermission("api-key:view"), controller.getApiKeyList);
router.get("/:id/logs", requireUserPermission("api-key:logs"), controller.getApiKeyLogs);
router.post("/", requireUserPermission("api-key:create"), controller.createApiKey);
router.put("/:id", requireUserPermission("api-key:update"), controller.updateApiKey);
router.patch("/:id/status", requireUserPermission("api-key:status"), controller.updateApiKeyStatus);
router.post("/:id/rotate", requireUserPermission("api-key:rotate"), controller.rotateApiKey);
router.delete("/:id", requireUserPermission("api-key:delete"), controller.deleteApiKey);

module.exports = router;
