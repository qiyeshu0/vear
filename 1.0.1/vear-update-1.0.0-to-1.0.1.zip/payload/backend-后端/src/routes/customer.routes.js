const express = require("express");
const { pool } = require("../config/db");
const { auth, requireUserPermission, buildStoreScope } = require("../middleware/auth");
const { sendSuccess, sendFail } = require("../utils/response");
const { syncCustomerCardSnapshot } = require("../utils/customer-card");
const { writeOperationLog } = require("../utils/operation-log");
const { createTables } = require("../install/schema");
const customerController = require("../controllers/customer.controller");

const router = express.Router();

async function ensureRefundRecordsTable(connection = pool) {
  await createTables(connection);
  await connection.query(`
    CREATE TABLE IF NOT EXISTS ` + '`refund_records`' + ` (
      ` + '`id`' + ` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
      ` + '`customer_id`' + ` bigint unsigned NOT NULL COMMENT '客户ID',
      ` + '`customer_card_id`' + ` bigint unsigned DEFAULT NULL COMMENT '客户卡ID',
      ` + '`original_times`' + ` int NOT NULL DEFAULT 0 COMMENT '原总次数',
      ` + '`used_times`' + ` int NOT NULL DEFAULT 0 COMMENT '已用次数',
      ` + '`refund_times`' + ` int NOT NULL DEFAULT 0 COMMENT '退还次数',
      ` + '`refund_amount`' + ` decimal(10,2) DEFAULT NULL COMMENT '退款金额',
      ` + '`reason`' + ` varchar(500) DEFAULT NULL COMMENT '退卡原因',
      ` + '`operator_id`' + ` bigint unsigned DEFAULT NULL COMMENT '操作人ID',
      ` + '`operator_name`' + ` varchar(50) DEFAULT NULL COMMENT '操作人姓名',
      ` + '`created_at`' + ` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (` + '`id`' + `),
      KEY ` + '`idx_refund_customer_id`' + ` (` + '`customer_id`' + `),
      KEY ` + '`idx_refund_card_id`' + ` (` + '`customer_card_id`' + `),
      KEY ` + '`idx_refund_created_at`' + ` (` + '`created_at`' + `)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退卡退款记录表'
  `);
}

function formatLocalDate(date = new Date()) {
  return `${date.getFullYear()}-${`${date.getMonth() + 1}`.padStart(2, "0")}-${`${date.getDate()}`.padStart(2, "0")}`;
}

function formatLocalDateTime(date = new Date()) {
  return `${formatLocalDate(date)} ${`${date.getHours()}`.padStart(2, "0")}:${`${date.getMinutes()}`.padStart(2, "0")}:${`${date.getSeconds()}`.padStart(2, "0")}`;
}

function generateRefundNo() {
  const now = new Date();
  return "RF" +
    now.getFullYear() +
    `${now.getMonth() + 1}`.padStart(2, "0") +
    `${now.getDate()}`.padStart(2, "0") +
    `${now.getHours()}`.padStart(2, "0") +
    `${now.getMinutes()}`.padStart(2, "0") +
    `${now.getSeconds()}`.padStart(2, "0") +
    `${now.getMilliseconds()}`.padStart(3, "0") +
    `${Math.floor(Math.random() * 90000) + 10000}`;
}

function normalizeRefundAmount(value) {
  if (value === undefined || value === null || value === "") return null;
  const num = Number(value);
  if (!Number.isFinite(num) || num < 0) return undefined;
  return Math.round(num * 100) / 100;
}

async function insertRefundVerifyRecordWithRetry(connection, payload, maxRetries = 3) {
  let lastError = null;

  for (let attempt = 0; attempt < maxRetries; attempt += 1) {
    const refundNo = generateRefundNo();
    try {
      await connection.execute(
        `
          INSERT INTO verify_records
          (verify_no, customer_id, customer_card_id, store_id, child_name, training_project,
           card_name, card_sale_price, verify_date, verify_time, operator_id, operator_name, remark)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [
          refundNo,
          payload.customerId,
          payload.customerCardId || null,
          payload.storeId,
          payload.childName,
          "退卡",
          payload.cardName || null,
          payload.cardSalePrice ?? null,
          payload.verifyDate,
          payload.verifyTime,
          payload.operatorId,
          payload.operatorName,
          payload.remark || null,
        ],
      );
      return refundNo;
    } catch (error) {
      lastError = error;
      if (error && error.code === "ER_DUP_ENTRY") continue;
      throw error;
    }
  }

  throw lastError || new Error("创建退卡单号失败");
}

router.use(auth());

// 基础数据
router.get("/options", requireUserPermission("customer:view"), customerController.getCustomerOptions);
router.get("/tags", requireUserPermission("customer:view"), customerController.getCustomerTags);
router.get("/stats", requireUserPermission("customer:view"), customerController.getCustomerStats);
router.get("/glasses-deliveries", requireUserPermission("customer:glasses"), customerController.getCustomerGlassesDeliveryList);

// 附件相关
router.post("/:id/attachments", requireUserPermission("customer:attachment"), customerController.uploadCustomerAttachments);
router.delete(
  "/:id/attachments/:attachmentId",
  requireUserPermission("customer:attachment"),
  customerController.deleteCustomerAttachment
);

// 绑定手机号
router.get("/:id/phones", requireUserPermission("customer:view"), customerController.getCustomerPhones);
router.post("/:id/phones", requireUserPermission("customer:phone"), customerController.addCustomerPhone);
router.patch("/:id/phones/:phoneId/primary", requireUserPermission("customer:phone"), customerController.setCustomerPhonePrimary);
router.patch("/:id/phones/:phoneId/status", requireUserPermission("customer:phone"), customerController.updateCustomerPhoneStatus);

// 续卡
router.post("/:id/open-card", requireUserPermission("customer:card:open"), customerController.openCustomerCard);
router.post("/:id/renew", requireUserPermission("customer:card:renew"), customerController.renewCustomer);
router.post("/:id/activity-cards", requireUserPermission("customer:activity-card"), customerController.createCustomerActivityCard);
router.post(
  "/:id/activity-cards/:cardId/consume",
  requireUserPermission("customer:activity-card"),
  customerController.consumeCustomerActivityCard
);
router.post("/:id/follow-ups", requireUserPermission("customer:follow"), customerController.createCustomerFollowUp);
router.post("/:id/visit-checks", requireUserPermission("customer:visit"), customerController.createCustomerVisitCheck);
router.post("/:id/glasses-records", requireUserPermission("customer:glasses"), customerController.createCustomerGlassesRecord);
router.patch("/:id/glasses-records/:recordId/status", requireUserPermission("customer:glasses"), customerController.updateCustomerGlassesStatus);

// 列表与详情
router.get("/", requireUserPermission("customer:view"), customerController.getCustomerList);
router.get("/:id", requireUserPermission("customer:view"), customerController.getCustomerDetail);

// 新增、编辑、删除
router.post("/", requireUserPermission("customer:create"), customerController.createCustomer);
router.put("/:id", requireUserPermission("customer:update"), customerController.updateCustomer);
router.patch("/:id/status", requireUserPermission("customer:status"), customerController.updateCustomerStatus);
router.delete("/:id", requireUserPermission("customer:delete"), customerController.deleteCustomer);

// ── 退卡退款 ──
router.post("/:id/refund", requireUserPermission("customer:refund"), async (req, res, next) => {
  const connection = await pool.getConnection();

  try {
    await ensureRefundRecordsTable(connection);
    const customerId = parseInt(req.params.id, 10) || 0;
    const cardIdToUse = parseInt(req.body.cardId, 10) || 0;
    const normalizedRefundAmount = normalizeRefundAmount(req.body.refundAmount);
    const reason = String(req.body.reason || "").trim().slice(0, 500);
    const user = req.user;

    if (!customerId) {
      connection.release();
      return sendFail(res, "参数错误", 400);
    }

    if (normalizedRefundAmount === undefined) {
      connection.release();
      return sendFail(res, "退款金额必须为大于等于0的数字", 400, {
        errorCode: "INVALID_REFUND_AMOUNT",
      });
    }

    await connection.beginTransaction();

    const scope = buildStoreScope(user, "c");
    const [[customer]] = await connection.query(
      `
        SELECT
          c.id,
          c.child_name,
          c.customer_no,
          c.store_id,
          c.total_times,
          c.used_times,
          c.training_project,
          c.remark,
          c.has_card,
          c.status
        FROM customers c
        WHERE c.id = ?
          AND ${scope.sql}
        LIMIT 1
        FOR UPDATE
      `,
      [customerId, ...scope.params],
    );

    if (!customer) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "客户不存在或无权限操作", 404);
    }

    const cardWhere = [
      "cc.customer_id = ?",
      "cc.status = 1",
      "COALESCE(cc.is_promotion, ct.is_promotion, 0) = 0",
    ];
    const cardParams = [customerId];
    if (cardIdToUse) {
      cardWhere.push("cc.id = ?");
      cardParams.push(cardIdToUse);
    }

    const [formalCards] = await connection.query(
      `
        SELECT
          cc.id,
          cc.customer_id,
          cc.card_name_snapshot,
          cc.training_project,
          cc.sale_price,
          cc.total_times,
          cc.used_times,
          cc.remaining_times,
          cc.status,
          COALESCE(cc.is_promotion, ct.is_promotion, 0) AS is_promotion
        FROM customer_cards cc
        LEFT JOIN card_templates ct ON ct.id = cc.card_template_id
        WHERE ${cardWhere.join(" AND ")}
        ORDER BY
          CASE WHEN cc.remaining_times > 0 AND (cc.expire_date IS NULL OR cc.expire_date >= CURDATE()) THEN 0 ELSE 1 END ASC,
          cc.open_card_date DESC,
          cc.id DESC
        FOR UPDATE
      `,
      cardParams,
    );

    if (cardIdToUse && !formalCards.length) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "所选卡项不存在、已退卡、已停用或不是正式卡", 404, {
        errorCode: "CARD_NOT_FOUND",
      });
    }

    if (!cardIdToUse && formalCards.length > 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "该客户存在多张正式卡，请先选择要退的卡项", 400, {
        errorCode: "REQUIRE_CARD_SELECTION",
        cards: formalCards.map((item) => ({
          id: Number(item.id || 0),
          cardName: item.card_name_snapshot || "",
          trainingProject: item.training_project || "",
          totalTimes: Number(item.total_times || 0),
          usedTimes: Number(item.used_times || 0),
          remainingTimes: Number(item.remaining_times || 0),
        })),
      });
    }

    const effectiveCard = formalCards[0] || null;
    const originalTotal = Number(effectiveCard ? effectiveCard.total_times : customer.total_times) || 0;
    const used = Number(effectiveCard ? effectiveCard.used_times : customer.used_times) || 0;
    const refundTimes = originalTotal - used;

    if (refundTimes <= 0) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "无可退次数", 400, {
        errorCode: "NO_REFUNDABLE_TIMES",
      });
    }

    if (effectiveCard) {
      const [cardUpdateResult] = await connection.execute(
        `
          UPDATE customer_cards
          SET status = 0,
              updated_by = ?
          WHERE id = ?
            AND customer_id = ?
            AND status = 1
            AND COALESCE(is_promotion, 0) = 0
        `,
        [user.userId, effectiveCard.id, customerId],
      );

      if (Number(cardUpdateResult.affectedRows || 0) !== 1) {
        await connection.rollback();
        connection.release();
        return sendFail(res, "卡项状态已变化，请刷新后重试", 409, {
          errorCode: "CARD_STATE_CHANGED",
        });
      }

      await syncCustomerCardSnapshot(connection, customerId, user.userId);

      const [[snapshot]] = await connection.query(
        "SELECT has_card FROM customers WHERE id = ? LIMIT 1 FOR UPDATE",
        [customerId],
      );
      if (Number(snapshot?.has_card || 0) !== 1) {
        await connection.execute(
          "UPDATE customers SET status = 0, updated_by = ? WHERE id = ?",
          [user.userId, customerId],
        );
      }
    } else {
      const [customerUpdateResult] = await connection.execute(
        `
          UPDATE customers
          SET has_card = 0,
              status = 0,
              training_project = NULL,
              total_times = ?,
              expire_date = NULL,
              updated_by = ?
          WHERE id = ?
        `,
        [used, user.userId, customerId],
      );

      if (Number(customerUpdateResult.affectedRows || 0) !== 1) {
        await connection.rollback();
        connection.release();
        return sendFail(res, "客户状态已变化，请刷新后重试", 409, {
          errorCode: "CUSTOMER_STATE_CHANGED",
        });
      }
    }

    const now = new Date();
    const dateStr = formatLocalDate(now);
    const verifyTime = formatLocalDateTime(now);
    const amountText = normalizedRefundAmount != null ? `，退款¥${normalizedRefundAmount}` : "";
    const reasonText = reason ? `，原因：${reason}` : "";
    const refundNote = `\n[${dateStr}] 退卡：${refundTimes}次${amountText}${reasonText}`;
    const newRemark = `${customer.remark || ""}${refundNote}`;

    await connection.execute(
      "UPDATE customers SET remark = ?, updated_by = ? WHERE id = ?",
      [newRemark, user.userId, customerId],
    );

    await connection.execute(
      "INSERT INTO refund_records (customer_id, customer_card_id, original_times, used_times, refund_times, refund_amount, reason, operator_id, operator_name) VALUES (?,?,?,?,?,?,?,?,?)",
      [
        customerId,
        effectiveCard ? effectiveCard.id : null,
        originalTotal,
        used,
        refundTimes,
        normalizedRefundAmount,
        reason || null,
        user.userId,
        user.realName,
      ],
    );

    const refundNo = await insertRefundVerifyRecordWithRetry(connection, {
      customerId,
      customerCardId: effectiveCard ? effectiveCard.id : null,
      storeId: Number(customer.store_id || 0),
      childName: customer.child_name,
      cardName: effectiveCard?.card_name_snapshot || null,
      cardSalePrice: effectiveCard?.sale_price ?? null,
      verifyDate: dateStr,
      verifyTime,
      operatorId: user.userId,
      operatorName: user.realName,
      remark: `退${refundTimes}次${amountText}${reason ? `，${reason}` : ""}`,
    });

    await writeOperationLog(connection, {
      operatorId: user.userId,
      operatorName: user.realName,
      operatorRole: user.role,
      storeId: Number(customer.store_id || 0),
      module: "customer",
      action: "refund",
      bizType: "customer_refund",
      bizId: customerId,
      bizNo: customer.customer_no,
      content: `退卡：${customer.child_name}，退${refundTimes}次${amountText}${reasonText}`,
      ip: req.ip || "",
      userAgent: String(req.headers["user-agent"] || "").slice(0, 500),
    });

    await connection.commit();
    connection.release();
    return sendSuccess(res, {
      refundTimes,
      refundAmount: normalizedRefundAmount,
      reason,
      refundNo,
      customerCardId: effectiveCard ? Number(effectiveCard.id || 0) : null,
    }, "退卡成功");
  } catch (error) {
    await connection.rollback().catch(() => {});
    connection.release();
    next(error);
  }
});

module.exports = router;
