const express = require("express");
const { toInt } = require("../utils/pagination");
const {
  auth,
  requireUserPermission,
  ROLE_ADMIN,
  ROLE_OWNER,
  ROLE_MANAGER,
} = require("../middleware/auth");
const { pool } = require("../config/db");
const { sendPage, sendSuccess, sendFail } = require("../utils/response");
const { toCamelCase } = require("../utils/case");

const router = express.Router();


function buildDateRange(startDate, endDate, fieldName = "l.created_at") {
  const conditions = [];
  const params = [];

  if (startDate) {
    conditions.push(`${fieldName} >= ?`);
    params.push(`${startDate} 00:00:00`);
  }

  if (endDate) {
    conditions.push(`${fieldName} <= ?`);
    params.push(`${endDate} 23:59:59`);
  }

  return { conditions, params };
}

// 日志列表：管理员看全部，店长看本店
router.get(
  "/",
  auth(),
  requireUserPermission("log:view"),
  async (req, res, next) => {
    try {
      const pageNum = toInt(req.query.pageNum, 1);
      const pageSize = toInt(req.query.pageSize, 10);
      const offset = (pageNum - 1) * pageSize;

      const keyword = String(req.query.keyword || "").trim();
      const moduleName = String(req.query.module || "").trim();
      const action = String(req.query.action || "").trim();
      const bizType = String(req.query.bizType || "").trim();
      const startDate = String(req.query.startDate || "").trim();
      const endDate = String(req.query.endDate || "").trim();
      const storeId = toInt(req.query.storeId, 0);

      const where = [];
      const params = [];

      if ([ROLE_OWNER, ROLE_MANAGER].includes(req.user.role)) {
        where.push("l.store_id = ?");
        params.push(Number(req.user.storeId));
      } else if (req.user.role === ROLE_ADMIN && storeId > 0) {
        where.push("l.store_id = ?");
        params.push(storeId);
      }

      if (keyword) {
        where.push(
          "(l.operator_name LIKE ? OR l.content LIKE ? OR l.biz_no LIKE ?)",
        );
        params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
      }

      if (moduleName) {
        where.push("l.module = ?");
        params.push(moduleName);
      }

      if (action) {
        where.push("l.action = ?");
        params.push(action);
      }

      if (bizType) {
        where.push("l.biz_type = ?");
        params.push(bizType);
      }

      const { conditions: dateConditions, params: dateParams } = buildDateRange(
        startDate,
        endDate,
      );
      where.push(...dateConditions);
      params.push(...dateParams);

      const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

      const countSql = `
      SELECT COUNT(*) AS total
      FROM operation_logs l
      ${whereSql}
    `;

      const listSql = `
      SELECT
        l.id,
        l.operator_id,
        l.operator_name,
        l.operator_role,
        l.store_id,
        s.store_name,
        l.module,
        l.action,
        l.biz_type,
        l.biz_id,
        l.biz_no,
        l.content,
        l.ip,
        l.user_agent,
        l.created_at
      FROM operation_logs l
      LEFT JOIN stores s ON s.id = l.store_id
      ${whereSql}
      ORDER BY l.id DESC
      LIMIT ? OFFSET ?
    `;

      const [[countRow]] = await pool.query(countSql, params);
      const [list] = await pool.query(listSql, [...params, pageSize, offset]);

      return sendPage(
        res,
        toCamelCase(list),
        Number(countRow.total || 0),
        pageNum,
        pageSize,
      );
    } catch (error) {
      return next(error);
    }
  },
);

// 日志筛选项
router.get(
  "/meta/options",
  auth(),
  requireUserPermission("log:view"),
  async (req, res, next) => {
    try {
      const scopeParams = [];
      let scopeSql = "";

      if ([ROLE_OWNER, ROLE_MANAGER].includes(req.user.role)) {
        scopeSql = "WHERE l.store_id = ?";
        scopeParams.push(Number(req.user.storeId));
      }

      const [modules] = await pool.query(
        `
      SELECT DISTINCT l.module
      FROM operation_logs l
      ${scopeSql}
      ORDER BY l.module ASC
      `,
        scopeParams,
      );

      const [actions] = await pool.query(
        `
      SELECT DISTINCT l.action
      FROM operation_logs l
      ${scopeSql}
      ORDER BY l.action ASC
      `,
        scopeParams,
      );

      const [bizTypes] = await pool.query(
        `
      SELECT DISTINCT l.biz_type
      FROM operation_logs l
      ${scopeSql}
      ORDER BY l.biz_type ASC
      `,
        scopeParams,
      );

      return sendSuccess(
        res,
        {
          modules: modules.map((item) => item.module).filter(Boolean),
          actions: actions.map((item) => item.action).filter(Boolean),
          bizTypes: bizTypes.map((item) => item.biz_type).filter(Boolean),
        },
        "查询成功",
      );
    } catch (error) {
      return next(error);
    }
  },
);

// 日志详情
router.get(
  "/:id",
  auth(),
  requireUserPermission("log:view"),
  async (req, res, next) => {
    try {
      const id = toInt(req.params.id, 0);
      if (!id) {
        return sendFail(res, "日志ID无效", 400);
      }

      const params = [id];
      let extraSql = "";

      if ([ROLE_OWNER, ROLE_MANAGER].includes(req.user.role)) {
        extraSql = " AND l.store_id = ?";
        params.push(Number(req.user.storeId));
      }

      const sql = `
      SELECT
        l.id,
        l.operator_id,
        l.operator_name,
        l.operator_role,
        l.store_id,
        s.store_name,
        l.module,
        l.action,
        l.biz_type,
        l.biz_id,
        l.biz_no,
        l.content,
        l.ip,
        l.user_agent,
        l.created_at
      FROM operation_logs l
      LEFT JOIN stores s ON s.id = l.store_id
      WHERE l.id = ?
      ${extraSql}
      LIMIT 1
    `;

      const [rows] = await pool.query(sql, params);

      if (!rows.length) {
        return sendFail(res, "日志不存在", 404);
      }

      return sendSuccess(res, toCamelCase(rows[0]), "查询成功");
    } catch (error) {
      return next(error);
    }
  },
);

module.exports = router;
