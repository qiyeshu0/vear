const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const controller = require("../controllers/visit.controller");

const router = express.Router();

router.use(auth());

router.get("/meta", requireUserPermission("visit:view"), controller.getVisitMeta);
// 员工端快捷登记是全员基础能力，数据范围仍由 controller 内的门店作用域限制。
router.get("/customer-options", controller.getVisitCustomerOptions);
router.get("/summary", requireUserPermission("visit:view"), controller.getVisitSummary);
router.get("/export", requireUserPermission("visit:export"), controller.exportVisitList);
router.get("/", requireUserPermission("visit:view"), controller.getVisitList);
router.post("/", controller.createVisit);
router.get("/:id", requireUserPermission("visit:view"), controller.getVisitDetail);
router.put("/:id", requireUserPermission("visit:update"), controller.updateVisit);
router.post("/:id/start", requireUserPermission("visit:complete"), controller.startVisit);
router.post("/:id/complete", requireUserPermission("visit:complete"), controller.completeVisit);
router.post("/:id/cancel", requireUserPermission("visit:cancel"), controller.cancelVisit);

module.exports = router;
