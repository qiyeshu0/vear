const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const { sendSuccess, sendFail } = require("../utils/response");
const { writeOperationLog } = require("../utils/operation-log");
const { pool } = require("../config/db");
const {
  getRuntimeConfigForClient,
  saveRuntimeConfig,
  writeEnvPatch,
} = require("../utils/runtime-config");
const { getSmsConfig, saveSmsConfig } = require("../services/sms.service");
const { clearWechatCache } = require("../services/wechat.service");

const router = express.Router();
router.use(auth());

router.get("/", requireUserPermission("system:view"), async (_req, res, next) => {
  try {
    const runtime = await getRuntimeConfigForClient();
    const sms = await getSmsConfig({ maskSecret: true });
    return sendSuccess(res, { runtime, sms }, "获取运行配置成功");
  } catch (error) { next(error); }
});

router.put("/", requireUserPermission("system:update"), async (req, res, next) => {
  try {
    const result = await saveRuntimeConfig(req.body || {}, req.user || {});
    if (result.changed.some(item => String(item.key).startsWith("wechat."))) clearWechatCache();
    await writeOperationLog(pool, {
      operatorId: req.user.userId,
      operatorName: req.user.realName || req.user.username,
      operatorRole: req.user.role,
      storeId: Number(req.user.storeId || 0),
      module: "system",
      action: "save_runtime_config",
      bizType: "runtime_config",
      bizId: 1,
      bizNo: "runtime_config",
      content: `保存运行配置：${result.changed.map(item => item.label).join("、") || "无变更"}`,
      ip: req.ip || "",
      userAgent: String(req.headers["user-agent"] || "").slice(0, 500),
    });
    return sendSuccess(res, result, result.restartRequired ? "保存成功，部分配置需重启服务后生效" : "保存成功，配置已热更新");
  } catch (error) { next(error); }
});

router.put("/sms", requireUserPermission("sms:config"), async (req, res, next) => {
  try {
    const config = await saveSmsConfig(req.body || {}, req.user || {});
    await writeOperationLog(pool, {
      operatorId: req.user.userId,
      operatorName: req.user.realName || req.user.username,
      operatorRole: req.user.role,
      storeId: Number(req.user.storeId || 0),
      module: "system",
      action: "save_runtime_sms_config",
      bizType: "sms_config",
      bizId: 1,
      bizNo: config.provider,
      content: `在运行配置中心保存短信配置【${config.provider}】`,
      ip: req.ip || "",
      userAgent: String(req.headers["user-agent"] || "").slice(0, 500),
    });
    return sendSuccess(res, config, "短信配置已热更新");
  } catch (error) {
    if (error.statusCode) return sendFail(res, error.message, error.statusCode);
    next(error);
  }
});

router.post("/write-env", requireUserPermission("system:update"), async (req, res, next) => {
  try {
    const allowedKeys = [
      "WX_LOGIN_MOCK", "WX_APPID", "WX_APPSECRET", "WX_SUBSCRIBE_TEMPLATE_ID", "WX_GLASSES_TEMPLATE_ID",
      "WX_LOW_TIMES_TEMPLATE_ID", "WX_EXPIRE_SOON_TEMPLATE_ID", "WX_FOLLOWUP_TEMPLATE_ID",
      "MINIPROGRAM_TITLE", "MINIPROGRAM_SUBTITLE", "MINIPROGRAM_ENABLE_STAFF_HIDDEN_ENTRY",
      "MINIPROGRAM_SHOW_GLASSES_PROGRESS", "MINIPROGRAM_SHOW_TRAINING_CARD",
      "MINIPROGRAM_HOME_GLASSES_KEEP_DAYS", "MINIPROGRAM_HOME_RECENT_VERIFY_LIMIT", "MINIPROGRAM_HOME_GLASSES_LIMIT",
      "WEATHER_ENABLED", "WEATHER_PROVIDER", "WEATHER_API_URL", "WEATHER_API_KEY", "WEATHER_API_KEY_HEADER",
      "WEATHER_LOCATION_NAME", "WEATHER_CITY", "WEATHER_ADCODE", "WEATHER_LATITUDE", "WEATHER_LONGITUDE", "WEATHER_CUSTOM_MAPPING",
      "WEATHER_REVERSE_GEOCODE_ENABLED", "WEATHER_REVERSE_GEOCODE_URL",
      "PUBLIC_BASE_URL", "MINIPROGRAM_API_BASE", "JWT_EXPIRES_IN", "UPLOAD_DIR", "UPLOAD_MAX_SIZE",
      "SMS_PROVIDER", "SMS_MOCK", "SMS_SIGN_NAME", "ALIYUN_SMS_ACCESS_KEY_ID",
      "ALIYUN_SMS_ACCESS_KEY_SECRET", "ALIYUN_SMS_ENDPOINT", "CORS_ORIGIN",
    ];
    const input = req.body || {};
    const patch = {};
    for (const key of allowedKeys) {
      if (Object.prototype.hasOwnProperty.call(input, key)) patch[key] = input[key];
    }
    const ok = writeEnvPatch(patch);
    return sendSuccess(res, { written: ok, keys: Object.keys(patch) }, ok ? "已写入 .env" : ".env 不存在，未写入");
  } catch (error) { next(error); }
});

module.exports = router;
