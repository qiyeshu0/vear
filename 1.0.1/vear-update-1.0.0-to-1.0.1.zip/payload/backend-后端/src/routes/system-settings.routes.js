const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const { sendSuccess, sendFail } = require("../utils/response");
const { getSettingsMap, saveSettings } = require("../utils/system-settings");

const router = express.Router();

// 登录页、浏览器标题、侧边栏 Logo 需要在未登录时读取系统名称。
// 只暴露展示类配置，不暴露业务阈值和备注。
router.get("/public", async (_req, res) => {
  try {
    const settings = await getSettingsMap();
    return sendSuccess(res, {
      systemName: settings.system_name,
    }, "获取公开系统设置成功");
  } catch (error) {
    return sendFail(res, "获取公开系统设置失败", 500);
  }
});

router.use(auth());

router.get("/", requireUserPermission("system:view"), async (_req, res) => {
  try {
    const settings = await getSettingsMap();
    return sendSuccess(res, {
      systemName: settings.system_name,
      soonExpireDays: settings.soon_expire_days,
      lowTimesThreshold: settings.low_times_threshold,
      remark: settings.remark || "",
    }, "获取系统设置成功");
  } catch (error) {
    return sendFail(res, "获取系统设置失败", 500);
  }
});

router.put("/", requireUserPermission("system:update"), async (req, res) => {
  try {
    const result = await saveSettings({
      systemName: req.body.systemName,
      soonExpireDays: req.body.soonExpireDays,
      lowTimesThreshold: req.body.lowTimesThreshold,
      remark: req.body.remark,
    });
    return sendSuccess(res, result, "保存系统设置成功");
  } catch (error) {
    return sendFail(res, "保存系统设置失败", 500);
  }
});

module.exports = router;
