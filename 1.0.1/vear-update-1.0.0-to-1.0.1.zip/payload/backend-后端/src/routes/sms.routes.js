const express = require("express");
const { pool } = require("../config/db");
const { auth, requireUserPermission, buildStoreScope } = require("../middleware/auth");
const { sendSuccess, sendFail, sendPage } = require("../utils/response");
const { toInt } = require("../utils/pagination");
const { writeOperationLog } = require("../utils/operation-log");
const {
  ensureSmsSchema,
  createTaskNo,
  normalizePhone,
  maskPhone,
  isValidPhone,
  sanitizeText,
  safeJsonParse,
  replaceTemplate,
  buildTemplateParams,
  getSmsConfig,
  saveSmsConfig,
  getProviderOptions,
  SMS_VARIABLE_DEFINITIONS,
  sendSms,
} = require("../services/sms.service");

const router = express.Router();
router.use(auth());

function parseVariables(input) {
  if (Array.isArray(input)) return input.map(v => String(v || "").trim()).filter(Boolean);
  if (typeof input === "string") {
    try {
      const parsed = JSON.parse(input);
      if (Array.isArray(parsed)) return parsed.map(v => String(v || "").trim()).filter(Boolean);
    } catch {}
    return input.split(/[,，\s]+/).map(v => v.trim()).filter(Boolean);
  }
  return [];
}

function formatTemplate(row) {
  return {
    id: Number(row.id),
    templateName: row.template_name || "",
    templateType: row.template_type || "service",
    provider: row.provider || "aliyun",
    providerTemplateId: row.provider_template_id || "",
    signName: row.sign_name || "",
    content: row.content || "",
    variables: safeJsonParse(row.variables, []),
    status: Number(row.status || 0),
    remark: row.remark || "",
    createdBy: row.created_by ? Number(row.created_by) : null,
    createdByName: row.created_by_name || "",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function formatRecord(row) {
  return {
    id: Number(row.id),
    taskId: row.task_id ? Number(row.task_id) : null,
    templateId: row.template_id ? Number(row.template_id) : null,
    customerId: row.customer_id ? Number(row.customer_id) : null,
    childName: row.child_name || "",
    parentPhone: row.parent_phone || "",
    maskedPhone: row.masked_phone || maskPhone(row.parent_phone),
    smsType: row.sms_type || "service",
    provider: row.provider || "aliyun",
    signName: row.sign_name || "",
    providerTemplateId: row.provider_template_id || "",
    providerRequestId: row.provider_request_id || "",
    content: row.content || "",
    templateParams: safeJsonParse(row.template_params, {}),
    sendStatus: Number(row.send_status || 0),
    failReason: row.fail_reason || "",
    operatorId: row.operator_id ? Number(row.operator_id) : null,
    operatorName: row.operator_name || "",
    sentAt: row.sent_at,
    createdAt: row.created_at,
  };
}

function formatTask(row) {
  return {
    id: Number(row.id),
    taskNo: row.task_no,
    taskName: row.task_name || "",
    templateId: row.template_id ? Number(row.template_id) : null,
    smsType: row.sms_type || "service",
    sendType: row.send_type || "manual",
    targetType: row.target_type || "selected",
    totalCount: Number(row.total_count || 0),
    successCount: Number(row.success_count || 0),
    failCount: Number(row.fail_count || 0),
    status: Number(row.status || 0),
    operatorId: row.operator_id ? Number(row.operator_id) : null,
    operatorName: row.operator_name || "",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function isMarketingType(type) {
  return ["marketing", "promotion", "activity"].includes(String(type || "").trim());
}

async function getTemplateById(id) {
  const [[row]] = await pool.query("SELECT * FROM sms_templates WHERE id = ? LIMIT 1", [id]);
  return row || null;
}

async function getCustomersByIds(req, ids = []) {
  const cleanIds = Array.from(new Set((ids || []).map(id => Number(id)).filter(Boolean))).slice(0, 500);
  if (!cleanIds.length) return [];
  const scope = buildStoreScope(req.user, "c.store_id");
  const marks = cleanIds.map(() => "?").join(",");
  const [rows] = await pool.query(
    `SELECT c.id, c.child_name, c.parent_name, c.parent_phone, c.store_id, s.store_name,
      c.training_project, c.total_times, c.used_times, c.remaining_times, c.expire_date,
      COALESCE(p.allow_service_sms, 1) AS allow_service_sms,
      COALESCE(p.allow_marketing_sms, 0) AS allow_marketing_sms,
      COALESCE(p.unsubscribed, 0) AS unsubscribed,
      vr.last_verify_date
     FROM customers c
     LEFT JOIN stores s ON s.id = c.store_id
     LEFT JOIN customer_sms_preferences p ON p.customer_id = c.id
     LEFT JOIN (
       SELECT customer_id, MAX(verify_date) AS last_verify_date
       FROM verify_records
       WHERE revoked = 0
       GROUP BY customer_id
     ) vr ON vr.customer_id = c.id
     WHERE c.id IN (${marks}) AND c.status = 1 AND ${scope.sql}`,
    [...cleanIds, ...scope.params]
  );
  return rows;
}

async function getCustomersByFilter(req, filter = {}) {
  const scope = buildStoreScope(req.user, "c.store_id");
  const where = ["c.status = 1", scope.sql];
  const params = [...scope.params];
  const keyword = String(filter.keyword || "").trim();
  const targetType = String(filter.targetType || "selected").trim();
  const limit = Math.min(Math.max(toInt(filter.limit, 200), 1), 500);

  if (keyword) {
    where.push("(c.child_name LIKE ? OR c.parent_phone LIKE ? OR c.parent_name LIKE ?)");
    params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
  }
  if (targetType === "lowTimes") {
    where.push("c.has_card = 1 AND c.remaining_times > 0 AND c.remaining_times <= ?");
    params.push(toInt(filter.lowTimesThreshold, 5));
  } else if (targetType === "expired") {
    where.push("c.has_card = 1 AND c.expire_date < CURDATE()");
  } else if (targetType === "soonExpire") {
    where.push("c.has_card = 1 AND c.expire_date >= CURDATE() AND c.expire_date <= DATE_ADD(CURDATE(), INTERVAL ? DAY)");
    params.push(toInt(filter.soonExpireDays, 15));
  }

  const [rows] = await pool.query(
    `SELECT c.id, c.child_name, c.parent_name, c.parent_phone, c.store_id, s.store_name,
      c.training_project, c.total_times, c.used_times, c.remaining_times, c.expire_date,
      COALESCE(p.allow_service_sms, 1) AS allow_service_sms,
      COALESCE(p.allow_marketing_sms, 0) AS allow_marketing_sms,
      COALESCE(p.unsubscribed, 0) AS unsubscribed,
      vr.last_verify_date
     FROM customers c
     LEFT JOIN stores s ON s.id = c.store_id
     LEFT JOIN customer_sms_preferences p ON p.customer_id = c.id
     LEFT JOIN (
       SELECT customer_id, MAX(verify_date) AS last_verify_date
       FROM verify_records
       WHERE revoked = 0
       GROUP BY customer_id
     ) vr ON vr.customer_id = c.id
     WHERE ${where.join(" AND ")}
     ORDER BY c.id DESC
     LIMIT ?`,
    [...params, limit]
  );
  return rows;
}

function buildVars(customer, extra = {}) {
  return {
    childName: customer.child_name || "",
    parentName: customer.parent_name || "",
    parentPhone: customer.parent_phone || "",
    storeName: customer.store_name || "",
    trainingProject: customer.training_project || "",
    totalTimes: Number(customer.total_times || 0),
    usedTimes: Number(customer.used_times || 0),
    remainingTimes: customer.remaining_times == null ? "" : Number(customer.remaining_times || 0),
    expireDate: customer.expire_date || "",
    lastVerifyDate: customer.last_verify_date || "",
    ...extra,
  };
}

router.get("/config", requireUserPermission("sms:view"), async (_req, res, next) => {
  try {
    const config = await getSmsConfig({ maskSecret: true });
    return sendSuccess(res, config, "获取短信配置成功");
  } catch (error) { next(error); }
});

router.put("/config", requireUserPermission("sms:config"), async (req, res, next) => {
  try {
    const config = await saveSmsConfig(req.body || {}, req.user || {});
    await writeOperationLog(pool, {
      operatorId: req.user.userId, operatorName: req.user.realName || req.user.username, operatorRole: req.user.role,
      storeId: Number(req.user.storeId || 0), module: "sms", action: "save_config", bizType: "sms_config", bizId: 1, bizNo: config.provider,
      content: `保存短信服务商配置【${config.provider}】`, ip: req.ip || "", userAgent: String(req.headers["user-agent"] || "").slice(0, 500)
    });
    return sendSuccess(res, config, "保存短信配置成功");
  } catch (error) {
    if (error.statusCode) return sendFail(res, error.message, error.statusCode);
    next(error);
  }
});

router.get("/meta", requireUserPermission("sms:view"), async (_req, res, next) => {
  try {
    const config = await getSmsConfig({ maskSecret: true });
    return sendSuccess(res, {
      providers: config.providers || getProviderOptions(config.provider),
      variables: SMS_VARIABLE_DEFINITIONS,
      currentProvider: config.provider,
    }, "获取短信元信息成功");
  } catch (error) { next(error); }
});

router.get("/templates", requireUserPermission("sms:view"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const pageNum = toInt(req.query.pageNum, 1);
    const pageSize = toInt(req.query.pageSize, 20);
    const offset = (pageNum - 1) * pageSize;
    const keyword = String(req.query.keyword || "").trim();
    const status = req.query.status === "" || req.query.status == null ? null : toInt(req.query.status, -1);
    const where = [];
    const params = [];
    if (keyword) { where.push("(template_name LIKE ? OR content LIKE ?)"); params.push(`%${keyword}%`, `%${keyword}%`); }
    if (status === 0 || status === 1) { where.push("status = ?"); params.push(status); }
    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
    const [[count]] = await pool.query(`SELECT COUNT(*) AS total FROM sms_templates ${whereSql}`, params);
    const [rows] = await pool.query(`SELECT * FROM sms_templates ${whereSql} ORDER BY id DESC LIMIT ? OFFSET ?`, [...params, pageSize, offset]);
    return sendPage(res, rows.map(formatTemplate), Number(count.total || 0), pageNum, pageSize);
  } catch (error) { next(error); }
});

router.post("/templates", requireUserPermission("sms:template"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const name = sanitizeText(req.body.templateName, 100);
    const type = sanitizeText(req.body.templateType || "service", 50);
    const provider = sanitizeText(req.body.provider || "aliyun", 30);
    const providerTemplateId = sanitizeText(req.body.providerTemplateId, 100) || null;
    const signName = sanitizeText(req.body.signName, 100) || null;
    const content = sanitizeText(req.body.content, 500);
    const variables = parseVariables(req.body.variables);
    const status = toInt(req.body.status, 1) === 0 ? 0 : 1;
    const remark = sanitizeText(req.body.remark, 500) || null;
    if (!name || !content) return sendFail(res, "模板名称和内容不能为空", 400);
    const [result] = await pool.execute(
      `INSERT INTO sms_templates (template_name, template_type, provider, provider_template_id, sign_name, content, variables, status, remark, created_by, created_by_name)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [name, type, provider, providerTemplateId, signName, content, JSON.stringify(variables), status, remark, req.user.userId || null, req.user.realName || req.user.username || ""]
    );
    return sendSuccess(res, { id: result.insertId }, "创建短信模板成功");
  } catch (error) { next(error); }
});

router.put("/templates/:id", requireUserPermission("sms:template"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const id = toInt(req.params.id, 0);
    if (!id) return sendFail(res, "模板ID无效", 400);
    const name = sanitizeText(req.body.templateName, 100);
    const type = sanitizeText(req.body.templateType || "service", 50);
    const provider = sanitizeText(req.body.provider || "aliyun", 30);
    const providerTemplateId = sanitizeText(req.body.providerTemplateId, 100) || null;
    const signName = sanitizeText(req.body.signName, 100) || null;
    const content = sanitizeText(req.body.content, 500);
    const variables = parseVariables(req.body.variables);
    const status = toInt(req.body.status, 1) === 0 ? 0 : 1;
    const remark = sanitizeText(req.body.remark, 500) || null;
    if (!name || !content) return sendFail(res, "模板名称和内容不能为空", 400);
    await pool.execute(
      `UPDATE sms_templates SET template_name=?, template_type=?, provider=?, provider_template_id=?, sign_name=?, content=?, variables=?, status=?, remark=? WHERE id=?`,
      [name, type, provider, providerTemplateId, signName, content, JSON.stringify(variables), status, remark, id]
    );
    return sendSuccess(res, null, "保存短信模板成功");
  } catch (error) { next(error); }
});

router.patch("/templates/:id/status", requireUserPermission("sms:template"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const id = toInt(req.params.id, 0);
    const status = toInt(req.body.status, 1) === 0 ? 0 : 1;
    await pool.execute("UPDATE sms_templates SET status = ? WHERE id = ?", [status, id]);
    return sendSuccess(res, null, "状态已更新");
  } catch (error) { next(error); }
});

router.get("/records", requireUserPermission("sms:view"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const pageNum = toInt(req.query.pageNum, 1);
    const pageSize = toInt(req.query.pageSize, 20);
    const offset = (pageNum - 1) * pageSize;
    const keyword = String(req.query.keyword || "").trim();
    const customerId = toInt(req.query.customerId, 0);
    const status = req.query.sendStatus === "" || req.query.sendStatus == null ? null : toInt(req.query.sendStatus, -1);
    const where = [];
    const params = [];
    if (keyword) { where.push("(child_name LIKE ? OR parent_phone LIKE ? OR content LIKE ?)"); params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`); }
    if (customerId) { where.push("customer_id = ?"); params.push(customerId); }
    if ([0,1,2].includes(status)) { where.push("send_status = ?"); params.push(status); }
    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
    const [[count]] = await pool.query(`SELECT COUNT(*) AS total FROM sms_records ${whereSql}`, params);
    const [rows] = await pool.query(`SELECT * FROM sms_records ${whereSql} ORDER BY id DESC LIMIT ? OFFSET ?`, [...params, pageSize, offset]);
    return sendPage(res, rows.map(formatRecord), Number(count.total || 0), pageNum, pageSize);
  } catch (error) { next(error); }
});

router.get("/tasks", requireUserPermission("sms:view"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const pageNum = toInt(req.query.pageNum, 1);
    const pageSize = toInt(req.query.pageSize, 20);
    const offset = (pageNum - 1) * pageSize;
    const [[count]] = await pool.query("SELECT COUNT(*) AS total FROM sms_tasks");
    const [rows] = await pool.query("SELECT * FROM sms_tasks ORDER BY id DESC LIMIT ? OFFSET ?", [pageSize, offset]);
    return sendPage(res, rows.map(formatTask), Number(count.total || 0), pageNum, pageSize);
  } catch (error) { next(error); }
});

router.post("/preview", requireUserPermission("sms:view"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const templateId = toInt(req.body.templateId, 0);
    const customerId = toInt(req.body.customerId, 0);
    const extraVars = req.body.variables || {};
    const template = templateId ? await getTemplateById(templateId) : null;
    if (!template) return sendFail(res, "请选择短信模板", 400);
    const customers = customerId ? await getCustomersByIds(req, [customerId]) : [];
    const vars = buildVars(customers[0] || {}, extraVars);
    return sendSuccess(res, { content: replaceTemplate(template.content, vars), variables: vars }, "预览成功");
  } catch (error) { next(error); }
});


async function executeSend(req, targets, options = {}) {
  const templateId = toInt(options.templateId ?? req.body.templateId, 0);
  const taskName = sanitizeText(options.taskName ?? req.body.taskName, 100) || "手动发送短信";
  const targetType = options.targetType || "selected";
  const extraVars = options.variables || req.body.variables || {};
  const template = templateId ? await getTemplateById(templateId) : null;
  if (!template || Number(template.status) !== 1) {
    const error = new Error("短信模板不存在或已停用");
    error.statusCode = 400;
    throw error;
  }
  if (!targets.length) {
    const error = new Error("请选择客户或填写手机号");
    error.statusCode = 400;
    throw error;
  }

  const uniqueTargets = [];
  const seen = new Set();
  for (const customer of targets) {
    const phoneKey = normalizePhone(customer.parent_phone || customer.phone || "");
    const dedupeKey = phoneKey || `customer:${Number(customer.id || 0)}`;
    if (!dedupeKey || seen.has(dedupeKey)) continue;
    seen.add(dedupeKey);
    uniqueTargets.push(customer);
  }

  targets = uniqueTargets;
  if (!targets.length) {
    const error = new Error("有效发送对象为空，请检查手机号或筛选条件");
    error.statusCode = 400;
    throw error;
  }

  const taskNo = createTaskNo();
  const [taskResult] = await pool.execute(
    `INSERT INTO sms_tasks (task_no, task_name, template_id, sms_type, send_type, target_type, total_count, status, operator_id, operator_name)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`,
    [taskNo, taskName, template.id, template.template_type, options.sendType || "manual", targetType, targets.length, req.user.userId || null, req.user.realName || req.user.username || ""]
  );
  const taskId = taskResult.insertId;

  let successCount = 0;
  let failCount = 0;
  const records = [];
  const envConfig = await getSmsConfig();

  for (const customer of targets) {
    const phone = normalizePhone(customer.parent_phone);
    const vars = buildVars(customer, extraVars);
    const content = replaceTemplate(template.content, vars);
    const params = buildTemplateParams(vars);
    let failReason = "";
    if (!isValidPhone(phone)) failReason = "手机号格式不正确";
    if (!failReason && Number(customer.unsubscribed || 0) === 1) failReason = "客户已退订短信";
    if (!failReason && isMarketingType(template.template_type) && Number(customer.allow_marketing_sms || 0) !== 1) failReason = "客户未授权营销短信";
    if (!failReason && !isMarketingType(template.template_type) && Number(customer.allow_service_sms || 1) !== 1) failReason = "客户未授权服务短信";

    let result = { ok: false, message: failReason };
    if (!failReason) {
      result = await sendSms({
        provider: template.provider || "aliyun",
        phone,
        signName: template.sign_name || envConfig.signName,
        templateCode: template.provider_template_id || "",
        params,
      });
    }
    const ok = Boolean(result.ok);
    if (ok) successCount += 1; else failCount += 1;
    const [recordResult] = await pool.execute(
      `INSERT INTO sms_records (task_id, template_id, customer_id, child_name, parent_phone, masked_phone, sms_type, provider, sign_name, provider_template_id, provider_request_id, content, template_params, send_status, fail_reason, operator_id, operator_name, sent_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ${ok ? "NOW()" : "NULL"})`,
      [taskId, template.id, customer.id || null, customer.child_name || "", phone, maskPhone(phone), template.template_type, template.provider || "aliyun", template.sign_name || envConfig.signName || "", template.provider_template_id || "", result.requestId || "", content, JSON.stringify(params), ok ? 1 : 2, ok ? null : (result.message || "发送失败"), req.user.userId || null, req.user.realName || req.user.username || ""]
    );
    records.push({ id: recordResult.insertId, phone: maskPhone(phone), ok, message: ok ? "发送成功" : (result.message || "发送失败") });
  }

  const taskStatus = successCount && failCount ? 3 : successCount ? 2 : 4;
  await pool.execute("UPDATE sms_tasks SET success_count=?, fail_count=?, status=? WHERE id=?", [successCount, failCount, taskStatus, taskId]);
  await writeOperationLog(pool, {
    operatorId: req.user.userId, operatorName: req.user.realName || req.user.username, operatorRole: req.user.role,
    storeId: Number(req.user.storeId || 0), module: "sms", action: options.sendType === "batch" ? "batch_send" : "send", bizType: "sms_task", bizId: taskId, bizNo: taskNo,
    content: `发送短信任务【${taskName}】，成功${successCount}条，失败${failCount}条`, ip: req.ip || "", userAgent: String(req.headers["user-agent"] || "").slice(0, 500)
  });

  return { taskId, taskNo, total: targets.length, successCount, failCount, records };
}

router.post("/send", requireUserPermission("sms:send"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const customerIds = Array.isArray(req.body.customerIds) ? req.body.customerIds : [];
    const directPhone = normalizePhone(req.body.phone);
    let targets = [];
    let targetType = "selected";
    if (customerIds.length) {
      targets = await getCustomersByIds(req, customerIds);
    } else if (directPhone) {
      targets = [{ id: null, child_name: sanitizeText(req.body.childName, 100), parent_phone: directPhone, allow_service_sms: 1, allow_marketing_sms: 0, unsubscribed: 0 }];
      targetType = "phone";
    }
    const result = await executeSend(req, targets, { targetType, sendType: "manual" });
    return sendSuccess(res, result, "短信发送完成");
  } catch (error) {
    if (error.statusCode) return sendFail(res, error.message, error.statusCode);
    next(error);
  }
});

router.post("/batch-send", requireUserPermission("sms:batch-send"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const filter = req.body.filter || {};
    const filterLimit = Math.min(Math.max(toInt(filter.limit, 200), 1), 500);
    if (filter.confirmTotal == null || Number(filter.confirmTotal) !== Number(filterLimit)) {
      return sendFail(res, "批量发送前请先确认目标人数，避免误发", 400);
    }
    const customers = await getCustomersByFilter(req, filter);
    if (!customers.length) return sendFail(res, "筛选结果为空，无法发送", 400);
    const result = await executeSend(req, customers, { targetType: filter.targetType || "filter", sendType: "batch", taskName: req.body.taskName || "批量发送短信", variables: req.body.variables || {} });
    return sendSuccess(res, result, "批量短信发送完成");
  } catch (error) {
    if (error.statusCode) return sendFail(res, error.message, error.statusCode);
    next(error);
  }
});

router.get("/customer/:customerId/preferences", requireUserPermission("sms:view"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const customerId = toInt(req.params.customerId, 0);
    const customers = await getCustomersByIds(req, [customerId]);
    if (!customers.length) return sendFail(res, "客户不存在或无权限查看", 404);
    const [[row]] = await pool.query("SELECT * FROM customer_sms_preferences WHERE customer_id = ? LIMIT 1", [customerId]);
    return sendSuccess(res, row ? {
      customerId,
      allowServiceSms: Number(row.allow_service_sms || 0) === 1,
      allowMarketingSms: Number(row.allow_marketing_sms || 0) === 1,
      unsubscribed: Number(row.unsubscribed || 0) === 1,
      remark: row.remark || "",
    } : { customerId, allowServiceSms: true, allowMarketingSms: false, unsubscribed: false, remark: "" }, "获取成功");
  } catch (error) { next(error); }
});

router.put("/customer/:customerId/preferences", requireUserPermission("sms:send"), async (req, res, next) => {
  try {
    await ensureSmsSchema();
    const customerId = toInt(req.params.customerId, 0);
    if (!customerId) return sendFail(res, "客户ID无效", 400);
    const customers = await getCustomersByIds(req, [customerId]);
    if (!customers.length) return sendFail(res, "客户不存在或无权限操作", 404);
    const allowService = req.body.allowServiceSms === false ? 0 : 1;
    const allowMarketing = req.body.allowMarketingSms === true ? 1 : 0;
    const unsubscribed = req.body.unsubscribed === true ? 1 : 0;
    const remark = sanitizeText(req.body.remark, 500) || null;
    await pool.execute(
      `INSERT INTO customer_sms_preferences (customer_id, allow_service_sms, allow_marketing_sms, unsubscribed, remark)
       VALUES (?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE allow_service_sms=VALUES(allow_service_sms), allow_marketing_sms=VALUES(allow_marketing_sms), unsubscribed=VALUES(unsubscribed), remark=VALUES(remark)`,
      [customerId, allowService, allowMarketing, unsubscribed, remark]
    );
    return sendSuccess(res, null, "短信授权设置已保存");
  } catch (error) { next(error); }
});

module.exports = router;
