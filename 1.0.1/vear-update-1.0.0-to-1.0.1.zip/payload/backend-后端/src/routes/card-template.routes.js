const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const controller = require("../controllers/card-template.controller");

const router = express.Router();
router.use(auth());

router.get("/options", controller.getCardTemplateOptions);
router.get("/", requireUserPermission("card-template:view"), controller.getCardTemplateList);
router.post("/", requireUserPermission("card-template:create"), controller.createCardTemplate);
router.put("/:id", requireUserPermission("card-template:update"), controller.updateCardTemplate);
router.patch("/:id/status", requireUserPermission("card-template:status"), controller.updateCardTemplateStatus);
router.delete("/:id", requireUserPermission("card-template:delete"), controller.deleteCardTemplate);

module.exports = router;
