const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const verifyController = require("../controllers/verify.controller");

const router = express.Router();
router.use(auth());

router.get("/customers/options", requireUserPermission("verify:view"), verifyController.getVerifyCustomerOptions);
router.get("/today", requireUserPermission("verify:view"), verifyController.getTodayVerifyRecords);
router.post("/", requireUserPermission("verify:create"), verifyController.createVerifyRecord);

module.exports = router;
