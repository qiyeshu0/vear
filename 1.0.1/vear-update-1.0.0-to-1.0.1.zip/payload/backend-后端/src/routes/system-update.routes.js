const express = require("express");
const { auth, requireUserPermission, adminOnly } = require("../middleware/auth");
const { sendSuccess, sendFail } = require("../utils/response");
const updateService = require("../services/system-update.service");
const { writeOperationLog } = require("../utils/operation-log");

const router = express.Router();
router.use(auth());

function action(permission, handler, successMessage) {
  return [requireUserPermission(permission), adminOnly, async (req, res) => {
    try {
      const data = await handler(req);
      await writeOperationLog(req, { module: "system-update", action: permission.split(":").pop(), bizType: "system_update", bizNo: data?.latestVersion || data?.toVersion || "", content: successMessage }).catch(() => {});
      return sendSuccess(res, data, successMessage);
    } catch (error) {
      return sendFail(res, error.message || successMessage + "失败", 400);
    }
  }];
}

router.get("/overview", requireUserPermission("system-update:view"), async (_req, res) => {
  try { return sendSuccess(res, await updateService.getOverview(), "获取系统版本信息成功"); }
  catch (error) { return sendFail(res, `获取系统版本信息失败：${error.message}`, 500); }
});
router.put("/config", ...action("system-update:config", req => updateService.saveConfig(req.body || {}), "保存更新设置成功"));
router.post("/check", ...action("system-update:check", async () => updateService.sanitizePublicUpdateState(await updateService.checkForUpdates()), "检查更新完成"));
router.post("/download", ...action("system-update:download", async () => updateService.sanitizePublicUpdateState(await updateService.downloadUpdate()), "更新包下载并校验成功"));
router.post("/apply", ...action("system-update:apply", async req => updateService.sanitizePublicUpdateState(await updateService.applyUpdate(req.user)), "更新文件安装完成"));
router.post("/rollback", ...action("system-update:rollback", req => updateService.rollbackLastUpdate(req.user), "更新代码回滚完成"));
router.post("/restart", ...action("system-update:restart", async () => {
  if (!process.env.pm_id) return { restarted: false, restartRequired: true, command: "npm start", message: "当前不是 PM2 托管，请在服务器终端手动重启" };
  setTimeout(() => process.exit(0), 800);
  return { restarted: true, restartRequired: false, message: "PM2 将自动重启服务" };
}, "已提交服务重启"));

module.exports = router;
