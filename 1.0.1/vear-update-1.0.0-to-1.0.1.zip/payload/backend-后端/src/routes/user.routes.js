const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const userController = require("../controllers/user.controller");

const router = express.Router();

router.use(auth());

router.get("/profile", userController.getProfile);
router.put("/profile", userController.updateProfile);
router.put("/profile/password", userController.updateMyPassword);

router.get("/", requireUserPermission("user:view"), userController.getUserList);
router.get("/registrations", requireUserPermission("user:registration:view"), userController.getRegistrationList);
router.post("/registrations/:id/approve", requireUserPermission("user:registration:audit"), userController.approveRegistration);
router.post("/registrations/:id/reject", requireUserPermission("user:registration:audit"), userController.rejectRegistration);
router.get("/:id", requireUserPermission("user:view"), userController.getUserDetail);
router.post("/", requireUserPermission("user:create"), userController.createUser);
router.put("/:id", requireUserPermission("user:update"), userController.updateUser);
router.patch("/:id/status", requireUserPermission("user:status"), userController.updateUserStatus);
router.delete("/:id", requireUserPermission("user:delete"), userController.deleteUser);
router.put("/:id/password", requireUserPermission("user:password"), userController.resetUserPassword);

module.exports = router;
