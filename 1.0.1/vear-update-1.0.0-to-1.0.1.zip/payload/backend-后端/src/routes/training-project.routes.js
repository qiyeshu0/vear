const express = require("express");
const { auth, requireUserPermission } = require("../middleware/auth");
const controller = require("../controllers/training-project.controller");

const router = express.Router();
router.use(auth());

router.get("/options", controller.getProjectOptions);
router.get("/", requireUserPermission("training:view"), controller.getProjectList);
router.post("/", requireUserPermission("training:create"), controller.createProject);
router.put("/:id", requireUserPermission("training:update"), controller.updateProject);
router.patch("/:id/status", requireUserPermission("training:status"), controller.updateProjectStatus);
router.delete("/:id", requireUserPermission("training:delete"), controller.deleteProject);

module.exports = router;
