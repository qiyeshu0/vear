const express = require("express");
const multer = require("multer");
const { auth, requireUserPermission, adminOnly } = require("../middleware/auth");
const controller = require("../controllers/data-center.controller");

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    // 备份包往往包含附件，默认放宽到 1GB；正式环境可用 BACKUP_UPLOAD_MAX_SIZE 调整。
    fileSize: Number(process.env.BACKUP_UPLOAD_MAX_SIZE || 1024 * 1024 * 1024),
  },
});

router.use(auth(), adminOnly);

router.get("/summary", requireUserPermission("data-center:view"), controller.getDataCenterSummary);

router.get("/backup/export", requireUserPermission("data-center:backup"), controller.exportSystemBackup);
router.post("/backup/precheck", requireUserPermission("data-center:restore"), upload.single("file"), controller.precheckBackupFile);
router.post("/backup/restore", requireUserPermission("data-center:restore"), upload.single("file"), controller.restoreSystemBackup);

router.get("/auto-backup/config", requireUserPermission("data-center:view"), controller.getAutoBackupConfig);
router.put("/auto-backup/config", requireUserPermission("data-center:auto-backup"), controller.saveAutoBackupConfig);
router.post("/auto-backup/run", requireUserPermission("data-center:backup"), controller.runAutoBackupNow);

router.get("/backup/files", requireUserPermission("data-center:view"), controller.listBackupFiles);
router.get("/backup/files/download", requireUserPermission("data-center:download"), controller.downloadBackupFile);
router.delete("/backup/files", requireUserPermission("data-center:delete"), controller.deleteBackupFile);

router.post("/attachments/import", requireUserPermission("data-center:attachment"), upload.single("file"), controller.importAttachmentArchive);

module.exports = router;
