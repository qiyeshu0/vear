const express = require("express");
const router = express.Router();
const installController = require("../controllers/install.controller");

// 检查安装状态
router.get("/status", installController.checkInstallStatus);

// 测试数据库连接
router.post("/test-db", installController.testDbConnection);

// 检测数据库是否可复用
router.post("/inspect-db", installController.inspectDb);

// 执行安装
router.post("/do", installController.doInstall);

module.exports = router;
