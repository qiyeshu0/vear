const express = require("express");
const { pool } = require("../config/db");
const { auth, requireUserPermission, buildStoreScope } = require("../middleware/auth");
const { sendSuccess, sendFail } = require("../utils/response");
const { syncCustomerCardSnapshot } = require("../utils/customer-card");
const { writeOperationLog } = require("../utils/operation-log");
const { createTables } = require("../install/schema");
const recordController = require("../controllers/record.controller");

const router = express.Router();

let revokeRequestTableReady = null;
function ensureRevokeRequestTable() {
  if (!revokeRequestTableReady) {
    revokeRequestTableReady = (async () => {
      await createTables(pool);
      await pool.query(`
      CREATE TABLE IF NOT EXISTS revoke_requests (
        id int NOT NULL AUTO_INCREMENT,
        verify_record_id int NOT NULL,
        requested_by int NOT NULL DEFAULT 0,
        requested_by_name varchar(100) DEFAULT NULL,
        reason varchar(500) DEFAULT NULL,
        status tinyint NOT NULL DEFAULT 0 COMMENT '0待审批 1通过 2拒绝',
        reviewed_by int DEFAULT NULL,
        reviewed_by_name varchar(100) DEFAULT NULL,
        review_note varchar(500) DEFAULT NULL,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_revoke_requests_record (verify_record_id),
        KEY idx_revoke_requests_status (status),
        KEY idx_revoke_requests_created (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    })().catch((error) => {
      revokeRequestTableReady = null;
      throw error;
    });
  }
  return revokeRequestTableReady;
}

router.use(auth());

router.get("/", requireUserPermission("record:view"), recordController.getRecordList);
router.get("/export", requireUserPermission("record:export"), recordController.exportRecordList);

// ── 撤回申请（店员/店长提交 → 管理员审批）──

// 管理员查看待审批列表。固定路径必须放在 /:id 前，避免被详情路由截获。
router.get("/revoke-requests/pending", requireUserPermission("record:revoke:approve"), async (req, res, next) => {
  try {
    await ensureRevokeRequestTable();
    const user = req.user;
    const scope = buildStoreScope(user, "vr");
    const [rows] = await pool.query(
      `SELECT r.id, r.verify_record_id, r.requested_by_name, r.reason, r.status, r.created_at,
        vr.verify_no, vr.child_name, vr.training_project, vr.verify_date, vr.verify_time, vr.store_id
      FROM revoke_requests r
      INNER JOIN verify_records vr ON vr.id = r.verify_record_id
      WHERE r.status = 0
        AND ${scope.sql}
      ORDER BY r.created_at DESC LIMIT 50`,
      [...scope.params],
    );
    return sendSuccess(res, rows, "获取成功");
  } catch (error) { next(error); }
});

// 当前登录员工发起过的撤回申请状态，用于小程序“审批中/已拒绝/已通过”闭环展示。
router.get("/revoke-requests/mine", requireUserPermission("record:revoke:request"), async (req, res, next) => {
  try {
    await ensureRevokeRequestTable();
    const user = req.user;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 200, 1), 500);
    const [rows] = await pool.query(
      `SELECT r.id, r.verify_record_id, r.requested_by_name, r.reason, r.status,
        r.reviewed_by_name, r.review_note, r.created_at, r.updated_at,
        vr.verify_no, vr.child_name, vr.training_project, vr.verify_date, vr.verify_time, vr.revoked
      FROM revoke_requests r
      INNER JOIN verify_records vr ON vr.id = r.verify_record_id
      WHERE r.requested_by = ?
      ORDER BY r.created_at DESC
      LIMIT ?`,
      [Number(user.userId || 0), limit],
    );
    return sendSuccess(res, rows, "获取成功");
  } catch (error) { next(error); }
});

// 管理员审批
router.post("/revoke-requests/:id/approve", requireUserPermission("record:revoke:approve"), async (req, res, next) => {
  const connection = await pool.getConnection();

  try {
    await ensureRevokeRequestTable();
    const reqId = parseInt(req.params.id) || 0;
    const approved = req.body.approved !== false;
    const note = String(req.body.note || "").trim();
    const user = req.user;
    if (!reqId) {
      connection.release();
      return sendFail(res, "参数错误", 400);
    }

    await connection.beginTransaction();

    const scope = buildStoreScope(user, "vr");
    const [[reqRow]] = await connection.query(
      `
        SELECT r.*
        FROM revoke_requests r
        INNER JOIN verify_records vr ON vr.id = r.verify_record_id
        WHERE r.id = ?
          AND r.status = 0
          AND ${scope.sql}
        LIMIT 1
        FOR UPDATE
      `,
      [reqId, ...scope.params],
    );
    if (!reqRow) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "申请不存在或已处理", 404);
    }

    const newStatus = approved ? 1 : 2;
    const [requestUpdateResult] = await connection.execute(
      "UPDATE revoke_requests SET status = ?, reviewed_by = ?, reviewed_by_name = ?, review_note = ? WHERE id = ? AND status = 0",
      [newStatus, user.userId, user.realName, note || null, reqId],
    );

    if (Number(requestUpdateResult.affectedRows || 0) !== 1) {
      await connection.rollback();
      connection.release();
      return sendFail(res, "申请已被其他人处理，请刷新后重试", 409);
    }

    let record = null;
    if (approved) {
      const [[lockedRecord]] = await connection.query(
        `
          SELECT
            vr.id,
            vr.verify_no,
            vr.customer_id,
            vr.customer_card_id,
            vr.store_id,
            vr.child_name,
            vr.training_project,
            vr.card_name,
            vr.revoked
          FROM verify_records vr
          WHERE vr.id = ?
            AND ${scope.sql}
          LIMIT 1
          FOR UPDATE
        `,
        [reqRow.verify_record_id, ...scope.params],
      );

      record = lockedRecord;
      if (!record) {
        await connection.rollback();
        connection.release();
        return sendFail(res, "核销记录不存在", 404);
      }

      if (Number(record.revoked || 0) === 1) {
        await connection.rollback();
        connection.release();
        return sendFail(res, "该记录已撤回", 400);
      }

      let timesUpdateResult;
      if (record.customer_card_id) {
        const [[usageLog]] = await connection.query(
          `
            SELECT quantity
            FROM customer_card_usage_logs
            WHERE verify_record_id = ?
              AND customer_card_id = ?
            LIMIT 1
            FOR UPDATE
          `,
          [Number(record.id || 0), Number(record.customer_card_id || 0)],
        );
        const revokeQuantity = Math.max(1, Math.trunc(Number(usageLog?.quantity || 1)));

        const [cardUpdateResult] = await connection.execute(
          `
            UPDATE customer_cards
            SET used_times = used_times - ?,
                updated_by = ?
            WHERE id = ?
              AND used_times >= ?
          `,
          [
            revokeQuantity,
            Number(user.userId || 0),
            Number(record.customer_card_id || 0),
            revokeQuantity,
          ],
        );
        timesUpdateResult = cardUpdateResult;
        await syncCustomerCardSnapshot(
          connection,
          Number(record.customer_id || 0),
          Number(user.userId || 0),
        );
      } else {
        const [customerUpdateResult] = await connection.execute(
          `
            UPDATE customers
            SET used_times = used_times - 1,
                updated_by = ?
            WHERE id = ?
              AND used_times > 0
          `,
          [Number(user.userId || 0), Number(record.customer_id || 0)],
        );
        timesUpdateResult = customerUpdateResult;
      }

      if (Number(timesUpdateResult.affectedRows || 0) !== 1) {
        await connection.rollback();
        connection.release();
        return sendFail(res, "客户次数状态异常，无法撤回本次核销", 409, {
          errorCode: "CUSTOMER_TIMES_INVALID",
        });
      }

      const [recordUpdateResult] = await connection.execute(
        `
          UPDATE verify_records
          SET revoked = 1,
              revoked_at = NOW(),
              revoked_by = ?,
              revoked_by_name = ?,
              revoke_reason = ?
          WHERE id = ?
            AND revoked = 0
        `,
        [
          Number(user.userId || 0),
          String(user.realName || ""),
          reqRow.reason || note || "管理员审批撤回",
          Number(record.id || 0),
        ],
      );

      if (Number(recordUpdateResult.affectedRows || 0) !== 1) {
        await connection.rollback();
        connection.release();
        return sendFail(res, "该记录已撤回", 400);
      }

      await writeOperationLog(connection, {
        operatorId: user.userId,
        operatorName: user.realName,
        operatorRole: user.role,
        storeId: Number(record.store_id || 0),
        module: "record",
        action: "revoke_approve",
        bizType: "verify_record",
        bizId: Number(record.id || 0),
        bizNo: record.verify_no,
        content: `审批通过撤回核销：客户【${record.child_name}】项目【${record.training_project}】${record.card_name ? `卡项【${record.card_name}】` : ""}单号【${record.verify_no}】${reqRow.reason ? `，申请原因：${reqRow.reason}` : ""}${note ? `，审批备注：${note}` : ""}`,
        ip: req.ip || "",
        userAgent: String(req.headers["user-agent"] || "").slice(0, 500),
      });
    }

    await connection.commit();
    connection.release();

    return sendSuccess(res, null, approved ? "已通过并撤回" : "已拒绝");
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore rollback error
    }
    connection.release();
    next(error);
  }
});

// 店员申请撤回
router.post("/:id/request-revoke", requireUserPermission("record:revoke:request"), async (req, res, next) => {
  try {
    await ensureRevokeRequestTable();
    const recordId = parseInt(req.params.id) || 0;
    const reason = String(req.body.reason || "").trim();
    const user = req.user;

    if (!recordId) return sendFail(res, "参数错误", 400);

    const scope = buildStoreScope(user, "vr");
    const [[record]] = await pool.query(
      `
        SELECT vr.id, vr.verify_no, vr.revoked, vr.store_id
        FROM verify_records vr
        WHERE vr.id = ?
          AND ${scope.sql}
        LIMIT 1
      `,
      [recordId, ...scope.params],
    );
    if (!record) return sendFail(res, "核销记录不存在", 404);
    if (record.revoked) return sendFail(res, "该记录已撤回", 400);

    const [[existing]] = await pool.query("SELECT id FROM revoke_requests WHERE verify_record_id = ? AND status = 0 LIMIT 1", [recordId]);
    if (existing) return sendFail(res, "已有待审批的撤回申请", 400);

    await pool.execute(
      "INSERT INTO revoke_requests (verify_record_id, requested_by, requested_by_name, reason, status) VALUES (?, ?, ?, ?, 0)",
      [recordId, user.userId || 0, user.realName || '', reason || null],
    );

    return sendSuccess(res, null, "撤回申请已提交，等待管理员审批");
  } catch (error) { next(error); }
});

router.get("/:id", requireUserPermission("record:view"), recordController.getRecordDetail);
router.post("/:id/revoke", requireUserPermission("record:revoke"), recordController.revokeRecord);

module.exports = router;
