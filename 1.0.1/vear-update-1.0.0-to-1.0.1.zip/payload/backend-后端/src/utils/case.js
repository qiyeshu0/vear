function toCamelCaseKey(key = "") {
  return String(key).replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
}

function toCamelCase(value) {
  if (Array.isArray(value)) {
    return value.map((item) => toCamelCase(item));
  }

  if (value && typeof value === "object" && !(value instanceof Date)) {
    const result = {};

    for (const [key, item] of Object.entries(value)) {
      result[toCamelCaseKey(key)] = toCamelCase(item);
    }

    return result;
  }

  return value;
}

module.exports = {
  toCamelCaseKey,
  toCamelCase,
};
