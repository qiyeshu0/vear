const { pool } = require("../config/db");
const { createTables } = require("../install/schema");

const DEFAULT_SETTINGS = {
  system_name: "视光门店核销管理系统",
  soon_expire_days: 15,
  low_times_threshold: 5,
  remark: "",
};

let settingsSchemaPromise = null;

async function ensureSettingsSchema() {
  if (!settingsSchemaPromise) {
    settingsSchemaPromise = createTables(pool).catch((error) => {
      settingsSchemaPromise = null;
      throw error;
    });
  }
  return settingsSchemaPromise;
}

function normalizeNumberSetting(value, fallback) {
  const num = Number(value);
  if (!Number.isFinite(num)) return fallback;
  return Math.max(1, Math.min(Math.floor(num), 9999));
}

async function getSettingsMap(connection = pool) {
  await ensureSettingsSchema();
  const [rows] = await connection.query(
    `
      SELECT setting_key, setting_value
      FROM system_settings
    `
  );

  const map = { ...DEFAULT_SETTINGS };
  for (const row of rows) {
    if (row.setting_key === "system_name") {
      map.system_name = String(row.setting_value || DEFAULT_SETTINGS.system_name);
    }
    if (row.setting_key === "soon_expire_days") {
      map.soon_expire_days = normalizeNumberSetting(
        row.setting_value,
        DEFAULT_SETTINGS.soon_expire_days,
      );
    }
    if (row.setting_key === "low_times_threshold") {
      map.low_times_threshold = normalizeNumberSetting(
        row.setting_value,
        DEFAULT_SETTINGS.low_times_threshold,
      );
    }
    if (row.setting_key === "remark") {
      map.remark = String(row.setting_value || "");
    }
  }

  return map;
}

async function getLowTimesThreshold(connection = pool) {
  const map = await getSettingsMap(connection);
  return map.low_times_threshold;
}

async function saveSettings(input = {}, connection = pool) {
  await ensureSettingsSchema();
  const systemName = String(input.systemName || input.system_name || DEFAULT_SETTINGS.system_name).trim() || DEFAULT_SETTINGS.system_name;
  const soonExpireDays = normalizeNumberSetting(
    input.soonExpireDays ?? input.soon_expire_days,
    DEFAULT_SETTINGS.soon_expire_days,
  );
  const lowTimesThreshold = normalizeNumberSetting(
    input.lowTimesThreshold ?? input.low_times_threshold,
    DEFAULT_SETTINGS.low_times_threshold,
  );
  const remark = String(input.remark || "").trim();

  const rows = [
    ["system_name", systemName, "系统名称"],
    ["soon_expire_days", String(soonExpireDays), "到期提醒天数"],
    ["low_times_threshold", String(lowTimesThreshold), "次数不足提醒阈值，默认小于等于5次"],
    ["remark", remark, "系统设置备注"],
  ];

  for (const row of rows) {
    await connection.query(
      `
        INSERT INTO system_settings (setting_key, setting_value, remark)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE
          setting_value = VALUES(setting_value),
          remark = VALUES(remark)
      `,
      row,
    );
  }

  return {
    systemName,
    soonExpireDays,
    lowTimesThreshold,
    remark,
  };
}

module.exports = {
  DEFAULT_SETTINGS,
  ensureSettingsSchema,
  getSettingsMap,
  getLowTimesThreshold,
  saveSettings,
};
