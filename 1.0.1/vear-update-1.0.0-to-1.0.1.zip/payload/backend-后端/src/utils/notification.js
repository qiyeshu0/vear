const { pool } = require("../config/db");

let ensureTablePromise = null;

const CREATE_NOTIFICATION_STATE_TABLE_SQL = `
  CREATE TABLE IF NOT EXISTS \`user_notification_states\` (
    \`id\` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    \`user_id\` bigint unsigned NOT NULL COMMENT '用户ID',
    \`notification_id\` varchar(100) NOT NULL COMMENT '通知唯一标识',
    \`is_read\` tinyint NOT NULL DEFAULT 0 COMMENT '是否已读',
    \`read_at\` datetime DEFAULT NULL COMMENT '已读时间',
    \`handled_at\` datetime DEFAULT NULL COMMENT '处理时间',
    \`handled_note\` varchar(255) DEFAULT NULL COMMENT '处理备注',
    \`created_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    \`updated_at\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (\`id\`),
    UNIQUE KEY \`uk_notification_user_notice\` (\`user_id\`, \`notification_id\`),
    KEY \`idx_notification_user_id\` (\`user_id\`),
    KEY \`idx_notification_is_read\` (\`is_read\`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户通知状态表'
`;

async function ensureNotificationStateTable() {
  if (!ensureTablePromise) {
    ensureTablePromise = pool.query(CREATE_NOTIFICATION_STATE_TABLE_SQL).catch((error) => {
      ensureTablePromise = null;
      throw error;
    });
  }

  await ensureTablePromise;
}

function buildNotificationStateMap(rows = []) {
  const map = new Map();
  rows.forEach((row) => {
    map.set(String(row.notification_id || ""), {
      isRead: Number(row.is_read || 0) === 1,
      readAt: row.read_at || null,
      isHandled: Boolean(row.handled_at),
      handledAt: row.handled_at || null,
      handledNote: row.handled_note || "",
    });
  });
  return map;
}

module.exports = {
  CREATE_NOTIFICATION_STATE_TABLE_SQL,
  ensureNotificationStateTable,
  buildNotificationStateMap,
};
