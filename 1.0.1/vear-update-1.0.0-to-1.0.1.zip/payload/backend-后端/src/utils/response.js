function success(data = null, message = "操作成功", code = 200) {
  return {
    code,
    success: true,
    message,
    data
  };
}

function fail(message = "操作失败", code = 400, data = null) {
  return {
    code,
    success: false,
    message,
    data
  };
}

function page(list = [], total = 0, pageNum = 1, pageSize = 10, extra = {}) {
  return {
    code: 200,
    success: true,
    message: "查询成功",
    data: {
      list,
      total,
      pageNum,
      pageSize,
      ...extra
    }
  };
}

function sendSuccess(res, data = null, message = "操作成功", code = 200) {
  return res.status(code).json(success(data, message, code));
}

function sendFail(res, message = "操作失败", code = 400, data = null) {
  return res.status(code).json(fail(message, code, data));
}

function sendPage(
  res,
  list = [],
  total = 0,
  pageNum = 1,
  pageSize = 10,
  extra = {}
) {
  return res.status(200).json(page(list, total, pageNum, pageSize, extra));
}

module.exports = {
  success,
  fail,
  page,
  sendSuccess,
  sendFail,
  sendPage
};
