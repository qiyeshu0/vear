const { ROLE_ADMIN } = require("../config/constants");

function buildStoreScope(user, fieldName = "store_id") {
  if (!user) {
    return {
      sql: "1 = 0",
      params: [],
    };
  }

  if (Number(user.role) === ROLE_ADMIN) {
    return {
      sql: "1 = 1",
      params: [],
    };
  }

  return {
    sql: `${fieldName} = ?`,
    params: [Number(user.storeId || 0)],
  };
}

module.exports = {
  buildStoreScope,
};
