const { DEFAULT_PAGE } = require("../config/constants");

/**
 * 安全转为整数
 */
function toInt(value, defaultValue = 0) {
  const num = Number(value);
  return Number.isFinite(num) ? Math.trunc(num) : defaultValue;
}

/**
 * 标准化分页参数，返回 { pageNum, pageSize, offset }
 */
function normalizePage(query = {}, maxPageSize = DEFAULT_PAGE.MAX_PAGE_SIZE) {
  const pageNum = Math.max(toInt(query.pageNum, DEFAULT_PAGE.PAGE_NUM), 1);
  const pageSize = Math.min(
    Math.max(toInt(query.pageSize, DEFAULT_PAGE.PAGE_SIZE), 1),
    maxPageSize || DEFAULT_PAGE.MAX_PAGE_SIZE,
  );
  const offset = (pageNum - 1) * pageSize;
  return { pageNum, pageSize, offset };
}

module.exports = {
  toInt,
  normalizePage,
};
