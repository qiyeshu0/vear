const { toInt } = require("./pagination");

function toMoney(value) {
  const num = Number(value);
  if (!Number.isFinite(num)) {
    return null;
  }
  return Math.round(num * 100) / 100;
}

function formatDateValue(value) {
  if (!value) return null;
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) {
    return String(value);
  }
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function normalizePriceOptionItem(item) {
  if (item == null) return "";
  if (typeof item === "number" && Number.isFinite(item)) return String(item);
  if (typeof item === "string") {
    const text = item.trim();
    if (!text || text === "[object Object]") return "";

    if ((text.startsWith("{") && text.endsWith("}")) || (text.startsWith("[") && text.endsWith("]"))) {
      try {
        const parsed = JSON.parse(text);
        if (Array.isArray(parsed)) {
          return parsed.map(normalizePriceOptionItem).filter(Boolean).join(",");
        }
        return normalizePriceOptionItem(parsed);
      } catch (error) {
        // 不是合法 JSON 时继续按普通字符串处理
      }
    }

    return text;
  }

  if (typeof item === "object") {
    const candidate =
      item.value ??
      item.label ??
      item.price ??
      item.amount ??
      item.salePrice ??
      item.name ??
      "";
    return normalizePriceOptionItem(candidate);
  }

  return String(item).trim();
}

function parsePriceOptions(value) {
  const rawItems = Array.isArray(value) ? value : String(value || "").split(/[,，|]/);
  return rawItems
    .flatMap((item) => String(normalizePriceOptionItem(item) || "").split(/[,，|]/))
    .map((item) => item.trim())
    .filter(Boolean);
}

function priceOptionsToDbString(value) {
  return parsePriceOptions(value).join(",");
}

function formatCardTemplate(row) {
  if (!row) return null;

  return {
    id: Number(row.id || 0),
    cardName: row.card_name || "",
    trainingProject: row.training_project || "",
    defaultTimes: Number(row.default_times || 0),
    priceOptions: parsePriceOptions(row.price_options),
    isPromotion: Number(row.is_promotion || 0) === 1,
    status: Number(row.status || 0),
    remark: row.remark || "",
    createdAt: row.created_at || null,
    updatedAt: row.updated_at || null,
  };
}

function formatCustomerCard(row) {
  if (!row) return null;

  const remainingTimes =
    row.remaining_times == null
      ? Number(row.total_times || 0) - Number(row.used_times || 0)
      : Number(row.remaining_times || 0);

  return {
    id: Number(row.id || 0),
    customerId: Number(row.customer_id || 0),
    cardTemplateId:
      row.card_template_id == null ? null : Number(row.card_template_id),
    cardName: row.card_name_snapshot || row.card_name || "",
    trainingProject: row.training_project || "",
    salePrice:
      row.sale_price == null || row.sale_price === ""
        ? null
        : Number(row.sale_price),
    isPromotion: Number(row.is_promotion || 0) === 1,
    totalTimes: Number(row.total_times || 0),
    usedTimes: Number(row.used_times || 0),
    remainingTimes,
    openCardDate: formatDateValue(row.open_card_date),
    expireDate: formatDateValue(row.expire_date),
    status: Number(row.status || 0),
    remark: row.remark || "",
    createdAt: row.created_at || null,
    updatedAt: row.updated_at || null,
  };
}

async function getCustomerCardsMap(connection, customerIds, options = {}) {
  const normalizedIds = [...new Set((customerIds || []).map((item) => toInt(item, 0)).filter(Boolean))];
  if (!normalizedIds.length) {
    return new Map();
  }

  const where = [`cc.customer_id IN (${normalizedIds.map(() => "?").join(",")})`];
  const params = [...normalizedIds];

  if (options.activeOnly) {
    where.push("cc.status = 1");
  }

  const [rows] = await connection.query(
    `
      SELECT
        cc.id,
        cc.customer_id,
        cc.card_template_id,
        cc.card_name_snapshot,
        cc.training_project,
        cc.sale_price,
        COALESCE(cc.is_promotion, ct.is_promotion, 0) AS is_promotion,
        cc.total_times,
        cc.used_times,
        cc.remaining_times,
        cc.open_card_date,
        cc.expire_date,
        cc.status,
        cc.remark,
        cc.created_at,
        cc.updated_at
      FROM customer_cards cc
      LEFT JOIN card_templates ct ON ct.id = cc.card_template_id
      WHERE ${where.join(" AND ")}
      ORDER BY
        cc.customer_id ASC,
        CASE
          WHEN cc.status = 1 AND cc.remaining_times > 0 AND cc.expire_date >= CURDATE() THEN 0
          WHEN cc.status = 1 THEN 1
          ELSE 2
        END ASC,
        cc.open_card_date DESC,
        cc.id DESC
    `,
    params,
  );

  const map = new Map();
  for (const row of rows) {
    const customerId = Number(row.customer_id || 0);
    if (!map.has(customerId)) {
      map.set(customerId, []);
    }
    map.get(customerId).push(formatCustomerCard(row));
  }
  return map;
}

async function getActiveCustomerCards(connection, customerId) {
  const map = await getCustomerCardsMap(connection, [customerId], {
    activeOnly: true,
  });

  const cards = (map.get(Number(customerId)) || []).filter(
    (item) =>
      !item.isPromotion &&
      item.status === 1 &&
      item.remainingTimes > 0 &&
      (!item.expireDate || item.expireDate >= new Date().toISOString().slice(0, 10)),
  );

  return cards;
}

async function createCustomerCardRecord(connection, payload) {
  const totalTimes = toInt(payload.totalTimes, 0);
  const salePrice = toMoney(payload.salePrice);
  const status = toInt(payload.status, 1) === 0 ? 0 : 1;

  const [result] = await connection.execute(
    `
      INSERT INTO customer_cards
      (
        customer_id,
        card_template_id,
        card_name_snapshot,
        training_project,
        sale_price,
        is_promotion,
        total_times,
        used_times,
        open_card_date,
        expire_date,
        status,
        remark,
        created_by,
        updated_by
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?)
    `,
    [
      payload.customerId,
      payload.cardTemplateId == null ? null : Number(payload.cardTemplateId),
      String(payload.cardName || "").trim(),
      String(payload.trainingProject || "").trim(),
      salePrice,
      Number(payload.isPromotion || 0) === 1 ? 1 : 0,
      totalTimes,
      payload.openCardDate,
      payload.expireDate,
      status,
      String(payload.remark || "").trim() || null,
      payload.userId == null ? null : Number(payload.userId),
      payload.userId == null ? null : Number(payload.userId),
    ],
  );

  return Number(result.insertId || 0);
}

async function syncCustomerCardSnapshot(connection, customerId, updatedBy = null) {
  const cardMap = await getCustomerCardsMap(connection, [customerId], {
    activeOnly: true,
  });
  const cards = (cardMap.get(Number(customerId)) || []).filter(
    (item) =>
      !item.isPromotion &&
      item.status === 1 &&
      item.remainingTimes > 0 &&
      (!item.expireDate || item.expireDate >= new Date().toISOString().slice(0, 10)),
  );

  if (!cards.length) {
    await connection.execute(
      `
        UPDATE customers
        SET
          has_card = 0,
          training_project = NULL,
          total_times = 0,
          used_times = 0,
          open_card_date = NULL,
          expire_date = NULL,
          updated_by = COALESCE(?, updated_by)
        WHERE id = ?
      `,
      [updatedBy == null ? null : Number(updatedBy), Number(customerId)],
    );

    return {
      hasCards: false,
      currentCard: null,
      cards: [],
    };
  }

  const currentCard = cards[0];

  await connection.execute(
    `
      UPDATE customers
      SET
        has_card = 1,
        training_project = ?,
        total_times = ?,
        used_times = ?,
        open_card_date = ?,
        expire_date = ?,
        updated_by = COALESCE(?, updated_by)
      WHERE id = ?
    `,
    [
      currentCard.trainingProject || null,
      currentCard.totalTimes,
      currentCard.usedTimes,
      currentCard.openCardDate,
      currentCard.expireDate,
      updatedBy == null ? null : Number(updatedBy),
      Number(customerId),
    ],
  );

  return {
    hasCards: true,
    currentCard,
    cards,
  };
}

module.exports = {
  formatCardTemplate,
  formatCustomerCard,
  parsePriceOptions,
  priceOptionsToDbString,
  getCustomerCardsMap,
  getActiveCustomerCards,
  createCustomerCardRecord,
  syncCustomerCardSnapshot,
};
