function formatDateYmd(input) {
  if (!input) return "";

  if (typeof input === "string") {
    const match = input.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (match) {
      return `${match[1]}-${match[2]}-${match[3]}`;
    }
    const parsed = new Date(input);
    if (!Number.isNaN(parsed.getTime())) {
      return formatDateYmd(parsed);
    }
    return "";
  }

  if (input instanceof Date) {
    const year = input.getFullYear();
    const month = `${input.getMonth() + 1}`.padStart(2, "0");
    const day = `${input.getDate()}`.padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  return "";
}

function parseDateYmd(input) {
  if (!input || typeof input !== "string") return "";
  const match = input.trim().match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return "";
  return `${match[1]}-${match[2]}-${match[3]}`;
}

function isValidDateYmd(input) {
  return Boolean(parseDateYmd(input));
}

function compareDateYmd(a, b) {
  const dateA = parseDateYmd(String(a || ""));
  const dateB = parseDateYmd(String(b || ""));
  if (!dateA || !dateB) return null;
  if (dateA === dateB) return 0;
  return dateA < dateB ? -1 : 1;
}

module.exports = {
  formatDateYmd,
  parseDateYmd,
  isValidDateYmd,
  compareDateYmd
};
