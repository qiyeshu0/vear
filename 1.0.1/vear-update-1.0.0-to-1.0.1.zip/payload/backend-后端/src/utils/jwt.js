const jwt = require("jsonwebtoken");

const DEFAULT_SECRET = "verify-system-secret";
const DEFAULT_EXPIRES_IN = "7d";

function getJwtSecret() {
  return process.env.JWT_SECRET || DEFAULT_SECRET;
}

function getJwtExpiresIn() {
  return process.env.JWT_EXPIRES_IN || DEFAULT_EXPIRES_IN;
}

function buildTokenPayload(user = {}) {
  return {
    userId: Number(user.id || user.userId || 0),
    username: user.username || "",
    realName: user.real_name || user.realName || "",
    role: Number(user.role || 0),
    storeId: Number(user.store_id || user.storeId || 0),
    status: Number(user.status ?? 1)
  };
}

function signAccessToken(user = {}, options = {}) {
  const payload = buildTokenPayload(user);
  const secret = options.secret || getJwtSecret();
  const expiresIn = options.expiresIn || getJwtExpiresIn();

  return jwt.sign(payload, secret, { expiresIn });
}

function signRefreshToken(user = {}, options = {}) {
  const payload = {
    userId: Number(user.id || user.userId || 0),
    tokenType: "refresh"
  };

  const secret = options.secret || getJwtSecret();
  const expiresIn = options.expiresIn || options.refreshExpiresIn || "30d";

  return jwt.sign(payload, secret, { expiresIn });
}

function verifyToken(token, options = {}) {
  const secret = options.secret || getJwtSecret();
  return jwt.verify(token, secret);
}

function decodeToken(token) {
  return jwt.decode(token);
}

function parseBearerToken(authorization = "") {
  if (!authorization || typeof authorization !== "string") {
    return null;
  }

  if (!authorization.startsWith("Bearer ")) {
    return null;
  }

  const token = authorization.slice(7).trim();
  return token || null;
}

module.exports = {
  getJwtSecret,
  getJwtExpiresIn,
  buildTokenPayload,
  signAccessToken,
  signRefreshToken,
  verifyToken,
  decodeToken,
  parseBearerToken
};
