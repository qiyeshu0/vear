const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { pool } = require("../config/db");
const { createTables } = require("../install/schema");

const PROJECT_ROOT = path.resolve(__dirname, "..", "..");
const ENV_FILE = path.join(PROJECT_ROOT, ".env");

const CONFIG_DEFINITIONS = [
  {
    key: "site.public_base_url",
    label: "后台正式域名",
    group: "site",
    type: "text",
    hotReload: true,
    envKey: "PUBLIC_BASE_URL",
    defaultValue: "",
    example: "https://admin.example.com",
    helpText: "客户访问后台的网址，必须带 http:// 或 https://。正式上线建议填写已备案并配置 SSL 的 HTTPS 域名；本地测试可留空或填 http://127.0.0.1:3000。",
    acquireText: "获取方式：使用你已经解析到服务器的正式域名；如果没有域名，需要先到域名服务商购买域名、完成备案，并在服务器/Nginx 中配置 HTTPS 证书。"
  },
  {
    key: "site.cors_origins",
    label: "CORS允许域名",
    group: "site",
    type: "textarea",
    hotReload: true,
    envKey: "CORS_ORIGIN",
    defaultValue: "",
    example: "https://admin.example.com,https://www.example.com",
    helpText: "允许访问后端接口的前端域名白名单，多个用英文逗号分隔。正式上线至少填写后台正式域名；不要随便填 *，否则有安全风险。",
    acquireText: "获取方式：填写所有会访问后端接口的网页域名，例如后台域名、官网域名。域名必须和浏览器地址栏中的协议+域名一致，例如 https://admin.example.com。"
  },
  {
    key: "site.miniprogram_api_base",
    label: "小程序接口地址",
    group: "site",
    type: "text",
    hotReload: true,
    envKey: "MINIPROGRAM_API_BASE",
    defaultValue: "",
    example: "https://api.example.com/api/wx",
    helpText: "小程序调用后端微信接口的地址，通常是 后端HTTPS域名 + /api/wx。微信正式版必须使用 HTTPS，不能使用 127.0.0.1、localhost 或普通 http。",
    acquireText: "获取方式：用你的后端正式 HTTPS 域名拼接 /api/wx，例如 https://your-domain.com/api/wx；同时要在微信公众平台配置 request 合法域名。",
    docUrl: "https://mp.weixin.qq.com/",
    docLabel: "微信公众平台"
  },

  {
    key: "weather.enabled",
    label: "启用首页天气",
    group: "weather",
    type: "boolean",
    hotReload: true,
    envKey: "WEATHER_ENABLED",
    defaultValue: "1",
    example: "1",
    helpText: "是否在后台首页显示高德天气预报。关闭后首页只显示节假日/周末日历。",
    acquireText: "填写方式：默认开启。如果暂时没有可用天气接口，或者不想展示天气，可以关闭。"
  },
  {
    key: "weather.provider",
    hidden: true,
    label: "天气接口类型",
    group: "weather",
    type: "text",
    hotReload: true,
    envKey: "WEATHER_PROVIDER",
    defaultValue: "amap",
    example: "open_meteo / qweather / amap / custom",
    helpText: "天气接口解析方式。open_meteo=默认免Key接口；qweather=和风天气；amap=高德天气；custom=自定义JSON字段映射。",
    acquireText: "填写方式：如果不确定用什么 API，先保持 open_meteo。后续换服务商时，按服务商返回结构改成 qweather、amap 或 custom。"
  },
  {
    key: "weather.api_url",
    hidden: true,
    label: "天气API地址",
    group: "weather",
    type: "textarea",
    hotReload: true,
    envKey: "WEATHER_API_URL",
    defaultValue: "https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max&timezone=auto&forecast_days=7",
    example: "https://api.example.com/weather?city={city}&key={key}",
    helpText: "天气接口完整地址。支持占位符：{lat}、{lon}、{city}、{adcode}、{key}。如果服务商要求 Key 放在 URL 参数里，可以用 {key}。",
    acquireText: "获取方式：从你选择的天气服务商接口文档复制请求地址，然后把城市、经纬度、Key 改成占位符。例如 key=xxx 改成 key={key}。"
  },
  {
    key: "weather.api_key",
    label: "高德 Web服务 Key",
    group: "weather",
    type: "secret",
    hotReload: true,
    envKey: "WEATHER_API_KEY",
    defaultValue: "",
    example: "高德开放平台中服务平台为“Web服务”的 Key",
    helpText: "系统固定使用高德逆地理编码和天气查询，只需填写 Web服务 Key。注意不能填写“Web端 JS API”、Android 或 iOS 类型的 Key。已配置时会脱敏显示，不修改请留空。",
    acquireText: "获取方式：登录高德开放平台 → 控制台 → 应用管理 → 我的应用 → 创建应用 → 添加 Key → 服务平台选择“Web服务”，复制生成的 Key。",
    docUrl: "https://console.amap.com/dev/key/app",
    docLabel: "高德应用管理"
  },
  {
    key: "weather.api_key_header",
    hidden: true,
    label: "天气Key请求头",
    group: "weather",
    type: "text",
    hotReload: true,
    envKey: "WEATHER_API_KEY_HEADER",
    defaultValue: "",
    example: "Authorization 或 X-API-Key",
    helpText: "如果天气服务商要求把 Key 放到请求头里，就填写请求头名称；如果 Key 已经放在 URL 里，此项留空。",
    acquireText: "填写方式：查看服务商文档。例如要求 Header Authorization: Bearer xxx，可填 Authorization，并在 API Key 中填 Bearer xxx。"
  },
  {
    key: "weather.location_name",
    hidden: true,
    label: "天气显示位置",
    group: "weather",
    type: "text",
    hotReload: true,
    envKey: "WEATHER_LOCATION_NAME",
    defaultValue: "默认城市",
    example: "北京 / 上海 / 门店所在城市",
    helpText: "后台首页展示的天气位置名称，只影响显示文字，不参与接口请求，除非你的 API URL 使用了 {city}。",
    acquireText: "填写方式：建议填写门店或用户常用城市，例如 北京、上海、广州。"
  },
  {
    key: "weather.reverse_geocode_enabled",
    hidden: true,
    label: "自动识别定位城市",
    group: "weather",
    type: "boolean",
    hotReload: true,
    envKey: "WEATHER_REVERSE_GEOCODE_ENABLED",
    defaultValue: "1",
    example: "1",
    helpText: "浏览器获得经纬度后，自动反查城市名称并显示在首页。关闭后仍按坐标查天气，但位置名称只显示“当前位置”。",
    acquireText: "填写方式：建议保持开启。城市反查失败不会影响天气数据，会自动显示当前位置。"
  },
  {
    key: "weather.reverse_geocode_url",
    hidden: true,
    label: "城市反查API地址",
    group: "weather",
    type: "textarea",
    hotReload: true,
    envKey: "WEATHER_REVERSE_GEOCODE_URL",
    defaultValue: "https://api-bdc.io/data/reverse-geocode-client?latitude={lat}&longitude={lon}&localityLanguage=zh",
    example: "https://api.example.com/reverse?lat={lat}&lng={lon}&key={key}",
    helpText: "把浏览器经纬度转换为城市名称。支持 {lat}、{lon}、{lng}、{key} 占位符，兼容 BigDataCloud、OpenStreetMap Nominatim、高德等常见返回字段。",
    acquireText: "填写方式：默认接口免 Key，可直接使用。更换服务商时复制逆地理编码接口地址，并将实际经纬度和 Key 替换为占位符。"
  },
  {
    key: "weather.city",
    hidden: true,
    label: "天气城市参数",
    group: "weather",
    type: "text",
    hotReload: true,
    envKey: "WEATHER_CITY",
    defaultValue: "上海",
    example: "上海 / Beijing / 101020100",
    helpText: "用于替换 API 地址中的 {city}。不同服务商可能要求中文城市名、城市ID或 location ID。",
    acquireText: "填写方式：按天气服务商文档要求填写。如果 API URL 不使用 {city}，可保持默认。"
  },
  {
    key: "weather.adcode",
    hidden: true,
    label: "天气城市adcode",
    group: "weather",
    type: "text",
    hotReload: true,
    envKey: "WEATHER_ADCODE",
    defaultValue: "310000",
    example: "310000",
    helpText: "用于替换 API 地址中的 {adcode}，常见于高德天气接口。上海=310000，北京=110000。",
    acquireText: "填写方式：如果使用高德天气，填写城市 adcode；如果不用高德或 URL 不使用 {adcode}，可保持默认。"
  },
  {
    key: "weather.latitude",
    hidden: true,
    label: "天气纬度",
    group: "weather",
    type: "text",
    hotReload: true,
    envKey: "WEATHER_LATITUDE",
    defaultValue: "31.2304",
    example: "31.2304",
    helpText: "用于替换 API 地址中的 {lat}。适合 open-meteo 或按经纬度查询的天气接口。",
    acquireText: "填写方式：填写城市或门店纬度；如果 API 不使用 {lat}，可保持默认。"
  },
  {
    key: "weather.longitude",
    hidden: true,
    label: "天气经度",
    group: "weather",
    type: "text",
    hotReload: true,
    envKey: "WEATHER_LONGITUDE",
    defaultValue: "121.4737",
    example: "121.4737",
    helpText: "用于替换 API 地址中的 {lon}。适合 open-meteo 或按经纬度查询的天气接口。",
    acquireText: "填写方式：填写城市或门店经度；如果 API 不使用 {lon}，可保持默认。"
  },
  {
    key: "weather.custom_mapping",
    hidden: true,
    label: "自定义天气字段映射",
    group: "weather",
    type: "textarea",
    hotReload: true,
    envKey: "WEATHER_CUSTOM_MAPPING",
    defaultValue: "",
    example: "{\"list\":\"data.daily\",\"date\":\"date\",\"weather\":\"text\",\"tempMax\":\"max\",\"tempMin\":\"min\",\"precipitation\":\"rain\"}",
    helpText: "当接口类型为 custom 时使用。填写 JSON，指定返回数据字段路径：list、date、weather、tempMax、tempMin、precipitation、wind。",
    acquireText: "填写方式：根据天气 API 返回 JSON 配置字段路径。list 是数组路径，其它字段是数组元素里的字段路径。不会写时可先把接口返回样例给开发人员配置。"
  },

  {
    key: "wechat.login_mock",
    label: "微信模拟登录",
    group: "wechat",
    type: "boolean",
    hotReload: true,
    envKey: "WX_LOGIN_MOCK",
    defaultValue: "0",
    example: "正式环境关闭，测试环境可开启",
    helpText: "仅供本地调试使用。开启后不会真实请求微信 code2session，会使用下面的模拟 OpenID；正式上线必须关闭。",
    acquireText: "填写方式：本地联调可开启；准备上线、提交审核、正式给客户使用时必须关闭。"
  },
  {
    key: "wechat.appid",
    label: "微信小程序AppID",
    group: "wechat",
    type: "text",
    hotReload: true,
    envKey: "WX_APPID",
    defaultValue: "",
    example: "wx1234567890abcdef",
    helpText: "微信公众平台小程序的 AppID。用于小程序登录、openid、订阅消息等能力。",
    acquireText: "获取方式：登录微信公众平台 → 选择小程序 → 开发管理/开发与服务 → 开发设置 → AppID（小程序ID）。复制以 wx 开头的一串字符。",
    docUrl: "https://mp.weixin.qq.com/",
    docLabel: "微信公众平台"
  },
  {
    key: "wechat.appsecret",
    label: "微信小程序Secret",
    group: "wechat",
    type: "secret",
    hotReload: true,
    envKey: "WX_APPSECRET",
    defaultValue: "",
    example: "从微信公众平台复制 AppSecret",
    helpText: "微信小程序 AppSecret，属于敏感密钥。已配置时会脱敏显示；不修改请留空。",
    acquireText: "获取方式：登录微信公众平台 → 选择小程序 → 开发管理/开发与服务 → 开发设置 → AppSecret（小程序密钥）。如果忘记只能重置，重置后这里也要同步更新。",
    docUrl: "https://mp.weixin.qq.com/",
    docLabel: "微信公众平台"
  },
  {
    key: "wechat.mock_openid",
    label: "本地模拟OpenID",
    group: "wechat",
    type: "text",
    hotReload: true,
    envKey: "WX_MOCK_OPENID",
    defaultValue: "dev-openid-local",
    example: "dev-openid-local",
    helpText: "微信模拟登录开启时使用的测试 OpenID。正式环境无效；一般保持默认即可。",
    acquireText: "填写方式：本地测试随便填一个稳定字符串即可，例如 dev-openid-local；正式环境关闭模拟登录后不会使用它。"
  },
  {
    key: "wechat.subscribe_template_id",
    label: "微信订阅消息模板ID",
    group: "wechat",
    type: "text",
    hotReload: true,
    envKey: "WX_SUBSCRIBE_TEMPLATE_ID",
    defaultValue: "",
    example: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    helpText: "用于【核销成功通知】。推荐模板名：核销成功通知/服务完成通知/训练记录通知。字段需匹配：thing2=客户姓名，character_string1=核销单号，time3=核销时间，thing4=剩余次数，thing5=训练项目。不用订阅消息可留空。",
    acquireText: "获取方式：微信公众平台 → 功能 → 订阅消息 → 公共模板库/我的模板 → 选择或申请模板 → 复制模板 ID。",
    docUrl: "https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/subscribe-message.html",
    docLabel: "微信订阅消息文档"
  },
  {
    key: "wechat.glasses_template_id",
    label: "微信配镜进度模板ID",
    group: "wechat",
    type: "text",
    hotReload: true,
    envKey: "WX_GLASSES_TEMPLATE_ID",
    defaultValue: "",
    example: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    helpText: "用于【配镜进度通知】。推荐模板名：订单进度通知/服务进度通知/取镜通知。字段需匹配：thing2=客户姓名，character_string1=订单编号，time3=更新时间，thing4=当前状态，thing5=镜片信息。不填时会临时复用上面的微信订阅消息模板ID。",
    acquireText: "获取方式：微信公众平台 → 功能 → 订阅消息 → 选择订单进度/服务进度/取镜相关模板 → 复制模板 ID。",
    docUrl: "https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/subscribe-message.html",
    docLabel: "微信订阅消息文档"
  },

  {
    key: "wechat.low_times_template_id",
    label: "微信剩余次数提醒模板ID",
    group: "wechat",
    type: "text",
    hotReload: true,
    envKey: "WX_LOW_TIMES_TEMPLATE_ID",
    defaultValue: "",
    example: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    helpText: "用于【训练记录剩余次数提醒】。推荐模板名：次数不足提醒/服务余量提醒。建议字段按 12345 顺序配置：thing1=用户姓名，thing2=记录项目，number3=剩余次数，time4=提醒时间，thing5=备注说明。当前为预留配置，不填则不推送该场景。",
    acquireText: "获取方式：微信公众平台 → 功能 → 订阅消息 → 选择次数不足/服务余量相关模板 → 复制模板 ID。",
    docUrl: "https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/subscribe-message.html",
    docLabel: "微信订阅消息文档"
  },
  {
    key: "wechat.expire_soon_template_id",
    label: "微信记录周期提醒模板ID",
    group: "wechat",
    type: "text",
    hotReload: true,
    envKey: "WX_EXPIRE_SOON_TEMPLATE_ID",
    defaultValue: "",
    example: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    helpText: "用于【训练记录周期提醒】。推荐模板名：到期提醒/服务到期提醒。建议字段按 12345 顺序配置：thing1=用户姓名，thing2=记录项目，date3=到期日期，number4=剩余次数，thing5=备注说明。需要配合定时任务；不填则不推送该场景。",
    acquireText: "获取方式：微信公众平台 → 功能 → 订阅消息 → 选择服务到期/到期提醒相关模板 → 复制模板 ID。",
    docUrl: "https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/subscribe-message.html",
    docLabel: "微信订阅消息文档"
  },
  {
    key: "wechat.followup_template_id",
    label: "微信回访/关怀模板ID",
    group: "wechat",
    type: "text",
    hotReload: true,
    envKey: "WX_FOLLOWUP_TEMPLATE_ID",
    defaultValue: "",
    example: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    helpText: "用于【回访/复查/交付后关怀】。推荐模板名：回访提醒/复查提醒/售后关怀提醒。建议字段按 12345 顺序配置：thing1=用户姓名，thing2=提醒事项，time3=建议时间，thing4=记录来源，thing5=备注说明；不填则不推送该场景。",
    acquireText: "获取方式：微信公众平台 → 功能 → 订阅消息 → 选择回访/复查/售后关怀相关模板 → 复制模板 ID。",
    docUrl: "https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/subscribe-message.html",
    docLabel: "微信订阅消息文档"
  },

  {
    key: "miniprogram.title",
    label: "小程序首页标题",
    group: "miniprogram",
    type: "text",
    hotReload: true,
    envKey: "MINIPROGRAM_TITLE",
    defaultValue: "训练助手",
    example: "训练助手",
    helpText: "小程序首页顶部显示的标题。客户修改后，小程序下次打开自动生效。",
    acquireText: "填写方式：这是展示名称，不需要去第三方平台获取。建议填写门店业务名称或客户容易理解的名称，例如 训练助手、视力训练助手。"
  },
  {
    key: "miniprogram.subtitle",
    label: "小程序首页副标题",
    group: "miniprogram",
    type: "text",
    hotReload: true,
    envKey: "MINIPROGRAM_SUBTITLE",
    defaultValue: "视界记录本",
    example: "视界记录本",
    helpText: "小程序首页顶部显示的副标题。",
    acquireText: "填写方式：这是展示文案，不需要去第三方平台获取。建议填写品牌名、门店名或一句简短说明，例如 视界记录本、XX视光服务。"
  },
  {
    key: "miniprogram.enable_staff_hidden_entry",
    label: "小程序隐藏员工入口",
    group: "miniprogram",
    type: "boolean",
    hotReload: true,
    envKey: "MINIPROGRAM_ENABLE_STAFF_HIDDEN_ENTRY",
    defaultValue: "1",
    example: "1",
    helpText: "是否启用小程序隐藏员工入口。开启后仍需连续点击指定区域才显示员工登录。",
    acquireText: "填写方式：建议保持开启。开启后普通客户看不到员工入口，员工需要连续点击隐藏区域 6 次才会出现管理端登录。"
  },
  {
    key: "miniprogram.show_glasses_progress",
    label: "首页显示配镜进度",
    group: "miniprogram",
    type: "boolean",
    hotReload: true,
    envKey: "MINIPROGRAM_SHOW_GLASSES_PROGRESS",
    defaultValue: "1",
    example: "1",
    helpText: "是否在客户小程序首页显示短期配镜进度卡片。",
    acquireText: "填写方式：门店有配镜交付业务建议开启；如果客户只做训练核销、不展示配镜进度，可以关闭。"
  },
  {
    key: "miniprogram.show_training_card",
    label: "首页显示训练次数信息",
    group: "miniprogram",
    type: "boolean",
    hotReload: true,
    envKey: "MINIPROGRAM_SHOW_TRAINING_CARD",
    defaultValue: "1",
    example: "1",
    helpText: "是否在用户小程序首页显示训练次数、到期日期等信息。没有训练记录的用户仍会自动隐藏。",
    acquireText: "填写方式：需要展示训练次数或记录周期时建议开启。即使开启，没有训练记录的用户也会自动隐藏，不会显示空卡片。"
  },
  {
    key: "miniprogram.home_glasses_keep_days",
    label: "已交付配镜首页保留天数",
    group: "miniprogram",
    type: "number",
    hotReload: true,
    envKey: "MINIPROGRAM_HOME_GLASSES_KEEP_DAYS",
    defaultValue: "15",
    example: "15",
    helpText: "配镜状态为已交付后，继续在小程序首页展示多少天；超过后只在记录页保留。",
    acquireText: "填写方式：填写数字即可。建议 7-15 天，既能让客户看到交付结果，又不会让首页长期堆旧订单。"
  },
  {
    key: "miniprogram.home_recent_verify_limit",
    label: "首页最近核销条数",
    group: "miniprogram",
    type: "number",
    hotReload: true,
    envKey: "MINIPROGRAM_HOME_RECENT_VERIFY_LIMIT",
    defaultValue: "5",
    example: "5",
    helpText: "小程序首页最近核销最多显示多少条。",
    acquireText: "填写方式：填写数字即可。建议 3-5 条，太多会让首页显得拥挤。"
  },
  {
    key: "miniprogram.home_glasses_limit",
    label: "首页配镜进度条数",
    group: "miniprogram",
    type: "number",
    hotReload: true,
    envKey: "MINIPROGRAM_HOME_GLASSES_LIMIT",
    defaultValue: "2",
    example: "2",
    helpText: "小程序首页配镜进度最多显示多少条。",
    acquireText: "填写方式：填写数字即可。建议 1-2 条，更多历史配镜记录让客户到记录页查看。"
  },

  {
    key: "security.jwt_expires_in",
    label: "JWT有效期",
    group: "security",
    type: "text",
    hotReload: false,
    envKey: "JWT_EXPIRES_IN",
    defaultValue: "7d",
    example: "7d / 30d / 12h",
    helpText: "后台登录令牌有效期。7d 表示 7 天，12h 表示 12 小时。改短更安全但用户更容易重新登录；保存后需要重启服务。",
    acquireText: "填写方式：不需要第三方获取。建议正式环境使用 7d；如果是多人共用电脑或安全要求高，可以改成 12h/1d。"
  },
  {
    key: "upload.max_size",
    label: "上传大小限制",
    group: "upload",
    type: "number",
    hotReload: false,
    envKey: "UPLOAD_MAX_SIZE",
    defaultValue: "10485760",
    example: "10485760 表示 10MB",
    helpText: "单个上传文件大小限制，单位是字节。常用：5242880=5MB，10485760=10MB，20971520=20MB；保存后需要重启服务。",
    acquireText: "填写方式：不需要第三方获取。根据服务器硬盘和客户上传图片大小设置；常规门店建议 10485760，也就是 10MB。"
  },
  {
    key: "upload.dir",
    label: "上传目录",
    group: "upload",
    type: "text",
    hotReload: false,
    envKey: "UPLOAD_DIR",
    defaultValue: "src/uploads",
    example: "src/uploads",
    helpText: "客户附件、图片等文件保存目录。一般保持默认；如果改到服务器绝对路径，请确保 Node 服务有读写权限；保存后需要重启服务。",
    acquireText: "填写方式：一般保持默认 src/uploads。如果服务器有专门数据盘，可以填绝对路径，例如 /data/vear/uploads，并确保服务账号有读写权限。"
  },
];

const DEFINITION_MAP = new Map(CONFIG_DEFINITIONS.map(item => [item.key, item]));
const SECRET_KEYS = new Set(CONFIG_DEFINITIONS.filter(item => item.type === "secret").map(item => item.key));
let schemaReady = false;
let schemaPromise = null;
let cache = null;
let cacheExpireAt = 0;

function envValue(def) {
  if (!def.envKey) return def.defaultValue || "";
  if (def.envKey === "WX_APPSECRET") return process.env.WX_APPSECRET || process.env.WX_APP_SECRET || def.defaultValue || "";
  return process.env[def.envKey] ?? def.defaultValue ?? "";
}

function isEncrypted(text) {
  return String(text || "").startsWith("enc:v1:");
}

function getEncryptionKey() {
  const raw = process.env.CONFIG_ENCRYPTION_KEY || process.env.JWT_SECRET || "";
  return crypto.createHash("sha256").update(String(raw || "vear-runtime-config")).digest();
}

function encryptValue(value) {
  const text = String(value || "");
  if (!text) return "";
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", getEncryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `enc:v1:${iv.toString("base64")}:${tag.toString("base64")}:${encrypted.toString("base64")}`;
}

function decryptValue(value) {
  const text = String(value || "");
  if (!isEncrypted(text)) return text;
  try {
    const [, , ivB64, tagB64, dataB64] = text.split(":");
    const decipher = crypto.createDecipheriv("aes-256-gcm", getEncryptionKey(), Buffer.from(ivB64, "base64"));
    decipher.setAuthTag(Buffer.from(tagB64, "base64"));
    return Buffer.concat([decipher.update(Buffer.from(dataB64, "base64")), decipher.final()]).toString("utf8");
  } catch (error) {
    console.warn("[运行配置] 敏感配置解密失败：", error?.message || error);
    return "";
  }
}

function maskSecret(value) {
  const text = String(value || "");
  if (!text) return "";
  if (text.length <= 8) return "********";
  return `${text.slice(0, 4)}******${text.slice(-4)}`;
}

function normalizeValue(def, value) {
  if (def.type === "boolean") return value === true || value === 1 || String(value) === "1" || String(value).toLowerCase() === "true" ? "1" : "0";
  if (def.type === "number") {
    const n = Number(value);
    return Number.isFinite(n) ? String(Math.max(0, Math.floor(n))) : String(def.defaultValue || "0");
  }
  return String(value ?? "").trim();
}

function isHttpUrl(value) {
  try {
    const url = new URL(String(value || ""));
    return url.protocol === "http:" || url.protocol === "https:";
  } catch (error) {
    return false;
  }
}

function throwConfigError(message) {
  const error = new Error(message);
  error.statusCode = 400;
  throw error;
}

function validateRuntimeValue(def, value) {
  const text = String(value ?? "").trim();
  if (!text) return;

  if (["site.public_base_url", "site.miniprogram_api_base"].includes(def.key) && !isHttpUrl(text)) {
    throwConfigError(`${def.label}格式不正确，请填写以 http:// 或 https:// 开头的完整地址`);
  }

  if (["weather.api_url", "weather.reverse_geocode_url"].includes(def.key) && !isHttpUrl(text)) {
    throwConfigError(`${def.label}格式不正确，请填写以 http:// 或 https:// 开头的完整地址`);
  }

  if (def.key === "weather.provider") {
    const allow = new Set(["open_meteo", "qweather", "hefeng", "amap", "gaode", "custom"]);
    if (!allow.has(text.toLowerCase())) {
      throwConfigError("天气接口类型仅支持 open_meteo / qweather / hefeng / amap / gaode / custom");
    }
  }

  if (def.key === "weather.custom_mapping") {
    try {
      JSON.parse(text);
    } catch (error) {
      throwConfigError("自定义天气字段映射必须是合法 JSON");
    }
  }

  if (def.key === "site.miniprogram_api_base" && !text.endsWith("/api/wx")) {
    throwConfigError("小程序接口地址通常必须以 /api/wx 结尾，例如：https://api.example.com/api/wx");
  }

  if (def.key === "site.cors_origins") {
    const origins = text.split(",").map(item => item.trim()).filter(Boolean);
    for (const origin of origins) {
      if (origin === "*") {
        throwConfigError("CORS允许域名不建议填写 *，请填写具体域名，多个用英文逗号分隔");
      }
      if (!isHttpUrl(origin)) {
        throwConfigError(`CORS允许域名格式不正确：${origin}`);
      }
    }
  }
}


async function ensureRuntimeConfigSchema() {
  if (schemaReady) return;
  if (schemaPromise) return schemaPromise;
  schemaPromise = (async () => {
    await createTables(pool);
    const rows = [];
    for (const def of CONFIG_DEFINITIONS) {
      const initialValue = normalizeValue(def, envValue(def));
      const storedValue = SECRET_KEYS.has(def.key) ? encryptValue(initialValue) : initialValue;
      rows.push([`runtime.${def.key}`, storedValue, def.label]);
    }
    if (rows.length) {
      await pool.query(
        `INSERT INTO system_settings (setting_key, setting_value, remark)
         VALUES ?
         ON DUPLICATE KEY UPDATE remark = VALUES(remark)`,
        [rows]
      );
    }
    schemaReady = true;
  })().finally(() => { schemaPromise = null; });
  return schemaPromise;
}

async function readStoredMap() {
  await ensureRuntimeConfigSchema();
  const [rows] = await pool.query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key LIKE 'runtime.%'");
  const map = {};
  for (const row of rows) {
    const key = String(row.setting_key || "").replace(/^runtime\./, "");
    const def = DEFINITION_MAP.get(key);
    if (!def) continue;
    let value = row.setting_value ?? "";
    if (SECRET_KEYS.has(key)) value = decryptValue(value);
    map[key] = value;
  }
  for (const def of CONFIG_DEFINITIONS) {
    if (map[def.key] == null || map[def.key] === "") {
      map[def.key] = normalizeValue(def, envValue(def));
    }
  }
  return map;
}

function formatForClient(map) {
  return CONFIG_DEFINITIONS.filter(def => !def.hidden).map(def => {
    const value = normalizeValue(def, map[def.key]);
    const isSecret = SECRET_KEYS.has(def.key);
    return {
      key: def.key,
      label: def.label,
      group: def.group,
      type: def.type,
      hotReload: def.hotReload,
      envKey: def.envKey,
      helpText: def.helpText || "",
      acquireText: def.acquireText || "",
      docUrl: def.docUrl || "",
      docLabel: def.docLabel || "",
      example: def.example || "",
      value: isSecret ? "" : value,
      maskedValue: isSecret ? maskSecret(value) : "",
      configured: isSecret ? Boolean(value) : value !== "",
      requireRestart: !def.hotReload,
    };
  });
}

function clearRuntimeConfigCache() {
  cache = null;
  cacheExpireAt = 0;
}

async function getRuntimeConfig(options = {}) {
  if (!options.force && cache && Date.now() < cacheExpireAt) return cache;
  try {
    const map = await readStoredMap();
    cache = map;
    cacheExpireAt = Date.now() + Number(process.env.RUNTIME_CONFIG_CACHE_MS || 30000);
    return map;
  } catch (error) {
    const fallback = {};
    for (const def of CONFIG_DEFINITIONS) fallback[def.key] = normalizeValue(def, envValue(def));
    return fallback;
  }
}

async function getRuntimeConfigForClient() {
  const map = await getRuntimeConfig({ force: true });
  return {
    groups: [
      { key: "site", label: "站点与域名" },
      { key: "weather", label: "天气配置" },
      { key: "wechat", label: "微信小程序" },
      { key: "miniprogram", label: "小程序展示" },
      { key: "security", label: "安全配置" },
      { key: "upload", label: "上传配置" },
    ],
    items: formatForClient(map),
    restartRequiredKeys: CONFIG_DEFINITIONS.filter(item => !item.hotReload).map(item => item.key),
  };
}

async function saveRuntimeConfig(input = {}, operator = {}) {
  await ensureRuntimeConfigSchema();
  const values = input.values || input || {};
  const currentMap = await readStoredMap();
  const changed = [];
  const rows = [];
  for (const def of CONFIG_DEFINITIONS) {
    if (!Object.prototype.hasOwnProperty.call(values, def.key)) continue;
    let value = values[def.key];
    if (SECRET_KEYS.has(def.key) && (value == null || value === "")) continue;
    value = normalizeValue(def, value);
    validateRuntimeValue(def, value);
    if (normalizeValue(def, currentMap[def.key]) === value) {
      process.env[def.envKey] = value;
      continue;
    }
    const storedValue = SECRET_KEYS.has(def.key) ? encryptValue(value) : value;
    rows.push([
      `runtime.${def.key}`,
      storedValue,
      `${def.label}${operator.username ? `，最后修改：${operator.username}` : ""}`
    ]);
    process.env[def.envKey] = value;
    changed.push({ key: def.key, label: def.label, hotReload: def.hotReload, requireRestart: !def.hotReload });
  }
  if (rows.length) {
    await pool.query(
      `INSERT INTO system_settings (setting_key, setting_value, remark)
       VALUES ?
       ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), remark = VALUES(remark)`,
      [rows]
    );
  }
  if (changed.length) clearRuntimeConfigCache();
  return { changed, restartRequired: changed.some(item => item.requireRestart), config: await getRuntimeConfigForClient() };
}

async function getWechatRuntimeConfig() {
  const cfg = await getRuntimeConfig();
  return {
    appId: cfg["wechat.appid"] || "",
    appSecret: cfg["wechat.appsecret"] || "",
    mockLogin: String(cfg["wechat.login_mock"] || "0") === "1",
    mockOpenid: cfg["wechat.mock_openid"] || "dev-openid-local",
    subscribeTemplateId: cfg["wechat.subscribe_template_id"] || "",
    glassesTemplateId: cfg["wechat.glasses_template_id"] || "",
    lowTimesTemplateId: cfg["wechat.low_times_template_id"] || "",
    expireSoonTemplateId: cfg["wechat.expire_soon_template_id"] || "",
    followupTemplateId: cfg["wechat.followup_template_id"] || "",
  };
}

async function getMiniprogramRuntimeConfig() {
  const cfg = await getRuntimeConfig();
  return {
    title: cfg["miniprogram.title"] || "训练助手",
    subtitle: cfg["miniprogram.subtitle"] || "视界记录本",
    enableStaffHiddenEntry: String(cfg["miniprogram.enable_staff_hidden_entry"] || "1") === "1",
    showGlassesProgress: String(cfg["miniprogram.show_glasses_progress"] || "1") === "1",
    showTrainingCard: String(cfg["miniprogram.show_training_card"] || "1") === "1",
    homeGlassesKeepDays: Number(cfg["miniprogram.home_glasses_keep_days"] || 15),
    homeRecentVerifyLimit: Number(cfg["miniprogram.home_recent_verify_limit"] || 5),
    homeGlassesLimit: Number(cfg["miniprogram.home_glasses_limit"] || 2),
  };
}

async function getCorsOrigins() {
  const cfg = await getRuntimeConfig();
  const text = cfg["site.cors_origins"] || process.env.CORS_ORIGIN || "";
  return String(text).split(",").map(item => item.trim()).filter(Boolean);
}

function writeEnvPatch(values = {}) {
  if (!fs.existsSync(ENV_FILE)) return false;
  let content = fs.readFileSync(ENV_FILE, "utf8");
  for (const [key, value] of Object.entries(values)) {
    const line = `${key}=${String(value ?? "")}`;
    const re = new RegExp(`^${key}=.*$`, "m");
    if (re.test(content)) content = content.replace(re, line);
    else content += `\n${line}`;
  }
  fs.writeFileSync(ENV_FILE, content.replace(/\n{3,}/g, "\n\n"));
  return true;
}

module.exports = {
  CONFIG_DEFINITIONS,
  ensureRuntimeConfigSchema,
  getRuntimeConfig,
  getRuntimeConfigForClient,
  saveRuntimeConfig,
  getWechatRuntimeConfig,
  getMiniprogramRuntimeConfig,
  getCorsOrigins,
  clearRuntimeConfigCache,
  writeEnvPatch,
  maskSecret,
};
