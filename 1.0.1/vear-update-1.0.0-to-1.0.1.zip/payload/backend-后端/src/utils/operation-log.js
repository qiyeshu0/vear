const { pool } = require("../config/db");

async function writeOperationLog(target, payload = {}, maybeConnection = null) {
  let req = null;
  let connection = pool;

  if (target && typeof target === "object" && "headers" in target) {
    req = target;
    if (maybeConnection) {
      connection = maybeConnection;
    }
  } else if (target) {
    connection = target;
  }

  const user = req?.user || {};
  const {
    operatorId = user.userId || null,
    operatorName = user.realName || "",
    operatorRole = user.role || null,
    storeId = user.storeId || null,
    module = "system",
    action = "query",
    bizType = "system",
    bizId = null,
    bizNo = null,
    content = "",
    ip = req?.ip || "",
    userAgent = String(req?.headers?.["user-agent"] || "").slice(0, 500),
  } = payload;

  const normalizedBizNo =
    bizNo == null ? null : String(bizNo).slice(0, 100);

  await connection.execute(
    `
      INSERT INTO operation_logs
      (
        operator_id,
        operator_name,
        operator_role,
        store_id,
        module,
        action,
        biz_type,
        biz_id,
        biz_no,
        content,
        ip,
        user_agent
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
    [
      operatorId,
      operatorName,
      operatorRole,
      storeId,
      module,
      action,
      bizType,
      bizId,
      normalizedBizNo,
      content,
      ip,
      userAgent,
    ],
  );
}

module.exports = {
  writeOperationLog,
};
