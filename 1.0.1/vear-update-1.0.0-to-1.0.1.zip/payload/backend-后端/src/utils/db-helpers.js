const { pool } = require("../config/db");

/**
 * 在事务中执行回调函数。
 * - 自动获取连接
 * - 自动 BEGIN TRANSACTION
 * - 回调成功 → COMMIT
 * - 回调失败 → ROLLBACK
 * - 无论如何 → RELEASE
 *
 * @param {Function} callback  async (connection) => { ... return result; }
 * @returns {Promise<any>} callback 的返回值
 *
 * 用法：
 *   const result = await withTransaction(async (conn) => {
 *     await conn.execute('UPDATE ...', [...]);
 *     await conn.execute('INSERT ...', [...]);
 *     return { success: true };
 *   });
 */
async function withTransaction(callback) {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();
    const result = await callback(connection);
    await connection.commit();
    return result;
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      // ignore rollback errors
    }
    throw error;
  } finally {
    connection.release();
  }
}

/**
 * 获取一个连接执行回调（不开启事务）。
 * - 自动获取连接
 * - 回调失败也会自动释放连接
 *
 * @param {Function} callback  async (connection) => { ... return result; }
 * @returns {Promise<any>} callback 的返回值
 */
async function withConnection(callback) {
  const connection = await pool.getConnection();

  try {
    return await callback(connection);
  } finally {
    connection.release();
  }
}

module.exports = {
  withTransaction,
  withConnection,
};
