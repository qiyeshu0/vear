import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, "..");
const frontendRoot = path.join(projectRoot, "frontend-pure-前端");
const backendRoot = path.join(projectRoot, "backend-后端");
const frontendDistRoot = path.join(frontendRoot, "dist");
const npmCommand = process.platform === "win32" ? "npm.cmd" : "npm";
const npmCacheRoot = path.join(projectRoot, ".npm-cache");
const ensureDistOnly = process.argv.includes("--if-needed");
const buildOnly = process.argv.includes("--build-only");

function run(command, args, cwd) {
  const result = spawnSync(command, args, {
    cwd,
    stdio: "inherit",
    env: process.env
  });

  if (result.status !== 0) {
    process.exit(result.status || 1);
  }
}

function runInstall(args, cwd, extraEnv = {}) {
  return spawnSync(npmCommand, args, {
    cwd,
    stdio: "inherit",
    env: {
      ...process.env,
      NODE_ENV: "production",
      NPM_CONFIG_CACHE: npmCacheRoot,
      npm_config_cache: npmCacheRoot,
      ...extraEnv,
    },
  });
}

function missingDependencies(projectPath) {
  const pkg = JSON.parse(fs.readFileSync(path.join(projectPath, "package.json"), "utf8"));
  return Object.keys(pkg.dependencies || {}).filter(
    (name) => !fs.existsSync(path.join(projectPath, "node_modules", name)),
  );
}

function ensureDependencies(projectPath, name) {
  const nodeModulesPath = path.join(projectPath, "node_modules");
  const missing = missingDependencies(projectPath);

  if (fs.existsSync(nodeModulesPath) && missing.length === 0) {
    console.log(`[bootstrap] ${name} 依赖已存在，跳过安装`);
    return;
  }

  fs.mkdirSync(npmCacheRoot, { recursive: true });
  console.log(`[bootstrap] ${missing.length ? `缺少 ${missing.length} 个依赖` : "依赖目录不存在"}，自动安装 ${name} 生产依赖`);
  const hasLock = fs.existsSync(path.join(projectPath, "package-lock.json"));
  const args = [hasLock ? "ci" : "install", "--omit=dev", "--no-audit", "--no-fund"];
  let result = runInstall(args, projectPath);

  if (result.status !== 0 && !process.env.NPM_CONFIG_REGISTRY && !process.env.npm_config_registry) {
    console.warn("[bootstrap] 默认 npm 源安装失败，切换到 npmmirror 国内镜像重试");
    result = runInstall([...args, "--registry", "https://registry.npmmirror.com"], projectPath, {
      NPM_CONFIG_REGISTRY: "https://registry.npmmirror.com",
    });
  }

  if (result.status !== 0) {
    console.error("[bootstrap] 依赖安装失败，请检查服务器网络、npm 源和项目目录写入权限");
    process.exit(result.status || 1);
  }

  const stillMissing = missingDependencies(projectPath);
  if (stillMissing.length) {
    console.error(`[bootstrap] 安装后仍缺少依赖：${stillMissing.join(", ")}`);
    process.exit(1);
  }
  console.log(`[bootstrap] ${name} 生产依赖安装完成`);
}

if (
  ensureDistOnly &&
  fs.existsSync(frontendDistRoot) &&
  fs.existsSync(path.join(frontendDistRoot, "index.html"))
) {
  ensureDependencies(backendRoot, "backend-后端");
  console.log("[bootstrap] frontend-pure-前端/dist 已存在，跳过构建");
  process.exit(0);
}

if (ensureDistOnly) {
  console.error("[bootstrap] 未找到 frontend-pure-前端/dist。请重新解压完整的发布版部署包。");
  process.exit(1);
}

if (buildOnly) {
  ensureDependencies(frontendRoot, "frontend-pure-前端");
  ensureDependencies(backendRoot, "backend-后端");
}

console.log("[bootstrap] 构建 frontend-pure-前端");
run(npmCommand, ["run", "build"], frontendRoot);

if (!fs.existsSync(frontendDistRoot)) {
  console.error("[bootstrap] 未找到 frontend-pure-前端/dist，构建结果异常");
  process.exit(1);
}

console.log("[bootstrap] 完成");
console.log("[bootstrap] 启动方式: npm start");
